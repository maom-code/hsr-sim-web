from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(125, 4)
class ScholarLostInErudition4:

    def on_equip(self, wearer, battle, params) -> None:
        spd_up, team_cd, turns = (params[0], params[1], int(params[2]))
        key = f'set.125.4.{wearer.id}'
        state = {'used': False}

        def on_heal(healer=None, target=None, **kw):
            memo = battle.memosprite_of(wearer)
            if healer is not wearer and healer is not memo:
                return
            if target is wearer or target is memo:
                return
            if state['used']:
                return
            state['used'] = True
            battle.apply_effect(wearer, Effect(key=key, label='慈雨', stats=StatSheet.of(spd_pct=spd_up), duration=Duration(turns=turns, tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{key}.cd', label='慈雨・会心ダメージ', stats=StatSheet.of(crit_dmg=team_cd), duration=Duration(turns=turns, tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)

        def reset(**kw):
            state['used'] = False
        battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_START, reset, owner_id=wearer.id)

@register_set(320, 2)
class SprightlyVonwacq2:

    def on_equip(self, wearer, battle, params) -> None:
        spd_up, low, high, heal_low, heal_high = params[:5]
        battle.apply_effect(wearer, Effect(key=f'set.320.2.spd.{wearer.id}', label='巨樹2pc・速度', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))
        spd = wearer.stats[StatKey.SPD]
        heal = heal_high if spd >= high else heal_low if spd >= low else 0.0
        if not heal:
            return
        battle.apply_effect(wearer, Effect(key=f'set.320.2.heal.{wearer.id}', label='巨樹2pc・治癒量', stats=StatSheet.of(heal_boost=heal), source_id=wearer.id))
