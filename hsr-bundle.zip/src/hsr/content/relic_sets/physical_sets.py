from __future__ import annotations
from ...engine.effects import Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(105, 4)
class ChampionOfStreetwiseBoxing4:

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, max_stacks = (params[0], int(params[1]))

        def stack(source_id=None, rider=False, **kw):
            if source_id != wearer.id or rider:
                return
            battle.apply_effect(wearer, Effect(key=f'set.105.4.{wearer.id}', label='チャンピオン4pc', stats=StatSheet.of(atk_pct=atk_up), stacking=Stacking.STACK, max_stacks=max_stacks, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, stack, owner_id=wearer.id)
