from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, reward_total
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(133, 4)
class DreamPlayhouseMinstrel4:

    def on_equip(self, wearer, battle, params) -> None:
        rate, turns, need, team_cd, cd_turns = params[:5]
        key = f'set.133.4.{wearer.id}'

        def on_single_target(target=None, actor=None, **kw):
            if actor is not wearer or target is None or target is wearer:
                return
            battle.apply_effect(target, Effect(key=key, label='伶人4pc・愉悦度', stats=StatSheet.of(elation_rate=rate), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            if reward_total(wearer) < need:
                return
            battle.apply_to_team(lambda who: Effect(key=f'{key}.cd', label='伶人4pc・会心ダメージ', stats=StatSheet.of(crit_dmg=team_cd), duration=Duration(turns=int(cd_turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_single_target, owner_id=wearer.id)

@register_set(130, 4)
class DiviningTraveler4:

    def on_equip(self, wearer, battle, params) -> None:
        spd_low, spd_high, cr_low, cr_high, team_rate = params[:5]
        spd = wearer.built.stats[StatKey.SPD]
        cr = cr_high if spd >= spd_high else cr_low if spd >= spd_low else 0.0
        if cr:
            battle.apply_effect(wearer, Effect(key=f'set.130.4.{wearer.id}', label='卜者4pc・会心率', stats=StatSheet.of(crit_rate=cr), source_id=wearer.id))
        state = {'used': False}

        def on_elation_skill(source=None, **kw):
            if source is not wearer or state['used']:
                return
            state['used'] = True
            battle.apply_to_team(lambda who: Effect(key=f'set.130.4.{wearer.id}.rate', label='卜者4pc・愉悦度', stats=StatSheet.of(elation_rate=team_rate), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ELATION_SKILL, on_elation_skill, owner_id=wearer.id)

@register_set(129, 4)
class MagicalGirl4:

    def on_equip(self, wearer, battle, params) -> None:
        base, per, step, max_stacks = params[:4]
        key = f'set.129.4.{wearer.id}'
        state = {'progress': 0.0, 'stacks': 0}

        def refresh() -> None:
            value = base + step * state['stacks']
            for who in (wearer, battle.memosprite_of(wearer)):
                if who is None:
                    continue
                battle.apply_effect(who, Effect(key=key, label='魔法少女4pc・防御無視', stats=StatSheet.of(def_ignore_elation=value), stacking=Stacking.REFRESH, source_id=wearer.id))

        def on_notes(name=None, amount: float=0.0, **kw):
            if name != NOTES or amount <= 0:
                return
            state['progress'] += amount
            gained = int(state['progress'] // per)
            if not gained:
                return
            state['progress'] -= gained * per
            state['stacks'] = min(int(max_stacks), state['stacks'] + gained)
            refresh()
        refresh()
        battle.bus.subscribe(Event.ON_SHARED_GAIN, on_notes, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, lambda **kw: refresh(), owner_id=wearer.id)

@register_set(325, 2)
class StageZeroPunkRoad2:

    def on_equip(self, wearer, battle, params) -> None:
        rate, low, high, cd_low, cd_high = params[:5]
        battle.apply_effect(wearer, Effect(key=f'set.325.2.{wearer.id}', label='パンクロード2pc・愉悦度', stats=StatSheet.of(elation_rate=rate), source_id=wearer.id))
        key = f'set.325.2.{wearer.id}.cd'
        state = {'tier': 0}

        def check(**kw):
            value = wearer.stats[StatKey.ELATION_RATE]
            tier = 2 if value >= high else 1 if value >= low else 0
            if tier <= state['tier']:
                return
            state['tier'] = tier
            battle.apply_effect(wearer, Effect(key=key, label='パンクロード2pc・会心ダメージ', stats=StatSheet.of(crit_dmg=cd_high if tier == 2 else cd_low), stacking=Stacking.REFRESH, source_id=wearer.id))
        check()
        battle.bus.subscribe(Event.TURN_START, check, owner_id=wearer.id)
        battle.bus.subscribe(Event.BATTLE_START, check, owner_id=wearer.id)

@register_set(324, 2)
class HeavenStreamingRoom2:

    def on_equip(self, wearer, battle, params) -> None:
        cd, need, extra, turns = params[:4]
        battle.apply_effect(wearer, Effect(key=f'set.324.2.{wearer.id}', label='配信ルーム2pc・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), source_id=wearer.id))
        state = {'spent': 0.0}

        def on_sp(spent: float=0.0, **kw):
            state['spent'] += spent
            if state['spent'] < need:
                return
            battle.apply_effect(wearer, Effect(key=f'set.324.2.{wearer.id}.extra', label='配信ルーム2pc・会心ダメージ+', stats=StatSheet.of(crit_dmg=extra), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))

        def reset(**kw):
            state['spent'] = 0.0
        battle.bus.subscribe(Event.ON_SP_CHANGE, on_sp, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_START, reset, owner_id=wearer.id)

@register_set(310, 2)
class BrokenKeel2:

    def on_equip(self, wearer, battle, params) -> None:
        res, need, team_cd = params[:3]
        battle.apply_effect(wearer, Effect(key=f'set.310.2.{wearer.id}', label='折れた竜骨2pc・効果抵抗', stats=StatSheet.of(effect_res=res), source_id=wearer.id))
        if wearer.stats[StatKey.EFFECT_RES] < need:
            return
        battle.apply_aura(wearer, lambda who: Effect(key=f'set.310.2.{wearer.id}.cd', label='折れた竜骨2pc・会心ダメージ', stats=StatSheet.of(crit_dmg=team_cd), source_id=wearer.id))

@register_set(308, 2)
class LifeWenwark2:

    def on_equip(self, wearer, battle, params) -> None:
        regen, need, advance = params[:3]
        battle.apply_effect(wearer, Effect(key=f'set.308.2.{wearer.id}', label='ウェンワーク2pc', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))
        if wearer.built.stats[StatKey.SPD] >= need:
            battle.advance_forward(wearer, advance)
