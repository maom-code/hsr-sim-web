from __future__ import annotations
from ...engine.effects import Effect
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(309, 2)
class TheXianzhouLuofu2:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_up, threshold, dmg_up = (params[0], params[1], params[2])
        battle.apply_effect(wearer, Effect(key=f'set.309.2.crit.{wearer.id}', label='競技場2pc・会心率', stats=StatSheet.of(crit_rate=crit_up), source_id=wearer.id))
        if wearer.stats[StatKey.CRIT_RATE] < threshold:
            return
        battle.apply_effect(wearer, Effect(key=f'set.309.2.dmg.{wearer.id}', label='競技場2pc・与ダメ', stats=StatSheet.of(dmg_pct_basic=dmg_up, dmg_pct_skill=dmg_up), source_id=wearer.id))

@register_set(317, 2)
class SunkenRusakaSea2:

    def on_equip(self, wearer, battle, params) -> None:
        regen, atk = params[:2]
        battle.apply_effect(wearer, Effect(key=f'set.317.2.{wearer.id}', label='ルサカ2pc・EP回復効率', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))
        first = battle.team[0]
        if first is wearer:
            return
        battle.apply_effect(first, Effect(key=f'set.317.2.{wearer.id}.atk', label='ルサカ2pc・攻撃力', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))
