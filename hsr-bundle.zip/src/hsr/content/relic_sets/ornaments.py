from __future__ import annotations
from ...engine.effects import Effect
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(309, 2)
class TheXianzhouLuofu2:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_up, threshold, dmg_up = (params[0], params[1], params[2])
        battle.apply_effect(wearer, Effect(key=f'set.309.2.crit.{wearer.id}', label='競技場2pc・会心率', stats=StatSheet.of(crit_rate=crit_up), source_id=wearer.id))
        if wearer.stats[StatKey.CRIT_RATE] < threshold:
            return
        battle.apply_effect(wearer, Effect(key=f'set.309.2.dmg.{wearer.id}', label='競技場2pc・与ダメ', stats=StatSheet.of(dmg_pct_basic=dmg_up, dmg_pct_skill=dmg_up), source_id=wearer.id))

@register_set(317, 2)
class SunkenRusakaSea2:

    def on_equip(self, wearer, battle, params) -> None:
        regen, atk = params[:2]
        battle.apply_effect(wearer, Effect(key=f'set.317.2.{wearer.id}', label='ルサカ2pc・EP回復効率', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))
        first = battle.team[0]
        if first is wearer:
            return
        battle.apply_effect(first, Effect(key=f'set.317.2.{wearer.id}.atk', label='ルサカ2pc・攻撃力', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

@register_set(327, 2)
class PortOfFallenStars2:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ..characters.himeko_voyage import TRAILBLAZE_COMPANIONS
        crit_rate, crit_dmg = params[:2]
        stats = StatSheet.of(crit_rate=crit_rate)
        others = [c for c in battle.team if c is not wearer and c.id in TRAILBLAZE_COMPANIONS]
        if wearer.id in TRAILBLAZE_COMPANIONS and others:
            stats.add(StatKey.CRIT_DMG, crit_dmg)
        battle.apply_effect(wearer, Effect(key=f'set.327.2.{wearer.id}', label='墜星の出航地 2pc', stats=stats, source_id=wearer.id))

@register_set(306, 2)
class SigoniaTheUnclaimedDesolation_Salsotto2:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, need, up = params[:3]
        battle.apply_effect(wearer, Effect(key=f'set.306.2.{wearer.id}', label='サルソット 2pc', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def on_start(**kw):
            if wearer.stats[StatKey.CRIT_RATE] >= need:
                battle.apply_effect(wearer, Effect(key=f'set.306.2.{wearer.id}.dmg', label='サルソット 2pc・与ダメージ', stats=StatSheet.of(dmg_pct_followup=up, dmg_pct_ultimate=up), source_id=wearer.id))
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=wearer.id)

@register_set(316, 2)
class ForgeOfTheKalpagniLantern2:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.effects import Duration, Stacking
        from ...model.enums import Element
        spd, be, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'set.316.2.{wearer.id}', label='鋳煉宮 2pc', stats=StatSheet.of(spd_pct=spd), source_id=wearer.id))

        def on_attack_start(source=None, **kw):
            if source is not wearer:
                return
            if any((Element.FIRE in e.weaknesses for e in battle.alive_enemies)):
                battle.apply_effect(wearer, Effect(key=f'set.316.2.{wearer.id}.be', label='鋳煉宮 2pc・撃破特効', stats=StatSheet.of(break_effect=be), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK_START, on_attack_start, owner_id=wearer.id)

@register_set(321, 2)
class ArcadiaOfWovenDreams2:

    def on_equip(self, wearer, battle, params) -> None:
        over, under, max_over, max_under = params[:4]
        key = f'set.321.2.{wearer.id}'

        def refresh(**kw):
            n = sum((1 for c in battle.team if c.id not in battle.suspended)) + sum((1 for m in battle.memosprites if m.alive))
            if n > 4:
                value = over * min(n - 4, max_over)
            elif n < 4:
                value = under * min(4 - n, max_under)
            else:
                value = 0.0
            for who in (wearer, *battle.memosprites_of(wearer)):
                held = who.effects.get(key)
                if held is not None and held.stats[StatKey.DMG_PCT] == value:
                    continue
                battle.remove_effect(who, key)
                if value:
                    battle.apply_effect(who, Effect(key=key, label='妖精の楽園 2pc', stats=StatSheet.of(dmg_pct=value), source_id=wearer.id))
        battle.bus.subscribe(Event.BATTLE_START, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ACTION_START, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_START, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, refresh, owner_id=wearer.id)
