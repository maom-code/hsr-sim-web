from __future__ import annotations
from ...engine.effects import Effect
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(127, 4)
class SaviorOfRecreation4:

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, dmg_up = (params[0], params[1])
        key_hp = f'set.127.4.hp.{wearer.id}'
        key_dmg = f'set.127.4.dmg.{wearer.id}'

        def refresh(actor=None, source_id=None, **kw):
            if source_id != wearer.id:
                return
            memo = battle.memosprite_of(wearer)
            if memo is None:
                return
            for who in (wearer, memo):
                battle.apply_effect(who, Effect(key=key_hp, label='救世主4pc・HP', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
            battle.apply_to_team(lambda who: Effect(key=key_dmg, label='救世主4pc・与ダメ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))

        def follow(memo=None, **kw):
            if memo is None:
                return
            if wearer.effects.has(key_dmg):
                battle.apply_effect(memo, Effect(key=key_dmg, label='救世主4pc・与ダメ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))
            if memo.summoner is wearer and wearer.effects.has(key_hp):
                battle.apply_effect(memo, Effect(key=key_hp, label='救世主4pc・HP', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_BASIC_USED, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_SKILL_USED, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, follow, owner_id=wearer.id)

@register_set(319, 2)
class QuietOssuary2:

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, threshold, cd_up = (params[0], params[1], params[2])
        battle.apply_effect(wearer, Effect(key=f'set.319.2.hp.{wearer.id}', label='拾骨地2pc・HP', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        if wearer.stats[StatKey.HP] < threshold:
            return
        battle.apply_effect(wearer, Effect(key=f'set.319.2.cd.{wearer.id}', label='拾骨地2pc・会心ダメ', stats=StatSheet.of(crit_dmg=cd_up), source_id=wearer.id))

@register_set(124, 4)
class PoetOfMourningCollapse4:

    def on_equip(self, wearer, battle, params) -> None:
        spd_down = params[5]
        hi, lo, crit_hi, crit_lo = (params[1], params[2], params[3], params[4])
        battle.apply_effect(wearer, Effect(key=f'set.124.4.spd.{wearer.id}', label='詩人4pc・速度低下', stats=StatSheet.of(spd_pct=-abs(spd_down)), source_id=wearer.id))
        spd = wearer.stats[StatKey.SPD]
        crit = crit_lo if spd < lo else crit_hi if spd < hi else 0.0
        if not crit:
            return
        battle.apply_effect(wearer, Effect(key=f'set.124.4.crit.{wearer.id}', label='詩人4pc・会心率', stats=StatSheet.of(crit_rate=crit), source_id=wearer.id))

@register_set(323, 2)
class FlameReforgedOnpharos2:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_up, spd_up = (params[0], params[1])
        key_crit = f'set.323.2.crit.{wearer.id}'
        key_spd = 'set.323.2.spd'
        battle.apply_effect(wearer, Effect(key=key_crit, label='オンパロス2pc・会心率', stats=StatSheet.of(crit_rate=crit_up), source_id=wearer.id))

        def present_anywhere() -> bool:
            for c in battle.team:
                if int(c.built.relic_sets.get('323', 0)) >= 2 and battle.memosprite_of(c) is not None:
                    return True
            return False

        def refresh(**kw):
            present = present_anywhere()
            if present:
                battle.apply_to_team(lambda who: Effect(key=key_spd, label='オンパロス2pc・速度', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))
            else:
                for who in (*battle.team, *battle.memosprites):
                    battle.remove_effect(who, key_spd)
        refresh()
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, refresh, owner_id=wearer.id)

@register_set(123, 4)
class TriumphantHero4:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.effects import Duration, Stacking
        spd_up, crit_dmg, turns = (params[0], params[1], int(params[2]))
        key_spd = f'set.123.4.spd.{wearer.id}'
        key_cd = f'set.123.4.cd.{wearer.id}'

        def refresh_speed(**kw):
            if battle.memosprite_of(wearer) is not None:
                battle.apply_effect(wearer, Effect(key=key_spd, label='凱歌4pc・速度', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))
            elif wearer.effects.has(key_spd):
                battle.remove_effect(wearer, key_spd)

        def on_memo_attack(source=None, **kw):
            memo = battle.memosprite_of(wearer)
            if memo is None or source is not memo:
                return
            for who in (wearer, memo):
                battle.apply_effect(who, Effect(key=key_cd, label='凱歌4pc・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=turns, tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        refresh_speed()
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, refresh_speed, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, refresh_speed, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_memo_attack, owner_id=wearer.id)
