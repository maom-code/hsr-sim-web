from __future__ import annotations
from ...engine.effects import Effect
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(101, 4)
class PasserbyOfWanderingCloud4:

    def on_equip(self, wearer, battle, params) -> None:
        battle.gain_sp(1)

@register_set(302, 2)
class BrokenKeel2:

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, threshold, atk_up = (params[0], params[1], params[2])
        battle.apply_effect(wearer, Effect(key=f'set.302.2.hp.{wearer.id}', label='仙舟2pc・HP', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        if wearer.stats[StatKey.SPD] < threshold:
            return
        battle.apply_to_team(lambda who: Effect(key=f'set.302.2.atk.{wearer.id}', label='仙舟2pc・攻撃力', stats=StatSheet.of(atk_pct=atk_up), source_id=wearer.id))
