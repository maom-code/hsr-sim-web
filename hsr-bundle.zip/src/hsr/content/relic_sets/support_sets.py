from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatSheet
from ..equipment import register_set

@register_set(121, 4)
class SacerdosRelivedOrdeal4:

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, turns, max_stacks = (params[0], int(params[1]), int(params[2]))
        key = f'set.121.4.{wearer.id}'

        def on_targeted(actor=None, target=None, single=False, **kw):
            if actor is not wearer or target is None or (not single):
                return
            battle.apply_effect(target, Effect(key=key, label='司祭・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=turns), stacking=Stacking.STACK, max_stacks=max_stacks, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_targeted, owner_id=wearer.id)

@register_set(102, 4)
class MusketeerOfWildWheat4:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        battle.apply_effect(wearer, Effect(key=f'set.102.4.{wearer.id}', label='草の穂ガンマン 4pc', stats=StatSheet.of(spd_pct=params[0], dmg_pct_basic=params[1]), source_id=wearer.id))

@register_set(118, 4)
class WatchmakerMasterOfDreamMachinations4:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        be, turns = (params[0], int(params[1]))
        state = {'in_ult': False}

        def on_action(actor=None, action=None, **kw):
            if actor is wearer:
                state['in_ult'] = action is Action.ULTIMATE

        def on_targeted(actor=None, **kw):
            if actor is not wearer or not state['in_ult']:
                return
            state['in_ult'] = False
            battle.apply_to_team(lambda who: Effect(key='set.118.4', label='時計屋・撃破特効', stats=StatSheet.of(break_effect=be), duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_targeted, owner_id=wearer.id)

@register_set(307, 2)
class TaliaKingdomOfBanditry2:

    def on_equip(self, wearer, battle, params) -> None:
        from ...model.stats import StatKey
        be, spd_need, extra = params[:3]
        total = be + (extra if wearer.stats[StatKey.SPD] >= spd_need else 0.0)
        battle.apply_effect(wearer, Effect(key=f'set.307.2.{wearer.id}', label='タリア2pc・撃破特効', stats=StatSheet.of(break_effect=total), source_id=wearer.id))

@register_set(312, 2)
class PenaconyLandOfTheDreams2:

    def on_equip(self, wearer, battle, params) -> None:
        regen, dmg_up = params[:2]
        battle.apply_effect(wearer, Effect(key=f'set.312.2.{wearer.id}', label='ピノコニー2pc・EP回復効率', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))
        for c in battle.team:
            if c is not wearer and c.built.element is wearer.built.element:
                battle.apply_effect(c, Effect(key=f'set.312.2.{wearer.id}.dmg', label='ピノコニー2pc・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))

@register_set(128, 2)
class SelfEnshroudedRecluse2:

    def on_equip(self, wearer, battle, params) -> None:
        return

@register_set(128, 4)
class SelfEnshroudedRecluse4:

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg = params[1]

        def on_shield(source=None, target=None, turns=0, **kw):
            if source is not wearer or target is None:
                return
            battle.apply_effect(target, Effect(key=f'set.128.4.{wearer.id}', label='隠者4pc・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_SHIELD, on_shield, owner_id=wearer.id)
