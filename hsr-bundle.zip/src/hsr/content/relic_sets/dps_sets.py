from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_set

@register_set(132, 4)
class ArtisanOfDivineCraft4:

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, turns, dmg_up = (params[0], params[1], params[2])

        def on_applied(target=None, effect=None, source_id=None, **kw):
            from ...engine.entity import Enemy
            if source_id != wearer.id or not isinstance(target, Enemy):
                return
            if effect is None or effect.contribution()[StatKey.DEF_DOWN] <= 0:
                return
            d = effect.duration
            battle.apply_effect(target, Effect(key=f'set.132.4.crit.{wearer.id}', label='名匠4pc・会心ダメージ', stats=StatSheet.of(crit_dmg_taken_from_source=crit_dmg), duration=None if d is None else Duration(turns=d.turns, tick_owner_id=d.tick_owner_id), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_to_team(lambda who: Effect(key=f'set.132.4.jozen.{wearer.id}', label='助燃', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_EFFECT_APPLIED, on_applied, owner_id=wearer.id)

@register_set(115, 4)
class TheAshblazingGrandDuke4:

    def on_equip(self, wearer, battle, params) -> None:
        atk_per_hit, max_stacks, turns = (params[0], params[1], params[2])

        def on_followup(source=None, dmg_type=None, hits: int=0, as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            if not hits:
                return
            stacks = min(int(hits), int(max_stacks))
            battle.remove_effect(wearer, f'set.115.4.{wearer.id}')
            battle.apply_effect(wearer, Effect(key=f'set.115.4.{wearer.id}', label=f'大公4pc・攻撃力×{stacks}', stats=StatSheet.of(atk_pct=atk_per_hit * stacks), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_set(326, 2)
class TownOfAThousandStars2:

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, turns, _crit_dmg_on_kill = (params[0], params[1], params[2])

        def on_followup(source=None, dmg_type=None, as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            battle.apply_effect(wearer, Effect(key=f'set.326.2.{wearer.id}', label='千の星2pc・攻撃力', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_set(122, 4)
class ScholarLostInErudition4:

    def on_equip(self, wearer, battle, params) -> None:
        base_up, extra_up = (params[0], params[1])
        primed = f'set.122.4.primed.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'set.122.4.{wearer.id}', label='学者4pc・スキル/必殺技', stats=StatSheet.of(dmg_pct_skill=base_up, dmg_pct_ultimate=base_up), source_id=wearer.id))

        def on_ult(actor=None, **kw):
            if actor is not wearer:
                return
            battle.apply_effect(wearer, Effect(key=primed, label='学者4pc・次の戦闘スキル', stats=StatSheet.of(dmg_pct_skill=extra_up), source_id=wearer.id))

        def on_skill(actor=None, **kw):
            if actor is wearer:
                battle.remove_effect(wearer, primed)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)

@register_set(328, 2)
class InstituteOfCosmicLifeSciences2:

    def on_equip(self, wearer, battle, params) -> None:
        threshold, per_point, cap = (params[0], params[1], params[2])
        max_energy = wearer.built.max_energy
        if max_energy is None or max_energy < threshold:
            return
        dmg_up = min((max_energy - threshold) * per_point, cap)
        battle.apply_effect(wearer, Effect(key=f'set.328.2.{wearer.id}', label='研究院2pc・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))

@register_set(108, 4)
class GeniusOfBrilliantStars4:

    def on_equip(self, wearer, battle, params) -> None:
        from ...model.enums import Element
        ignore, extra = params[:2]
        weak = bool(battle.enemies) and Element.QUANTUM in battle.enemies[0].weaknesses
        battle.apply_effect(wearer, Effect(key=f'set.108.4.{wearer.id}', label='天才4pc・防御無視', stats=StatSheet.of(def_ignore=ignore + (extra if weak else 0.0)), source_id=wearer.id))

@register_set(126, 4)
class WavestriderCaptain4:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        need, atk, turns = (int(params[0]), params[1], int(params[2]))
        state = {'help': 0}

        def on_targeted(actor=None, target=None, **kw):
            if target is wearer and actor is not None and (actor is not wearer):
                state['help'] = min(need, state['help'] + 1)

        def on_action(actor=None, action=None, **kw):
            if actor is not wearer or action is not Action.ULTIMATE or state['help'] < need:
                return
            state['help'] = 0
            battle.apply_effect(wearer, Effect(key=f'set.126.4.{wearer.id}', label='船長4pc・攻撃力', stats=StatSheet.of(atk_pct=atk), duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_targeted, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)

@register_set(131, 4)
class NavigatorSiken4:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        up, max_stacks, clear = (params[0], int(params[1]), int(params[2]))
        key = f'set.131.4.{wearer.id}'

        def add() -> None:
            battle.apply_effect(wearer, Effect(key=key, label='シケン4pc', stats=StatSheet.of(dmg_pct_skill=up, dmg_pct_ultimate=up), stacking=Stacking.STACK, max_stacks=max_stacks, source_id=wearer.id))

        def drop() -> None:
            eff = wearer.effects.get(key)
            if eff is None:
                return
            if eff.stacks > clear:
                eff.stacks -= clear
            else:
                battle.remove_effect(wearer, key)
        add()
        battle.bus.subscribe(Event.ON_ACTION_START, lambda actor=None, action=None, **kw: add() if actor is wearer and action is Action.SKILL else None, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_START, lambda actor=None, **kw: drop() if actor is wearer else None, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, lambda source_id=None, **kw: drop() if source_id == wearer.id else None, owner_id=wearer.id)

@register_set(119, 4)
class IronCavalryAgainstTheScourge4:

    def on_equip(self, wearer, battle, params) -> None:
        low, high, brk, sup = params[:4]

        def on_start(**kw):
            be = wearer.stats[StatKey.BREAK_EFFECT]
            stats = StatSheet()
            if be >= low:
                stats.add(StatKey.DEF_IGNORE_BREAK, brk)
            if be >= high:
                stats.add(StatKey.DEF_IGNORE_SUPER_BREAK, sup)
            if stats.values:
                battle.apply_effect(wearer, Effect(key=f'set.119.4.{wearer.id}', label='鉄騎4pc・防御無視', stats=stats, source_id=wearer.id))
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=wearer.id)

@register_set(110, 4)
class EagleOfTwilightLine4:

    def on_equip(self, wearer, battle, params) -> None:
        advance = params[0]

        def on_ult(source_id=None, **kw):
            if source_id == wearer.id:
                battle.advance_forward(wearer, advance)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
