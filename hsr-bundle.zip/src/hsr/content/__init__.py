from . import characters, light_cones, relic_sets
from .base import REGISTRY as _R
if '8009' in _R:
    _R['8009'].relic_sets = {'130': 4, '325': 2}
if '8010' in _R:
    _R['8010'].relic_sets = {'130': 4, '325': 2}
