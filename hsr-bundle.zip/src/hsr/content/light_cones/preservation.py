from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23051')
class ThoughWorldsApart:

    def on_equip(self, wearer, battle, params) -> None:
        atk, dmg_up, summon_up, turns, heal_all, heal_low = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23051.atk.{wearer.id}', label='万里の山河を越えて', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            base = wearer.stats[StatKey.ATK]
            for c in battle.team:
                battle.heal(wearer, c, base * heal_all, label='万里の山河を越えて')
            low = min(battle.team, key=lambda c: c.hp / c.max_hp if c.max_hp else 1.0)
            battle.heal(wearer, low, base * heal_low, label='万里の山河を越えて')

            def make(who) -> Effect:
                owner = getattr(who, 'attributed_to', who)
                extra = summon_up if battle.memosprites_of(owner) else 0.0
                return Effect(key='lc.23051.guard', label='守護', stats=StatSheet.of(dmg_pct=dmg_up + extra), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id)
            battle.apply_to_team(make)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('21053')
class ReturnToDarkness_JourneyForeverPeaceful:

    def on_equip(self, wearer, battle, params) -> None:
        dmg_up = params[1]

        def on_shield(target=None, turns=0, **kw):
            if target is None:
                return
            battle.apply_effect(target, Effect(key='lc.21053.dmg', label='旅が平穏であるように・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_SHIELD, on_shield, owner_id=wearer.id)

@register_lc('23023')
class InherentlyUnjustDestiny:

    def on_equip(self, wearer, battle, params) -> None:
        from ...model.enums import DamageType
        dfn, cd, cd_turns, _, vuln, vuln_turns = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23023.def.{wearer.id}', label='運命は常に不公平', stats=StatSheet.of(def_pct=dfn), source_id=wearer.id))

        def on_shield(source=None, **kw):
            if source is wearer:
                battle.apply_effect(wearer, Effect(key=f'lc.23023.cd.{wearer.id}', label='運命は常に不公平・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), duration=Duration(turns=int(cd_turns)), stacking=Stacking.REFRESH, source_id=wearer.id))

        def on_attack(source=None, dmg_type=None, targets=None, **kw):
            if source is not wearer or dmg_type is not DamageType.FOLLOWUP:
                return
            for e in targets or []:
                battle.apply_effect(e, Effect(key='lc.23023.vuln', label='運命は常に不公平・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(vuln_turns)), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_SHIELD, on_shield, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23005')
class MomentOfVictory:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.effects import TickTiming
        _, dfn, hit_def, hit = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23005.{wearer.id}', label='勝利の刹那', stats=StatSheet.of(def_pct=dfn, effect_hit=hit), source_id=wearer.id))

        def on_hit(target=None, **kw):
            if target is wearer:
                battle.apply_effect(wearer, Effect(key=f'lc.23005.hit.{wearer.id}', label='勝利の刹那・防御力', stats=StatSheet.of(def_pct=hit_def), duration=Duration(turns=1, tick_on=TickTiming.OWNER_TURN_END), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hit, owner_id=wearer.id)

@register_lc('23011')
class SheWhoWearsTheClosedEyes:

    def on_equip(self, wearer, battle, params) -> None:
        hp, dmg_up, _, regen, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23011.{wearer.id}', label='閉ざした瞳', stats=StatSheet.of(hp_pct=hp, energy_regen=regen), source_id=wearer.id))

        def on_loss(target=None, **kw):
            if target is wearer:
                battle.apply_to_team(lambda who: Effect(key='lc.23011.dmg', label='閉ざした瞳・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_HP_LOSS, on_loss, owner_id=wearer.id)

@register_lc('24002')
class TextureOfMemories:

    def on_equip(self, wearer, battle, params) -> None:
        res, ratio, turns, every = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.24002.{wearer.id}', label='記憶の素材', stats=StatSheet.of(effect_res=res), source_id=wearer.id))
        state = {'cooldown': 0}

        def on_turn(actor=None, **kw):
            if actor is wearer and state['cooldown'] > 0:
                state['cooldown'] -= 1

        def on_hit(target=None, **kw):
            if target is not wearer or battle.has_shield(wearer) or state['cooldown'] > 0:
                return
            state['cooldown'] = int(every)
            battle.apply_shield(wearer, wearer, wearer.max_hp * ratio, turns=int(turns))
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hit, owner_id=wearer.id)

@register_lc('21016')
class TrendOfTheUniversalMarket:

    def on_equip(self, wearer, battle, params) -> None:
        from ...model.enums import Element
        dfn, _, ratio, turns = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.21016.{wearer.id}', label='星間市場のトレンド', stats=StatSheet.of(def_pct=dfn), source_id=wearer.id))

        def on_hit(target=None, enemy=None, **kw):
            if target is not wearer or enemy is None:
                return
            battle.apply_effect(enemy, Effect(key=f'lc.21016.burn.{wearer.id}', label='燃焼（星間市場のトレンド）', dot_base=wearer.stats[StatKey.DEF] * ratio, dot_element=Element.FIRE, duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hit, owner_id=wearer.id)

@register_lc('21002')
class DayOneOfMyNewLife:

    def on_equip(self, wearer, battle, params) -> None:
        battle.apply_effect(wearer, Effect(key=f'lc.21002.{wearer.id}', label='余生の初日', stats=StatSheet.of(def_pct=params[0]), source_id=wearer.id))

@register_lc('21009')
class LandausChoice:

    def on_equip(self, wearer, battle, params) -> None:
        return

@register_lc('21023')
class WeAreWildfire:

    def on_equip(self, wearer, battle, params) -> None:
        return

@register_lc('21030')
class ThisIsMe:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        from ...model.enums import DamageType
        dfn, ratio = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21030.{wearer.id}', label='これがウチだよ！', stats=StatSheet.of(def_pct=dfn), source_id=wearer.id))
        hit: set[str] = set()

        def on_action(actor=None, action=None, **kw):
            if actor is wearer and action is Action.ULTIMATE:
                hit.clear()

        def bonus(source, target, dmg_type):
            if source is not wearer or dmg_type is not DamageType.ULTIMATE or target.id in hit:
                return None
            hit.add(target.id)
            return ((StatKey.DEF, ratio),)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.add_scaling_bonus(wearer, bonus)

@register_lc('21039')
class DestinysThreadsForewoven:

    def on_equip(self, wearer, battle, params) -> None:
        res, step, per, cap = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.21039.{wearer.id}', label='運命を紡ぐ糸', stats=StatSheet.of(effect_res=res), source_id=wearer.id))
        battle.add_target_bonus(wearer, lambda src, tgt: StatSheet.of(dmg_pct=min(cap, int(wearer.stats[StatKey.DEF] // step) * per)))

@register_lc('21043')
class ConcertForTwo:

    def on_equip(self, wearer, battle, params) -> None:
        dfn, per = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21043.{wearer.id}', label='二人だけのコンサート', stats=StatSheet.of(def_pct=dfn), source_id=wearer.id))
        battle.add_target_bonus(wearer, lambda src, tgt: StatSheet.of(dmg_pct=per * sum((1 for c in battle.team if battle.has_shield(c)))))
