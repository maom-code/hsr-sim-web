from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23051')
class ThoughWorldsApart:

    def on_equip(self, wearer, battle, params) -> None:
        atk, dmg_up, summon_up, turns, heal_all, heal_low = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23051.atk.{wearer.id}', label='万里の山河を越えて', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            base = wearer.stats[StatKey.ATK]
            for c in battle.team:
                battle.heal(wearer, c, base * heal_all, label='万里の山河を越えて')
            low = min(battle.team, key=lambda c: c.hp / c.max_hp if c.max_hp else 1.0)
            battle.heal(wearer, low, base * heal_low, label='万里の山河を越えて')

            def make(who) -> Effect:
                owner = getattr(who, 'attributed_to', who)
                extra = summon_up if battle.memosprites_of(owner) else 0.0
                return Effect(key='lc.23051.guard', label='守護', stats=StatSheet.of(dmg_pct=dmg_up + extra), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id)
            battle.apply_to_team(make)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('21053')
class ReturnToDarkness_JourneyForeverPeaceful:

    def on_equip(self, wearer, battle, params) -> None:
        dmg_up = params[1]

        def on_shield(target=None, turns=0, **kw):
            if target is None:
                return
            battle.apply_effect(target, Effect(key='lc.21053.dmg', label='旅が平穏であるように・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_SHIELD, on_shield, owner_id=wearer.id)
