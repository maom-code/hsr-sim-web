from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23049')
class LongNightStar:

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, def_ignore, dmg_up, energy = (params[0], params[1], params[2], params[3])
        battle.apply_effect(wearer, Effect(key=f'lc.23049.hp.{wearer.id}', label='長き夜に輝く星へ', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        key = f'lc.23049.yoiro.{wearer.id}'

        def grant_to(m) -> None:
            battle.apply_effect(m, Effect(key=key, label='夜色', stats=StatSheet.of(**{'dmg_pct': dmg_up} if m.summoner is wearer else {}, def_ignore=def_ignore), source_id=wearer.id))

        def on_memo_skill(memo=None, source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_effect(wearer, Effect(key=key, label='夜色', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))
            for m in battle.memosprites:
                grant_to(m)

        def on_memo_summon(memo=None, **kw):
            if memo is not None and wearer.effects.has(key):
                grant_to(memo)

        def on_memo_dismiss(memo=None, source_id=None, **kw):
            if source_id == wearer.id:
                battle.gain_energy(wearer, energy, apply_regen=False)
        battle.bus.subscribe(Event.ON_MEMO_SKILL_START, on_memo_skill, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, on_memo_summon, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, on_memo_dismiss, owner_id=wearer.id)

@register_lc('23038')
class IfTimeWereAFlower:

    def on_equip(self, wearer, battle, params) -> None:
        cd_self, energy_fua, turns, cd_team, energy_start, turns_start = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23038.cd.{wearer.id}', label='もしも時が花だったら', stats=StatSheet.of(crit_dmg=cd_self), source_id=wearer.id))
        key = f'lc.23038.revelation.{wearer.id}'

        def grant_revelation(turns_: float) -> None:
            battle.apply_effect(wearer, Effect(key=key, label='啓示', duration=Duration(turns=int(turns_), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{key}.team', label='啓示・会心ダメージ', stats=StatSheet.of(crit_dmg=cd_team), duration=Duration(turns=int(turns_), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        battle.gain_energy(wearer, energy_start, apply_regen=False)
        grant_revelation(turns_start)

        def on_followup(source_id=None, dmg_type=None, as_followup=False, **kw):
            if source_id != wearer.id or not as_followup:
                return
            battle.gain_energy(wearer, energy_fua, apply_regen=False)
            grant_revelation(turns)
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_lc('23042')
class SoTheRainbowNeverFades:

    def on_equip(self, wearer, battle, params) -> None:
        spd_up, hp_cost, _unused, vuln, vuln_turns, extra_ratio = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23042.spd.{wearer.id}', label='空の虹が消えぬように', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))

        def on_action(actor=None, source_id=None, **kw):
            if source_id != wearer.id:
                return
            pool = 0.0
            for c in battle.team:
                pool += battle.spend_hp(c, ratio=hp_cost)
            if pool:
                self._pending = getattr(self, '_pending', 0.0) + pool

        def on_memo_skill(memo=None, source_id=None, **kw):
            if source_id != wearer.id or memo is None:
                return
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=f'lc.23042.vuln.{wearer.id}', label='虹・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(vuln_turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
            pool = getattr(self, '_pending', 0.0)
            if pool > 0:
                battle.attack(memo, memo.element, DamageType.ADDITIONAL, flat_main=pool * extra_ratio, label='虹・付加ダメージ')
                self._pending = 0.0
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_SKILL, on_memo_skill, owner_id=wearer.id)

@register_lc('23040')
class FarewellBeautiful:

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, def_ignore, turns, forward = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23040.hp.{wearer.id}', label='永訣よ美しくあれ', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))

        def grant(target=None, **kw):
            if target is None:
                return
            owner = getattr(target, 'attributed_to', target)
            if getattr(owner, 'id', None) != wearer.id:
                return
            for who in (wearer, *[m for m in battle.memosprites if m.summoner is wearer]):
                battle.apply_effect(who, Effect(key=f'lc.23040.flower.{wearer.id}', label='冥花', stats=StatSheet.of(def_ignore=def_ignore), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_HP_LOSS, grant, owner_id=wearer.id)
        state = {'used': False}

        def on_dismiss(source_id=None, **kw):
            if source_id != wearer.id or state['used']:
                return
            state['used'] = True
            battle.advance_forward(wearer, forward)

        def on_ult(source_id=None, **kw):
            if source_id == wearer.id:
                state['used'] = False
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, on_dismiss, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('23052')
class LoveIsForeverNow:

    def on_equip(self, wearer, battle, params) -> None:
        from ..characters.cyrene import MEMO_SKILL_ALLY, MEMO_SKILL_ENEMY
        spd_up, poem_cd, blank_vuln, boost = params[:4]
        key_blank = f'lc.23052.blank.{wearer.id}'
        key_poem = f'lc.23052.poem.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23052.spd.{wearer.id}', label='愛はいま永遠に', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))
        state = {'ally': 0.0, 'enemy': 0.0, 'blank': False, 'poem': False}

        def apply_all() -> None:
            scale = 1.0 + boost if state['blank'] and state['poem'] else 1.0
            if state['blank']:
                for e in battle.alive_enemies:
                    battle.apply_effect(e, Effect(key=key_blank, label='空白', stats=StatSheet.of(vulnerability=blank_vuln * scale), source_id=wearer.id))
            if state['poem']:
                battle.apply_aura(wearer, lambda who: Effect(key=key_poem, label='詩句・会心ダメージ', stats=StatSheet.of(crit_dmg=poem_cd * scale), source_id=wearer.id))

        def on_memo_skill(source_id=None, **kw):
            if source_id != wearer.id:
                return
            ally = battle.counter_value(wearer, MEMO_SKILL_ALLY)
            enemy = battle.counter_value(wearer, MEMO_SKILL_ENEMY)
            if ally > state['ally']:
                state['blank'] = True
            if enemy > state['enemy']:
                state['poem'] = True
            state['ally'], state['enemy'] = (ally, enemy)
            apply_all()
        battle.bus.subscribe(Event.ON_MEMO_SKILL, on_memo_skill, owner_id=wearer.id)

@register_lc('23063')
class RiseAndSingAloud:

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, forward, spd_up, turns = params[:4]
        key_song = f'lc.23063.song.{wearer.id}'
        key_spd = f'lc.23063.spd.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23063.hp.{wearer.id}', label='立ち上がり高らかな歌を', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        battle.advance_forward(wearer, forward)
        battle.apply_effect(wearer, Effect(key=key_song, label='新たな歌声', duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.apply_aura(wearer, lambda who: Effect(key=key_spd, label='新たな歌声・速度', stats=StatSheet.of(spd_pct=spd_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key_song)

        def on_ult(source_id=None, **kw):
            if source_id == wearer.id:
                battle.gain_sp(1)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('24005')
class EndlessReminiscence:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        spd, dmg_up, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.24005.spd.{wearer.id}', label='尽きぬ追憶', stats=StatSheet.of(spd_pct=spd), source_id=wearer.id))
        key = f'lc.24005.dmg.{wearer.id}'

        def on_skill(source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_aura(wearer, lambda who: Effect(key=key, label='尽きぬ追憶・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)

@register_lc('22006')
class PinkTomorrow:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, team_dmg, basic_dmg = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.22006.cd.{wearer.id}', label='ピンク色の明日へ', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))
        impl = battle.impl_of(wearer)
        ready = getattr(impl, 'enhanced_basic_ready', None)
        if ready is None:
            return
        battle.apply_aura(wearer, lambda who: Effect(key=f'lc.22006.team.{wearer.id}', label='視線・与ダメージ', stats=StatSheet.of(dmg_pct=team_dmg), source_id=wearer.id))
        key = f'lc.22006.basic.{wearer.id}'

        def refresh(**kw):
            if ready(wearer, battle):
                battle.apply_effect(wearer, Effect(key=key, label='視線・強化通常攻撃', stats=StatSheet.of(dmg_pct_basic=basic_dmg), stacking=Stacking.REFRESH, source_id=wearer.id))
            elif wearer.effects.has(key):
                battle.remove_effect(wearer, key)

        def on_turn(actor=None, **kw):
            if actor is wearer:
                refresh()
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_turn, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, lambda **kw: refresh(), owner_id=wearer.id)
