from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23061')
class TheFlameThatFlickersQuietly:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, skill_dmg, need, turns, ignore = params[:5]
        mark = f'lc.23061.crown.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23061.cr.{wearer.id}', label='静かに瞬く小さな火', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))
        state = {'spent': 0.0, 'turn_of': None}

        def on_turn(actor=None, **kw):
            state['spent'], state['turn_of'] = (0.0, actor)

        def on_spent(spent=0, actor=None, **kw):
            who = actor if actor is not None else battle.acting
            if who is None or who is not state['turn_of'] or who not in battle.team:
                return
            state['spent'] += float(spent)
            if state['spent'] < need:
                return
            state['spent'] = float('-inf')
            battle.apply_effect(wearer, Effect(key=mark, label='輝く王冠', stats=StatSheet.of(dmg_pct_skill=skill_dmg), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{mark}.team', label='輝く王冠・防御無視', stats=StatSheet.of(def_ignore=ignore), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=mark)
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_SP_CHANGE, on_spent, owner_id=wearer.id)

@register_lc('23046')
class TheHellWhereIdealsBurn:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, need, atk, per, max_stacks = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23046.cr.{wearer.id}', label='理想を焼く奈落で', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def on_start(**kw):
            if battle.sp.maximum >= need:
                battle.apply_effect(wearer, Effect(key=f'lc.23046.atk.{wearer.id}', label='理想を焼く奈落で・攻撃力', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_skill(source_id=None, **kw):
            if source_id == wearer.id:
                battle.apply_effect(wearer, Effect(key=f'lc.23046.stack.{wearer.id}', label='理想を焼く奈落で・累積', stats=StatSheet.of(atk_pct=per), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)

@register_lc('23037')
class IntoTheUnreachableVeil:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        crit_rate, _, need_ep, dmg_up, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23037.cr.{wearer.id}', label='触れてはならぬ領域へ', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def on_action(actor=None, action=None, **kw):
            if actor is not wearer or action is not Action.ULTIMATE:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.23037.dmg.{wearer.id}', label='触れてはならぬ領域へ・与ダメージ', stats=StatSheet.of(dmg_pct_skill=dmg_up, dmg_pct_ultimate=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            maximum = float(getattr(wearer.resource, 'maximum', 0.0) or 0.0)
            if source_id == wearer.id and maximum >= need_ep:
                battle.gain_sp(1, actor=wearer)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('24004')
class EternalCalculus:

    def on_equip(self, wearer, battle, params) -> None:
        atk, per, need, spd, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.24004.atk.{wearer.id}', label='絶え間ない演算', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_attack(source=None, targets_hit=0, rider=False, **kw):
            if source is not wearer or rider or (not targets_hit):
                return
            battle.apply_effect(wearer, Effect(key=f'lc.24004.stack.{wearer.id}', label='絶え間ない演算・攻撃力', stats=StatSheet.of(atk_pct=per * min(5, int(targets_hit))), stacking=Stacking.REFRESH, source_id=wearer.id))
            if targets_hit >= need:
                before = wearer.speed()
                battle.apply_effect(wearer, Effect(key=f'lc.24004.spd.{wearer.id}', label='絶え間ない演算・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
                if any((s.actor is wearer for s in battle.queue.slots)):
                    battle.queue.rescale(wearer, before)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23060')
class NightOfTheGuidingStar:

    def on_equip(self, wearer, battle, params) -> None:
        _, energy, max_stacks, skill_up, need, ult_up, ignore = params[:7]
        key = f'lc.23060.sail.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23060.def.{wearer.id}', label='夜を照らす導きの星', stats=StatSheet.of(def_ignore=ignore), source_id=wearer.id))

        def on_assist(source=None, **kw):
            if source is not wearer:
                return
            battle.gain_energy(wearer, energy, apply_regen=False)
            eff = battle.apply_effect(wearer, Effect(key=key, label='出航', stats=StatSheet.of(dmg_pct_skill=skill_up), duration=Duration(turns=2), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))
            if eff is not None and eff.stacks >= need:
                eff.stats = StatSheet.of(dmg_pct_skill=skill_up, dmg_pct_ultimate=ult_up)
        battle.bus.subscribe(Event.ON_ASSIST_SKILL, on_assist, owner_id=wearer.id)
