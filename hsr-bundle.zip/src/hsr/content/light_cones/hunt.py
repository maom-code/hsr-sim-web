from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23056')
class TheEndOfALie:

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, per, turns, atk_up, vuln = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23056.crit.{wearer.id}', label='或る嘘の終幕', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def grant() -> None:
            battle.apply_effect(wearer, Effect(key=f'lc.23056.kagekui.{wearer.id}', label='影喰い', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=f'lc.23056.vuln.{wearer.id}', label='影喰い・脆弱', exclusive='lc.23056.vuln', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        grant()
        count = 0

        def on_followup(source=None, dmg_type=None, as_followup=False, **kw):
            nonlocal count
            if source is not wearer or not as_followup:
                return
            count += 1
            if count % int(per) == 0:
                grant()
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_lc('23016')
class WorrisomeBlissful:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, fua_dmg, crit_dmg, stacks = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23016.crit.{wearer.id}', label='悩んで笑って', stats=StatSheet.of(crit_rate=crit_rate, dmg_pct_followup=fua_dmg), source_id=wearer.id))

        def on_followup(source=None, targets=(), as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            for enemy in targets:
                battle.apply_effect(enemy, Effect(key=f'lc.23016.tame.{wearer.id}', label='従順', stats=StatSheet.of(crit_dmg_taken=crit_dmg), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_lc('23031')
class MyDestinyThisHunt:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, def_ignore, stacks = params[:3]
        key = f'lc.23031.flow.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23031.crit.{wearer.id}', label='我が征く巡狩の道', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def on_followup(source=None, as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            battle.apply_effect(wearer, Effect(key=key, label='流光', stats=StatSheet.of(def_ignore_ultimate=def_ignore), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))

        def on_turn_end(actor=None, **kw):
            if actor is not wearer:
                return
            eff = wearer.effects.get(key)
            if eff is None:
                return
            if eff.stacks <= 1:
                battle.remove_effect(wearer, key)
            else:
                eff.stacks -= 1
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=wearer.id)

@register_lc('23027')
class SailingTowardsASecondLife:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        be, need, ignore, spd = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23027.{wearer.id}', label='二度目の生に向かって', stats=StatSheet.of(break_effect=be, def_ignore_break=ignore), source_id=wearer.id))

        def on_start(**kw):
            if wearer.stats[StatKey.BREAK_EFFECT] >= need:
                before = wearer.speed()
                battle.apply_effect(wearer, Effect(key=f'lc.23027.spd.{wearer.id}', label='二度目の生に向かって・速度', stats=StatSheet.of(spd_pct=spd), source_id=wearer.id))
                if any((sl.actor is wearer for sl in battle.queue.slots)):
                    battle.queue.rescale(wearer, before)
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=wearer.id)

@register_lc('21024')
class RiverFlowsInSpring:

    def on_equip(self, wearer, battle, params) -> None:
        spd, dmg_up = params[:2]
        key = f'lc.21024.{wearer.id}'

        def on():
            battle.apply_effect(wearer, Effect(key=key, label='春水に初生する', stats=StatSheet.of(spd_pct=spd, dmg_pct=dmg_up), stacking=Stacking.REFRESH, source_id=wearer.id))
        state = {'off': False}

        def on_hit(target=None, **kw):
            if target is wearer:
                battle.remove_effect(wearer, key)
                state['off'] = True

        def on_turn_end(actor=None, **kw):
            if actor is wearer and state['off']:
                state['off'] = False
                on()
        battle.bus.subscribe(Event.BATTLE_START, lambda **kw: on(), owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hit, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=wearer.id)
