from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23056')
class TheEndOfALie:

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, per, turns, atk_up, vuln = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23056.crit.{wearer.id}', label='或る嘘の終幕', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def grant() -> None:
            battle.apply_effect(wearer, Effect(key=f'lc.23056.kagekui.{wearer.id}', label='影喰い', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=f'lc.23056.vuln.{wearer.id}', label='影喰い・脆弱', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        grant()
        count = 0

        def on_followup(source=None, dmg_type=None, as_followup=False, **kw):
            nonlocal count
            if source is not wearer or not as_followup:
                return
            count += 1
            if count % int(per) == 0:
                grant()
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_lc('23016')
class WorrisomeBlissful:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, fua_dmg, crit_dmg, stacks = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23016.crit.{wearer.id}', label='悩んで笑って', stats=StatSheet.of(crit_rate=crit_rate, dmg_pct_followup=fua_dmg), source_id=wearer.id))

        def on_followup(source=None, targets=(), as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            for enemy in targets:
                battle.apply_effect(enemy, Effect(key=f'lc.23016.tame.{wearer.id}', label='従順', stats=StatSheet.of(crit_dmg_taken=crit_dmg), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_lc('23031')
class MyDestinyThisHunt:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, def_ignore, stacks = params[:3]
        key = f'lc.23031.flow.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23031.crit.{wearer.id}', label='我が征く巡狩の道', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def on_followup(source=None, as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            battle.apply_effect(wearer, Effect(key=key, label='流光', stats=StatSheet.of(def_ignore_ultimate=def_ignore), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))

        def on_turn_end(actor=None, **kw):
            if actor is not wearer:
                return
            eff = wearer.effects.get(key)
            if eff is None:
                return
            if eff.stacks <= 1:
                battle.remove_effect(wearer, key)
            else:
                eff.stacks -= 1
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=wearer.id)
