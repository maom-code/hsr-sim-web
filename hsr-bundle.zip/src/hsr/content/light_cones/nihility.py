from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('21015')
class ResolutionShinesAsPearlsOfSweat:

    def on_equip(self, wearer, battle, params) -> list[str]:
        chance, def_down, turns = (params[0], params[1], int(params[2]))
        key = f'lc.21015.fall.{wearer.id}'

        def on_hit(source=None, targets=None, **kw):
            if source is not wearer:
                return
            for target in targets or ():
                if not target.alive or target.effects.has(key):
                    continue
                battle.apply_effect(target, Effect(key=key, label='陥落', stats=StatSheet.of(def_down=def_down), duration=Duration(turns=turns), source_id=wearer.id))
        battle.bus.subscribe(Event.AFTER_DAMAGE, on_hit, owner_id=wearer.id)
        if chance < 1.0:
            return [f'光円錐「決意は汗のように輝く」の基礎確率 {chance:.0%}（振らずに必ず付く扱い）']
        return []

@register_lc('23059')
class PurgatoryForgedAnew:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(hp_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, energy, turns, crit_all, crit_mine = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23059.hp.{wearer.id}', label='煉獄に焼かれし新身', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        fired = False

        def on_turn_start(actor=None, **kw):
            nonlocal fired
            if fired or actor is not wearer:
                return
            fired = True
            battle.gain_energy(wearer, energy, apply_regen=False)

        def on_skill_damage(source=None, dmg_type=None, targets=None, **kw):
            if source is not wearer or dmg_type is not DamageType.SKILL:
                return
            for target in targets or ():
                if not target.alive:
                    continue
                battle.apply_effect(target, Effect(key=f'lc.23059.rengoku.{wearer.id}', label='煉獄', stats=StatSheet.of(crit_dmg_taken=crit_all, crit_dmg_taken_from_source=crit_mine), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.TURN_START, on_turn_start, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_skill_damage, owner_id=wearer.id)

@register_lc('23043')
class LiesDancingInTheWind:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        spd_up, _chance, daze_def, turns, _chance2, steal_def, spd_need = params[:7]
        key = f'lc.23043.debuff.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23043.spd.{wearer.id}', label='風に揺蕩う虚言', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))

        def put(enemy, suffix: str, label: str, down: float) -> None:
            battle.apply_effect(enemy, Effect(key=f'{key}.{suffix}', label=label, exclusive=f'lc.23043.{suffix}', stats=StatSheet.of(def_down=down), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))

        def on_attack(source=None, **kw):
            if source is not wearer:
                return
            fast = wearer.stats[StatKey.SPD] >= spd_need
            for enemy in battle.alive_enemies:
                put(enemy, 'daze', '茫然', daze_def)
                if fast:
                    put(enemy, 'steal', '盗難', steal_def)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23007')
class IncessantRain:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(effect_hit=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        hit, _, vuln, need, cr = params[:5]
        key = 'lc.23007.code'
        battle.apply_effect(wearer, Effect(key=f'lc.23007.hit.{wearer.id}', label='降りやまぬ雨', stats=StatSheet.of(effect_hit=hit), source_id=wearer.id))
        battle.add_target_bonus(wearer, lambda src, tgt: StatSheet.of(crit_rate=cr) if battle.debuff_count(tgt) >= need else None)

        def on_attack(source=None, dmg_type=None, targets=None, rider=False, **kw):
            from ...model.enums import DamageType
            if source is not wearer or rider or dmg_type not in (DamageType.BASIC, DamageType.SKILL, DamageType.ULTIMATE):
                return
            pool = [e for e in targets or [] if e.alive and (not e.effects.has(key))]
            if not pool:
                return
            battle.apply_effect(pool[0], Effect(key=key, label='エーテルコード', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=1), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23006')
class PatienceIsAllYouNeed:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.effects import DOT_SHOCK
        from ...model.enums import Element
        dot, dmg_up, spd, max_stacks, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23006.{wearer.id}', label='待つのみ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))
        key = f'lc.23006.gossamer.{wearer.id}'

        def on_attack(source=None, targets=None, rider=False, **kw):
            if source is not wearer or rider:
                return
            before = wearer.speed()
            battle.apply_effect(wearer, Effect(key=f'lc.23006.spd.{wearer.id}', label='待つのみ・速度', stats=StatSheet.of(spd_pct=spd), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))
            if any((sl.actor is wearer for sl in battle.queue.slots)):
                battle.queue.rescale(wearer, before)
            for e in targets or []:
                if e.alive and (not e.effects.has(key)):
                    battle.apply_effect(e, Effect(key=key, label='遊糸', dot_base=wearer.stats[StatKey.ATK] * dot, dot_element=Element.LIGHTNING, dot_kind=DOT_SHOCK, duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23022')
class ReforgedRemembrance:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(effect_hit=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.effects import DOT_KINDS_BASIC, has_dot_kind
        hit, atk, ignore, max_stacks = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23022.{wearer.id}', label='時間の記憶を再構築して', stats=StatSheet.of(effect_hit=hit), source_id=wearer.id))
        seen: set[str] = set()

        def on_damage(source=None, targets=None, **kw):
            if source is not wearer:
                return
            for e in targets or []:
                for kind in DOT_KINDS_BASIC:
                    if kind not in seen and len(seen) < max_stacks and has_dot_kind(e, kind):
                        seen.add(kind)
                        n = len(seen)
                        battle.apply_effect(wearer, Effect(key=f'lc.23022.prophet.{wearer.id}', label=f'予見 {n} 層', stats=StatSheet.of(atk_pct=atk * n, def_ignore_dot=ignore * n), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.AFTER_DAMAGE, on_damage, owner_id=wearer.id)

@register_lc('24003')
class SolitaryHealing:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        be, dot, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.24003.{wearer.id}', label='孤独の癒し', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_action(actor=None, action=None, **kw):
            if actor is wearer and action is Action.ULTIMATE:
                battle.apply_effect(wearer, Effect(key=f'lc.24003.dot.{wearer.id}', label='孤独の癒し・持続ダメージ', stats=StatSheet.of(dmg_pct_dot=dot), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)

@register_lc('21008')
class EyesOfThePrey:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(effect_hit=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        battle.apply_effect(wearer, Effect(key=f'lc.21008.{wearer.id}', label='獲物の視線', stats=StatSheet.of(effect_hit=params[0], dmg_pct_dot=params[1]), source_id=wearer.id))

@register_lc('23047')
class WhyDoesTheOceanSing:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(effect_hit=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        hit, _, turns, per, max_stacks, spd, spd_turns = params[:7]
        key = 'lc.23047.enthrall'
        battle.apply_effect(wearer, Effect(key=f'lc.23047.{wearer.id}', label='海の歌は何がため', stats=StatSheet.of(effect_hit=hit), source_id=wearer.id))

        def on_applied(source_id=None, target=None, effect=None, **kw):
            if source_id != wearer.id or target is None or effect is None or (not effect.debuff):
                return
            if target not in battle.enemies or effect.key == key:
                return
            battle.apply_effect(target, Effect(key=key, label='魂迷', stats=StatSheet.of(dot_taken=per), duration=Duration(turns=int(turns)), stacking=Stacking.STACK, max_stacks=int(max_stacks), debuff=True, source_id=wearer.id))

        def on_attack(source=None, targets=None, rider=False, **kw):
            owner = getattr(source, 'attributed_to', source)
            if rider or owner not in battle.team:
                return
            if any((e.effects.has(key) for e in targets or [])):
                before = owner.speed()
                battle.apply_effect(owner, Effect(key='lc.23047.spd', label='魂迷・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=int(spd_turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
                if any((sl.actor is owner for sl in battle.queue.slots)):
                    battle.queue.rescale(owner, before)
        battle.bus.subscribe(Event.ON_EFFECT_APPLIED, on_applied, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('21061')
class HolidayThermaeEscapade:

    def on_equip(self, wearer, battle, params) -> None:
        dmg, _, vuln, turns = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.21061.{wearer.id}', label='休日のバルネア大冒険', stats=StatSheet.of(dmg_pct=dmg), source_id=wearer.id))

        def on_attack(source=None, targets=None, rider=False, **kw):
            if source is not wearer or rider:
                return
            for e in targets or []:
                battle.apply_effect(e, Effect(key='lc.21061.vuln', label='休日のバルネア大冒険・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23050')
class NeverForgetHerFlame:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        be, brk = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.23050.{wearer.id}', label='彼女の炎を忘れずに', stats=StatSheet.of(break_effect=be), source_id=wearer.id))
        state = {'ready': True}

        def on_start(**kw):
            others = [c for c in battle.team if c is not wearer]
            best = max(others, key=lambda c: c.stats[StatKey.BREAK_EFFECT]) if others else None
            for c in [wearer] + ([best] if best is not None else []):
                battle.apply_effect(c, Effect(key='lc.23050.break_dmg', label='彼女の炎を忘れずに・弱点撃破ダメージ', stats=StatSheet.of(break_dmg_pct=brk), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id == wearer.id:
                state['ready'] = True

        def on_implant(source=None, **kw):
            if source is wearer and state['ready']:
                state['ready'] = False
                battle.gain_sp(1, actor=wearer)
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_WEAKNESS_IMPLANT, on_implant, owner_id=wearer.id)

@register_lc('23035')
class LongRoadLeadsHome:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        be, _, up, turns, max_stacks = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23035.{wearer.id}', label='長途はやがて帰途へと続く', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_break(target=None, **kw):
            if target is None:
                return
            battle.apply_effect(target, Effect(key='lc.23035.charring', label='着火', stats=StatSheet.of(break_taken=up), duration=Duration(turns=int(turns)), stacking=Stacking.STACK, max_stacks=int(max_stacks), debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=wearer.id)

@register_lc('23004')
class InTheNameOfTheWorld:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        dmg, hit, atk = params[:3]
        battle.add_target_bonus(wearer, lambda src, tgt: StatSheet.of(dmg_pct=dmg) if battle.debuff_count(tgt) > 0 else None)
        key = f'lc.23004.skill.{wearer.id}'

        def on_action(actor=None, action=None, **kw):
            if actor is wearer and action is Action.SKILL:
                battle.apply_effect(wearer, Effect(key=key, label='世界の名を以て・戦闘スキル', stats=StatSheet.of(effect_hit=hit, atk_pct=atk), source_id=wearer.id))

        def on_skill(actor=None, **kw):
            if actor is wearer:
                battle.remove_effect(wearer, key)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)

@register_lc('23024')
class AlongThePassingShore:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        cd, dmg, ult = params[:3]
        key = f'lc.23024.bubble.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23024.{wearer.id}', label='流れ逝く岸を歩いて', stats=StatSheet.of(crit_dmg=cd), source_id=wearer.id))
        battle.add_target_bonus(wearer, lambda src, tgt: StatSheet.of(dmg_pct=dmg, dmg_pct_ultimate=ult) if tgt.effects.has(key) else None)

        def on_hit(source=None, targets=None, rider=False, **kw):
            if getattr(source, 'attributed_to', source) is not wearer or rider:
                return
            for target in targets or ():
                if target.alive:
                    battle.apply_effect(target, Effect(key=key, label='泡影', duration=Duration(turns=1), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.AFTER_DAMAGE, on_hit, owner_id=wearer.id)

@register_lc('21001')
class GoodNightAndSleepWell:

    def on_equip(self, wearer, battle, params) -> None:
        per, cap = (params[0], int(params[1]))
        battle.add_target_bonus(wearer, lambda src, tgt: StatSheet.of(dmg_pct=per * min(cap, battle.debuff_count(tgt))))
