from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('21015')
class ResolutionShinesAsPearlsOfSweat:

    def on_equip(self, wearer, battle, params) -> list[str]:
        chance, def_down, turns = (params[0], params[1], int(params[2]))
        key = f'lc.21015.fall.{wearer.id}'

        def on_hit(source=None, targets=None, **kw):
            if source is not wearer:
                return
            for target in targets or ():
                if not target.alive or target.effects.has(key):
                    continue
                battle.apply_effect(target, Effect(key=key, label='陥落', stats=StatSheet.of(def_down=def_down), duration=Duration(turns=turns), source_id=wearer.id))
        battle.bus.subscribe(Event.AFTER_DAMAGE, on_hit, owner_id=wearer.id)
        if chance < 1.0:
            return [f'光円錐「決意は汗のように輝く」の基礎確率 {chance:.0%}（振らずに必ず付く扱い）']
        return []

@register_lc('23059')
class PurgatoryForgedAnew:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(hp_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, energy, turns, crit_all, crit_mine = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23059.hp.{wearer.id}', label='煉獄に焼かれし新身', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))
        fired = False

        def on_turn_start(actor=None, **kw):
            nonlocal fired
            if fired or actor is not wearer:
                return
            fired = True
            battle.gain_energy(wearer, energy, apply_regen=False)

        def on_skill_damage(source=None, dmg_type=None, targets=None, **kw):
            if source is not wearer or dmg_type is not DamageType.SKILL:
                return
            for target in targets or ():
                if not target.alive:
                    continue
                battle.apply_effect(target, Effect(key=f'lc.23059.rengoku.{wearer.id}', label='煉獄', stats=StatSheet.of(crit_dmg_taken=crit_all, crit_dmg_taken_from_source=crit_mine), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.TURN_START, on_turn_start, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_skill_damage, owner_id=wearer.id)

@register_lc('23043')
class LiesDancingInTheWind:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        spd_up, _chance, daze_def, turns, _chance2, steal_def, spd_need = params[:7]
        key = f'lc.23043.debuff.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.23043.spd.{wearer.id}', label='風に揺蕩う虚言', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))

        def put(enemy, suffix: str, label: str, down: float) -> None:
            battle.apply_effect(enemy, Effect(key=f'{key}.{suffix}', label=label, stats=StatSheet.of(def_down=down), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))

        def on_attack(source=None, **kw):
            if source is not wearer:
                return
            fast = wearer.stats[StatKey.SPD] >= spd_need
            for enemy in battle.alive_enemies:
                put(enemy, 'daze', '茫然', daze_def)
                if fast:
                    put(enemy, 'steal', '盗難', steal_def)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)
