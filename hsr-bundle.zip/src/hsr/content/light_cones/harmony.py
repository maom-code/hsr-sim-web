from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatSheet
from ..equipment import register_lc

@register_lc('23021')
class EarthlyEscapade:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, team_cd, mask_turns, need, team_cr, start_turns = params[:6]
        mask_key = f'lc.23021.mask.{wearer.id}'
        team_key = f'lc.23021.mask.{wearer.id}.team'
        battle.apply_effect(wearer, Effect(key=f'lc.23021.cd.{wearer.id}', label='人生は遊び', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))
        state = {'flames': 0}

        def give_mask(turns: int) -> None:
            battle.apply_effect(wearer, Effect(key=mask_key, label='仮面', duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=team_key, label='仮面・会心', stats=StatSheet.of(crit_rate=team_cr, crit_dmg=team_cd), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=mask_key, exclude=wearer)
        battle.bus.subscribe(Event.BATTLE_START, lambda **kw: give_mask(start_turns), owner_id=wearer.id)

        def on_sp_gain(actor=None, amount=0, **kw):
            if actor is not wearer:
                return
            state['flames'] += int(amount)
            if state['flames'] >= need:
                state['flames'] = 0
                give_mask(mask_turns)
        battle.bus.subscribe(Event.ON_SP_GAIN, on_sp_gain, owner_id=wearer.id)

@register_lc('23034')
class APoemAboutSin:

    def on_equip(self, wearer, battle, params) -> None:
        energy, dmg_up, max_stacks, turns, every = params[:5]
        key = f'lc.23034.hymn.{wearer.id}'
        state = {'casts': 0}

        def on_targeted(actor=None, target=None, single=False, **kw):
            if actor is not wearer or target is None or (not single):
                return
            battle.gain_energy(wearer, energy, apply_regen=False)
            battle.apply_effect(target, Effect(key=key, label='聖なる詠唱', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))
            state['casts'] += 1
            if state['casts'] >= int(every):
                state['casts'] = 0
                battle.gain_sp(1, actor=wearer)
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_targeted, owner_id=wearer.id)

def _next_ally_buff(wearer, battle, key: str, label: str, dmg_up: float, turns: int) -> None:
    from ...engine.effects import TickTiming
    from ...engine.entity import Character
    from ...engine.memosprite import Memosprite
    state = {'pending': False}

    def on_skill(source_id=None, **kw):
        if source_id == wearer.id:
            state['pending'] = True

    def on_turn(actor=None, **kw):
        if not state['pending'] or actor is None:
            return
        if not isinstance(actor, (Character, Memosprite)):
            return
        if actor is wearer or getattr(actor, 'summoner', None) is wearer:
            return
        state['pending'] = False
        battle.apply_effect(actor, Effect(key=key, label=label, stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_on=TickTiming.OWNER_TURN_END), stacking=Stacking.REFRESH, source_id=wearer.id))
    battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)
    battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=wearer.id)

@register_lc('23003')
class ButTheBattleIsntOver:

    def on_equip(self, wearer, battle, params) -> None:
        regen, dmg_up, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.23003.regen.{wearer.id}', label='だが戦争は終わらない', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))
        state = {'ults': 0, 'targeted': False}

        def on_action(actor=None, **kw):
            if actor is wearer:
                state['targeted'] = False

        def on_targeted(actor=None, **kw):
            if actor is wearer:
                state['targeted'] = True

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id or not state['targeted']:
                return
            state['ults'] += 1
            if state['ults'] % 2 == 1:
                battle.gain_sp(1, actor=wearer)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_targeted, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        _next_ally_buff(wearer, battle, f'lc.23003.next.{wearer.id}', 'だが戦争は終わらない・与ダメージ', dmg_up, int(turns))

@register_lc('21025')
class PastAndFuture:

    def on_equip(self, wearer, battle, params) -> None:
        dmg_up, turns = params[:2]
        _next_ally_buff(wearer, battle, f'lc.21025.next.{wearer.id}', '過去と未来・与ダメージ', dmg_up, int(turns))

@register_lc('23026')
class FlowingNightglow:

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        regen, max_stacks, team_dmg, atk, turns = params[:5]
        chant = f'lc.23026.chant.{wearer.id}'
        mark = f'lc.23026.cadenza.{wearer.id}'

        def on_attack(source=None, rider=False, **kw):
            if source is None or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            battle.apply_effect(wearer, Effect(key=chant, label='朗唱', stats=StatSheet.of(energy_regen=regen), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))

        def on_action(actor=None, action=None, **kw):
            if actor is not wearer or action is not Action.ULTIMATE:
                return
            battle.remove_effect(wearer, chant)
            battle.apply_effect(wearer, Effect(key=mark, label='華彩', stats=StatSheet.of(atk_pct=atk), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{mark}.team', label='華彩・与ダメージ', stats=StatSheet.of(dmg_pct=team_dmg), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=mark)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)

@register_lc('22002')
class ForTomorrowsJourney:

    def on_equip(self, wearer, battle, params) -> None:
        atk, dmg_up, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.22002.atk.{wearer.id}', label='明日のための旅', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.22002.dmg.{wearer.id}', label='明日のための旅・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('23019')
class PastSelfInMirror:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...model.stats import StatKey
        be, dmg_up, turns, threshold, energy = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23019.be.{wearer.id}', label='鏡の中の私', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_to_team(lambda who: Effect(key='lc.23019.dmg', label='鏡の中の私・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
            if wearer.stats[StatKey.BREAK_EFFECT] >= threshold:
                battle.gain_sp(1, actor=wearer)

        def on_start(**kw):
            for c in battle.team:
                battle.gain_energy(c, energy, apply_regen=False)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=wearer.id)

@register_lc('21056')
class ASecretVow_ChasingTheWind:

    def on_equip(self, wearer, battle, params) -> None:
        battle.apply_to_team(lambda who: Effect(key='lc.21056.break_dmg', label='風を追う時・弱点撃破ダメージ', stats=StatSheet.of(break_dmg_pct=params[0]), source_id=wearer.id))
