from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('21065')
class GoodLuckToday:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, rate_up, stacks = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.21065.crit.{wearer.id}', label='今日は好運・会心率', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def on_elation_skill(source=None, **kw):
            if source is not wearer:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.21065.rate.{wearer.id}', label='今日は好運・愉悦度', stats=StatSheet.of(elation_rate=rate_up), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ELATION_SKILL, on_elation_skill, owner_id=wearer.id)

@register_lc('21066')
class ASliceOfVacation:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(elation_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        rate, def_ignore = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21066.rate.{wearer.id}', label='バカンスのひと時', stats=StatSheet.of(elation_rate=rate, def_ignore_elation=def_ignore), source_id=wearer.id))

@register_lc('22008')
class ToTheGoalOnTheHorizon:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(atk_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, crit_dmg, turns, stacks = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.22008.atk.{wearer.id}', label='地平線のゴールへ・攻撃力', stats=StatSheet.of(atk_pct=atk_up), source_id=wearer.id))

        def on_followup(source=None, dmg_type=None, as_followup=False, **kw):
            if source is not wearer or not as_followup:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.22008.cd.{wearer.id}', label='地平線のゴールへ・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_followup, owner_id=wearer.id)

@register_lc('21062')
class SeeYouAtTheEnd:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, dmg_up = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21062.{wearer.id}', label='終点でまた会おう', stats=StatSheet.of(crit_dmg=crit_dmg, dmg_pct_skill=dmg_up, dmg_pct_followup=dmg_up), source_id=wearer.id))

@register_lc('24001')
class CruisingInTheStellarSea:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> list[str]:
        crit_rate, threshold, extra_crit, atk_up, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.24001.crit.{wearer.id}', label='星海巡航・会心率', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))
        return [f'光円錐「星海巡航」の「残り HP {threshold:.0%} 以下の敵に会心率 +{extra_crit:.0%}」（敵ごとの条件を会心率に表せない）', f'光円錐「星海巡航」の「敵を倒した後、攻撃力 +{atk_up:.0%}」（比較用の敵は落ちない）']

@register_lc('21007')
class SameHeart:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(heal_boost=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        heal_up, energy = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21007.heal.{wearer.id}', label='同じ気持ち', stats=StatSheet.of(heal_boost=heal_up), source_id=wearer.id))

        def on_skill(source_id=None, **kw):
            if source_id != wearer.id:
                return
            for ally in battle.team:
                battle.gain_energy(ally, energy, apply_regen=False)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)

@register_lc('21018')
class DanceDanceDance:

    def on_equip(self, wearer, battle, params) -> None:
        ratio = params[0]

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            for ally in battle.team:
                battle.advance_forward(ally, ratio)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('21019')
class UnderTheBlueSky:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(atk_pct=params[0])

    def on_equip(self, wearer, battle, params) -> list[str]:
        atk_up, crit_up, _turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.21019.atk.{wearer.id}', label='青空の下で', stats=StatSheet.of(atk_pct=atk_up), source_id=wearer.id))
        return [f'光円錐「青空の下で」の「敵を倒した後、会心率 +{crit_up:.0%}」（敵を倒さない）']

@register_lc('21026')
class WoofWalkTime:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(atk_pct=params[0])

    def on_equip(self, wearer, battle, params) -> list[str]:
        atk_up, dmg_up = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21026.atk.{wearer.id}', label='ワン！散歩の時間！', stats=StatSheet.of(atk_pct=atk_up), source_id=wearer.id))
        return [f'光円錐「ワン！散歩の時間！」の「燃焼・裂創の敵への与ダメージ +{dmg_up:.0%}」（持続ダメージを撒くキャラを実装していない）']

@register_lc('21050')
class FleetingMoment:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, dmg_up, turns = params[:3]
        key = f'lc.21050.dmg.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.21050.cd.{wearer.id}', label='瞬刻の勝機', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))

        def on_ally_targeted(actor=None, **kw):
            memo = battle.memosprite_of(wearer)
            if memo is None or actor is not memo:
                return
            battle.apply_aura(wearer, lambda who: Effect(key=key, label='瞬刻の勝機・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_ally_targeted, owner_id=wearer.id)

@register_lc('21052')
class SweatNowCryLater:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, dmg_up = params[:2]
        key = f'lc.21052.dmg.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.21052.crit.{wearer.id}', label='流すなら涙より汗', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))

        def refresh(**kw):
            memo = battle.memosprite_of(wearer)
            if memo is None:
                battle.remove_effect(wearer, key)
                return
            for who in (wearer, memo):
                battle.apply_effect(who, Effect(key=key, label='流すなら涙より汗・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=wearer.id))
        refresh()
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, refresh, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, refresh, owner_id=wearer.id)

@register_lc('21057')
class FlowersRemember:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, memo_crit_dmg = params[:2]
        key = f'lc.21057.memo.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.21057.cd.{wearer.id}', label='花は忘れない', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))

        def grant(**kw):
            memo = battle.memosprite_of(wearer)
            if memo is not None:
                battle.apply_effect(memo, Effect(key=key, label='花は忘れない・精霊の会心ダメージ', stats=StatSheet.of(crit_dmg=memo_crit_dmg), source_id=wearer.id))
        grant()
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, grant, owner_id=wearer.id)

@register_lc('22000')
class BeforeTheFirstQuest:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(effect_hit=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        hit_up, energy = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.22000.hit.{wearer.id}', label='初めてのクエストの前に', stats=StatSheet.of(effect_hit=hit_up), source_id=wearer.id))

        def on_attack(source=None, targets=(), **kw):
            if source is not wearer:
                return
            if any((e.stats[StatKey.DEF_DOWN] > 0 for e in targets)):
                battle.gain_energy(wearer, energy, apply_regen=False)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('22001')
class HeyOverHere:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(hp_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        hp_up, heal_up, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.22001.hp.{wearer.id}', label='よぉ、ここにいるぜ', stats=StatSheet.of(hp_pct=hp_up), source_id=wearer.id))

        def on_skill(source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.22001.heal.{wearer.id}', label='よぉ、ここにいるぜ・治癒量', stats=StatSheet.of(heal_boost=heal_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=wearer.id)

@register_lc('22007')
class TogetherToTheFuture:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, rate_up, turns = params[:3]
        key = f'lc.22007.rate.{wearer.id}'
        battle.apply_effect(wearer, Effect(key=f'lc.22007.cd.{wearer.id}', label='みんなで一緒に未来へ', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_aura(wearer, lambda who: Effect(key=key, label='みんなで一緒に未来へ・愉悦度', stats=StatSheet.of(elation_rate=rate_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
