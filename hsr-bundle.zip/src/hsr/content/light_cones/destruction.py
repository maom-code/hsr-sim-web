from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23062')
class AsIAm:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(atk_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, regen, per_energy, turns, crit_dmg, cap = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23062.base.{wearer.id}', label='在るがままの我', stats=StatSheet.of(atk_pct=atk_up, energy_regen=regen), source_id=wearer.id))
        key = f'lc.23062.amusement.{wearer.id}'

        def grant_amusement() -> None:
            battle.apply_effect(wearer, Effect(key=key, label='王の娯楽', duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{key}.team', label='王の娯楽・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        grant_amusement()
        boost = f'lc.23062.ult.{wearer.id}'

        def on_action(actor=None, action=None, **kw):
            from ...engine.battle import Action
            if actor is not wearer or action is not Action.ULTIMATE:
                return
            spent = wearer.resource.maximum if hasattr(wearer.resource, 'maximum') else 0.0
            battle.apply_effect(wearer, Effect(key=boost, label='王の娯楽・必殺技ダメージ', stats=StatSheet.of(dmg_pct_ultimate=min(spent * per_energy, cap)), source_id=wearer.id))
            grant_amusement()

        def on_ult_used(actor=None, **kw):
            if actor is wearer:
                battle.remove_effect(wearer, boost)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult_used, owner_id=wearer.id)

@register_lc('23045')
class ACrownUnrewarded:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, extra_atk, energy_need, turns, energy_ratio, atk_up = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23045.cd.{wearer.id}', label='報われぬ戴冠', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            total = atk_up
            maximum = getattr(wearer.resource, 'maximum', 0.0)
            if maximum >= energy_need:
                total += extra_atk
                battle.gain_energy(wearer, maximum * energy_ratio, apply_regen=False)
            battle.apply_effect(wearer, Effect(key=f'lc.23045.atk.{wearer.id}', label='報われぬ戴冠・攻撃力', stats=StatSheet.of(atk_pct=total), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('24000')
class OnTheFallOfAnAeon:

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, stacks, dmg_up, turns = params[:4]

        def on_attack(source=None, rider=False, **kw):
            if source is not wearer or rider:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.24000.atk.{wearer.id}', label='とある星神の殞落を記す', stats=StatSheet.of(atk_pct=atk_up), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))

        def on_break(source=None, **kw):
            if source is not wearer:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.24000.break.{wearer.id}', label='とある星神の殞落を記す・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=wearer.id)

@register_lc('23025')
class WhereaboutsShouldDreamsRest:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        be, taken, slow, turns = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23025.be.{wearer.id}', label='夢が帰り着く場所', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_break(source=None, target=None, **kw):
            if source is not wearer or target is None:
                return
            before = target.speed()
            battle.apply_effect(target, Effect(key='lc.23025.routed', label='敗走', stats=StatSheet.of(spd_pct=-slow), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
            if any((sl.actor is target for sl in battle.queue.slots)):
                battle.queue.rescale(target, before)
            battle.apply_effect(wearer, Effect(key=f'lc.23025.taken.{wearer.id}', label='敗走・弱点撃破ダメージ（近似）', stats=StatSheet.of(break_dmg_pct=taken), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=wearer.id)

@register_lc('21042')
class IndeliblePromise:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.battle import Action
        be, cr, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.21042.be.{wearer.id}', label='心に刻まれた約束', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_action(actor=None, action=None, **kw):
            if actor is wearer and action is Action.ULTIMATE:
                battle.apply_effect(wearer, Effect(key=f'lc.21042.cr.{wearer.id}', label='心に刻まれた約束・会心率', stats=StatSheet.of(crit_rate=cr), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)

@register_lc('23044')
class ThusBurnsTheDawn:

    def on_equip(self, wearer, battle, params) -> None:
        spd, ignore, dmg_up = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.23044.spd.{wearer.id}', label='燃え盛る黎明のように', stats=StatSheet.of(spd=spd, def_ignore=ignore), source_id=wearer.id))
        key = f'lc.23044.sun.{wearer.id}'

        def on_ult(source_id=None, **kw):
            if source_id == wearer.id:
                battle.apply_effect(wearer, Effect(key=key, label='烈日', stats=StatSheet.of(dmg_pct=dmg_up), stacking=Stacking.REFRESH, source_id=wearer.id))

        def on_turn(actor=None, **kw):
            if actor is wearer:
                battle.remove_effect(wearer, key)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=wearer.id)

@register_lc('21058')
class InheritedBlood_AncientBlood:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        cr, dmg_up = params[:2]
        battle.apply_effect(wearer, Effect(key=f'lc.21058.{wearer.id}', label='古より受け継がれる血', stats=StatSheet.of(crit_rate=cr, dmg_pct_skill=dmg_up, dmg_pct_ultimate=dmg_up), source_id=wearer.id))
