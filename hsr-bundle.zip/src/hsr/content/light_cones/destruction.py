from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23062')
class AsIAm:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(atk_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, regen, per_energy, turns, crit_dmg, cap = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23062.base.{wearer.id}', label='在るがままの我', stats=StatSheet.of(atk_pct=atk_up, energy_regen=regen), source_id=wearer.id))
        key = f'lc.23062.amusement.{wearer.id}'

        def grant_amusement() -> None:
            battle.apply_effect(wearer, Effect(key=key, label='王の娯楽', duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{key}.team', label='王の娯楽・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        grant_amusement()
        boost = f'lc.23062.ult.{wearer.id}'

        def on_action(actor=None, action=None, **kw):
            from ...engine.battle import Action
            if actor is not wearer or action is not Action.ULTIMATE:
                return
            spent = wearer.resource.maximum if hasattr(wearer.resource, 'maximum') else 0.0
            battle.apply_effect(wearer, Effect(key=boost, label='王の娯楽・必殺技ダメージ', stats=StatSheet.of(dmg_pct_ultimate=min(spent * per_energy, cap)), source_id=wearer.id))
            grant_amusement()

        def on_ult_used(actor=None, **kw):
            if actor is wearer:
                battle.remove_effect(wearer, boost)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult_used, owner_id=wearer.id)

@register_lc('23045')
class ACrownUnrewarded:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_dmg, extra_atk, energy_need, turns, energy_ratio, atk_up = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23045.cd.{wearer.id}', label='報われぬ戴冠', stats=StatSheet.of(crit_dmg=crit_dmg), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            total = atk_up
            maximum = getattr(wearer.resource, 'maximum', 0.0)
            if maximum >= energy_need:
                total += extra_atk
                battle.gain_energy(wearer, maximum * energy_ratio, apply_regen=False)
            battle.apply_effect(wearer, Effect(key=f'lc.23045.atk.{wearer.id}', label='報われぬ戴冠・攻撃力', stats=StatSheet.of(atk_pct=total), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('24000')
class OnTheFallOfAnAeon:

    def on_equip(self, wearer, battle, params) -> None:
        atk_up, stacks, dmg_up, turns = params[:4]

        def on_attack(source=None, rider=False, **kw):
            if source is not wearer or rider:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.24000.atk.{wearer.id}', label='とある星神の殞落を記す', stats=StatSheet.of(atk_pct=atk_up), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))

        def on_break(source=None, **kw):
            if source is not wearer:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.24000.break.{wearer.id}', label='とある星神の殞落を記す・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=wearer.id)
