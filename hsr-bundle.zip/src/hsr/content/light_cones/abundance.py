from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23017')
class NightOfFright:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(energy_regen=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        regen, heal_ratio, atk_up, stacks, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23017.regen.{wearer.id}', label='驚魂の夜・EP回復効率', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if not any((c.id == source_id for c in battle.team)):
                return
            target = min(battle.team, key=lambda c: c.hp / c.max_hp if c.max_hp else 1.0)
            battle.heal(wearer, target, target.max_hp * heal_ratio, label='驚魂の夜')

        def on_heal(healer=None, target=None, **kw):
            if healer is not wearer or target is None:
                return
            battle.apply_effect(target, Effect(key=f'lc.23017.atk.{wearer.id}', label='驚魂の夜・攻撃力', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=target.id), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=wearer.id)

@register_lc('23032')
class ScentAloneStaysTrue:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        be, vuln, need, extra, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23032.{wearer.id}', label='昔日の香りは今も猶', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_attack(source=None, dmg_type=None, targets=None, rider=False, **kw):
            if source is not wearer or rider or dmg_type is not DamageType.ULTIMATE:
                return
            up = vuln + (extra if wearer.stats[StatKey.BREAK_EFFECT] >= need else 0.0)
            for e in targets or []:
                battle.apply_effect(e, Effect(key='lc.23032.woefree', label='忘憂', stats=StatSheet.of(vulnerability=up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)

@register_lc('23008')
class EchoesOfTheCoffin:

    def on_equip(self, wearer, battle, params) -> None:
        atk, spd, energy, times = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23008.{wearer.id}', label='棺のこだま', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_attack(source=None, targets=None, rider=False, **kw):
            if source is not wearer or rider:
                return
            n = min(int(times), len(targets or []))
            if n:
                battle.gain_energy(wearer, energy * n, apply_regen=False)

        def on_ult(source_id=None, **kw):
            if source_id != wearer.id:
                return
            for c in battle.team:
                before = c.speed()
                battle.apply_effect(c, Effect(key='lc.23008.spd', label='棺のこだま・速度', stats=StatSheet.of(spd=spd), duration=Duration(turns=1), stacking=Stacking.REFRESH, source_id=wearer.id))
                if any((sl.actor is c for sl in battle.queue.slots)):
                    battle.queue.rescale(c, before)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('21035')
class WhatIsReal:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(break_effect=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        be, ratio, flat = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.21035.{wearer.id}', label='何が真か', stats=StatSheet.of(break_effect=be), source_id=wearer.id))

        def on_basic(source_id=None, **kw):
            if source_id == wearer.id:
                battle.heal(wearer, wearer, wearer.max_hp * ratio + flat, label='何が真か')
        battle.bus.subscribe(Event.ON_BASIC_USED, on_basic, owner_id=wearer.id)
