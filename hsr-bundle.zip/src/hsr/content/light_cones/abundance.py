from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatSheet
from ..equipment import register_lc

@register_lc('23017')
class NightOfFright:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(energy_regen=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        regen, heal_ratio, atk_up, stacks, turns = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23017.regen.{wearer.id}', label='驚魂の夜・EP回復効率', stats=StatSheet.of(energy_regen=regen), source_id=wearer.id))

        def on_ult(source_id=None, **kw):
            if not any((c.id == source_id for c in battle.team)):
                return
            target = min(battle.team, key=lambda c: c.hp / c.max_hp if c.max_hp else 1.0)
            battle.heal(wearer, target, target.max_hp * heal_ratio, label='驚魂の夜')

        def on_heal(healer=None, target=None, **kw):
            if healer is not wearer or target is None:
                return
            battle.apply_effect(target, Effect(key=f'lc.23017.atk.{wearer.id}', label='驚魂の夜・攻撃力', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=target.id), stacking=Stacking.STACK, max_stacks=int(stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=wearer.id)
