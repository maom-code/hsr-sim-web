from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23015')
class BrighterThanTheSun:

    def on_equip(self, wearer, battle, params) -> None:
        crit, turns, max_stacks, atk_per, err_per = params[:5]
        battle.apply_effect(wearer, Effect(key=f'lc.23015.crit.{wearer.id}', label='陽光より輝くもの', stats=StatSheet.of(crit_rate=crit), source_id=wearer.id))

        def on_basic(actor=None, source_id=None, **kw):
            if source_id != wearer.id:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.23015.dragon.{wearer.id}', label='龍吟', stats=StatSheet.of(atk_pct=atk_per, energy_regen=err_per), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))
        battle.bus.subscribe(Event.ON_BASIC_USED, on_basic, owner_id=wearer.id)
