from __future__ import annotations
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.stats import StatKey, StatSheet
from ..equipment import register_lc

@register_lc('23054')
class WhenSheChoseToSee:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        spd, cr, cd, turns, regen, energy = params[:6]
        battle.apply_effect(wearer, Effect(key=f'lc.23054.spd.{wearer.id}', label='彼女が視ると決めた時', stats=StatSheet.of(spd_pct=spd), source_id=wearer.id))
        key = f'lc.23054.fortune.{wearer.id}'

        def grant() -> None:
            battle.apply_effect(wearer, Effect(key=key, label='超大吉', stats=StatSheet.of(energy_regen=regen), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
            battle.apply_aura(wearer, lambda who: Effect(key=f'{key}.team', label='超大吉・会心', stats=StatSheet.of(crit_rate=cr, crit_dmg=cd), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id), key=key)
        battle.gain_energy(wearer, energy, apply_regen=False)
        grant()

        def on_ult(actor=None, **kw):
            grant()
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)

@register_lc('21064')
class TakeTakeAdventures:

    def on_equip(self, wearer, battle, params) -> None:
        rate, taken, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.21064.rate.{wearer.id}', label='タケタケ冒険記', stats=StatSheet.of(elation_rate=rate), source_id=wearer.id))

        def on_elation_skill(source=None, **kw):
            if source is not wearer:
                return
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=f'lc.21064.taken.{wearer.id}', label='タケタケ冒険記・被愉悦ダメージ', stats=StatSheet.of(elation_taken=taken), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ELATION_SKILL, on_elation_skill, owner_id=wearer.id)

@register_lc('23057')
class WelcomeToGalaxyCity:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(spd_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.elation import NOTES
        spd, def_ignore, notes, shots = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23057.{wearer.id}', label='銀河シティへようこそ', stats=StatSheet.of(spd_pct=spd, def_ignore_elation=def_ignore), source_id=wearer.id))
        state = {'ready': True, 'basics': 0}

        def on_ult(actor=None, **kw):
            if actor is not wearer or not state['ready']:
                return
            state['ready'] = False
            state['basics'] = 0
            battle.gain_shared(NOTES, notes)

        def on_basic(actor=None, **kw):
            if actor is not wearer or state['ready']:
                return
            state['basics'] += 1
            if state['basics'] >= shots:
                state['ready'] = True
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=wearer.id)
        battle.bus.subscribe(Event.ON_BASIC_USED, on_basic, owner_id=wearer.id)

@register_lc('24006')
class BlessingOfElation:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(atk_pct=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        atk, rate, turns = params[:3]
        battle.apply_effect(wearer, Effect(key=f'lc.24006.atk.{wearer.id}', label='愉悦溢れる祝福', stats=StatSheet.of(atk_pct=atk), source_id=wearer.id))

        def on_target(actor=None, target=None, **kw):
            if actor is not wearer or target is None:
                return
            battle.apply_effect(target, Effect(key=f'lc.24006.rate.{wearer.id}', label='愉悦溢れる祝福・愉悦度', stats=StatSheet.of(elation_rate=rate), duration=Duration(turns=int(turns), tick_owner_id=wearer.id), stacking=Stacking.REFRESH, source_id=wearer.id))
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_target, owner_id=wearer.id)

@register_lc('23064')
class RideTheSummerSwell:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_rate=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        crit_rate, spd_up, rate_up, per = params[:4]
        battle.apply_effect(wearer, Effect(key=f'lc.23064.crit.{wearer.id}', label='波しぶきが躍る夏へ', stats=StatSheet.of(crit_rate=crit_rate), source_id=wearer.id))
        battle.gain_sp(1)
        count = 0
        previous: str | None = None

        def on_elation(source=None, **kw):
            nonlocal count, previous
            if source is not wearer:
                return
            battle.apply_effect(wearer, Effect(key=f'lc.23064.tailwind.{wearer.id}', label='追い風', stats=StatSheet.of(spd_pct=spd_up), source_id=wearer.id))
            current = getattr(battle.impl_of(wearer), 'last_elation_skill_id', None)
            if current is not None and current != previous:
                battle.apply_effect(wearer, Effect(key=f'lc.23064.current.{wearer.id}', label='潮流', stats=StatSheet.of(elation_rate=rate_up), source_id=wearer.id))
            previous = current
            count += 1
            if count % int(per) == 0:
                battle.gain_sp(1)
        battle.bus.subscribe(Event.ON_ELATION_SKILL, on_elation, owner_id=wearer.id)

@register_lc('23053')
class GlitteringWorld:

    @staticmethod
    def build_stats(params) -> StatSheet:
        return StatSheet.of(crit_dmg=params[0])

    def on_equip(self, wearer, battle, params) -> None:
        from ...engine.elation import elation_members
        cd, per, cap, rate, max_stacks, ignore, need = params[:7]
        battle.apply_effect(wearer, Effect(key=f'lc.23053.cd.{wearer.id}', label='きらびやかな世界・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), source_id=wearer.id))
        if not getattr(battle, '_lc_23053_sp', False):
            battle._lc_23053_sp = True
            battle.sp.maximum += int(min(per * len(elation_members(battle)), cap))
        state = {'spent': 0.0}

        def on_sp(spent: float=0.0, actor=None, **kw):
            if actor is not wearer or spent <= 0:
                return
            for _ in range(int(spent)):
                held = wearer.effects.get(f'lc.23053.ignore.{wearer.id}')
                if held is not None and held.stacks >= int(max_stacks):
                    break
                battle.apply_effect(wearer, Effect(key=f'lc.23053.ignore.{wearer.id}', label='きらびやかな世界・防御無視', stats=StatSheet.of(def_ignore_elation=ignore), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=wearer.id))
            state['spent'] += spent
            if state['spent'] >= need and (not wearer.effects.has(f'lc.23053.push.{wearer.id}')):
                battle.apply_effect(wearer, Effect(key=f'lc.23053.push.{wearer.id}', label='配信プッシュ', source_id=wearer.id))
                battle.apply_aura(wearer, lambda who: Effect(key='lc.23053.push_rate', label='配信プッシュ・愉悦度', stats=StatSheet.of(elation_rate=rate), source_id=wearer.id))

        def reset(**kw):
            state['spent'] = 0.0
        battle.bus.subscribe(Event.ON_SP_CHANGE, on_sp, owner_id=wearer.id)
        battle.bus.subscribe(Event.TURN_START, reset, owner_id=wearer.id)
