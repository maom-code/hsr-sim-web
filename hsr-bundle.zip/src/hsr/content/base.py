from __future__ import annotations
import re
from functools import lru_cache
from typing import TYPE_CHECKING, Protocol
if TYPE_CHECKING:
    from ..engine.battle import Battle
    from ..engine.entity import Character

def params_at(skill: dict, level: int) -> list[float]:
    keys = skill.get('params') or {}
    if not keys:
        return []
    top = max((int(k) for k in keys))
    return keys[str(min(level, top))]

def p(skill: dict, level: int, n: int) -> float:
    values = params_at(skill, level)
    try:
        return values[n - 1]
    except IndexError:
        raise IndexError(f'{skill.get('name')}: #{n} は存在しません (params は {len(values)} 個)') from None

class CharacterImpl(Protocol):
    char_id: str

    def basic(self, me: 'Character', battle: 'Battle') -> None:
        ...

    def skill(self, me: 'Character', battle: 'Battle') -> None:
        ...

    def ultimate(self, me: 'Character', battle: 'Battle') -> None:
        ...
BASE_SKILL_LEVELS: dict[str, int] = {'Normal': 6, 'BPSkill': 10, 'Ultra': 10, 'Talent': 10, 'Servant': 6, 'ServantTalent': 6, 'ElationDamage': 10}
_SKILL_TYPE_BY_LABEL: dict[str, str] = {'通常攻撃': 'Normal', '戦闘スキル': 'BPSkill', '必殺技': 'Ultra', '天賦': 'Talent', '精霊スキル': 'Servant', '精霊天賦': 'ServantTalent', '愉悦スキル': 'ElationDamage'}
_LEVEL_UP_RE = re.compile('(' + '|'.join(sorted(_SKILL_TYPE_BY_LABEL, key=len, reverse=True)) + ')のLv\\.\\+(\\d+)')

@lru_cache(maxsize=None)
def eidolon_skill_bonus(char_id: str) -> dict[int, dict[str, int]]:
    from ..data import loader
    ranks = loader.character(char_id).get('ranks') or {}
    out: dict[int, dict[str, int]] = {}
    for rank in (3, 5):
        desc = (ranks.get(str(rank)) or {}).get('desc') or ''
        table = {_SKILL_TYPE_BY_LABEL[label]: int(bonus) for label, bonus in _LEVEL_UP_RE.findall(desc)}
        if table:
            out[rank] = table
    return out

def skill_levels_for(eidolon: int, char_id: str) -> dict[str, int]:
    levels = dict(BASE_SKILL_LEVELS)
    bonus = eidolon_skill_bonus(char_id)
    for rank in range(1, eidolon + 1):
        for key, add in (bonus.get(rank) or {}).items():
            levels[key] = levels.get(key, 0) + add
    return levels

def primary_skill(char_id: str) -> dict | None:
    from ..data import loader
    skills = loader.character(char_id)['skills']
    for sid, s in skills.items():
        if s['type'] == 'BPSkill' and sid.endswith('02'):
            return s
    return None

def skill_sp_cost(char_id: str) -> int:
    s = primary_skill(char_id)
    return int(s['sp_cost']) if s else 1
REGISTRY: dict[str, type] = {}

def register(char_id: str):

    def deco(cls):
        cls.char_id = char_id
        REGISTRY[char_id] = cls
        return cls
    return deco

class NotImplementedCharacter(NotImplementedError):
    pass

def impl_for(char_id: str, name: str=''):
    try:
        return REGISTRY[char_id]()
    except KeyError:
        raise NotImplementedCharacter(f'{name or char_id} はまだ実装されていません。 src/hsr/content/characters/ に @register("{char_id}") を書いてください') from None
