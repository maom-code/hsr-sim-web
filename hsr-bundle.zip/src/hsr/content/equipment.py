from __future__ import annotations
import re
from typing import TYPE_CHECKING, Protocol
from ..model.stats import StatKey, StatSheet
if TYPE_CHECKING:
    from ..engine.battle import Battle
    from ..engine.entity import Character

class EquipmentImpl(Protocol):

    def on_equip(self, wearer: 'Character', battle: 'Battle', params: list[float]) -> None:
        ...
LC_REGISTRY: dict[str, type] = {}
SET_REGISTRY: dict[tuple[str, int], type] = {}

def register_lc(lc_id: str):

    def deco(cls):
        cls.lc_id = str(lc_id)
        LC_REGISTRY[str(lc_id)] = cls
        return cls
    return deco

def register_set(set_id: int | str, pieces: int):

    def deco(cls):
        cls.set_id = str(set_id)
        cls.pieces = pieces
        SET_REGISTRY[str(set_id), pieces] = cls
        return cls
    return deco
STAT_WORDS: dict[str, StatKey] = {'攻撃力': StatKey.ATK_PCT, '最大HP': StatKey.HP_PCT, '防御力': StatKey.DEF_PCT, '速度': StatKey.SPD_PCT, '会心率': StatKey.CRIT_RATE, '会心ダメージ': StatKey.CRIT_DMG, '撃破特効': StatKey.BREAK_EFFECT, '効果命中': StatKey.EFFECT_HIT, '効果抵抗': StatKey.EFFECT_RES, '治癒量': StatKey.HEAL_BOOST, 'EP回復効率': StatKey.ENERGY_REGEN, '物理属性ダメージ': StatKey.DMG_PCT_PHYSICAL, '炎属性ダメージ': StatKey.DMG_PCT_FIRE, '氷属性ダメージ': StatKey.DMG_PCT_ICE, '雷属性ダメージ': StatKey.DMG_PCT_THUNDER, '風属性ダメージ': StatKey.DMG_PCT_WIND, '量子属性ダメージ': StatKey.DMG_PCT_QUANTUM, '虚数属性ダメージ': StatKey.DMG_PCT_IMAGINARY, '追加攻撃ダメージ': StatKey.DMG_PCT_FOLLOWUP}
_SIMPLE = re.compile('^(?:装備キャラの)?(.+?)\\+#1\\[[a-z0-9]+\\]%。?$')

def simple_stat_effect(desc: str, params: list[float]) -> tuple[StatKey, float] | None:
    m = _SIMPLE.match((desc or '').strip())
    if not m or not params:
        return None
    key = STAT_WORDS.get(m.group(1).strip())
    if key is None:
        return None
    return (key, float(params[0]))

def apply_relic_sets(wearer: 'Character', battle: 'Battle') -> list[str]:
    from ..data import loader
    from ..engine.effects import Effect
    unresolved: list[str] = []
    all_sets = loader.relic_sets()
    for set_id, pieces in wearer.built.relic_sets.items():
        s = all_sets.get(str(set_id))
        if s is None:
            unresolved.append(f'遺物セット {set_id} (データ無し)')
            continue
        for n in (2, 4):
            if n > pieces:
                continue
            eff = s['effects'].get(str(n))
            if eff is None:
                continue
            label = f'{s['name']} {n}pc'
            impl_cls = SET_REGISTRY.get((str(set_id), n))
            if impl_cls is not None:
                impl_cls().on_equip(wearer, battle, list(eff['params']))
                continue
            auto = simple_stat_effect(eff['desc'], eff['params'])
            if auto is not None:
                key, value = auto
                battle.apply_effect(wearer, Effect(key=f'set.{set_id}.{n}.{wearer.id}', label=label, stats=StatSheet({key: value}), source_id=wearer.id))
                continue
            unresolved.append(label)
    return unresolved

def light_cone_build_stats(lc_id: str | None, superimpose: int) -> StatSheet:
    from ..data import loader
    if lc_id is None:
        return StatSheet()
    impl_cls = LC_REGISTRY.get(str(lc_id))
    declare = getattr(impl_cls, 'build_stats', None) if impl_cls else None
    if declare is None:
        return StatSheet()
    lc = loader.light_cone(str(lc_id))
    params = list((lc['effect']['params'] or {}).get(str(superimpose)) or [])
    return declare(params)

def relic_set_build_stats(relic_sets: dict[str, int]) -> StatSheet:
    from ..data import loader
    out = StatSheet()
    all_sets = loader.relic_sets()
    for set_id, pieces in relic_sets.items():
        s = all_sets.get(str(set_id))
        if s is None:
            continue
        for n in (2, 4):
            eff = s['effects'].get(str(n))
            if n > int(pieces) or eff is None:
                continue
            impl_cls = SET_REGISTRY.get((str(set_id), n))
            if impl_cls is not None:
                declare = getattr(impl_cls, 'build_stats', None)
                if declare is not None:
                    out = out.merged(declare(list(eff['params'])))
                continue
            auto = simple_stat_effect(eff['desc'], eff['params'])
            if auto is not None:
                out.add(auto[0], auto[1])
    return out

def apply_light_cone(wearer: 'Character', battle: 'Battle') -> list[str]:
    from ..data import loader
    lc_id = wearer.built.light_cone_id
    if lc_id is None:
        return []
    lc = loader.light_cone(lc_id)
    superimpose = str(wearer.built.superimpose)
    params = list((lc['effect']['params'] or {}).get(superimpose) or [])
    impl_cls = LC_REGISTRY.get(str(lc_id))
    if impl_cls is None:
        return [f'光円錐「{lc['name']}」']
    return list(impl_cls().on_equip(wearer, battle, params) or [])
