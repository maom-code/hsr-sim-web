from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.memosprite import Memosprite, MemospriteSpec
from ...engine.resources import CounterPool
from ...model.enums import DamageType, Element, Path
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1415'
ELEMENT = Element.ICE
REMINISCENCE = '追憶'
FUTURE = 'cyrene.talent.future'
POEM_PRIORITY = ('1407', '1413', '1403')
KEY_TEAM_DMG = 'cyrene.talent.team_dmg'
KEY_BARRIER = 'cyrene.skill.barrier'
KEY_RIPPLE = 'cyrene.ult.ripple'
KEY_ULT_CRIT = 'cyrene.ult.crit_rate'
KEY_MEMO_HP = 'cyrene.memo.max_hp'
KEY_POEM = 'cyrene.memo.poem'
KEY_TRACE_DMG = 'cyrene.trace.team_dmg'
KEY_TRACE_RESPEN = 'cyrene.trace.res_pen'
KEY_E6_DEF_DOWN = 'cyrene.e6.def_down'
SKY_POEM = '『天空』に捧ぐ詩'
STORY = '物語'
MEMO_SKILL_ALLY = '精霊スキル・味方対象'
MEMO_SKILL_ENEMY = '精霊スキル・敵対象'
_AUTO_POEMS = ('1409',)
GOLDEN_KIN = frozenset({'1403', '1407', '1409', '1413', '1415'})

@register(CHAR_ID)
class Cyrene:
    speed_target = 180.0
    unimplemented = ('黄金裔のうち編成に入らない 10 人ぶんの専用効果（アグライア・モーディス・アナイクスなど）。実装済みはキャストリス・長夜月・トリビー・ヒアンシーの 4 本', '黄金裔の判定はデータに印が無いので、デミウルゴスの詩が名指ししている顔ぶれから起こした固定リスト（`GOLDEN_KIN`）で見ている')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _memo_skills(self) -> dict:
        return self._char()['memosprite']['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _ripple(self, me) -> bool:
        return me.effects.has(KEY_RIPPLE)
    rotation_label = '最初だけスキル'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if battle.skill_uses.get(me.id, 0) == 0 else Action.BASIC

    def can_use_skill(self, me, battle) -> bool:
        return not self._ripple(me)

    def on_battle_start(self, me, battle) -> None:
        self._poem_done: set[str] = set()
        self._ult_used = False
        self._donors: set[str] = set()
        self._true_self_dances = 0
        self._dances = 0
        talent = self._skills()['141504']
        lv = self._levels(me)['Talent']
        gain, team_dmg, cap, need, need_ripple = (p(talent, lv, i) for i in (1, 2, 3, 4, 5))
        counter = me.counter(REMINISCENCE, maximum=cap)
        me.resource = CounterPool(counter, threshold=need, cost=need_ripple)
        self._need_ripple = need_ripple
        battle.apply_to_team(lambda who: Effect(key=KEY_TEAM_DMG, label='天賦・与ダメージ', stats=StatSheet.of(dmg_pct=team_dmg), source_id=me.id))
        keeps_future = self._traces().get('1415101') is not None

        def consume_future(actor) -> None:
            if actor is None or actor is me or (not actor.effects.has(FUTURE)):
                return
            battle.gain_counter(me, REMINISCENCE, gain)
            owner = getattr(actor, 'attributed_to', actor)
            if owner is not me:
                self._donors.add(actor.id)
            if not (keeps_future and isinstance(actor, Memosprite)):
                battle.remove_effect(actor, FUTURE)

        def on_turn_start(actor=None, **kw):
            if not isinstance(actor, Memosprite):
                consume_future(actor)

        def on_memo_skill(memo=None, **kw):
            consume_future(memo)
        battle.bus.subscribe(Event.TURN_START, on_turn_start, owner_id=me.id)
        battle.bus.subscribe(Event.ON_MEMO_SKILL, on_memo_skill, owner_id=me.id)
        if keeps_future:

            def on_summon(memo=None, source_id=None, **kw):
                if memo is not None and source_id != me.id:
                    self._grant_future(me, battle, only=memo)
            battle.bus.subscribe(Event.ON_MEMO_SUMMON, on_summon, owner_id=me.id)
        a4 = self._traces().get('1415102')
        if a4:
            steps = a4['params'][0]
            allies = sum((1 for c in battle.team if c is not me and (c.id in GOLDEN_KIN or c.built.path is Path.REMEMBRANCE)))
            if allies:
                battle.gain_counter(me, REMINISCENCE, steps[min(allies, len(steps)) - 1])
        if self._traces().get('1415103'):
            self._refresh_speed_trace(me, battle)

            def on_speed_changed(effect=None, **kw):
                if effect is not None and getattr(effect, 'key', None) in (KEY_TRACE_DMG, KEY_TRACE_RESPEN):
                    return
                self._refresh_speed_trace(me, battle)
            battle.bus.subscribe(Event.ON_EFFECT_APPLIED, on_speed_changed, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_START, on_speed_changed, owner_id=me.id)
            battle.bus.subscribe(Event.ON_MEMO_SUMMON, on_speed_changed, owner_id=me.id)
        if me.eidolon >= 2:
            battle.gain_counter(me, REMINISCENCE, self._char()['ranks']['2']['params'][0])
        for ally in battle.team:
            if ally.id in _AUTO_POEMS:
                self._poem_hyacine(me, battle, ally, with_energy=False)
        self._grant_future(me, battle)

    def _refresh_speed_trace(self, me, battle) -> None:
        a6 = self._traces().get('1415103')
        if not a6:
            return
        threshold, per_speed, cap_over, dmg_up = a6['params'][0]
        spd = me.stats[StatKey.SPD]
        over = min(max(0.0, spd - threshold), cap_over)
        want = dmg_up if spd >= threshold else 0.0
        if want > 0 and (not me.effects.has(KEY_TRACE_DMG)):
            battle.apply_to_team(lambda who: Effect(key=KEY_TRACE_DMG, label='軌跡・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=me.id))
        elif want <= 0 and me.effects.has(KEY_TRACE_DMG):
            for who in battle.team:
                battle.remove_effect(who, KEY_TRACE_DMG)
        res_pen = over * per_speed
        targets = [me, *[m for m in battle.memosprites if m.summoner is me]]
        for who in targets:
            current = who.effects.get(KEY_TRACE_RESPEN)
            if current is not None and abs(current.contribution()[StatKey.RES_PEN_ICE] - res_pen) < 1e-09:
                continue
            if res_pen <= 0:
                if current is not None:
                    battle.remove_effect(who, KEY_TRACE_RESPEN)
                continue
            battle.apply_effect(who, Effect(key=KEY_TRACE_RESPEN, label='軌跡・氷耐性貫通', stats=StatSheet.of(res_pen_ice=res_pen), source_id=me.id))

    def _grant_future(self, me, battle, *, only=None) -> None:
        targets = [only] if only is not None else [*[c for c in battle.team if c is not me], *[m for m in battle.memosprites if m.summoner is not me]]
        for who in targets:
            battle.apply_effect(who, Effect(key=FUTURE, label='未来', stacking=Stacking.UNIQUE, source_id=me.id))

    def basic(self, me, battle) -> None:
        if self._ripple(me):
            self._enhanced_basic(me, battle)
        else:
            s = self._skills()['141501']
            lv = self._levels(me)['Normal']
            battle.gain_counter(me, REMINISCENCE, p(s, lv, 2))
            battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
            battle.gain_sp(s['sp_gain'])
        self._grant_future(me, battle)

    def _enhanced_basic(self, me, battle) -> None:
        s = self._skills()['141508']
        lv = self._levels(me)['Normal']
        battle.gain_counter(me, REMINISCENCE, p(s, lv, 2))
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, lv, 3)),), toughness=s.get('toughness'), label=s['name'])
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.HP, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'] + '（全体）')

    def technique(self, me, battle) -> None:
        s = self._skills()['141502']
        lv = self._levels(me)['BPSkill']
        share, turns = (p(s, lv, 1), p(s, lv, 2))
        self._deploy_barrier(me, battle, share, int(turns))

    def skill(self, me, battle) -> None:
        s = self._skills()['141502']
        lv = self._levels(me)['BPSkill']
        share, turns, gain = (p(s, lv, i) for i in (1, 2, 3))
        battle.spend_sp(s['sp_cost'])
        battle.gain_counter(me, REMINISCENCE, gain)
        self._deploy_barrier(me, battle, share, int(turns))
        self._grant_future(me, battle)

    def _deploy_barrier(self, me, battle, share: float, turns: int | None) -> None:
        eff = Effect(key=KEY_BARRIER, label='結界', duration=None if turns is None else Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id)
        applied = battle.apply_effect(me, eff)
        if applied is None:
            return
        battle._drop_listeners(applied)
        applied.listener_ids.append(battle.bus.subscribe(Event.AFTER_DAMAGE, lambda **kw: self._barrier_extra(me, battle, share, **kw), owner_id=me.id))

    def _barrier_extra(self, me, battle, share: float, *, source=None, amount: float=0.0, dmg_type=None, **kw) -> None:
        if source is None or amount <= 0 or dmg_type is DamageType.TRUE:
            return
        target = battle.target
        if target is None:
            return
        if me.eidolon >= 2:
            _, _, per_ally, cap = self._char()['ranks']['2']['params']
            share += min(len(self._poem_done) * per_ally, cap)
        dealt = battle.deal_damage(me, target, ELEMENT, DamageType.TRUE, (), flat=amount * share)
        if dealt:
            battle._log(me.name, '結界・確定ダメージ', dealt)

    def ultimate(self, me, battle) -> None:
        if self._ult_used:
            self._encore(me, battle)
            return
        self._ult_used = True
        s = self._skills()['141503']
        lv = self._levels(me)['Ultra']
        hp_ratio, crit_rate = (p(s, lv, 1), p(s, lv, 3))
        dragon = self._summon(me, battle, hp_ratio)
        for who in (me, dragon):
            battle.apply_effect(who, Effect(key=KEY_ULT_CRIT, label='必殺技・会心率', stats=StatSheet.of(crit_rate=crit_rate), source_id=me.id))
        battle.apply_effect(me, Effect(key=KEY_RIPPLE, label='過去のさざ波', source_id=me.id))
        me.resource.threshold = self._need_ripple
        skill = self._skills()['141502']
        self._deploy_barrier(me, battle, p(skill, self._levels(me)['BPSkill'], 1), None)
        for ally in battle.team:
            if ally is me:
                continue
            pool = ally.resource
            if isinstance(pool, CounterPool):
                need = pool._need()
                if need is not None:
                    pool.counter.current = max(pool.counter.current, need)
            elif hasattr(pool, 'maximum'):
                pool.current = pool.maximum
        if me.eidolon >= 6:
            forward = self._char()['ranks']['6']['params'][0]
            for ally in battle.team:
                battle.advance_forward(ally, forward)
        battle.act_now(dragon)
        self._gain_story(me, battle, dragon)

    def _encore(self, me, battle) -> None:
        dragon = battle.memosprite_of(me)
        if dragon is None:
            return
        battle._log(me.name, self._skills()['141514']['name'])
        battle.act_now(dragon)
        self._gain_story(me, battle, dragon)

    def _summon(self, me, battle, hp_ratio: float) -> Memosprite:
        memo_talent = self._memo_skills()['1141503']
        hp_up = p(memo_talent, self._levels(me)['ServantTalent'], 1)
        spec = MemospriteSpec(name=self._char()['memosprite']['name'], hp_base=0.0, hp_ratio=hp_ratio, hp_from=StatKey.HP, spd_base=0.0, spd_ratio=0.0, aggro=self._char()['memosprite']['aggro'])
        dragon = battle.summon_memosprite(me, spec)
        self._gain_story(me, battle, dragon)
        for who in (me, dragon):
            battle.apply_effect(who, Effect(key=KEY_MEMO_HP, label='精霊天賦・最大HP', stats=StatSheet.of(hp_pct=hp_up), source_id=me.id))
        return dragon

    def memo_turn(self, memo, battle) -> None:
        me = memo.summoner
        target = self._next_poem_target(me, battle)
        if target is not None:
            self._poem(me, memo, battle, target)
        else:
            self._dance(me, memo, battle)
        battle.tick_own_effects(memo)

    def _next_poem_target(self, me, battle):
        order = [cid for cid in POEM_PRIORITY if cid in GOLDEN_KIN] + [c.id for c in battle.team if c.id in GOLDEN_KIN and c.id not in POEM_PRIORITY]
        for cid in order:
            if cid in self._poem_done or cid == me.id or cid in _AUTO_POEMS:
                continue
            for c in battle.team:
                if c.id == cid:
                    return c
        return None

    def _poem(self, me, memo, battle, target) -> None:
        s = self._memo_skills()['1141502']
        self._poem_done.add(target.id)
        battle._log(memo.name, f'{s['name']} -> {target.name}')
        battle.gain_counter(me, MEMO_SKILL_ALLY, 1)
        special = _POEMS.get(target.id)
        if special is not None:
            special(self, me, battle, target)
            return
        lv = self._levels(me)['Servant']
        dmg_up, turns = (p(s, lv, 2), p(s, lv, 3))
        for who in (target, *[m for m in battle.memosprites if m.summoner is target]):
            battle.apply_effect(who, Effect(key=KEY_POEM, label='詩・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=target.id), stacking=Stacking.REFRESH, source_id=me.id))

    def _poem_castorice(self, me, battle, target) -> None:
        s = self._memo_skills()['1141517']
        lv = self._levels(me)['Servant']
        per_percent, cap_ratio, per_percent_few, few = (p(s, lv, i) for i in (2, 3, 5, 6))
        hook = getattr(battle.impl_of(target), 'grant_newbud_overflow', None)
        if hook is None:
            return
        hook(target, battle, cap_ratio=cap_ratio, per_percent=per_percent, per_percent_few=per_percent_few, few_enemies=int(few))

    def _poem_nagayotsuki(self, me, battle, target) -> None:
        from .nagayotsuki import DREAM_DMG_BONUS, MEMO_CRIT_BONUS, MEMOSTHENE
        s = self._memo_skills()['1141524']
        lv = self._levels(me)['Servant']
        dream_dmg, quality, crit_ratio = (p(s, lv, i) for i in (1, 2, 3))
        battle.gain_counter(target, DREAM_DMG_BONUS, dream_dmg)
        battle.gain_counter(target, MEMO_CRIT_BONUS, crit_ratio)

        def on_action(source_id=None, **kw):
            if source_id == target.id:
                battle.gain_counter(target, MEMOSTHENE, quality)
        for event in (Event.ON_SKILL_USED, Event.ON_ULT_USED):
            battle.bus.subscribe(event, on_action, owner_id=me.id)

    def _poem_tribbie(self, me, battle, target) -> None:
        from .tribbie import ZONE_EXTRA_HITS
        s = self._memo_skills()['1141515']
        lv = self._levels(me)['Servant']
        extra_hits, def_ignore = (p(s, lv, 1), p(s, lv, 2))
        battle.apply_effect(target, Effect(key=KEY_POEM, label='詩・防御無視', stats=StatSheet.of(def_ignore=def_ignore), source_id=me.id))
        battle.gain_counter(target, ZONE_EXTRA_HITS, extra_hits)

    def _poem_hyacine(self, me, battle, target, *, with_energy: bool=True) -> None:
        s = self._memo_skills()['1141519']
        lv = self._levels(me)['Servant']
        share, energy = (p(s, lv, 1), p(s, lv, 2))
        if with_energy:
            battle.gain_energy(target, energy, apply_regen=False)

        def on_heal(healer=None, amount: float=0.0, **kw):
            if healer is None or amount <= 0:
                return
            owner = getattr(healer, 'attributed_to', healer)
            if owner is not target:
                return
            if battle.counter_value(target, SKY_POEM) <= 0:
                return
            battle.add_healing(healer, amount * share)

        def on_consume(source_id=None, **kw):
            if source_id == target.id:
                battle.spend_counter(target, SKY_POEM, 1)

        def on_memo_skill(source_id=None, **kw):
            if source_id == me.id:
                battle.gain_counter(target, SKY_POEM, 2)
        battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=me.id)
        battle.bus.subscribe(Event.ON_MEMO_SKILL, on_memo_skill, owner_id=me.id)
        for event in (Event.ON_SKILL_USED, Event.ON_ULT_USED):
            battle.bus.subscribe(event, on_consume, owner_id=me.id)

    def _gain_story(self, me, battle, dragon) -> None:
        s = self._memo_skills()['1141526']
        need = p(s, self._levels(me)['Servant'], 2)
        battle.gain_counter(me, STORY, 1)
        if battle.counter_value(me, STORY) < need:
            return
        battle.spend_counter(me, STORY)
        battle._log(dragon.name, '物語・追加ターン')
        self._dance(me, dragon, battle, via_true_self=True)

    def _dance(self, me, memo, battle, *, via_true_self: bool=False) -> None:
        battle.gain_counter(me, MEMO_SKILL_ENEMY, 1)
        s = self._memo_skills()['1141501']
        mult = p(s, self._levels(me)['Servant'], 1)
        extra = len(self._donors)
        bounce = p(self._memo_skills()['1141526'], self._levels(me)['Servant'], 1)
        self._dances += 1
        bounce_mult = 1.0
        if me.eidolon >= 4:
            per, max_stacks = self._char()['ranks']['4']['params']
            bounce_mult += min(self._dances, int(max_stacks)) * per
        if via_true_self:
            if me.eidolon >= 1:
                gain, more = self._char()['ranks']['1']['params']
                battle.gain_counter(me, REMINISCENCE, gain)
                extra += int(more)
            self._true_self_dances += 1
            self._eidolon_6_on_dance(me, battle, memo)
        battle.attack(memo, ELEMENT, DamageType.MEMO, aoe=((StatKey.HP, mult),), random=((StatKey.HP, bounce),) if extra else (), random_hits=extra, independent_random=bounce_mult, toughness=s.get('toughness'), label=s['name'] + (f'（+{extra}ヒット）' if extra else ''))

    def _eidolon_6_on_dance(self, me, battle, memo) -> None:
        if me.eidolon < 6:
            return
        _, def_down, forward = self._char()['ranks']['6']['params']
        if self._true_self_dances == 1:
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_E6_DEF_DOWN, label='星魂6・防御力ダウン', stats=StatSheet.of(def_down=def_down), source_id=me.id))
        else:
            for ally in battle.team:
                battle.advance_forward(ally, forward)
_POEMS = {'1407': Cyrene._poem_castorice, '1413': Cyrene._poem_nagayotsuki, '1403': Cyrene._poem_tribbie, '1409': Cyrene._poem_hyacine}
