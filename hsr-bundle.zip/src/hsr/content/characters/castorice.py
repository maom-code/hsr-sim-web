from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking, TickTiming
from ...engine.events import Event
from ...engine.memosprite import Memosprite, MemospriteSpec
from ...engine.resources import CounterPool
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1407'
ELEMENT = Element.QUANTUM
NEWBUD = '新蕾'
EMBER = '熾意'
NEWBUD_CAP_PER_LEVEL = 34000.0 / (80 * 4)
KEY_TALENT_DMG = 'castorice.talent.dmg'
KEY_ZONE_RES = 'castorice.ult.zone'
KEY_SUMMON_DMG = 'castorice.memo.summon_dmg'
KEY_TRACE_SPD = 'castorice.trace.speed'
KEY_TRACE_BREATH = 'castorice.trace.breath_dmg'
KEY_E4_HEAL = 'castorice.e4.heal_taken'
KEY_E6_RESPEN = 'castorice.e6.res_pen'
_MAX_BREATHS = 12

@register(CHAR_ID)
class Castorice:
    unimplemented = ('精霊天賦「月の繭が覆う身躯」（味方の後陣。ダメージを死竜が肩代わりする）。敵が味方を落とさない前提の戦闘なので数字に効かない', '軌跡「反転した炬火」の後半（死竜がオーバーキルした時の速度 +100%）。敵の HP を削り切る戦闘を組んでいないので発動条件を作れない', '星魂 6 の「量子属性の弱点撃破効果」。撃破の属性別効果（纏縛など）がまだ無い')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _memo_skills(self) -> dict:
        return self._char()['memosprite']['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _newbud_cap(self, battle) -> float:
        return sum((c.level for c in battle.team)) * NEWBUD_CAP_PER_LEVEL

    def _dragon(self, me, battle) -> Memosprite | None:
        return battle.memosprite_of(me)

    def on_battle_start(self, me, battle) -> None:
        self._breath_stage = 0
        self._dragon_turns = 0
        self._e2_pending = False
        self._overflow_poem = None
        self._death_wing_bonus = 0.0
        self._heal_converted: dict[str, float] = {}
        cap = self._newbud_cap(battle)
        counter = me.counter(NEWBUD, maximum=cap)
        me.resource = CounterPool(counter, threshold=cap, cost=0.0)
        battle._log(me.name, f'{NEWBUD}の上限 {cap:,.0f}')
        battle.bus.subscribe(Event.ON_HP_LOSS, self._make_hp_loss(me, battle), owner_id=me.id)
        if self._traces().get('1407101'):
            battle.bus.subscribe(Event.ON_HEAL, self._make_heal_convert(me, battle), owner_id=me.id)
            battle.bus.subscribe(Event.TURN_END, lambda **kw: self._heal_converted.clear(), owner_id=me.id)
        if self._traces().get('1407102'):
            refresh = lambda **kw: self._refresh_speed(me, battle)
            self._refresh_speed(me, battle)
            for event in (Event.TURN_START, Event.ON_HP_LOSS, Event.ON_HEAL):
                battle.bus.subscribe(event, refresh, owner_id=me.id)
        if me.eidolon >= 4:
            bonus = self._char()['ranks']['4']['params'][0]
            battle.apply_to_team(lambda who: Effect(key=KEY_E4_HEAL, label='星魂4・回復量', stats=StatSheet.of(heal_taken=bonus), source_id=me.id))
        if me.eidolon >= 6:
            res_pen = self._char()['ranks']['6']['params'][0]
            battle.apply_effect(me, Effect(key=KEY_E6_RESPEN, label='星魂6・量子耐性貫通', stats=StatSheet.of(res_pen_quantum=res_pen), source_id=me.id))

    def grant_newbud_overflow(self, me, battle, *, cap_ratio: float, per_percent: float, per_percent_few: float, few_enemies: int) -> None:
        base = self._newbud_cap(battle)
        me.counter(NEWBUD).maximum = base * cap_ratio
        me.resource.threshold = base
        self._overflow_poem = (base, per_percent, per_percent_few, few_enemies)
        battle._log(me.name, f'{NEWBUD}の上限 {base * cap_ratio:,.0f}（詩）')

    def _spend_for_summon(self, me, battle) -> None:
        self._death_wing_bonus = 0.0
        base = self._newbud_cap(battle)
        current = battle.counter_value(me, NEWBUD)
        if self._overflow_poem is not None:
            _, per_percent, per_percent_few, few_enemies = self._overflow_poem
            overflow = max(0.0, current - base)
            if overflow > 0:
                battle.spend_counter(me, NEWBUD, overflow)
                rate = per_percent
                if len(battle.alive_enemies) <= few_enemies:
                    rate += per_percent_few
                self._death_wing_bonus = overflow / base * 100.0 * rate
                battle._log(me.name, f'詩・晦翼のダメージ倍率 +{self._death_wing_bonus:.0%}')
        battle.spend_counter(me, NEWBUD, base)

    def _refresh_speed(self, me, battle) -> None:
        threshold, spd_up, _ = self._traces()['1407102']['params'][0]
        healthy = me.hp >= me.max_hp * threshold
        if healthy and (not me.effects.has(KEY_TRACE_SPD)):
            battle.apply_effect(me, Effect(key=KEY_TRACE_SPD, label='軌跡・速度', stats=StatSheet.of(spd_pct=spd_up), source_id=me.id))
        elif not healthy and me.effects.has(KEY_TRACE_SPD):
            battle.remove_effect(me, KEY_TRACE_SPD)

    def _make_hp_loss(self, me, battle):

        def on_hp_loss(target=None, amount: float=0.0, **kw):
            if target is None or amount <= 0:
                return
            dragon = self._dragon(me, battle)
            if dragon is None:
                battle.gain_counter(me, NEWBUD, amount)
            elif target is not dragon:
                dragon.heal(amount)
            self._talent_stacks(me, battle, dragon)
        return on_hp_loss

    def _talent_stacks(self, me, battle, dragon) -> None:
        s = self._skills()['140704']
        lv = self._levels(me)['Talent']
        dmg_up, max_stacks, turns = (p(s, lv, i) for i in (2, 3, 4))
        for who in (me, dragon):
            if who is None:
                continue
            battle.apply_effect(who, Effect(key=KEY_TALENT_DMG, label='天賦・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id))

    def _make_heal_convert(self, me, battle):
        trace = self._traces()['1407101']

        def on_heal(target=None, amount: float=0.0, **kw):
            ratio, per_unit_cap = trace['params'][0]
            if target is None or amount <= 0:
                return
            dragon = self._dragon(me, battle)
            if target is dragon:
                return
            cap = self._newbud_cap(battle) * per_unit_cap
            used = self._heal_converted.get(target.id, 0.0)
            converted = max(0.0, min(amount * ratio, cap - used))
            if converted <= 0:
                return
            self._heal_converted[target.id] = used + converted
            if dragon is None:
                battle.gain_counter(me, NEWBUD, converted)
            else:
                dragon.heal(converted)
        return on_heal

    def technique(self, me, battle) -> None:
        cost, hp_ratio, _seconds, _no_summon = params_at(self._skills()['140707'], 1)[:4]
        self._summon_dragon(me, battle, hp_ratio=hp_ratio)
        for ally in battle.team:
            battle.spend_hp(ally, ratio=cost)

    def _summon_dragon(self, me, battle, *, hp_ratio: float) -> Memosprite:
        ult = self._skills()['140703']
        lv = self._levels(me)['Ultra']
        speed = p(ult, lv, 1)
        cap_ratio = p(ult, lv, 3)
        res_down = p(ult, lv, 4)
        cap = self._newbud_cap(battle) * cap_ratio
        spec = MemospriteSpec(name=self._char()['memosprite']['name'], hp_base=cap, spd_base=speed, aggro=self._char()['memosprite']['aggro'], acts_immediately=True)
        dragon = battle.summon_memosprite(me, spec, entry_av=0.0)
        dragon.hp = dragon.max_hp * hp_ratio
        self._breath_stage = 0
        self._dragon_turns = 0
        talent = self._memo_skills()['1140705']
        tlv = self._levels(me)['ServantTalent']
        dmg_up, turns = (p(talent, tlv, 1), p(talent, tlv, 2))
        battle.apply_to_team(lambda who: Effect(key=KEY_SUMMON_DMG, label='精霊天賦・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        mine = me.effects.get(KEY_TALENT_DMG)
        if mine is not None:
            battle.apply_effect(dragon, Effect(key=KEY_TALENT_DMG, label='天賦・与ダメージ', stats=StatSheet(dict(mine.stats.values)), duration=Duration(turns=mine.duration.turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, max_stacks=mine.max_stacks, stacks=mine.stacks, source_id=me.id))
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_ZONE_RES, label='遺世の冥域', stats=StatSheet.of(res_down=res_down), source_id=me.id))
        if me.eidolon >= 2:
            gain, cap_ember, _ = self._char()['ranks']['2']['params']
            battle.gain_counter(me, EMBER, gain, maximum=cap_ember)
            battle.advance_forward(me, 1.0)
            self._e2_pending = True
        return dragon

    def _dismiss_dragon(self, dragon, battle) -> None:
        me = dragon.summoner
        self._death_wing(dragon, battle, '1140706')
        for e in battle.enemies:
            battle.remove_effect(e, KEY_ZONE_RES)
        dragon.hp = 0.0
        battle.dismiss_memosprite(dragon)
        self._breath_stage = 0

    def _hp_cost_targets(self, me, battle) -> list:
        dragon = self._dragon(me, battle)
        return [*battle.team, *[m for m in battle.memosprites if m is not dragon]]

    def basic(self, me, battle) -> None:
        s = self._skills()['140701']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'], independent=self._eidolon_1(me, battle))
        battle.gain_sp(s['sp_gain'])

    def skill(self, me, battle) -> None:
        if self._dragon(me, battle) is not None:
            self._enhanced_skill(me, battle)
        else:
            self._base_skill(me, battle)

    def _base_skill(self, me, battle) -> None:
        s = self._skills()['140702']
        lv = self._levels(me)['BPSkill']
        cost, main, adjacent = (p(s, lv, i) for i in (1, 2, 3))
        battle.spend_sp(s['sp_cost'])
        for who in self._hp_cost_targets(me, battle):
            battle.spend_hp(who, ratio=cost)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.HP, main),), adjacent=((StatKey.HP, adjacent),), toughness=s.get('toughness'), label=s['name'], independent=self._eidolon_1(me, battle))

    def _enhanced_skill(self, me, battle) -> None:
        s = self._skills()['140709']
        lv = self._levels(me)['BPSkill']
        cost, mine, dragon_mult = (p(s, lv, i) for i in (1, 2, 3))
        battle.spend_sp(s['sp_cost'])
        for who in self._hp_cost_targets(me, battle):
            battle.spend_hp(who, ratio=cost)
        dragon = self._dragon(me, battle)
        ind = self._eidolon_1(me, battle)
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.HP, mine),), toughness=s.get('toughness'), label=s['name'], independent=ind)
        if dragon is not None:
            battle.attack(dragon, ELEMENT, DamageType.MEMO, flat_aoe=me.stats[StatKey.HP] * dragon_mult, toughness=s.get('toughness'), label=s['name'] + '（死竜）', independent=ind)
        if me.eidolon >= 2 and getattr(self, '_e2_pending', False):
            self._e2_pending = False
            ratio = self._char()['ranks']['2']['params'][2]
            battle.gain_counter(me, NEWBUD, self._newbud_cap(battle) * ratio)

    def ultimate(self, me, battle) -> None:
        self._spend_for_summon(me, battle)
        self._summon_dragon(me, battle, hp_ratio=1.0)

    def memo_turn(self, dragon, battle) -> None:
        me = dragon.summoner
        breath = self._memo_skills()['1140702']
        lv = self._levels(me)['Servant']
        hp_cost_ratio = p(breath, lv, 1)
        low_hp_ratio = p(breath, lv, 5)
        fired = False
        for _ in range(_MAX_BREATHS):
            if dragon.hp <= 1.0:
                break
            if me.eidolon >= 2 and battle.counter_value(me, EMBER) >= 1:
                self._breath(dragon, battle)
                battle.spend_counter(me, EMBER, 1)
                fired = True
                continue
            if dragon.hp <= dragon.max_hp * low_hp_ratio:
                self._breath(dragon, battle)
                dragon.hp = 1.0
                self._dismiss_dragon(dragon, battle)
                return
            self._breath(dragon, battle)
            dragon.take_hp_cost(dragon.max_hp * hp_cost_ratio)
            fired = True
        if not fired:
            self._claw(dragon, battle)
        self._dragon_turns += 1
        turns = int(p(self._skills()['140703'], self._levels(me)['Ultra'], 2))
        if self._dragon_turns >= turns:
            self._dismiss_dragon(dragon, battle)

    def _claw(self, dragon, battle) -> None:
        me = dragon.summoner
        s = self._memo_skills()['1140701']
        mult = p(s, self._levels(me)['Servant'], 1)
        self._memo_attack(dragon, battle, mult, s['name'])

    def _breath(self, dragon, battle) -> None:
        me = dragon.summoner
        s = self._memo_skills()['1140702']
        lv = self._levels(me)['Servant']
        mults = [p(s, lv, i) for i in (2, 3, 4)]
        mult = mults[min(self._breath_stage, len(mults) - 1)]
        self._breath_stage += 1
        trace = self._traces().get('1407103')
        if trace:
            dmg_up, max_stacks = trace['params'][0]
            battle.apply_effect(dragon, Effect(key=KEY_TRACE_BREATH, label='軌跡・息吹の与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=1, tick_on=TickTiming.OWNER_TURN_END, tick_owner_id=dragon.id), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id))
        self._memo_attack(dragon, battle, mult, f'{s['name']}（{mult:.1%}）')

    def _death_wing(self, dragon, battle, skill_id: str) -> None:
        me = dragon.summoner
        s = self._memo_skills()[skill_id]
        lv = self._levels(me)['Servant' if s.get('type') == 'Servant' else 'ServantTalent']
        mult, hits, heal_ratio, heal_flat = (p(s, lv, i) for i in (1, 2, 3, 4))
        if me.eidolon >= 6:
            hits += self._char()['ranks']['6']['params'][1]
        mult *= 1.0 + self._death_wing_bonus
        base_ind = self._eidolon_1(me, battle)
        battle.attack(dragon, ELEMENT, DamageType.MEMO, flat_random=me.stats[StatKey.HP] * mult, random_hits=int(hits), toughness=s.get('toughness'), label=s['name'], independent=base_ind)
        healing = me.stats[StatKey.HP] * heal_ratio + heal_flat
        for ally in battle.team:
            battle.heal(me, ally, healing, label=s['name'])

    def _memo_attack(self, dragon, battle, mult: float, label: str) -> None:
        me = dragon.summoner
        battle.attack(dragon, ELEMENT, DamageType.MEMO, flat_aoe=me.stats[StatKey.HP] * mult, label=label, independent=self._eidolon_1(me, battle))

    def _eidolon_1(self, me, battle):
        if me.eidolon < 1:
            return 1.0
        high, low, mid_mult, high_mult = self._char()['ranks']['1']['params']

        def factor(enemy) -> float:
            ratio = enemy.hp / enemy.max_hp if enemy.max_hp else 1.0
            if ratio <= low:
                return high_mult
            if ratio <= high:
                return mid_mult
            return 1.0
        return factor
