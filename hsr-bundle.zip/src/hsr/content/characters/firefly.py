from __future__ import annotations
from contextlib import contextmanager
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1310'
ELEMENT = Element.FIRE
KEY_CC = 'firefly.ult.combustion'
KEY_CC_ATTACK = 'firefly.ult.attack'
KEY_A4_SB = 'firefly.trace.super_break'
KEY_A6_BE = 'firefly.trace.break_effect'
KEY_E1 = 'firefly.e1.def_ignore'

@register(CHAR_ID)
class Firefly:
    unimplemented = ('天賦の被ダメージ軽減と効果抵抗（敵が攻撃しない前提）', '強化戦闘スキル・秘技の「炎属性弱点を付与する」（弱点撃破をオンにすると全属性弱点なので差が出ない）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        self._cc = False
        self._timer: Countdown | None = None
        self._e2_ready = True
        self._e2_pending = False
        self._in_enhanced = False
        self._alpha_used = 0
        t = params_at(self._skills()['131004'], self._levels(me)['Talent'])
        pool = me.resource
        if getattr(pool, 'maximum', None) and float(pool.current) < pool.maximum * t[1]:
            pool.current = pool.maximum * t[1]
        self._refresh_be(me, battle)

        def on_break(source=None, **kw):
            if source is not me or not self._cc:
                return
            a2 = self._traces().get('1310101')
            if a2 and self._in_enhanced and (self._timer is not None):
                _, delay, times = a2['params'][0][:3]
                if self._alpha_used < int(times):
                    self._alpha_used += 1
                    battle.delay_action(self._timer, delay)
            if me.eidolon >= 2 and self._e2_ready:
                self._e2_ready = False
                self._e2_pending = True

        def on_turn_end(actor=None, **kw):
            if actor is me and self._e2_pending:
                self._e2_pending = False
                battle.extra_turn(me)

        def on_turn_start(actor=None, **kw):
            if actor is me:
                self._e2_ready = True
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=me.id)
        battle.bus.subscribe(Event.TURN_START, on_turn_start, owner_id=me.id)

    def _refresh_be(self, me, battle) -> None:
        a6 = self._traces().get('1310103')
        if not a6:
            return
        floor, step, per = a6['params'][0][:3]
        battle.remove_effect(me, KEY_A6_BE)
        over = max(0.0, me.stats[StatKey.ATK] - floor)
        battle.apply_effect(me, Effect(key=KEY_A6_BE, label='γモジュール・撃破特効', stats=StatSheet.of(break_effect=int(over // step) * per), source_id=me.id))

    def on_turn_start(self, me, battle) -> None:
        self._refresh_be(me, battle)

    def can_use_ultimate(self, me, battle) -> bool:
        return not self._cc

    @contextmanager
    def _enhanced_attack(self, me, battle):
        u = params_at(self._skills()['131003'], self._levels(me)['Ultra'])
        eff = u[1] + (self._rank(6)[1] if me.eidolon >= 6 else 0.0)
        stats = StatSheet.of(break_efficiency=eff, break_dmg_pct=u[0])
        a4 = self._traces().get('1310102')
        if a4:
            low, high, r_low, r_high = a4['params'][0][:4]
            be = me.stats[StatKey.BREAK_EFFECT]
            rate = r_high if be >= high else r_low if be >= low else 0.0
            if rate:
                stats.add(StatKey.SUPER_BREAK_RATE, rate)
        battle.apply_effect(me, Effect(key=KEY_CC_ATTACK, label='完全燃焼・強化攻撃', stats=stats, source_id=me.id))
        self._in_enhanced = True
        try:
            yield
        finally:
            self._in_enhanced = False
            battle.remove_effect(me, KEY_CC_ATTACK)

    def basic(self, me, battle) -> None:
        self._refresh_be(me, battle)
        if self._cc:
            s = self._skills()['131008']
            lv = self._levels(me)['Normal']
            battle.heal(me, me, me.max_hp * p(s, lv, 2), label=s['name'])
            with self._enhanced_attack(me, battle):
                battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
            battle.gain_sp(s.get('sp_gain') or 1, actor=me)
            return
        s = self._skills()['131001']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    @property
    def skill_sp_cost(self):
        me = getattr(self, '_me', None)
        if me is not None and self._cc and (me.eidolon >= 1):
            return 0
        return None

    def skill(self, me, battle) -> None:
        self._me = me
        self._refresh_be(me, battle)
        if self._cc:
            self._overload(me, battle)
            return
        s = self._skills()['131002']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        mult, hp_cost, ep_ratio, advance = (p(s, lv, i) for i in (1, 2, 3, 4))
        battle.spend_hp(me, amount=me.max_hp * hp_cost)
        battle.gain_energy(me, me.resource.maximum * ep_ratio, apply_regen=False)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        battle.advance_forward(me, advance)

    def _overload(self, me, battle) -> None:
        s = self._skills()['131009']
        lv = self._levels(me)['BPSkill']
        main, adj, _, _, main_be, adj_be, cap = (p(s, lv, i) for i in range(1, 8))
        heal = 0.25
        cost = battle.skill_cost(me)
        if cost:
            battle.spend_sp(cost, actor=me)
        battle.heal(me, me, me.max_hp * heal, label=s['name'])
        be = min(me.stats[StatKey.BREAK_EFFECT], cap)
        if me.eidolon >= 1:
            battle.apply_effect(me, Effect(key=KEY_E1, label='星魂1・防御無視', stats=StatSheet.of(def_ignore=self._rank(1)[0]), source_id=me.id))
        with self._enhanced_attack(me, battle):
            battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, main_be * be + main),), adjacent=((StatKey.ATK, adj_be * be + adj),), toughness=s.get('toughness'), label=s['name'])
        battle.remove_effect(me, KEY_E1)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['131003']
        lv = self._levels(me)['Ultra']
        spd, cd_spd = (p(s, lv, 3), p(s, lv, 4))
        self._cc = True
        self._me = me
        before = me.speed()
        stats = StatSheet.of(spd=spd)
        a2 = self._traces().get('1310101')
        if a2:
            stats.add(StatKey.BREAK_EFFECT, a2['params'][0][0])
        self._alpha_used = 0
        if me.eidolon >= 4:
            stats.add(StatKey.EFFECT_RES, self._rank(4)[0])
        if me.eidolon >= 6:
            stats.add(StatKey.RES_PEN_FIRE, self._rank(6)[0])
        battle.apply_effect(me, Effect(key=KEY_CC, label='完全燃焼', stats=stats, source_id=me.id))
        if any((sl.actor is me for sl in battle.queue.slots)):
            battle.queue.rescale(me, before)
        battle.advance_forward(me, 1.0)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
        self._timer = battle.add_countdown(Countdown(name='完全燃焼', spd=cd_spd, on_turn=lambda: self._end(me, battle)), order=me.position)
        battle.gain_energy(me, s['energy'])

    def _end(self, me, battle) -> None:
        self._cc = False
        before = me.speed()
        battle.remove_effect(me, KEY_CC)
        if any((sl.actor is me for sl in battle.queue.slots)):
            battle.queue.rescale(me, before)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
            self._timer = None

    def technique(self, me, battle) -> None:
        tech = self._skills()['131007']
        mult = params_at(tech, 1)[1]
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult),), toughness=tech.get('toughness'), label=tech['name'])
