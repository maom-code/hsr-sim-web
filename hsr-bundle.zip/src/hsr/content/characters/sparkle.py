from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1306'
ELEMENT = Element.QUANTUM
SKILL_PRIORITY = ('1407', '1507', '1504', '1506', '1501', '1415', '1413', '1509', '1508', '1015', '1014', '1510', '1505', '1408')
KEY_SKILL_CD = 'sparkle.skill.crit_dmg'
KEY_PHANTOM = 'sparkle.talent.phantom'
KEY_PHANTOM_VULN = 'sparkle.talent.phantom.vuln'
KEY_CIPHER = 'sparkle.ult.cipher'
KEY_A6_ATK = 'sparkle.trace.atk'
KEY_E1_SPD = 'sparkle.e1.spd'
SP_RECORD = 'SP 記録値'

@register(CHAR_ID)
class Sparkle:
    target_override_label = '戦闘スキルの対象'
    target_override_priority = SKILL_PRIORITY
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _allies(self, battle) -> list:
        return [*battle.team, *[m for m in battle.memosprites if m.alive]]

    def on_battle_start(self, me, battle) -> None:
        self._me = me
        self._phantom: list[float] = []
        self._free_skill = False
        self._spent_turn: dict[str, float] = {}
        talent = self._skills()['130604']
        lv = self._levels(me)['Talent']
        battle.sp.maximum += int(p(talent, lv, 3)) + (1 if me.eidolon >= 4 else 0)

        def on_sp_spent(spent=0, actor=None, **kw):
            if spent <= 0:
                return
            who = actor if actor is not None else battle.acting
            self._add_phantom(me, battle, int(spent), who)
            a2 = self._traces().get('1306101')
            if a2 and who is not None and who.effects.has(KEY_SKILL_CD):
                battle.gain_energy(me, a2['params'][0][1], apply_regen=False)
            if who is not None and who in battle.team:
                self._spent_turn[who.id] = self._spent_turn.get(who.id, 0.0) + spent
                a4 = self._traces().get('1306102')
                if a4 and self._spent_turn[who.id] >= a4['params'][0][0]:
                    self._free_skill = True
        battle.bus.subscribe(Event.ON_SP_CHANGE, on_sp_spent, owner_id=me.id)

        def on_turn_start(actor=None, **kw):
            if actor is not None:
                self._spent_turn.pop(getattr(actor, 'id', ''), None)

        def on_turn_end(actor=None, **kw):
            if actor not in battle.team:
                return
            room = battle.sp.maximum - battle.sp.current
            stored = battle.counter_value(me, SP_RECORD)
            if room > 0 and stored > 0:
                n = int(min(room, stored))
                battle.spend_counter(me, SP_RECORD, n)
                battle.gain_sp(n, actor=me)
        battle.bus.subscribe(Event.TURN_START, on_turn_start, owner_id=me.id)
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=me.id)
        a6 = self._traces().get('1306103')
        if a6:
            battle.apply_to_team(lambda who: Effect(key=KEY_A6_ATK, label='軌跡・夜想曲', stats=StatSheet.of(atk_pct=a6['params'][0][0]), source_id=me.id))
        self._e1_speed(me, battle)

    def _e1_speed(self, me, battle) -> None:
        if me.eidolon < 1:
            return
        _, spd, turns = self._rank(1)[:3]
        before = me.speed()
        battle.apply_effect(me, Effect(key=KEY_E1_SPD, label='星魂1・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        if any((s.actor is me for s in battle.queue.slots)):
            battle.queue.rescale(me, before)

    def _add_phantom(self, me, battle, n: int, who) -> None:
        talent = self._skills()['130604']
        lv = self._levels(me)['Talent']
        per, turns, max_stacks = (p(talent, lv, 2), int(p(talent, lv, 1)), int(p(talent, lv, 4)))
        extra = p(self._skills()['130603'], self._levels(me)['Ultra'], 3)
        value = per + (extra if who is not None and who.effects.has(KEY_CIPHER) else 0.0)
        self._phantom = (self._phantom + [value] * n)[-max_stacks:]
        stacks = len(self._phantom)
        battle.apply_effect(me, Effect(key=KEY_PHANTOM, label=f'幻相 {stacks} 層', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        stats = StatSheet.of(vulnerability=sum(self._phantom))
        if me.eidolon >= 2:
            stats.add(StatKey.DEF_DOWN, self._rank(2)[0] * stacks)
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_PHANTOM_VULN, label='幻相・被ダメージ', stats=StatSheet(dict(stats.values)), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))

    def on_turn_start(self, me, battle) -> None:
        if not me.effects.has(KEY_PHANTOM):
            self._phantom = []

    @property
    def skill_sp_cost(self):
        return 0 if getattr(self, '_free_skill', False) else None

    def basic(self, me, battle) -> None:
        s = self._skills()['130601']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        energy = s['energy']
        a2 = self._traces().get('1306101')
        if a2:
            energy += a2['params'][0][0]
        battle.gain_energy(me, energy)

    def _skill_target(self, me, battle):
        return battle.resolve_target_override(me, self.target_override_priority)

    def _skill_buff(self, me, battle) -> float:
        s = self._skills()['130602']
        lv = self._levels(me)['BPSkill']
        ratio, flat = (p(s, lv, 1), p(s, lv, 2))
        if me.eidolon >= 6:
            ratio += self._rank(6)[0]
        return me.stats[StatKey.CRIT_DMG] * ratio + flat

    def _give_skill_buff(self, me, battle, who, value: float) -> None:
        s = self._skills()['130602']
        turns = int(p(s, self._levels(me)['BPSkill'], 3))
        stats = StatSheet.of(crit_dmg=value)
        a6 = self._traces().get('1306103')
        if a6:
            stats.add(StatKey.RES_PEN, a6['params'][0][1])
        battle.apply_effect(who, Effect(key=KEY_SKILL_CD, label='夢を泳ぐ魚・会心ダメージ', stats=stats, duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=me.id))

    def skill(self, me, battle) -> None:
        s = self._skills()['130602']
        lv = self._levels(me)['BPSkill']
        cost = battle.skill_cost(me)
        self._free_skill = False
        if cost:
            battle.spend_sp(cost, actor=me)
        target = self._skill_target(me, battle) or me
        value = self._skill_buff(me, battle)
        battle.target_ally(me, target)
        self._give_skill_buff(me, battle, target, value)
        if me.eidolon >= 6:
            for who in self._allies(battle):
                if who is not target and who.effects.has(KEY_CIPHER):
                    self._give_skill_buff(me, battle, who, value)
        if target is not me:
            battle.advance_forward(target, p(s, lv, 4))
        self._e1_speed(me, battle)
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['130603']
        lv = self._levels(me)['Ultra']
        sp = int(p(s, lv, 2)) + (1 if me.eidolon >= 4 else 0)
        before = battle.sp.current
        battle.gain_sp(sp, actor=me)
        over = sp - (battle.sp.current - before)
        if over > 0:
            battle.gain_counter(me, SP_RECORD, over, maximum=p(s, lv, 5))
        turns = int(p(s, lv, 4))
        stats = StatSheet()
        if me.eidolon >= 1:
            stats.add(StatKey.ATK_PCT, self._rank(1)[0])
        battle.target_team(me)
        battle.apply_to_team(lambda who: Effect(key=KEY_CIPHER, label='奇怪な謎', stats=StatSheet(dict(stats.values)), duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 6:
            holder = next((w for w in self._allies(battle) if w.effects.has(KEY_SKILL_CD)), None)
            if holder is not None:
                value = holder.effects.get(KEY_SKILL_CD).stats[StatKey.CRIT_DMG]
                for who in self._allies(battle):
                    if who is not holder and who.effects.has(KEY_CIPHER):
                        self._give_skill_buff(me, battle, who, value)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['130607']
        sp, energy = params_at(tech, 1)[:2]
        battle.gain_sp(int(sp), actor=me)
        battle.gain_energy(me, energy, apply_regen=False)
