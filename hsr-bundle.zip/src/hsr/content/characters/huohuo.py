from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1217'
ELEMENT = Element.WIND
KEY_EXORCISM = 'huohuo.talent.exorcism'
KEY_ULT_ATK = 'huohuo.ult.atk'
KEY_E1_SPD = 'huohuo.e1.speed'
KEY_E6_DMG = 'huohuo.e6.dmg'

@register(CHAR_ID)
class Huohuo:
    speed_target = 134.0
    unimplemented = ('戦闘スキルと天賦のデバフ解除。デバフを撃つ敵を実装していない', '軌跡「貞凶の命」の行動制限デバフ抵抗。同上', '星魂 2 の「HP が 0 になっても戦闘不能にならない」。味方が倒れる戦闘を回していない', '秘技「凶相・鬼物圧伏」の敵の攻撃力ダウン。敵の攻撃力を参照していない')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def on_battle_start(self, me, battle) -> None:
        self._heals_left = 0
        a2 = self._traces().get('1217101')
        if a2:
            self._grant_exorcism(me, battle, int(a2['params'][0][0]))

        def on_ally_turn(actor=None, **kw):
            if actor in battle.team:
                self._talent_heal(me, battle, actor)

        def on_ally_ult(source_id=None, **kw):
            ally = next((c for c in battle.team if c.id == source_id), None)
            if ally is not None:
                self._talent_heal(me, battle, ally)
        battle.bus.subscribe(Event.TURN_START, on_ally_turn, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ally_ult, owner_id=me.id)
        if me.eidolon >= 6:
            dmg_up, turns = self._char()['ranks']['6']['params']

            def on_heal(healer=None, target=None, **kw):
                if healer is not me or target is None:
                    return
                battle.apply_effect(target, Effect(key=KEY_E6_DMG, label='星魂6・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=target.id), stacking=Stacking.REFRESH, source_id=me.id))
            battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=me.id)

    def _grant_exorcism(self, me, battle, turns: int) -> None:
        if me.eidolon >= 1:
            turns += int(self._char()['ranks']['1']['params'][1])
        battle.apply_effect(me, Effect(key=KEY_EXORCISM, label='厄払い', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 1:
            spd = self._char()['ranks']['1']['params'][0]
            battle.apply_to_team(lambda who: Effect(key=KEY_E1_SPD, label='星魂1・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        self._heals_left = int(p(self._skills()['121704'], self._levels(me)['Talent'], 7))

    def _heal_amount(self, me, target, ratio: float, flat: float) -> float:
        amount = me.stats[StatKey.HP] * ratio + flat
        if me.eidolon >= 4 and target.max_hp:
            missing = max(0.0, 1.0 - target.hp / target.max_hp)
            amount *= 1.0 + self._char()['ranks']['4']['params'][0] * missing
        return amount

    def _talent_heal(self, me, battle, ally) -> None:
        if not me.effects.has(KEY_EXORCISM) or self._heals_left <= 0:
            return
        s = self._skills()['121704']
        lv = self._levels(me)['Talent']
        ratio, flat, low = (p(s, lv, 3), p(s, lv, 5), p(s, lv, 6))
        self._heals_left -= 1
        battle.heal(me, ally, self._heal_amount(me, ally, ratio, flat), label='厄払い')
        for other in battle.team:
            if other is not ally and other.max_hp and (other.hp <= other.max_hp * low):
                battle.heal(me, other, self._heal_amount(me, other, ratio, flat), label='厄払い(低 HP)')
        a6 = self._traces().get('1217103')
        if a6:
            battle.gain_energy(me, a6['params'][0][0], apply_regen=False)
    rotation_label = 'バフが切れるならスキル（厄払い）'

    def buff_expiring(self, me, battle) -> bool:
        return not me.effects.has(KEY_EXORCISM)

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self.buff_expiring(me, battle) else Action.BASIC

    def basic(self, me, battle) -> None:
        s = self._skills()['121701']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['121702']
        lv = self._levels(me)['BPSkill']
        ratio, flat, adj_ratio, adj_flat = (p(s, lv, i) for i in (1, 2, 3, 4))
        team = sorted(battle.team, key=lambda c: c.position)
        target = min(team, key=lambda c: c.hp / c.max_hp if c.max_hp else 1.0)
        battle.heal(me, target, self._heal_amount(me, target, ratio, flat), label=s['name'])
        i = team.index(target)
        for j in (i - 1, i + 1):
            if 0 <= j < len(team):
                battle.heal(me, team[j], self._heal_amount(me, team[j], adj_ratio, adj_flat), label=s['name'] + '(隣接)')
        self._grant_exorcism(me, battle, int(p(self._skills()['121704'], self._levels(me)['Talent'], 1)))
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['121703']
        lv = self._levels(me)['Ultra']
        ep_ratio, atk_up, turns = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        for ally in battle.team:
            if ally is me:
                continue
            maximum = getattr(getattr(ally, 'resource', None), 'maximum', None)
            if maximum:
                battle.gain_energy(ally, maximum * ep_ratio, apply_regen=False)
            battle.apply_effect(ally, Effect(key=KEY_ULT_ATK, label='必殺技・攻撃力', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=ally.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, s['energy'])
