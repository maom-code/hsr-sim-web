from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1509'
ELEMENT = Element.LIGHTNING
KYO = '興'
GOLDEN_RULE = '黄金律'
KEY_SPEED = 'gilgamesh.kyo.speed'
KEY_TRACE_CD = 'gilgamesh.trace.crit_dmg'
KEY_TRACE_TEAM = 'gilgamesh.trace.team'
KEY_ULT_UP = 'gilgamesh.talent.ult_dmg'
KEY_APPROVAL = 'gilgamesh.skill.approval'
KEY_E1_ATK = 'gilgamesh.e1.atk'
KEY_E4_ENERGY = 'gilgamesh.e4.energy'
KEY_E6_RESPEN = 'gilgamesh.e6.res_pen'

@register(CHAR_ID)
class Gilgamesh:
    relic_sets = {'122': 4, '328': 2}
    unimplemented = ('天賦「攻撃を許す」（セイバーとの連携追加攻撃）。セイバーを実装しない方針なので、この編成では発動しない',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def on_battle_start(self, me, battle) -> None:
        self._roused = False
        self._cd_stacks = 0.0
        a6 = self._traces().get('1509103')
        if a6:
            atk, cd, threshold, per, cap = a6['params'][0]

            def make(who) -> Effect:
                max_ep = getattr(getattr(who, 'built', None), 'max_energy', None)
                over = 0.0
                if max_ep is not None and max_ep > threshold:
                    over = min((max_ep - threshold) * per, cap)
                return Effect(key=KEY_TRACE_TEAM, label='王の争覇', stats=StatSheet.of(atk_pct=atk + over, crit_dmg=cd + over), source_id=me.id)
            battle.apply_aura(me, make)
        if me.eidolon >= 2:
            self._gain_kyo(me, battle, self._char()['ranks']['2']['params'][0])
        if me.eidolon >= 4:
            battle.apply_effect(me, Effect(key=KEY_E4_ENERGY, label='星魂4・EP回復効率', stats=StatSheet.of(energy_regen=self._char()['ranks']['4']['params'][0]), source_id=me.id))
        if me.eidolon >= 6:
            res_pen = self._char()['ranks']['6']['params'][1]
            battle.apply_aura(me, lambda who: Effect(key=KEY_E6_RESPEN, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=res_pen), source_id=me.id))

        def on_turn_start(actor=None, **kw):
            from ...engine.entity import Character
            if isinstance(actor, Character) and actor is not me and (actor in battle.team):
                self._gain_kyo(me, battle, 1)

        def on_ult(actor=None, **kw):
            if actor is me or actor not in battle.team:
                return
            s = self._skills()['150904']
            lv = self._levels(me)['Talent']
            turns, ult_up = (p(s, lv, 1), p(s, lv, 3))
            battle.apply_effect(me, Effect(key=KEY_ULT_UP, label='王が背負う', stats=StatSheet.of(dmg_pct_ultimate=ult_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
            a2 = self._traces().get('1509101')
            if a2:
                bonus_kyo, ep_share, _own = a2['params'][0]
                self._gain_kyo(me, battle, bonus_kyo)
                spent = getattr(actor.resource, 'maximum', 0.0)
                battle.gain_energy(me, spent * ep_share, apply_regen=False)
            if me.eidolon >= 6:
                cap = self._char()['ranks']['6']['params'][2]
                battle.gain_counter(me, GOLDEN_RULE, 1, maximum=cap)
        battle.bus.subscribe(Event.TURN_START, on_turn_start, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=me.id)

    def _gain_kyo(self, me, battle, amount: float) -> None:
        gained = battle.gain_counter(me, KYO, amount)
        if not gained:
            return
        a4 = self._traces().get('1509102')
        if a4:
            per, cap = a4['params'][0]
            self._cd_stacks = min(self._cd_stacks + gained, cap)
            battle.apply_effect(me, Effect(key=KEY_TRACE_CD, label=f'孤高の英雄×{self._cd_stacks:.0f}', stats=StatSheet.of(crit_dmg=per * self._cd_stacks), source_id=me.id))
        self._refresh_speed(me, battle)
        s = self._skills()['150904']
        threshold = p(s, self._levels(me)['Talent'], 2)
        if not self._roused and battle.counter_value(me, KYO) >= threshold:
            self._roused = True
            battle._log(me.name, '興が乗った！')

    def _refresh_speed(self, me, battle) -> None:
        s = self._skills()['150904']
        per = p(s, self._levels(me)['Talent'], 4)
        battle.apply_effect(me, Effect(key=KEY_SPEED, label=f'興×{battle.counter_value(me, KYO):.0f}', stats=StatSheet.of(spd_pct=per * battle.counter_value(me, KYO)), source_id=me.id))
    rotation_label = '「興が乗った！」の間だけスキル'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self._roused else Action.BASIC

    def can_use_skill(self, me, battle) -> bool:
        return self._roused

    def basic(self, me, battle) -> None:
        s = self._skills()['150901']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['150902']
        lv = self._levels(me)['BPSkill']
        main, adjacent = (p(s, lv, 1), p(s, lv, 2))
        def_ignore, turns = (p(s, lv, 5), p(s, lv, 6))
        if me.eidolon >= 2:
            _kyo_start, _kyo_ult, main_up, adj_up = self._char()['ranks']['2']['params']
            main += main_up
            adjacent += adj_up
        approval = Effect(key=KEY_APPROVAL, label='王が認める', stats=StatSheet.of(def_ignore=def_ignore), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id)
        battle.apply_effect(me, approval)
        if me.eidolon >= 1:
            atk_up, energy = self._char()['ranks']['1']['params']
            for c in battle.team:
                if c is me:
                    continue
                battle.apply_effect(c, Effect(key=KEY_APPROVAL, label='王が認める（星魂1）', stats=StatSheet.of(def_ignore=def_ignore), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
            battle.apply_effect(me, Effect(key=KEY_E1_ATK, label='星魂1・攻撃力', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
            battle.gain_energy(me, energy, apply_regen=False)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, main),), adjacent=((StatKey.ATK, adjacent),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])
        battle.spend_counter(me, KYO)
        self._refresh_speed(me, battle)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150903']
        lv = self._levels(me)['Ultra']
        aoe, bounce, hits = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        crit_dmg_up = 0.0
        if me.eidolon >= 6:
            bounce_up, _res_pen, _cap, per_rule = self._char()['ranks']['6']['params']
            bounce += bounce_up
            rules = battle.spend_counter(me, GOLDEN_RULE)
            crit_dmg_up = per_rule * rules
        key = 'gilgamesh.e6.ult_crit_dmg'
        if crit_dmg_up:
            battle.apply_effect(me, Effect(key=key, label=f'黄金律・会心ダメージ +{crit_dmg_up:.0%}', stats=StatSheet.of(crit_dmg_ultimate=crit_dmg_up), source_id=me.id))
        try:
            battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, aoe),), random=((StatKey.ATK, bounce),), random_hits=int(hits), toughness=s.get('toughness'), label=s['name'])
        finally:
            if crit_dmg_up:
                battle.remove_effect(me, key)
        battle.gain_energy(me, s['energy'])
        a2 = self._traces().get('1509101')
        if a2:
            self._gain_kyo(me, battle, a2['params'][0][2])
        if me.eidolon >= 2:
            self._gain_kyo(me, battle, self._char()['ranks']['2']['params'][1])

    def technique(self, me, battle) -> None:
        s = self._skills()['150907']
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, p(s, 1, 2)),), label='秘技・天の鎖')
        self._gain_kyo(me, battle, p(s, 1, 3))
