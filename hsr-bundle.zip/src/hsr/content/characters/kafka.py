from __future__ import annotations
from ...data import loader
from ...engine.effects import DOT_SHOCK, Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1005'
ELEMENT = Element.LIGHTNING
KEY_SHOCK = 'kafka.shock'
KEY_A2_ATK = 'kafka.trace.atk'
KEY_E1_TAKEN = 'kafka.e1.dot_taken'
KEY_E2_DOT = 'kafka.e2.dot'

@register(CHAR_ID)
class Kafka:
    unimplemented = ('軌跡「略奪」（感電の敵が倒された時の EP。敵が倒れない前提）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _ult(self, me) -> list[float]:
        return params_at(self._skills()['100503'], self._levels(me)['Ultra'])

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['100504'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._charges = int(self._talent(me)[4])
        a2 = self._traces().get('1005101')
        if a2:
            need, atk = a2['params'][0][:2]
            for c in battle.team:
                if c.stats[StatKey.EFFECT_HIT] >= need:
                    battle.apply_effect(c, Effect(key=KEY_A2_ATK, label='苛み・攻撃力', stats=StatSheet.of(atk_pct=atk), source_id=me.id))
        if me.eidolon >= 2:
            battle.apply_to_team(lambda who: Effect(key=KEY_E2_DOT, label='星魂2・持続ダメージ', stats=StatSheet.of(dmg_pct_dot=self._rank(2)[0]), source_id=me.id))

        def on_attack(source=None, targets=None, rider=False, dmg_type=None, **kw):
            if source is None or rider or (not targets):
                return
            owner = getattr(source, 'attributed_to', source)
            if owner is me and me.eidolon >= 1:
                _, up, turns = self._rank(1)[:3]
                for e in targets:
                    battle.apply_effect(e, Effect(key=KEY_E1_TAKEN, label='星魂1・受ける持続ダメージ', stats=StatSheet.of(dot_taken=up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
            if owner is me or owner not in battle.team or self._charges <= 0:
                return
            if dmg_type in (DamageType.DOT, DamageType.ADDITIONAL, DamageType.TRUE):
                return
            alive = [e for e in targets if e.alive]
            if not alive:
                return
            focus = battle.target if battle.target in alive else alive[0]
            self._charges -= 1
            self._followup(me, battle, focus)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        if me.eidolon >= 4:

            def on_dot(source=None, effect=None, **kw):
                if source is me and effect is not None and (effect.key == KEY_SHOCK):
                    battle.gain_energy(me, self._rank(4)[0], apply_regen=False)
            battle.bus.subscribe(Event.ON_DOT_DAMAGE, on_dot, owner_id=me.id)

        def on_turn_end(actor=None, **kw):
            if actor is me:
                self._charges = min(int(self._talent(me)[4]), self._charges + int(self._talent(me)[3]))
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=me.id)

    def _shock(self, me, battle, enemy, *, e6: bool) -> None:
        u = self._ult(me)
        mult, turns = (u[3], int(u[2]))
        if e6 and me.eidolon >= 6:
            mult += self._rank(6)[0]
            turns += int(self._rank(6)[1])
        battle.apply_effect(enemy, Effect(key=KEY_SHOCK, label='感電（カフカ）', dot_base=me.stats[StatKey.ATK] * mult, dot_element=ELEMENT, dot_kind=DOT_SHOCK, duration=Duration(turns=turns), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))

    def _followup(self, me, battle, focus) -> None:
        t = self._talent(me)
        s = self._skills()['100504']
        with battle.attack_action(me):
            battle.attack(me, ELEMENT, DamageType.FOLLOWUP, main=((StatKey.ATK, t[0]),), target=focus, toughness=s.get('toughness'), label=s['name'])
        self._shock(me, battle, focus, e6=True)
        a6 = self._traces().get('1005103')
        if a6:
            battle.detonate_dots(focus, a6['params'][0][0])
        battle.gain_energy(me, s['energy'])

    def basic(self, me, battle) -> None:
        s = self._skills()['100501']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['100502']
        lv = self._levels(me)['BPSkill']
        main, main_det, adj, adj_det = (p(s, lv, i) for i in range(1, 5))
        battle.spend_sp(battle.skill_cost(me), actor=me)
        focus = battle.target
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, main),), adjacent=((StatKey.ATK, adj),), target=focus, toughness=s.get('toughness'), label=s['name'])
        if focus is not None:
            battle.detonate_dots(focus, main_det)
            for e in battle.adjacent_to(focus):
                battle.detonate_dots(e, adj_det)
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['100503']
        u = self._ult(me)
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, u[0]),), toughness=s.get('toughness'), label=s['name'])
        for e in battle.alive_enemies:
            self._shock(me, battle, e, e6=True)
            battle.detonate_dots(e, u[4])
        if self._traces().get('1005103'):
            self._charges = min(int(self._talent(me)[4]), self._charges + 1)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['100507']
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, params_at(tech, 1)[2]),), toughness=tech.get('toughness'), label=tech['name'])
        for e in battle.alive_enemies:
            self._shock(me, battle, e, e6=True)
