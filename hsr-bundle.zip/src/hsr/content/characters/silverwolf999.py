from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, reward_total
from ...engine.events import Event
from ...engine.resources import CounterPool
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1506'

def _rate(w: float) -> str:
    return f'{w:.0%}' if w >= 0.01 else f'{w:.2%}'
ELEMENT = Element.IMAGINARY
SCORE = 'シークレットスコア'
KEY_TRACE_RATE = 'sw999.trace.elation_rate'
KEY_SCORE_CRIT = 'sw999.score.crit'
KEY_INVINCIBLE = 'sw999.invincible'
KEY_ZONE_VULN = 'sw999.zone.vuln'
KEY_E6_WEAK = 'sw999.e6.weakness'
KEY_E6_UP = 'sw999.e6.elation_up'
KEY_ENHANCED_UP = 'sw999.enhanced.dmg_up'
SUPPLY_OUTCOMES = 3

@register(CHAR_ID)
class SilverWolf999:
    speed_target = 200.0
    substat_priority = ['CriticalChanceBase', 'CriticalDamageBase']
    unimplemented = ('秘技「ストレンジ・ビーン」のマップ上での撃破（戦闘外の処理）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _elation_level(self, me) -> int:
        return self._levels(me).get('ElationDamage', 10)

    def on_battle_start(self, me, battle) -> None:
        talent = self._skills()['150604']
        tlv = self._levels(me)['Talent']
        need, cap, self._talent_mult, self._cr_per, self._shots, self._cd_per = (p(talent, tlv, i) for i in (1, 2, 3, 4, 5, 6))
        counter = me.counter(SCORE, maximum=cap)
        me.resource = CounterPool(counter, threshold=need, cost=0.0)
        self._supply_dist: dict[int, float] = {0: 1.0}
        self._enhanced_left = 0.0
        self._score_since_ult = 0.0
        a2 = self._traces().get('1506101')
        if a2:
            threshold, base, step, per, over_cap = a2['params'][0]
            spd = me.stats[StatKey.SPD]
            if spd >= threshold:
                over = min(spd - threshold, over_cap)
                battle.apply_effect(me, Effect(key=KEY_TRACE_RATE, label='軌跡・愉悦度', stats=StatSheet.of(elation_rate=base + over / step * per), source_id=me.id))

        def on_notes(name=None, amount: float=0.0, **kw):
            if name == NOTES and amount > 0:
                self._gain_score(me, battle, amount)
        battle.bus.subscribe(Event.ON_SHARED_GAIN, on_notes, owner_id=me.id)
        if me.eidolon >= 6:
            res_down = self._char()['ranks']['6']['params'][0]
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_E6_WEAK, label='禁忌の弱点', stats=StatSheet.of(res_down=res_down), source_id=me.id))
        self._refresh_crit(me, battle)

    def _gain_score(self, me, battle, amount: float) -> None:
        gained = battle.gain_counter(me, SCORE, amount)
        self._refresh_crit(me, battle)
        if me.effects.has(KEY_INVINCIBLE):
            self._score_since_ult += gained
            self._check_e2_extra_turns(me, battle)

    def _check_e2_extra_turns(self, me, battle) -> None:
        if me.eidolon < 2:
            return
        per = self._char()['ranks']['2']['params'][0]
        while self._score_since_ult >= per:
            self._score_since_ult -= per
            self._enhanced_left += 1
            battle.extra_turn(me)

    def _refresh_crit(self, me, battle) -> None:
        score = battle.counter_value(me, SCORE)
        held = me.effects.get(KEY_SCORE_CRIT)
        current_cr = me.stats[StatKey.CRIT_RATE]
        if held is not None:
            current_cr -= held.stats[StatKey.CRIT_RATE]
        headroom = max(0.0, 1.0 - current_cr)
        to_cr = min(score, headroom / self._cr_per) if self._cr_per else 0.0
        rest = score - to_cr
        battle.apply_effect(me, Effect(key=KEY_SCORE_CRIT, label='シークレットスコア・会心', stats=StatSheet.of(crit_rate=to_cr * self._cr_per, crit_dmg=rest * self._cd_per), stacking=Stacking.REFRESH, source_id=me.id))

    def _supply_box(self, me, battle, *, weight: float | None=None, notes: float | None=None) -> None:
        s = self._skills()['150603']
        lv = self._levels(me)['Ultra']
        mult, decay, true_pct, note_gain, sp_gain = (p(s, lv, i) for i in (3, 4, 5, 6, 7))
        decay = p(s, lv, 4)
        w = self.supply_chance(decay) if weight is None else weight
        if w <= 0.0:
            return
        if notes is None:
            notes = reward_total(me)
        dealt = battle.attack(me, ELEMENT, DamageType.ELATION, elation=(mult, notes), elation_shape='aoe', independent=w / max(1, len(battle.alive_enemies)), label='SSSサプライボックス' if w >= 1.0 else f'SSSサプライボックス（発動率 {_rate(w)}）', rider=True)
        share = w / SUPPLY_OUTCOMES
        target = max(battle.alive_enemies, key=lambda e: e.hp, default=None)
        if target is not None and dealt > 0:
            battle.attack(me, ELEMENT, DamageType.TRUE, target=target, flat_main=dealt * true_pct * share, label='スーパー・グレートソード' if w >= 1.0 else f'スーパー・グレートソード（発動率 {_rate(share)}）')
        battle.gain_sp(sp_gain * share)
        battle.gain_shared(NOTES, note_gain * share)
        nxt: dict[int, float] = {}
        for k, pr in self._supply_dist.items():
            fire = 1.0 if weight is not None else decay ** k
            nxt[k + 1] = nxt.get(k + 1, 0.0) + pr * fire
            if fire < 1.0:
                nxt[k] = nxt.get(k, 0.0) + pr * (1.0 - fire)
        self._supply_dist = {k: v for k, v in nxt.items() if v > 1e-12}

    def supply_chance(self, decay: float | None=None) -> float:
        if decay is None:
            decay = p(self._skills()['150603'], 10, 4)
        return sum((pr * decay ** k for k, pr in self._supply_dist.items()))

    def _reset_supply_chance(self) -> None:
        self._supply_dist = {0: 1.0}

    def basic(self, me, battle) -> None:
        if me.effects.has(KEY_INVINCIBLE):
            self._enhanced_basic(me, battle)
            return
        s = self._skills()['150601']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        self._talent_elation(me, battle, shape='main')

    def skill(self, me, battle) -> None:
        s = self._skills()['150602']
        lv = self._levels(me)['BPSkill']
        mult, notes = (p(s, lv, 1), p(s, lv, 2))
        battle.spend_sp(s['sp_cost'])
        battle.gain_shared(NOTES, notes)
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        self._talent_elation(me, battle, shape='aoe')

    def _talent_elation(self, me, battle, *, shape: str) -> None:
        notes = reward_total(me)
        if notes <= 0:
            return
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(self._talent_mult, notes), elation_shape=shape, label='天賦・愉悦ダメージ', rider=True)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150603']
        battle.apply_effect(me, Effect(key=KEY_INVINCIBLE, label='無敵プレイヤー', stacking=Stacking.REFRESH, source_id=me.id))
        self._enhanced_left = self._shots
        self._score_since_ult = 0.0
        if me.eidolon >= 2:
            for e in me.effects:
                if e.duration is not None:
                    e.duration.turns += 1
        me.resource.threshold = None
        me.counter(SCORE).maximum = None
        battle.advance_forward(me, 1.0)
        if me.eidolon >= 1:
            vuln = self._char()['ranks']['1']['params'][1]
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_ZONE_VULN, label='結界・被ダメージ', stats=StatSheet.of(vulnerability=vuln), source_id=me.id))
        a6 = self._traces().get('1506103')
        if a6:
            self._gain_score(me, battle, a6['params'][0][0])
        self._pending_boxes = 0

        def open_boxes(count: int) -> None:
            if not me.effects.has(KEY_INVINCIBLE) or reward_total(me) <= 0:
                return
            for _ in range(count):
                self._supply_box(me, battle)

        def on_sp(spent: float=0.0, **kw):
            if spent <= 0:
                return
            if battle.in_sp_batch:
                self._pending_boxes += int(spent)
                return
            open_boxes(int(spent))

        def on_batch_end(**kw):
            count, self._pending_boxes = (self._pending_boxes, 0)
            if count:
                open_boxes(count)
        self._sp_listener = battle.bus.subscribe(Event.ON_SP_CHANGE, on_sp, owner_id=me.id)
        self._batch_listener = battle.bus.subscribe(Event.ON_SP_BATCH_END, on_batch_end, owner_id=me.id)

    def _end_invincible(self, me, battle) -> None:
        me.effects.remove(KEY_INVINCIBLE)
        battle.bus.unsubscribe(getattr(self, '_sp_listener', -1))
        battle.bus.unsubscribe(getattr(self, '_batch_listener', -1))
        self._pending_boxes = 0
        talent = self._skills()['150604']
        tlv = self._levels(me)['Talent']
        need, cap = (p(talent, tlv, 1), p(talent, tlv, 2))
        me.resource.threshold = need
        me.counter(SCORE).maximum = cap
        keep = self._char()['ranks']['1']['params'][0] if me.eidolon >= 1 else 0.0
        score = battle.counter_value(me, SCORE)
        battle.spend_counter(me, SCORE, score * (1.0 - keep))
        self._refresh_crit(me, battle)

    def can_use_skill(self, me, battle) -> bool:
        return not me.effects.has(KEY_INVINCIBLE)

    def _enhanced_basic(self, me, battle) -> None:
        s = self._skills()['150608']
        lv = self._levels(me)['Normal']
        total, hits, last, boxes, per_stack, max_stack, up = (p(s, lv, i) for i in (1, 3, 4, 5, 6, 7, 8))
        notes = reward_total(me)
        stacks = min(int(battle.counter_value(me, SCORE) // per_stack), int(max_stack))
        boost = 1.0 + up * stacks
        if me.eidolon >= 6:
            e6 = self._char()['ranks']['6']['params'][1]
            battle.apply_effect(me, Effect(key=KEY_E6_UP, label='星魂6・上笑', stats=StatSheet.of(dmg_pct_elation=e6), stacking=Stacking.REFRESH, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(total / hits, notes), elation_shape='random', random_hits=int(hits), independent=boost, toughness=s.get('toughness'), label=s['name'])
        for _ in range(int(boxes)):
            self._supply_box(me, battle, weight=1.0, notes=notes)
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(last, notes), elation_shape='aoe', independent=boost / max(1, len(battle.alive_enemies)), label='ラストアタック')
        if me.eidolon >= 6:
            me.effects.remove(KEY_E6_UP)
        self._enhanced_left -= 1
        if self._enhanced_left <= 0:
            self._end_invincible(me, battle)

    def elation_skill(self, me, battle, notes: float) -> None:
        if me.effects.has(KEY_INVINCIBLE):
            self._collapse_demo(me, battle, notes)
        else:
            s = self._skills()['150620']
            self._gain_score(me, battle, p(s, self._elation_level(me), 1))
        self._elation_trace(me, battle, notes)

    def _collapse_demo(self, me, battle, notes: float) -> None:
        s = self._skills()['150621']
        lv = self._elation_level(me)
        mult, hits = (p(s, lv, 1), p(s, lv, 2))
        if me.eidolon >= 4:
            notes = notes * (1.0 + self._char()['ranks']['4']['params'][0])
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(mult, notes), elation_shape='random', random_hits=int(hits), independent=battle.aha.skill_multiplier, toughness=s.get('toughness'), label=s['name'])
        self._reset_supply_chance()

    def _elation_trace(self, me, battle, notes: float) -> None:
        a4 = self._traces().get('1506102')
        if not a4:
            return
        low, high, first, second = a4['params'][0]
        gained = 0.0
        if notes >= low:
            gained += first
        if notes >= high:
            gained += second
        if gained:
            self._gain_score(me, battle, gained)

    def technique(self, me, battle) -> None:
        s = self._skills()['150607']
        notes = p(s, self._levels(me)['Normal'], 1)
        self._supply_box(me, battle, weight=1.0, notes=notes)
