from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element, Path
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1224'
ELEMENT = Element.IMAGINARY
CHARGE = 'march_hunt.charge'
KEY_MASTER_SPD = 'march_hunt.master.spd.'
KEY_ENHANCED = 'march_hunt.talent.dmg'
KEY_A6 = 'march_hunt.trace.master.'
KEY_E1 = 'march_hunt.e1.spd'
KEY_E6 = 'march_hunt.e6.cd'
DAMAGE_PATHS = frozenset({Path.ERUDITION, Path.DESTRUCTION, Path.HUNT, Path.REMEMBRANCE, Path.ELATION})

@register(CHAR_ID)
class MarchHunt:
    target_override_label = '師匠'
    target_override_priority = ()
    target_override_default = '与ダメージが最も多い味方'
    unimplemented = ('軌跡「玲瓏」（師匠の属性の弱点を削れる。弱点撃破オンでは全属性弱点なので差が出ない）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['122404'], self._levels(me)['Talent'])

    def _skill_params(self, me) -> list[float]:
        return params_at(self._skills()['122402'], self._levels(me)['BPSkill'])

    def on_battle_start(self, me, battle) -> None:
        need, _, cap = self._talent(me)[:3]
        me.counter(CHARGE, maximum=cap)
        self._master = None
        self._armed = False
        self._pending = False
        self._ult_boost = False
        self._e2_ready = True
        a2 = self._traces().get('1224101')
        if a2:
            battle.advance_forward(me, a2['params'][0][0])

        def is_master(who) -> bool:
            return self._master is not None and getattr(who, 'attributed_to', who) is self._master

        def on_action(actor=None, **kw):
            if actor is not None and actor is self._master:
                self._armed = True

        def on_attack(source=None, targets=(), dmg_type=None, rider=False, **kw):
            if rider or not is_master(source):
                return
            if dmg_type is DamageType.FOLLOWUP:
                self._gain(me, battle, 1)
            elif self._armed:
                self._armed = False
                self._gain(me, battle, 1)
            if me.eidolon >= 2 and self._e2_ready and (dmg_type in (DamageType.BASIC, DamageType.SKILL)):
                self._e2_ready = False
                target = next((e for e in targets or () if e.alive), None) or battle.target
                self._e2_followup(me, battle, target)

        def on_ult(actor=None, **kw):
            if actor is not None and actor is self._master and self._armed:
                self._armed = False
                self._gain(me, battle, 1)

        def on_turn(actor=None, **kw):
            if actor is me:
                self._e2_ready = True
                self._pending = False
                if me.eidolon >= 4:
                    battle.gain_energy(me, self._rank(4)[0], apply_regen=False)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=me.id)
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=me.id)

    def _charge(self, me, battle) -> float:
        return battle.counter_value(me, CHARGE)

    def _enhanced(self, me, battle) -> bool:
        return self._charge(me, battle) >= self._talent(me)[0]

    def _gain(self, me, battle, n: float) -> None:
        me.counter(CHARGE).gain(n)
        self._sync(me, battle)

    def _sync(self, me, battle) -> None:
        if self._enhanced(me, battle):
            if not me.effects.has(KEY_ENHANCED):
                battle.apply_effect(me, Effect(key=KEY_ENHANCED, label='師匠、わかりました！・与ダメージ', stats=StatSheet.of(dmg_pct=self._talent(me)[1]), source_id=me.id))
            if not self._pending:
                self._pending = True
                battle.act_next(me)
        elif me.effects.has(KEY_ENHANCED):
            battle.remove_effect(me, KEY_ENHANCED)

    def _master_deals_damage(self) -> bool:
        return self._master is not None and self._master.built.path in DAMAGE_PATHS

    def _master_breaks(self) -> bool:
        return self._master is not None and self._master.built.path not in DAMAGE_PATHS

    def _path_rider(self, me, battle, target, weight: float) -> None:
        if not self._master_deals_damage() or target is None or (not target.alive):
            return
        mult = self._skill_params(me)[1]
        dealt = battle.deal_damage(me, target, self._master.built.element, DamageType.ADDITIONAL, ((StatKey.ATK, mult),), weight=weight)
        battle._log(me.name, '師匠・付加ダメージ', dealt)

    def _toughness(self, me, base):
        if base is None or not self._master_breaks():
            return base
        up = 1.0 + self._skill_params(me)[2]
        if isinstance(base, dict):
            return {k: v * up for k, v in base.items()}
        return base * up

    def can_use_skill(self, me, battle) -> bool:
        return not self._enhanced(me, battle)
    rotation_label = '師匠がいなければ戦闘スキル、あとは通常攻撃（チャージ 7 で強化通常攻撃）'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        if self._master is None and (not self._enhanced(me, battle)):
            return Action.SKILL
        return Action.BASIC

    def basic(self, me, battle) -> None:
        if self._enhanced(me, battle):
            self._enhanced_basic(me, battle)
            return
        s = self._skills()['122401']
        lv = self._levels(me)['Normal']
        target = battle.target
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), target=target, toughness=self._toughness(me, s.get('toughness')), label=s['name'])
        self._path_rider(me, battle, target, 1.0)
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])
        self._gain(me, battle, p(s, lv, 2))

    def _enhanced_basic(self, me, battle) -> None:
        s = self._skills()['122408']
        lv = self._levels(me)['Normal']
        mult, chance, extra_max, initial = (p(s, lv, i) for i in range(1, 5))
        if self._ult_boost:
            u = params_at(self._skills()['122403'], self._levels(me)['Ultra'])
            initial += u[1]
            chance += u[2]
        chance = min(1.0, chance)
        if self._ult_boost and me.eidolon >= 6:
            battle.apply_effect(me, Effect(key=KEY_E6, label='星魂6・会心ダメージ', stats=StatSheet.of(crit_dmg=self._rank(6)[0]), source_id=me.id))
        target = battle.target
        tough = self._toughness(me, s.get('toughness'))
        weights = [1.0] * int(initial) + [chance ** k for k in range(1, int(extra_max) + 1)]
        for w in weights:
            if target is None or not target.alive:
                target = battle.target
                if target is None:
                    break
            battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, mult),), target=target, toughness=None if tough is None else {k: v * w for k, v in tough.items()} if isinstance(tough, dict) else tough * w, independent=w, label=s['name'])
            self._path_rider(me, battle, target, w)
        battle.remove_effect(me, KEY_E6)
        self._ult_boost = False
        battle.gain_energy(me, s['energy'])
        battle.spend_counter(me, CHARGE, self._talent(me)[0])
        self._sync(me, battle)
        a6 = self._traces().get('1224103')
        if a6 and self._master is not None:
            cd, be, turns = a6['params'][0][:3]
            battle.apply_effect(self._master, Effect(key=KEY_A6 + me.id, label='破浪', stats=StatSheet.of(crit_dmg=cd, break_effect=be), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))

    def skill(self, me, battle) -> None:
        s = self._skills()['122402']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        master = battle.resolve_target_override(me, self.target_override_priority)
        if master is not None:
            battle.target_ally(me, master)
            if self._master is not None and self._master is not master:
                self._set_speed(battle, self._master, key=KEY_MASTER_SPD + me.id)
            self._master = master
            self._set_speed(battle, master, key=KEY_MASTER_SPD + me.id, effect=Effect(key=KEY_MASTER_SPD + me.id, label='師匠・速度', stats=StatSheet.of(spd_pct=self._skill_params(me)[0]), source_id=me.id))
            if me.eidolon >= 1 and (not me.effects.has(KEY_E1)):
                self._set_speed(battle, me, key=KEY_E1, effect=Effect(key=KEY_E1, label='星魂1・速度', stats=StatSheet.of(spd_pct=self._rank(1)[0]), source_id=me.id))
        battle.gain_energy(me, s['energy'])

    def _set_speed(self, battle, who, effect: Effect | None=None, *, key: str) -> None:
        before = who.speed()
        if effect is None:
            battle.remove_effect(who, key)
        else:
            battle.apply_effect(who, effect)
        if any((sl.actor is who for sl in battle.queue.slots)):
            battle.queue.rescale(who, before)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['122403']
        lv = self._levels(me)['Ultra']
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        self._ult_boost = True
        battle.gain_energy(me, s['energy'])

    def _e2_followup(self, me, battle, target) -> None:
        mult, _, charge, tough = self._rank(2)[:4]
        if target is None:
            return
        battle.attack(me, ELEMENT, DamageType.FOLLOWUP, main=((StatKey.ATK, mult),), target=target, toughness=self._toughness(me, tough), label='星魂2・追加攻撃')
        self._path_rider(me, battle, target, 1.0)
        self._gain(me, battle, charge)

    def technique(self, me, battle) -> None:
        cap, ep = params_at(self._skills()['122407'], 1)[:2]
        battle.gain_energy(me, ep, apply_regen=False)
        others = sum((1 for c in battle.team if c is not me))
        self._gain(me, battle, min(cap, others))
