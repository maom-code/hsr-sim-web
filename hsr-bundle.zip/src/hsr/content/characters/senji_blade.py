from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element, Path
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1507'
ELEMENT = Element.FIRE
CHARGE = 'チャージ'
KEY_ZONE = 'senji.zone'
KEY_SHURA = 'senji.shura'
KEY_TRACE_TEAM = 'senji.trace.team_dmg'
KEY_E1_RES = 'senji.e1.res_down'
KEY_E2_FUA = 'senji.e2.followup'

@register(CHAR_ID)
class SenjiBlade:
    speed_target = 140.0
    relic_sets = {'132': 4, '319': 2}
    self_crit_rate_buff = 0.2
    unimplemented = ('軌跡「千鍛の魂」（挑発・被ダメージ軽減・被治癒アップと、攻撃を受けた時の「修羅の炎」付与とチャージ +1）。敵が反撃しない前提なので発動しない',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def in_zone(self, me) -> bool:
        return me.effects.has(KEY_ZONE)

    def on_battle_start(self, me, battle) -> None:
        self._timer: Countdown | None = None
        self._casting = False
        self._banked = 0.0
        self._e6_ready = True
        a2 = self._traces().get('1507101')
        if a2:
            floor_ratio, bank_cap = a2['params'][0]
            self._refill(me, battle, floor_ratio)

            def on_energy(who=None, overflow: float=0.0, **kw):
                if who is me and overflow > 0:
                    self._banked = min(self._banked + overflow, bank_cap)
            battle.bus.subscribe(Event.ON_ENERGY_GAIN, on_energy, owner_id=me.id)
        if me.eidolon >= 2:
            fua = self._char()['ranks']['2']['params'][0]
            battle.ultimate_as_followup = True
            battle.apply_to_team(lambda who: Effect(key=KEY_E2_FUA, label='星魂2・追加攻撃ダメージ', stats=StatSheet.of(dmg_pct_followup=fua), source_id=me.id))

        def on_damage(source=None, targets=None, rider=False, **kw):
            if not self.in_zone(me) or not targets or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            self._apply_shura(me, battle, targets)
            self._gain_charge(me, battle, 1)
        battle.bus.subscribe(Event.ON_ATTACK, on_damage, owner_id=me.id)
        if me.eidolon >= 6:

            def on_hp_loss(target=None, **kw):
                if target is me and self._e6_ready and self.in_zone(me):
                    self._e6_ready = False
                    self._gain_charge(me, battle, 1)

            def on_turn_end(**kw):
                self._e6_ready = True
            battle.bus.subscribe(Event.ON_HP_LOSS, on_hp_loss, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=me.id)

    def _refill(self, me, battle, ratio: float) -> None:
        pool = me.resource
        floor = getattr(pool, 'maximum', 0.0) * ratio
        if getattr(pool, 'current', 0.0) < floor:
            battle.gain_energy(me, floor - float(pool.current), apply_regen=False)

    def _apply_shura(self, me, battle, enemies) -> None:
        s = self._skills()['150703']
        lv = self._levels(me)['Ultra']
        vuln, def_down, turns = (p(s, lv, 4), p(s, lv, 7), p(s, lv, 8))
        for e in enemies:
            if not e.alive:
                continue
            battle.apply_effect(e, Effect(key=KEY_SHURA, label='修羅の炎', stats=StatSheet.of(def_down=def_down, vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))

    def _charge_threshold(self, me) -> float:
        s = self._skills()['150704']
        need = p(s, self._levels(me)['Talent'], 1)
        if me.eidolon >= 2:
            need = self._char()['ranks']['2']['params'][1]
        return need

    def _gain_charge(self, me, battle, amount: float) -> None:
        battle.gain_counter(me, CHARGE, amount)
        self._spend_charge(me, battle)

    def _spend_charge(self, me, battle) -> None:
        if self._casting:
            return
        need = self._charge_threshold(me)
        s = self._skills()['150704']
        energy = p(s, self._levels(me)['Talent'], 2)
        for _ in range(10):
            if not self.in_zone(me) or me.hp <= 1 or battle.counter_value(me, CHARGE) < need:
                return
            battle.spend_counter(me, CHARGE, need)
            battle.gain_energy(me, energy, apply_regen=False)
            self._cast_skill(me, battle, dmg_type=DamageType.FOLLOWUP)
            if me.eidolon >= 1 and self._timer is not None:
                delay = self._char()['ranks']['1']['params'][1]
                battle.delay_action(self._timer, delay)
    rotation_label = '結界（無量忿怒）の間だけスキル'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self.in_zone(me) and me.hp > 1 else Action.BASIC

    def can_use_skill(self, me, battle) -> bool:
        return self.in_zone(me) and me.hp > 1
    skill_sp_cost = 0

    def basic(self, me, battle) -> None:
        sid = '150708' if self.in_zone(me) else '150701'
        s = self._skills()[sid]
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        self._cast_skill(me, battle, dmg_type=DamageType.SKILL)

    def _cast_skill(self, me, battle, *, dmg_type: DamageType) -> None:
        s = self._skills()['150702']
        lv = self._levels(me)['BPSkill']
        aoe, hits, single, cost = (p(s, lv, i) for i in (1, 2, 3, 4))
        self._casting = True
        battle.spend_hp(me, amount=me.max_hp * cost)
        try:
            with battle.attack_action(me):
                battle.attack(me, ELEMENT, dmg_type, aoe=((StatKey.HP, aoe),), toughness=s.get('toughness'), label=s['name'])
                battle.attack(me, ELEMENT, dmg_type, random=((StatKey.HP, single),), random_hits=int(hits), toughness=s.get('toughness'), label=s['name'] + '（追撃）')
        finally:
            self._casting = False
        battle.gain_energy(me, s['energy'])
        self._spend_charge(me, battle)

    def ultimate(self, me, battle) -> None:
        if self.in_zone(me):
            self._ultimate_burn(me, battle)
        else:
            self._ultimate_zone(me, battle)
        if self._banked:
            battle.gain_energy(me, self._banked, apply_regen=False)
            self._banked = 0.0

    def _ultimate_zone(self, me, battle) -> None:
        s = self._skills()['150703']
        lv = self._levels(me)['Ultra']
        hp_cost, crit_rate, crit_dmg, spd = (p(s, lv, i) for i in (1, 2, 3, 5))
        self._apply_shura(me, battle, list(battle.alive_enemies))
        battle.spend_hp(me, amount=me.max_hp * hp_cost)
        battle.apply_effect(me, Effect(key=KEY_ZONE, label='無量忿怒', stats=StatSheet.of(crit_rate=crit_rate, crit_dmg=crit_dmg), source_id=me.id))
        a6 = self._traces().get('1507103')
        if a6:
            team_dmg, ult_dmg, own_dmg = a6['params'][0]
            if me.eidolon >= 4:
                team_dmg += self._char()['ranks']['4']['params'][0]
            others = [c for c in battle.team if c is not me and c.built.path is Path.NIHILITY]
            extra_ult = ult_dmg if others else 0.0
            battle.apply_aura(me, lambda who: Effect(key=KEY_TRACE_TEAM, label='万淬の心', stats=StatSheet.of(dmg_pct=team_dmg, dmg_pct_ultimate=extra_ult), source_id=me.id), key=KEY_ZONE)
            if not others:
                battle.apply_effect(me, Effect(key=f'{KEY_TRACE_TEAM}.self', label='万淬の心・単独', stats=StatSheet.of(dmg_pct=own_dmg), source_id=me.id))
        if me.eidolon >= 1:
            res_down = self._char()['ranks']['1']['params'][0]
            for e in battle.enemies:
                battle.apply_effect(e, Effect(key=KEY_E1_RES, label='星魂1・耐性ダウン', stats=StatSheet.of(res_down=res_down), source_id=me.id))
        self._timer = battle.add_countdown(Countdown(name='無量忿怒', spd=spd, on_turn=lambda: self._end_zone(me, battle)), order=me.position)
        battle.gain_energy(me, s['energy'])

    def _ultimate_burn(self, me, battle) -> None:
        s = self._skills()['150714']
        lv = self._levels(me)['Ultra']
        mult = p(s, lv, 1)
        independent = self._char()['ranks']['6']['params'][0] if me.eidolon >= 6 else 1.0
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.HP, mult),), independent=independent, toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def _end_zone(self, me, battle) -> None:
        battle.remove_effect(me, KEY_ZONE)
        for key in (KEY_TRACE_TEAM, KEY_E2_FUA):
            for c in battle.team:
                battle.remove_effect(c, key)
            for m in battle.memosprites:
                battle.remove_effect(m, key)
        battle.remove_effect(me, f'{KEY_TRACE_TEAM}.self')
        for e in battle.enemies:
            battle.remove_effect(e, KEY_E1_RES)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
            self._timer = None
        a2 = self._traces().get('1507101')
        if a2:
            self._refill(me, battle, a2['params'][0][0])

    def technique(self, me, battle) -> None:
        s = self._skills()['150707']
        battle.apply_effect(me, Effect(key='senji.technique', label='秘技・十方不赦', stats=StatSheet.of(dmg_reduction=p(s, 1, 1)), duration=Duration(turns=int(p(s, 1, 2)), tick_owner_id=me.id), source_id=me.id))
