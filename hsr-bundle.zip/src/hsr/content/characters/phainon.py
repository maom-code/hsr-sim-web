from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.resources import CounterPool
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1408'
ELEMENT = Element.PHYSICAL
EMBER = '火種'
WOUND = '壊傷'
KEY_TALENT_CD = 'phainon.talent.crit_dmg'
KEY_A4_DMG = 'phainon.trace.dmg'
KEY_A6_ATK = 'phainon.trace.atk'
KEY_KHASLANA = 'phainon.khaslana'
KEY_END_SPD = 'phainon.end.spd'
KEY_E1_CD = 'phainon.e1.crit_dmg'

@register(CHAR_ID)
class Phainon:
    manual_play_note = 'カスライナの行動の組み立て（滅却と天裁の順番）で伸び方が大きく変わる。このシミュは「壊傷 4 以上なら天裁、それ以外は滅却」の単純な決め打ち'
    unimplemented = ('軌跡「幾千万の炎を携えて」の「自身以外の味方のスキルによる EP 回復で火種 +1」（EP 回復の出どころをエンジンが持っていない）', 'カスライナの被ダメージ軽減・戦闘不能回避（敵が攻撃しない前提）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _t1(self, me) -> list[float]:
        return params_at(self._skills()['140804'], self._levels(me)['Talent'])

    def _t2(self, me) -> list[float]:
        return params_at(self._skills()['140805'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._khaslana = False
        self._turns_left = 0
        self._stored = 0.0
        self._timer: Countdown | None = None
        self._saved_av: dict[int, tuple[object, float | None]] = {}
        self._a4_used_turn = -1
        need = self._t1(me)[3]
        counter = me.counter(EMBER, maximum=need)
        me.resource = CounterPool(counter, threshold=need, cost=need)
        a2 = self._traces().get('1408101')
        start = a2['params'][0][1] if a2 else 0.0
        if me.eidolon >= 6:
            start += self._rank(6)[1]
        self._gain_ember(me, battle, start)
        self._atk_stack(me, battle)
        t1 = self._t1(me)

        def on_targeted(actor=None, target=None, **kw):
            if target is not me or actor is None or actor is me:
                return
            self._gain_ember(me, battle, 1)
            if getattr(actor, 'attributed_to', actor) in battle.team:
                battle.apply_effect(me, Effect(key=KEY_TALENT_CD, label='この身を炬火とす・会心ダメージ', stats=StatSheet.of(crit_dmg=t1[0]), duration=Duration(turns=int(t1[1])), stacking=Stacking.REFRESH, source_id=me.id))
        battle.bus.subscribe(Event.ON_ALLY_TARGETED, on_targeted, owner_id=me.id)
        a4 = self._traces().get('1408102')
        if a4:
            up, turns = a4['params'][0][:2]

            def on_support(target=None, healer=None, source=None, **kw):
                giver = healer if healer is not None else source
                if target is not me or giver is None or giver is me:
                    return
                if self._a4_used_turn == battle._turn_no:
                    return
                self._a4_used_turn = battle._turn_no
                battle.apply_effect(me, Effect(key=KEY_A4_DMG, label='幾千万の炎を携えて', stats=StatSheet.of(dmg_pct=up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
            battle.bus.subscribe(Event.ON_HEAL, on_support, owner_id=me.id)
            battle.bus.subscribe(Event.ON_SHIELD, on_support, owner_id=me.id)

    def _gain_ember(self, me, battle, n: float) -> None:
        cap = self._t1(me)[3]
        room = max(0.0, cap - battle.counter_value(me, EMBER))
        battle.gain_counter(me, EMBER, min(n, room), maximum=cap)
        over = n - min(n, room)
        if over > 0:
            limit = float('inf') if me.eidolon >= 6 else self._t1(me)[2]
            self._stored = min(limit, self._stored + over)

    def _atk_stack(self, me, battle) -> None:
        a6 = self._traces().get('1408103')
        if a6:
            battle.apply_effect(me, Effect(key=KEY_A6_ATK, label='映し出されし英雄の本質', stats=StatSheet.of(atk_pct=a6['params'][0][0]), stacking=Stacking.STACK, max_stacks=int(a6['params'][0][1]), source_id=me.id))

    def can_use_ultimate(self, me, battle) -> bool:
        return not self._khaslana

    def basic(self, me, battle) -> None:
        s = self._skills()['140801']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)

    def skill(self, me, battle) -> None:
        s = self._skills()['140802']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        self._gain_ember(me, battle, p(s, lv, 3))
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, p(s, lv, 1)),), adjacent=((StatKey.ATK, p(s, lv, 2)),), toughness=s.get('toughness'), label=s['name'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['140803']
        lv = self._levels(me)['Ultra']
        _, _, spd_ratio, turns = (p(s, lv, i) for i in (1, 2, 3, 4))
        if me.eidolon >= 1:
            spd_ratio = self._rank(1)[4]
            e1 = self._rank(1)
            battle.apply_effect(me, Effect(key=KEY_E1_CD, label='星魂1・会心ダメージ', stats=StatSheet.of(crit_dmg=e1[1]), duration=Duration(turns=int(e1[2])), stacking=Stacking.REFRESH, source_id=me.id))
        t2 = self._t2(me)
        self._khaslana = True
        self._turns_left = int(turns)
        stats = StatSheet.of(atk_pct=t2[3], hp_pct=t2[4])
        if me.eidolon >= 2:
            stats.add(StatKey.RES_PEN_PHYSICAL, self._rank(2)[1])
        battle.apply_effect(me, Effect(key=KEY_KHASLANA, label='カスライナ', stats=stats, source_id=me.id))
        battle.gain_counter(me, WOUND, t2[0])
        self._saved_av = {}
        for u in [*battle.team, *battle.memosprites]:
            if u is me:
                continue
            av = battle.leave_action_bar(u)
            if av is not None:
                self._saved_av[id(u)] = (u, av)
            if u in battle.team:
                battle.suspended.add(u.id)
        battle.leave_action_bar(me)
        base_spd = me.built.base[StatKey.SPD]
        lc = me.effects.get(f'lc.23044.spd.{me.id}')
        if lc is not None:
            base_spd += lc.stats[StatKey.SPD]
        self._timer = battle.add_countdown(Countdown(name='カスライナ', spd=base_spd * spd_ratio * (int(turns) - 1), on_turn=lambda: self._khaslana_turn(me, battle)), order=me.position, entry_av=0.0)

    def _khaslana_turn(self, me, battle) -> None:
        self._turns_left -= 1
        if self._turns_left <= 0:
            self._last_attack(me, battle)
            self._end(me, battle)
            return
        battle._log(me.name, f'カスライナの追加ターン（残り {self._turns_left}）')
        with battle.attack_action(me):
            if battle.counter_value(me, WOUND) >= self._skills()['140811']['params']['1'][3]:
                self._judgement(me, battle)
            else:
                self._calamity(me, battle)
        battle.heal(me, me, me.max_hp * self._t2(me)[6], label='カスライナ')

    def _calamity(self, me, battle) -> None:
        s = self._skills()['140809']
        lv = self._levels(me)['BPSkill']
        aoe, _, hits, per, up = (p(s, lv, i) for i in range(1, 6))
        n = len(battle.alive_enemies)
        battle.gain_counter(me, WOUND, n)
        stacks = 1 + n + (self._rank(4)[0] if me.eidolon >= 4 else 0)
        scale = 1.0 + up * stacks
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, aoe * scale),), random=((StatKey.ATK, per * scale),), random_hits=int(hits), toughness=s.get('toughness'), label=f'{s['name']}・カウンター（熾炎 {stacks:.0f}）')

    def _judgement(self, me, battle) -> None:
        s = self._skills()['140811']
        lv = self._levels(me)['BPSkill']
        extra, per, hits, need, _ = (p(s, lv, i) for i in range(1, 6))
        wounds = battle.counter_value(me, WOUND)
        used = need if wounds >= need else wounds
        battle.spend_counter(me, WOUND, used)
        n = max(1, len(battle.alive_enemies))
        before = battle.total_damage
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, extra / n),) if used >= need else (), random=((StatKey.ATK, per),), random_hits=int(used * hits), toughness=s.get('toughness'), label=f'{s['name']}（壊傷 {used:.0f}）')
        total = battle.total_damage - before
        if me.eidolon >= 6 and battle.alive_enemies and (total > 0):
            top = max(battle.alive_enemies, key=lambda e: e.hp)
            battle.deal_damage(me, top, ELEMENT, DamageType.TRUE, (), flat=total * self._rank(6)[0])
        if me.eidolon >= 2 and used >= self._rank(2)[0]:
            self._turns_left += 1

    def _last_attack(self, me, battle) -> None:
        s = self._skills()['140803']
        lv = self._levels(me)['Ultra']
        n = max(1, len(battle.alive_enemies))
        with battle.attack_action(me):
            battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, p(s, lv, 1) / n),), toughness=s.get('toughness'), label='ラストアタック')

    def _end(self, me, battle) -> None:
        self._khaslana = False
        battle.remove_effect(me, KEY_KHASLANA)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
            self._timer = None
        for u, av in self._saved_av.values():
            battle.return_to_action_bar(u, av=av)
            battle.suspended.discard(getattr(u, 'id', ''))
        self._saved_av = {}
        battle.return_to_action_bar(me, av=None)
        spd = self._t2(me)[5]
        battle.apply_to_team(lambda who: Effect(key=KEY_END_SPD, label='変身終了・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=1), stacking=Stacking.REFRESH, source_id=me.id))
        a2 = self._traces().get('1408101')
        gain = self._stored + (a2['params'][0][0] if a2 else 0.0)
        self._stored = 0.0
        self._gain_ember(me, battle, gain)
        self._atk_stack(me, battle)

    def technique(self, me, battle) -> None:
        tech = self._skills()['140807']
        mult, wound, energy, sp = params_at(tech, 1)[:4]
        for c in battle.team:
            if c is not me:
                battle.gain_energy(c, energy, apply_regen=False)
        battle.gain_counter(me, WOUND, wound)
        battle.gain_sp(int(sp), actor=me)
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult),), toughness=tech.get('toughness'), label=tech['name'])
