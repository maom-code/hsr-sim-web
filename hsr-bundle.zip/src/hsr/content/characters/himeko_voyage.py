from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1510'
TRAILBLAZE_COMPANIONS = frozenset({'1001', '1002', '1003', '1004', '1213', '1224', '1313', '1413', '1414', '1510', '8001', '8002', '8003', '8004', '8005', '8006', '8007', '8008', '8009', '8010'})
ELEMENT = Element.FIRE
MODE_AUTO = 'auto'
MODE_ANNIHILATE = 'annihilate'
MODE_JUDGEMENT = 'judgement'
JUDGEMENT_USERS = frozenset({'1002', '1213', '1414', '1313', '8001', '8002', '8003', '8004', '8005', '8006', '8007', '8008', '8009', '8010'})
KEY_FLAG = 'himeko_v.skill.flag'
KEY_FLAG_TEAM = 'himeko_v.skill.flag.team'
KEY_TALENT = 'himeko_v.talent'
KEY_E4_TEAM = 'himeko_v.e4.team_pen'
KEY_E2 = 'himeko_v.e2.mult'
KEY_E6 = 'himeko_v.e6'
KEY_PACT = 'himeko_v.pact'
KEY_PACT_TEAM = 'himeko_v.pact.team'

@register(CHAR_ID)
class HimekoVoyage:
    mode_label = '同行協定'
    mode_options = ((MODE_AUTO, '同行協定：PT に合わせる'), (MODE_ANNIHILATE, '同行協定：殲滅に固定'), (MODE_JUDGEMENT, '同行協定：裁決に固定'))
    unimplemented = ('天賦の「弱点属性を無視して靭性を削る」（弱点撃破をオンにしたときは全属性弱点なので差が出ない）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _policy(self, battle, me) -> str:
        return battle.char_modes.get(me.id, MODE_AUTO)

    def _mode(self, battle, me) -> str:
        pact = getattr(self, '_pact', None)
        if pact is None:
            pact = self._initial_pact(battle, me)
            self._pact = pact
        return pact

    def _initial_pact(self, battle, me) -> str:
        policy = self._policy(battle, me)
        if policy != MODE_AUTO:
            return policy
        others = [c.id for c in battle.team if c is not me]
        return MODE_JUDGEMENT if any((cid in JUDGEMENT_USERS for cid in others)) else MODE_ANNIHILATE

    def _pact_for_user(self, battle, me, user) -> str:
        policy = self._policy(battle, me)
        if policy != MODE_AUTO:
            return policy
        return MODE_JUDGEMENT if user.id in JUDGEMENT_USERS else MODE_ANNIHILATE

    def _assist_params(self, me, battle) -> list[float]:
        sid = '151026' if self._mode(battle, me) == MODE_ANNIHILATE else '151025'
        return params_at(self._skills()[sid], self._levels(me)['BPSkill'])

    def _flag_expiring(self, me) -> bool:
        eff = me.effects.get(KEY_FLAG)
        return eff is None or eff.duration is None or eff.duration.turns <= 1

    @property
    def skill_sp_cost(self):
        me = getattr(self, '_me', None)
        if me is None:
            return None
        return 1 if self._flag_expiring(me) else 0
    rotation_label = '旗印が切れるならスキル、それ以外は支援スキル'

    def on_battle_start(self, me, battle) -> None:
        self._me = me
        self._pact = self._initial_pact(battle, me)
        self._charge = 0.0
        self._charges: dict[str, int] = {}
        self._refill(battle)

        def on_ally_turn(actor=None, kind=None, **kw):
            if actor is None or actor is me or actor not in battle.team:
                return
            if actor.id in battle.suspended or self._charges.get(actor.id, 0) < 1:
                return
            if actor.id not in TRAILBLAZE_COMPANIONS and me.eidolon < 2:
                return
            if not self._traces().get('1510102'):
                return
            self._ally_assist(me, battle, actor)
        battle.bus.subscribe(Event.TURN_START, on_ally_turn, owner_id=me.id)
        self._ally_ults = 0
        self._in_auto = False
        t = params_at(self._skills()['151004'], self._levels(me)['Talent'])
        stats = StatSheet.of(crit_dmg=t[0], res_pen=t[1])
        if me.eidolon >= 4:
            stats.add(StatKey.RES_PEN, self._rank(4)[0])
            battle.apply_to_team(lambda who: Effect(key=KEY_E4_TEAM, label='星魂4・耐性貫通', stats=StatSheet.of(res_pen=t[1]), source_id=me.id), exclude=me)
        battle.apply_effect(me, Effect(key=KEY_TALENT, label='共に灼熱の遠征へ', stats=stats, source_id=me.id))
        if me.eidolon >= 2:
            ratio = self._rank(2)[0]
            battle.apply_effect(me, Effect(key=KEY_E2, label='星魂2・必殺技と支援スキル 130%', type_multiplier={DamageType.SKILL: ratio, DamageType.ULTIMATE: ratio}, source_id=me.id))
        if me.eidolon >= 6:
            battle.apply_effect(me, Effect(key=KEY_E6, label='星魂6', source_id=me.id, stats=StatSheet.of(res_pen_fire=self._rank(6)[0], dmg_pct_skill=self._rank(6)[2])))

        def on_attack(source=None, targets_hit=0, rider=False, **kw):
            if rider or source is None or self._in_auto:
                return
            if self._mode(battle, me) != MODE_ANNIHILATE or not me.effects.has(KEY_PACT):
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            self._charge += targets_hit
            need = self._assist_params(me, battle)[8] - (self._rank(1)[1] if me.eidolon >= 1 else 0)
            while self._charge >= need:
                self._charge -= need
                self._auto_assist(me, battle)

        def on_ult(source_id=None, **kw):
            if source_id == me.id or self._mode(battle, me) != MODE_JUDGEMENT:
                return
            if not me.effects.has(KEY_PACT):
                return
            self._ally_ults += 1
            need = self._assist_params(me, battle)[8] - (self._rank(1)[0] if me.eidolon >= 1 else 0)
            if self._ally_ults >= need:
                self._ally_ults = 0
                self._auto_assist(me, battle)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=me.id)

    def on_turn_start(self, me, battle) -> None:
        a2 = self._traces().get('1510101')
        if a2:
            battle.gain_energy(me, a2['params'][0][0], apply_regen=False)
        if me.effects.has(KEY_FLAG):
            self._refill(battle, 1 + (1 if me.eidolon >= 2 else 0))

    def _cap(self, me, who) -> int:
        return 2 if who is me and me.eidolon >= 2 else 1

    def _refill(self, battle, n: int | None=None) -> None:
        me = self._me
        for c in battle.team:
            cap = self._cap(me, c)
            self._charges[c.id] = cap if n is None else min(cap, self._charges.get(c.id, 0) + n)

    def _ally_assist(self, me, battle, user) -> None:
        self._charges[user.id] = self._charges.get(user.id, 0) - 1
        self._enter_pact(me, battle, self._pact_for_user(battle, me, user))
        s = self._skills()['151022']
        a = params_at(s, self._levels(me)['BPSkill'])
        battle._log(user.name, '支援スキル')
        battle.bus.emit(Event.ON_ASSIST_SKILL, source_id=me.id, source=me, user=user, auto=False)
        with battle.attack_action(me):
            battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, a[0]),), random=((StatKey.ATK, a[2]),), random_hits=int(a[1]), label=f'支援スキル（{user.name}）')
        battle.bus.emit(Event.ON_SKILL_USED, source_id=me.id, actor=me)
        t = params_at(self._skills()['151004'], self._levels(me)['Talent'])
        battle.gain_energy(user, t[2], apply_regen=False)

    def basic(self, me, battle) -> None:
        s = self._skills()['151001']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        if self._flag_expiring(me):
            s = self._skills()['151002']
            battle.spend_sp(1, actor=me)
            self._refill(battle)
            self._raise_flag(me, battle)
            battle.gain_energy(me, s['energy'])
            return
        self._assist(me, battle)

    def _raise_flag(self, me, battle) -> None:
        s = self._skills()['151002']
        lv = self._levels(me)['BPSkill']
        dmg_up, turns = (p(s, lv, 1), int(p(s, lv, 2)))
        battle.apply_effect(me, Effect(key=KEY_FLAG, label='導く旗印', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, lambda who: Effect(key=KEY_FLAG_TEAM, label='導く旗印・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_FLAG)

    def _enter_pact(self, me, battle, pact: str | None=None) -> None:
        if pact is not None and pact != self._mode(battle, me):
            battle.remove_effect(me, KEY_PACT)
            for who in [*battle.team, *battle.memosprites]:
                battle.remove_effect(who, KEY_PACT_TEAM)
            battle._log(me.name, '同行協定の切り替え')
            self._pact = pact
        a = self._assist_params(me, battle)
        if self._mode(battle, me) == MODE_ANNIHILATE:
            battle.apply_effect(me, Effect(key=KEY_PACT, label='同行協定：殲滅', source_id=me.id))
            battle.apply_aura(me, lambda who: Effect(key=KEY_PACT_TEAM, label='同行協定：殲滅・会心ダメージ', stats=StatSheet.of(crit_dmg=a[7], crit_dmg_skill=a[9]), source_id=me.id), key=KEY_PACT)
        else:
            battle.apply_effect(me, Effect(key=KEY_PACT, label='同行協定：裁決', stats=StatSheet.of(dmg_pct=a[7], dmg_pct_ultimate=a[9]), source_id=me.id))

    def _assist_damage(self, me, battle, label: str, *, auto: bool=False) -> None:
        battle.bus.emit(Event.ON_ASSIST_SKILL, source_id=me.id, source=me, auto=auto)
        a = self._assist_params(me, battle)
        hits = int(a[4]) + (int(self._rank(1)[3]) if me.eidolon >= 1 else 0)
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, a[3]),), random=((StatKey.ATK, a[5]),), random_hits=hits, label=label)

    def _assist(self, me, battle) -> None:
        s = self._skills()['151026' if self._mode(battle, me) == MODE_ANNIHILATE else '151025']
        self._enter_pact(me, battle)
        self._assist_damage(me, battle, s['name'])
        battle.gain_energy(me, s['energy'])

    def _auto_assist(self, me, battle) -> None:
        self._in_auto = True
        try:
            with battle.attack_action(me):
                self._assist_damage(me, battle, '追加の支援スキル', auto=True)
        finally:
            self._in_auto = False

    def ultimate(self, me, battle) -> None:
        s = self._skills()['151003']
        lv = self._levels(me)['Ultra']
        main_total, others = (p(s, lv, 9), p(s, lv, 10))
        hits = 6
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, others),), random=((StatKey.ATK, (main_total - others) / hits),), random_hits=hits, toughness=self._skills()['151014'].get('toughness'), label=s['name'])
        if me.eidolon >= 6:
            battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, self._rank(6)[4]),), label='星魂6・追加ダメージ')
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        self._raise_flag(me, battle)
