from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.memosprite import MemospriteSpec, spec_from_curated
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1413'
ELEMENT = Element.ICE
MEMOSTHENE = '憶質'
KEY_MEMO_CRIT = 'nagayotsuki.skill.memo_crit'
KEY_RIDDLE = 'nagayotsuki.ult.riddle'
KEY_RIDDLE_VULN = 'nagayotsuki.ult.riddle_vuln'
KEY_TRACE_CRIT = 'nagayotsuki.trace.crit_rate'
KEY_HP_LOSS_CRIT = 'nagayotsuki.talent.hp_loss_crit'
KEY_TRACE_A2_CRIT = 'nagayotsuki.trace.a2_crit_dmg'
KEY_E2_CRIT = 'nagayotsuki.e2.crit_dmg'
KEY_E6_RESPEN = 'nagayotsuki.e6.res_pen'
KEY_DISMISS_SPD = 'nagayotsuki.memo.dismiss_spd'
KEY_E1_MULT = 'nagayotsuki.e1.memo_multiplier'
KEY_MEMO_PRESENT = 'nagayotsuki.memo.presence_dmg'
KEY_E4_BREAK = 'nagayotsuki.e4.break_efficiency'
DREAM_DMG_BONUS = '歳月の詩・夢の与ダメージ'
MEMO_CRIT_BONUS = '歳月の詩・会心ダメージ比率'

@register(CHAR_ID)
class Nagayotsuki:
    self_crit_rate_buff = 0.35
    crit_rate_target = 0.65
    main_stats = {'FOOT': 'HPAddedRatio'}
    speed_target = 110.0
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _memo_skills(self) -> dict:
        return self._char()['memosprite']['skills']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _memo_spec(self, me) -> MemospriteSpec:
        char = self._char()
        m = char['memosprite']
        ref = char['skills'].get(m['ref_skill']) if m['ref_skill'] else None
        spec = spec_from_curated(m, ref, self._levels(me)['Talent'])
        return MemospriteSpec(**{**spec.__dict__, 'acts_immediately': True})

    def _quality(self, battle, me) -> float:
        return battle.counter_value(me, MEMOSTHENE)

    def on_battle_start(self, me, battle) -> None:
        lv = self._levels(me)
        traces = self._char()['traces']['abilities']
        if me.eidolon >= 2:
            e2 = self._char()['ranks']['2']['params']
            me.counter(MEMOSTHENE).bonus_per_gain = e2[0]
        a2 = traces.get('1413101')
        if a2:
            battle.apply_effect(me, Effect(key=KEY_TRACE_CRIT, label='軌跡・会心率', stats=StatSheet.of(crit_rate=a2['params'][0][0]), source_id=me.id))
        a4 = traces.get('1413102')
        if a4:
            gain, energy, start_quality, energy_on_skill = a4['params'][0]
            battle.gain_energy(me, energy, apply_regen=False)
            self._gain_quality(me, battle, start_quality)

            def on_own_skill(actor=None, source_id=None, **kw):
                if source_id != me.id:
                    return
                battle.gain_energy(me, energy_on_skill, apply_regen=False)
                self._gain_quality(me, battle, gain)

            def on_memo_skill(memo=None, source_id=None, **kw):
                owner = getattr(memo, 'summoner', None)
                if owner is None or owner not in battle.team:
                    return
                battle.gain_energy(me, energy_on_skill, apply_regen=False)
                self._gain_quality(me, battle, gain)
            battle.bus.subscribe(Event.ON_SKILL_USED, on_own_skill, owner_id=me.id)
            battle.bus.subscribe(Event.ON_MEMO_SKILL, on_memo_skill, owner_id=me.id)
        if me.eidolon >= 4:
            team_eff, own_eff = self._char()['ranks']['4']['params']

            def grant_break_eff(**kw):
                for memo in battle.memosprites:
                    if memo.summoner not in battle.team:
                        continue
                    value = team_eff + (own_eff if memo.summoner is me else 0.0)
                    battle.apply_effect(memo, Effect(key=KEY_E4_BREAK, label='星魂4・弱点撃破効率', stats=StatSheet.of(break_efficiency=value), source_id=me.id))
            grant_break_eff()
            battle.bus.subscribe(Event.ON_MEMO_SUMMON, grant_break_eff, owner_id=me.id)
        if me.eidolon >= 6:
            res_pen = self._char()['ranks']['6']['params'][1]
            battle.apply_to_team(lambda who: Effect(key=KEY_E6_RESPEN, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=res_pen), source_id=me.id))
        presence = p(self._memo_skills()['1141303'], lv['ServantTalent'], 1)

        def refresh_presence(**kw):
            memo = battle.memosprite_of(me)
            if memo is None:
                battle.remove_effect(me, KEY_MEMO_PRESENT)
                return
            for who in (me, memo):
                battle.apply_effect(who, Effect(key=KEY_MEMO_PRESENT, label='精霊天賦・与ダメージ', stats=StatSheet.of(dmg_pct=presence), source_id=me.id))
            riddle = me.effects.get(KEY_RIDDLE)
            if riddle is not None:
                battle.apply_effect(memo, Effect(key=KEY_RIDDLE, label='至暗の謎', stats=StatSheet(dict(riddle.stats.values)), source_id=me.id))
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, refresh_presence, owner_id=me.id)
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, refresh_presence, owner_id=me.id)
        battle.summon_memosprite(me, self._memo_spec(me))
        refresh_presence()

        def on_dismiss(memo=None, source_id=None, **kw):
            if source_id != me.id:
                return
            s = self._memo_skills()['1141306']
            base, per, cap = (p(s, lv['ServantTalent'], i) for i in (1, 2, 3))
            spent = getattr(self, '_last_dream_spent', 0.0)
            bonus = base + min(spent, cap) * per
            battle.apply_effect(me, Effect(key=KEY_DISMISS_SPD, label='精霊天賦・速度', stats=StatSheet.of(spd_pct=bonus), duration=Duration(turns=1, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
            self._last_dream_spent = 0.0
        battle.bus.subscribe(Event.ON_MEMO_DISMISS, on_dismiss, owner_id=me.id)

        def on_hp_loss(target=None, **kw):
            if target is me or getattr(target, 'summoner', None) is me:
                self._on_hp_loss(me, battle)
        battle.bus.subscribe(Event.ON_HP_LOSS, on_hp_loss, owner_id=me.id)

    def _on_hp_loss(self, me, battle) -> None:
        s = self._skills()['141304']
        lv = self._levels(me)['Talent']
        quality, crit_dmg, turns = (p(s, lv, i) for i in (1, 2, 3))
        for who in (me, *[m for m in battle.memosprites if m.summoner is me]):
            battle.apply_effect(who, Effect(key=KEY_HP_LOSS_CRIT, label='天賦・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        self._gain_quality(me, battle, quality)

    def _gain_quality(self, me, battle, amount: float, *, by_memo: bool=False) -> None:
        battle.gain_counter(me, MEMOSTHENE, amount)
        self._check_instant_action(me, battle, by_memo=by_memo)

    def _check_instant_action(self, me, battle, *, by_memo: bool=False) -> None:
        s = self._skills()['141304']
        threshold = p(s, self._levels(me)['Talent'], 6)
        if self._quality(battle, me) < threshold:
            return
        if getattr(self, '_instant_used', False):
            return
        memo = battle.memosprite_of(me)
        if memo is None or not memo.alive:
            return
        self._instant_used = True
        if by_memo:
            self._chain_pending = True
            return
        battle.act_next(memo)

    def basic(self, me, battle) -> None:
        s = self._skills()['141301']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def _memo_crit_buff(self, me, battle, ratio: float, turns: int) -> None:
        ratio += battle.counter_value(me, MEMO_CRIT_BONUS)
        bonus = me.stats[StatKey.CRIT_DMG] * ratio
        a6 = self._char()['traces']['abilities'].get('1413103')
        if a6:
            memory_allies = sum((1 for c in battle.team if c.built.path.value == 'Memory'))
            steps = a6['params'][0]
            bonus += steps[min(max(memory_allies, 1), len(steps)) - 1]
        for m in battle.memosprites:
            battle.apply_effect(m, Effect(key=KEY_MEMO_CRIT, label='長夜月・会心ダメージ', stats=StatSheet.of(crit_dmg=bonus), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))

    def technique(self, me, battle) -> None:
        tech = self._skills()['141307']
        skill = self._skills()['141302']
        lv = self._levels(me)['BPSkill']
        ratio, turns = (p(skill, lv, 1), p(skill, lv, 2))
        self._memo_crit_buff(me, battle, ratio, int(turns))
        self._gain_quality(me, battle, params_at(tech, 1)[0])

    def skill(self, me, battle) -> None:
        s = self._skills()['141302']
        lv = self._levels(me)['BPSkill']
        ratio, turns, quality, heal, riddle_bonus, hp_cost = (p(s, lv, i) for i in (1, 2, 3, 4, 5, 6))
        battle.spend_hp(me, ratio=hp_cost)
        existing = battle.memosprite_of(me)
        if existing is not None:
            existing.heal(existing.max_hp * heal)
        memo = battle.summon_memosprite(me, self._memo_spec(me))
        self._memo_crit_buff(me, battle, ratio, int(turns))
        self._gain_quality(me, battle, quality)
        if me.effects.has(KEY_RIDDLE):
            self._gain_quality(me, battle, riddle_bonus)
        a2 = self._char()['traces']['abilities'].get('1413101')
        if a2:
            _, cost, cd_up, cd_turns = a2['params'][0]
            battle.spend_hp(me, ratio=cost)
            for who in (me, *[m for m in battle.memosprites if m.summoner is me]):
                battle.apply_effect(who, Effect(key=KEY_TRACE_A2_CRIT, label='軌跡A2・会心ダメージ', stats=StatSheet.of(crit_dmg=cd_up), duration=Duration(turns=int(cd_turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, s['energy'])
        _ = memo

    def ultimate(self, me, battle) -> None:
        s = self._skills()['141303']
        lv = self._levels(me)['Ultra']
        dmg_mult, charge, dmg_up, vuln = (p(s, lv, i) for i in (1, 2, 3, 4))
        memo = battle.summon_memosprite(me, self._memo_spec(me))
        battle.attack(memo, ELEMENT, DamageType.MEMO, aoe=((StatKey.HP, dmg_mult),), toughness=s.get('toughness'), label=s['name'])
        if me.eidolon >= 2:
            charge += self._char()['ranks']['2']['params'][1]
        battle.gain_counter(me, '至暗の謎チャージ', charge)
        for who in (me, *[m for m in battle.memosprites if m.summoner is me]):
            battle.apply_effect(who, Effect(key=KEY_RIDDLE, label='至暗の謎', stats=StatSheet.of(dmg_pct=dmg_up), source_id=me.id))
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_RIDDLE_VULN, label='至暗の謎(脆弱)', stats=StatSheet.of(vulnerability=vuln), source_id=me.id))
        battle.gain_energy(me, s['energy'])

    def on_turn_start(self, me, battle) -> None:
        if not me.effects.has(KEY_RIDDLE):
            return
        if battle.counter_value(me, '至暗の謎チャージ') > 0:
            return
        battle.remove_effect(me, KEY_RIDDLE)
        for m in battle.memosprites:
            battle.remove_effect(m, KEY_RIDDLE)

    def memo_turn(self, memo, battle) -> None:
        me = memo.summoner
        lv = self._levels(me)
        dream = self._memo_skills()['1141307']
        threshold = p(dream, lv['Servant'], 3)
        self._chain_pending = False
        if self._quality(battle, me) >= threshold:
            self._dream(memo, battle)
        else:
            self._rain(memo, battle)
        if self._chain_pending:
            self._chain_pending = False
            if memo.alive:
                battle.act_now(memo)

    def _rain(self, memo, battle) -> None:
        me = memo.summoner
        s = self._memo_skills()['1141301']
        lv = self._levels(me)['Servant']
        base, per_group, group, gain = (p(s, lv, i) for i in (1, 2, 3, 4))
        groups = int(self._quality(battle, me) // group)
        battle.attack(memo, ELEMENT, DamageType.MEMO, main=((StatKey.HP, base + per_group * groups),), label=f'{s['name']}（憶質{groups}組）')
        battle.gain_energy(me, s['energy'])
        self._gain_quality(me, battle, gain, by_memo=True)

    def _dream(self, memo, battle) -> None:
        me = memo.summoner
        s = self._memo_skills()['1141307']
        lv = self._levels(me)['Servant']
        main_per, others_per = (p(s, lv, 1), p(s, lv, 2))
        quality = self._quality(battle, me)
        bonus = battle.counter_value(me, DREAM_DMG_BONUS)
        if bonus:
            battle.apply_effect(memo, Effect(key='nagayotsuki.dream.external_dmg', label='詩・夢の与ダメージ', stats=StatSheet.of(dmg_pct=bonus), duration=Duration(turns=1, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.attack(memo, ELEMENT, DamageType.MEMO, main=((StatKey.HP, main_per * quality),), others=((StatKey.HP, others_per * quality),), label=f'{s['name']}（憶質{quality:.0f}）')
        if bonus:
            battle.remove_effect(memo, 'nagayotsuki.dream.external_dmg')
        battle.gain_energy(me, s['energy'])
        spent = battle.spend_counter(me, MEMOSTHENE)
        self._last_dream_spent = spent
        self._instant_used = False
        if me.eidolon >= 6:
            ratio = self._char()['ranks']['6']['params'][0]
            self._gain_quality(me, battle, spent * ratio)
        battle.spend_counter(me, '至暗の謎チャージ', 1)
        if self._char()['traces']['abilities'].get('1413101'):
            battle.gain_sp(1)
        battle.spend_hp(memo, amount=memo.hp)
        battle.dismiss_memosprite(memo)

    def eidolon_1(self, me, battle) -> None:
        steps = self._char()['ranks']['1']['params']

        def refresh(**kw):
            alive = len(battle.alive_enemies)
            if alive <= 0:
                return
            mult = steps[0] if alive >= 4 else steps[4 - alive]
            for m in battle.memosprites:
                battle.apply_effect(m, Effect(key=KEY_E1_MULT, label='星魂1・憶像ダメージ', multiplier=mult, source_id=me.id))
        refresh()
        battle.bus.subscribe(Event.TURN_START, lambda **kw: refresh(), owner_id=me.id)
        battle.bus.subscribe(Event.ON_MEMO_SUMMON, lambda **kw: refresh(), owner_id=me.id)

    def eidolon_2(self, me, battle) -> None:
        cd = self._char()['ranks']['2']['params'][2]
        battle.apply_effect(me, Effect(key=KEY_E2_CRIT, label='星魂2・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), source_id=me.id))
