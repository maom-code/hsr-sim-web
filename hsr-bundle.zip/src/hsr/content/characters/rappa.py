from __future__ import annotations
from contextlib import contextmanager
from ...data import loader
from ...engine import break_effects
from ...engine import damage as dmg
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1317'
ELEMENT = Element.IMAGINARY
CHARGE = 'チャージ'
INK = '彩墨'
KEY_SEAL = 'rappa.sealform'
KEY_ENHANCED = 'rappa.enhanced_attack'
KEY_IGNORE = 'rappa.ignore_weakness'
KEY_A6 = 'rappa.trace.break_taken'
KEY_E4_SPD = 'rappa.e4.spd'
TOUGHNESS_UNIT = 3.0

@register(CHAR_ID)
class Rappa:
    unimplemented = ('強化通常攻撃の「虚数弱点がない敵にも本来の 50% の靭性を削る」。弱点撃破は全属性弱点で回すので差が出ない',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['131704'], self._levels(me)['Talent'])

    def _charge_cap(self, me) -> float:
        cap = self._talent(me)[0]
        if me.eidolon >= 6:
            cap += self._rank(6)[1]
        return cap

    def on_battle_start(self, me, battle) -> None:
        self._seal = False
        me.counter(CHARGE, maximum=self._charge_cap(me))
        me.counter(INK, maximum=3)
        if me.eidolon >= 6:
            battle.gain_counter(me, CHARGE, self._rank(6)[0], maximum=self._charge_cap(me))

        def on_break(target=None, **kw):
            battle.gain_counter(me, CHARGE, 1, maximum=self._charge_cap(me))
            a2 = self._traces().get('1317101')
            if a2:
                energy, extra = a2['params'][0][:2]
                battle.gain_counter(me, CHARGE, extra, maximum=self._charge_cap(me))
                battle.gain_energy(me, energy, apply_regen=False)
            a6 = self._traces().get('1317103')
            if a6 and target is not None:
                base, floor, per, cap, turns = a6['params'][0][:5]
                over = max(0.0, me.stats[StatKey.ATK] - floor)
                up = base + min(cap, int(over // 100) * per)
                battle.apply_effect(target, Effect(key=KEY_A6, label='忍法帖・枯葉', stats=StatSheet.of(break_taken=up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)
        self._pending_extra = False

        def on_ult_used(source_id=None, **kw):
            if source_id == me.id and self._pending_extra:
                self._pending_extra = False
                battle.extra_turn(me)
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult_used, owner_id=me.id)

    def can_use_skill(self, me, battle) -> bool:
        return not self._seal

    def can_use_ultimate(self, me, battle) -> bool:
        return not self._seal

    def basic(self, me, battle) -> None:
        if self._seal:
            self._petals(me, battle)
            return
        s = self._skills()['131701']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['131702']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    @contextmanager
    def _enhanced(self, me, battle):
        a4 = self._traces().get('1317102')
        if a4:
            battle.apply_effect(me, Effect(key=KEY_ENHANCED, label='忍法帖・海鳴', stats=StatSheet.of(super_break_rate=a4['params'][0][0]), source_id=me.id))
        try:
            yield
        finally:
            battle.remove_effect(me, KEY_ENHANCED)

    def _petals(self, me, battle) -> None:
        lv = self._levels(me)['Normal']
        s1, s2, s3 = (self._skills()[k] for k in ('131708', '131710', '131712'))
        main, adj = (p(s1, lv, 1), p(s1, lv, 2))
        aoe = p(s3, lv, 1)
        with self._enhanced(me, battle):
            for s in (s1, s2):
                tough = dict(s.get('toughness') or {})
                if me.eidolon >= 2 and 'main' in tough:
                    tough['main'] *= 1 + self._rank(2)[0]
                battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, main),), adjacent=((StatKey.ATK, adj),), toughness=tough, label=s['name'])
            battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, aoe),), toughness=s3.get('toughness'), label=f'{s3['name']}（3段目）')
            self._talent_hit(me, battle)
        battle.gain_energy(me, sum((s.get('energy') or 0 for s in (s1, s2, s3))))
        battle.spend_counter(me, INK, 1)
        if battle.counter_value(me, INK) <= 0:
            self._end_seal(me, battle)

    def _talent_hit(self, me, battle) -> None:
        t = self._talent(me)
        charges = battle.spend_counter(me, CHARGE)
        ratio = t[2] + t[4] * charges
        tough = (t[3] + t[5] * charges) * TOUGHNESS_UNIT
        dealt = 0.0
        for e in list(battle.alive_enemies):
            base = dmg.break_damage_base(ELEMENT, me.level, e.max_toughness)
            dealt += battle.deal_damage(me, e, ELEMENT, DamageType.BREAK, (), break_base=base * ratio)
        if dealt:
            battle._log(me.name, f'天賦・撃破ダメージ（チャージ {charges:.0f}）', dealt)
        battle.apply_effect(me, Effect(key=break_effects.IGNORE_WEAKNESS_KEY, label='弱点無視', source_id=me.id))
        try:
            for e in list(battle.alive_enemies):
                battle.reduce_toughness(me, e, tough, ELEMENT)
        finally:
            battle.remove_effect(me, break_effects.IGNORE_WEAKNESS_KEY)
        if me.eidolon >= 6:
            battle.gain_counter(me, CHARGE, self._rank(6)[0], maximum=self._charge_cap(me))

    def ultimate(self, me, battle) -> None:
        s = self._skills()['131703']
        lv = self._levels(me)['Ultra']
        eff, be, ink = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        stats = StatSheet.of(break_efficiency=eff, break_effect=be)
        if me.eidolon >= 1:
            stats.add(StatKey.DEF_IGNORE, self._rank(1)[0])
        battle.apply_effect(me, Effect(key=KEY_SEAL, label='結印', stats=stats, source_id=me.id))
        self._seal = True
        battle.gain_counter(me, INK, ink, maximum=3)
        if me.eidolon >= 4:
            spd = self._rank(4)[0]
            for c in battle.team:
                before = c.speed()
                battle.apply_effect(c, Effect(key=KEY_E4_SPD, label='星魂4・速度', stats=StatSheet.of(spd_pct=spd), source_id=me.id))
                if any((sl.actor is c for sl in battle.queue.slots)):
                    battle.queue.rescale(c, before)
        battle.gain_energy(me, s['energy'])
        self._pending_extra = True

    def _end_seal(self, me, battle) -> None:
        self._seal = False
        battle.remove_effect(me, KEY_SEAL)
        if me.eidolon >= 4:
            for c in battle.team:
                if c.effects.has(KEY_E4_SPD):
                    before = c.speed()
                    battle.remove_effect(c, KEY_E4_SPD)
                    if any((sl.actor is c for sl in battle.queue.slots)):
                        battle.queue.rescale(c, before)
        if me.eidolon >= 1:
            battle.gain_energy(me, self._rank(1)[1], apply_regen=False)

    def technique(self, me, battle) -> None:
        tech = self._skills()['131707']
        _, main, adj, energy, tough = params_at(tech, 1)[:5]
        foe = battle.target
        if foe is None:
            return
        for e, ratio in [(foe, main)] + [(a, adj) for a in battle.adjacent_to(foe)]:
            base = dmg.break_damage_base(ELEMENT, me.level, e.max_toughness)
            dealt = battle.deal_damage(me, e, ELEMENT, DamageType.BREAK, (), break_base=base * ratio)
            battle._log(me.name, '秘技・撃破ダメージ', dealt)
        battle.apply_effect(me, Effect(key=break_effects.IGNORE_WEAKNESS_KEY, label='弱点無視', source_id=me.id))
        try:
            battle.reduce_toughness(me, foe, tough * TOUGHNESS_UNIT, ELEMENT)
        finally:
            battle.remove_effect(me, break_effects.IGNORE_WEAKNESS_KEY)
        battle.gain_energy(me, energy, apply_regen=False)
