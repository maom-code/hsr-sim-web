from __future__ import annotations
from ...data import loader
from ...engine.effects import DOT_BLEED, DOT_BURN, DOT_SHOCK, DOT_WIND, Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1410'
ELEMENT = Element.PHYSICAL
KEY_DOT = 'hysilens.dot.'
KEY_ZONE = 'hysilens.zone'
KEY_ZONE_DEBUFF = 'hysilens.zone.debuff'
KEY_SKILL_VULN = 'hysilens.skill.vuln'
KEY_A6_DMG = 'hysilens.trace.dmg'
KEY_A6_TEAM = 'hysilens.trace.dmg.team'
KEY_E1_DOT = 'hysilens.e1.dot'
KEY_ECHO = 'hysilens.echo'
KINDS = ((DOT_WIND, Element.WIND, '風化'), (DOT_BLEED, Element.PHYSICAL, '裂創'), (DOT_BURN, Element.FIRE, '燃焼'), (DOT_SHOCK, Element.LIGHTNING, '感電'))

@register(CHAR_ID)
class Hysilens:
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _ult(self, me) -> list[float]:
        return params_at(self._skills()['141003'], self._levels(me)['Ultra'])

    def _echo_cap(self, me) -> int:
        return int(self._rank(6)[0]) if me.eidolon >= 6 else int(self._ult(me)[4])

    def on_battle_start(self, me, battle) -> None:
        self._echo_left = self._echo_cap(me)
        a6 = self._traces().get('1410103')
        self._a6 = 0.0
        if a6:
            floor, step, per, cap = a6['params'][0][:4]
            over = max(0.0, me.stats[StatKey.EFFECT_HIT] - floor)
            self._a6 = min(cap, int(over / step + 1e-09) * per)
            battle.apply_effect(me, Effect(key=KEY_A6_DMG, label='真珠の琴線', stats=StatSheet.of(dmg_pct=self._a6), source_id=me.id))
        if me.eidolon >= 1:
            battle.apply_to_team(lambda who: Effect(key=KEY_E1_DOT, label='星魂1・持続ダメージ', type_multiplier={DamageType.DOT: self._rank(1)[0]}, source_id=me.id))

        def on_attack_start(source=None, **kw):
            owner = getattr(source, 'attributed_to', source)
            if owner in battle.team:
                self._echo_left = self._echo_cap(me)

        def on_turn(actor=None, **kw):
            if actor is not None and actor in battle.enemies:
                self._echo_left = self._echo_cap(me)

        def on_attack(source=None, targets=None, rider=False, **kw):
            if source is None or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            n = 1 + (int(self._rank(1)[1]) if me.eidolon >= 1 else 0)
            for e in targets or []:
                for _ in range(n):
                    self._afflict(me, battle, e)

        def on_dot(target=None, effect=None, **kw):
            if target is None or effect is None or effect.key == KEY_ECHO:
                return
            if not me.effects.has(KEY_ZONE) or self._echo_left <= 0:
                return
            self._echo_left -= 1
            mult = self._ult(me)[3] + (self._rank(6)[1] if me.eidolon >= 6 else 0.0)
            dealt = battle.deal_damage(me, target, ELEMENT, DamageType.DOT, ((StatKey.ATK, mult),))
            if dealt:
                battle._log(me.name, '結界・持続ダメージ', dealt)
            battle.bus.emit(Event.ON_DOT_DAMAGE, source_id=me.id, source=me, target=target, effect=Effect(key=KEY_ECHO, dot_base=1.0), amount=dealt, detonated=True)
        battle.bus.subscribe(Event.ON_ATTACK_START, on_attack_start, owner_id=me.id)
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.bus.subscribe(Event.ON_DOT_DAMAGE, on_dot, owner_id=me.id)
        a2 = self._traces().get('1410101')
        if a2:
            self._zone(me, battle, int(a2['params'][0][0]))

    def _afflict(self, me, battle, enemy) -> None:
        if not enemy.alive:
            return
        t = params_at(self._skills()['141004'], self._levels(me)['Talent'])
        ratio, turns = (t[1], int(t[4]))
        missing = [k for k in KINDS if not enemy.effects.has(KEY_DOT + k[0])]
        kind = missing[0] if missing else min(KINDS, key=lambda k: enemy.effects.get(KEY_DOT + k[0]).duration.turns)
        dot_kind, element, label = kind
        base = me.stats[StatKey.ATK] * ratio
        if dot_kind == DOT_BLEED:
            base = min(enemy.max_hp * t[2], base)
        battle.apply_effect(enemy, Effect(key=KEY_DOT + dot_kind, label=f'{label}（セイレンス）', dot_base=base, dot_element=element, dot_kind=dot_kind, duration=Duration(turns=turns), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))

    def _zone(self, me, battle, turns: int) -> None:
        u = self._ult(me)
        battle.apply_effect(me, Effect(key=KEY_ZONE, label='結界', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        stats = StatSheet.of(atk_pct=-u[5], def_down=u[2])
        if me.eidolon >= 4:
            stats.add(StatKey.RES_DOWN, self._rank(4)[0])
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_ZONE_DEBUFF, label='結界・弱体', stats=StatSheet(dict(stats.values)), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        if me.eidolon >= 2 and self._a6:
            battle.apply_aura(me, lambda who: Effect(key=KEY_A6_TEAM, label='星魂2・真珠の琴線', stats=StatSheet.of(dmg_pct=self._a6), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_ZONE, exclude=me)
        a2 = self._traces().get('1410101')
        if a2:
            battle.gain_sp(int(a2['params'][0][1]), actor=me)

    def basic(self, me, battle) -> None:
        s = self._skills()['141001']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['141002']
        lv = self._levels(me)['BPSkill']
        mult, _, vuln, turns = (p(s, lv, i) for i in range(1, 5))
        battle.spend_sp(battle.skill_cost(me), actor=me)
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_SKILL_VULN, label='倍音・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['141003']
        u = self._ult(me)
        self._zone(me, battle, int(u[1]))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, u[0]),), toughness=s.get('toughness'), label=s['name'])
        a4 = self._traces().get('1410102')
        if a4:
            for e in battle.alive_enemies:
                battle.detonate_dots(e, a4['params'][0][0])
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['141007']
        n = int(params_at(tech, 1)[2])
        for e in battle.enemies:
            for _ in range(n):
                self._afflict(me, battle, e)
