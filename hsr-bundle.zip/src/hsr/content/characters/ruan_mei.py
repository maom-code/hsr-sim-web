from __future__ import annotations
from ...data import loader
from ...engine import damage as dmg
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1303'
ELEMENT = Element.ICE
KEY_STRING = 'ruanmei.skill.overtone'
KEY_STRING_TEAM = 'ruanmei.skill.overtone.team'
KEY_ZONE = 'ruanmei.ult.zone'
KEY_ZONE_TEAM = 'ruanmei.ult.zone.team'
KEY_THANOXIAN = 'ruanmei.ult.thanoxian'
KEY_TALENT_SPD = 'ruanmei.talent.spd'
KEY_A2_BE = 'ruanmei.trace.break_effect'
KEY_E2_ATK = 'ruanmei.e2.atk'
KEY_E4_BE = 'ruanmei.e4.break_effect'

@register(CHAR_ID)
class RuanMei:
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _break_damage(self, me, battle, target, ratio: float, label: str) -> None:
        base = dmg.break_damage_base(ELEMENT, me.level, target.max_toughness) * ratio
        dealt = battle.deal_damage(me, target, ELEMENT, DamageType.BREAK, (), break_base=base)
        if dealt:
            battle._log(me.name, label, dealt)

    def on_battle_start(self, me, battle) -> None:
        self._thanoxian_used: set[str] = set()
        talent = self._skills()['130304']
        lv = self._levels(me)['Talent']
        spd, break_ratio = (p(talent, lv, 1), p(talent, lv, 2))
        if me.eidolon >= 6:
            break_ratio += self._rank(6)[1]
        battle.apply_to_team(lambda who: Effect(key=KEY_TALENT_SPD, label='フラクタルの螺旋・速度', stats=StatSheet.of(spd_pct=spd), source_id=me.id), exclude=me)
        a2 = self._traces().get('1303101')
        if a2:
            battle.apply_to_team(lambda who: Effect(key=KEY_A2_BE, label='軌跡・撃破特効', stats=StatSheet.of(break_effect=a2['params'][0][0]), source_id=me.id))

        def on_break(target=None, **kw):
            if target is None:
                return
            self._break_damage(me, battle, target, break_ratio, '天賦・撃破ダメージ')
            if me.eidolon >= 4:
                be, turns = self._rank(4)[:2]
                battle.apply_effect(me, Effect(key=KEY_E4_BE, label='星魂4・撃破特効', stats=StatSheet.of(break_effect=be), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
            self._sync_e2(me, battle)
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)

        def on_recover_attempt(target=None, state=None, **kw):
            if target is None or state is None or (not target.effects.has(KEY_THANOXIAN)):
                return
            battle.remove_effect(target, KEY_THANOXIAN)
            self._thanoxian_used.add(target.id)
            state['extend'] = True
            ult = self._skills()['130303']
            ulv = self._levels(me)['Ultra']
            delay = me.stats[StatKey.BREAK_EFFECT] * p(ult, ulv, 3) + p(ult, ulv, 4)
            battle._log(target.name, '残梅・撃破延長')
            battle.delay_action(target, delay)
            self._break_damage(me, battle, target, p(ult, ulv, 5), '残梅・撃破ダメージ')

        def on_recover(target=None, **kw):
            if target is not None:
                self._thanoxian_used.discard(target.id)
            self._sync_e2(me, battle)
        battle.bus.subscribe(Event.ON_BREAK_RECOVER_ATTEMPT, on_recover_attempt, owner_id=me.id)
        battle.bus.subscribe(Event.ON_BREAK_RECOVER, on_recover, owner_id=me.id)

        def on_ally_attack(source=None, targets=None, rider=False, **kw):
            if source is None or rider or (not me.effects.has(KEY_ZONE)):
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            for e in targets or []:
                if e.alive and e.id not in self._thanoxian_used and (not e.effects.has(KEY_THANOXIAN)):
                    battle.apply_effect(e, Effect(key=KEY_THANOXIAN, label='残梅', stacking=Stacking.UNIQUE, source_id=me.id))
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)

    def _sync_e2(self, me, battle) -> None:
        if me.eidolon < 2:
            return
        if any((e.is_broken for e in battle.alive_enemies)):
            battle.apply_aura(me, lambda who: Effect(key=KEY_E2_ATK, label='星魂2・攻撃力（撃破中）', stats=StatSheet.of(atk_pct=self._rank(2)[0]), source_id=me.id))
        else:
            for who in [*battle.team, *battle.memosprites]:
                battle.remove_effect(who, KEY_E2_ATK)

    def on_turn_start(self, me, battle) -> None:
        a4 = self._traces().get('1303102')
        if a4:
            battle.gain_energy(me, a4['params'][0][0], apply_regen=False)

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self.buff_expiring(me, battle) else Action.BASIC
    rotation_label = 'バフが切れるならスキル'

    def buff_expiring(self, me, battle) -> bool:
        eff = me.effects.get(KEY_STRING)
        return eff is None or eff.duration is None or eff.duration.turns <= 1

    def basic(self, me, battle) -> None:
        s = self._skills()['130301']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['130302']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        self._overtone(me, battle)
        battle.gain_energy(me, s['energy'])

    def _overtone(self, me, battle) -> None:
        s = self._skills()['130302']
        lv = self._levels(me)['BPSkill']
        dmg_up, efficiency, turns = (p(s, lv, 1), p(s, lv, 2), int(p(s, lv, 3)))
        a6 = self._traces().get('1303103')
        if a6:
            floor, step, per, cap = a6['params'][0][:4]
            over = max(0.0, me.stats[StatKey.BREAK_EFFECT] - floor)
            dmg_up += min(cap, int(over / step + 1e-09) * per)
        battle.target_team(me)
        battle.apply_effect(me, Effect(key=KEY_STRING, label='弦外の音', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, lambda who: Effect(key=KEY_STRING_TEAM, label='弦外の音・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up, break_efficiency=efficiency), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_STRING)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['130303']
        lv = self._levels(me)['Ultra']
        res_pen, turns = (p(s, lv, 1), int(p(s, lv, 2)))
        if me.eidolon >= 6:
            turns += int(self._rank(6)[0])
        stats = StatSheet.of(res_pen=res_pen)
        if me.eidolon >= 1:
            stats.add(StatKey.DEF_IGNORE, self._rank(1)[0])
        battle.target_team(me)
        battle.apply_effect(me, Effect(key=KEY_ZONE, label='結界', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, lambda who: Effect(key=KEY_ZONE_TEAM, label='結界・耐性貫通', stats=StatSheet(dict(stats.values)), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_ZONE)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        self._overtone(me, battle)
