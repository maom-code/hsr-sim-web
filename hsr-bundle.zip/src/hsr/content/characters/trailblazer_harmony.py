from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '8005'
TWIN_ID = '8006'
ELEMENT = Element.IMAGINARY
KEY_DANCE = 'tb_harmony.ult.dance'
KEY_DANCE_TEAM = 'tb_harmony.ult.dance.team'
KEY_E2_ER = 'tb_harmony.e2.er'
KEY_E4_BE = 'tb_harmony.e4.be'
KEY_TECH_BE = 'tb_harmony.technique.be'

@register(CHAR_ID)
@register(TWIN_ID)
class TrailblazerHarmony:
    fixed_eidolon = 6
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        self._first_skill = True
        talent = params_at(self._skills()['800504'], self._levels(me)['Talent'])

        def on_break(target=None, **kw):
            battle.gain_energy(me, talent[0], apply_regen=False)
            a6 = self._traces().get('8005103')
            if a6 and target is not None:
                battle.delay_action(target, a6['params'][0][0])
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)
        if me.eidolon >= 2:
            er, turns = self._rank(2)[:2]
            battle.apply_effect(me, Effect(key=KEY_E2_ER, label='星魂2・EP回復効率', stats=StatSheet.of(energy_regen=er), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))

        def on_start(**kw):
            if me.eidolon >= 4:
                be = me.stats[StatKey.BREAK_EFFECT] * self._rank(4)[0]
                battle.apply_to_team(lambda who: Effect(key=KEY_E4_BE, label='星魂4・撃破特効', stats=StatSheet.of(break_effect=be), source_id=me.id), exclude=me)
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=me.id)

    def basic(self, me, battle) -> None:
        s = self._skills()['800501']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['800502']
        lv = self._levels(me)['BPSkill']
        mult = p(s, lv, 1)
        hits = 4 + (int(self._rank(6)[0]) if me.eidolon >= 6 else 0)
        battle.spend_sp(battle.skill_cost(me), actor=me)
        tough = s.get('toughness') or {}
        a4 = self._traces().get('8005102')
        first = dict(tough)
        if a4 and isinstance(first, dict):
            first = {k: v * (1 + a4['params'][0][0]) for k, v in first.items()}
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, mult),), toughness=first, label=s['name'])
        battle.attack(me, ELEMENT, DamageType.SKILL, random=((StatKey.ATK, mult),), random_hits=hits, toughness=tough, label=f'{s['name']}（{hits} ヒット）')
        if me.eidolon >= 1 and self._first_skill:
            battle.gain_sp(int(self._rank(1)[0]), actor=me)
        self._first_skill = False
        battle.gain_energy(me, s['energy'])

    def _dance_rate(self, battle) -> float:
        a2 = self._traces().get('8005101')
        if not a2:
            return 1.0
        five, four, three, two, one = a2['params'][0][:5]
        n = len(battle.alive_enemies)
        up = five if n >= 5 else {4: four, 3: three, 2: two}.get(n, one)
        return 1.0 + up

    def ultimate(self, me, battle) -> None:
        s = self._skills()['800503']
        lv = self._levels(me)['Ultra']
        turns, _, be = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        rate = self._dance_rate(battle)
        battle.apply_effect(me, Effect(key=KEY_DANCE, label='バックダンス（付与中）', duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.target_team(me)
        battle.apply_aura(me, lambda who: Effect(key=KEY_DANCE_TEAM, label='バックダンス', stats=StatSheet.of(break_effect=be, super_break_rate=rate), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_DANCE)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['800507']
        be, turns = params_at(tech, 1)[:2]
        battle.apply_to_team(lambda who: Effect(key=KEY_TECH_BE, label='秘技・撃破特効', stats=StatSheet.of(break_effect=be), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
