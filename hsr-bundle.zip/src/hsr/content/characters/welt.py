from __future__ import annotations
from ...data import loader
from ...engine.effects import CONTROL_IMPRISON, Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1004'
ELEMENT = Element.IMAGINARY
KEY_SLOW = 'welt.skill.slow'
KEY_IMPRISON = 'welt.imprison'
KEY_WEIGHTLESS = 'welt.weightless'
KEY_A2 = 'welt.trace.dmg.'
KEY_A6_ATK = 'welt.trace.atk'

@register(CHAR_ID)
class Welt:
    substat_priority = ['CriticalChanceBase', 'CriticalDamageBase', 'StatusProbabilityBase', 'AttackAddedRatio', 'SpeedDelta']
    unimplemented = ('デバフの基礎確率（必ず付くとしている。敵の効果抵抗が無い）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['100404'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._in_big = False
        self._weightless_hits: dict[str, int] = {}
        a2 = self._traces().get('1004101')
        if a2:
            battle.gain_energy(me, a2['params'][0][3], apply_regen=False)
        a6 = self._traces().get('1004103')
        if a6:
            floor, step, per, cap = a6['params'][0][:4]
            over = max(0.0, me.stats[StatKey.EFFECT_HIT] - floor)
            up = min(cap, int(over / step + 1e-09) * per)
            if up:
                battle.apply_effect(me, Effect(key=KEY_A6_ATK, label='裁決・攻撃力', stats=StatSheet.of(atk_pct=up), source_id=me.id))
        if me.eidolon >= 6:
            cr, cd = self._rank(6)[:2]
            battle.add_target_bonus(me, lambda src, tgt: StatSheet.of(crit_rate=cr, crit_dmg=cd) if self._in_big and battle.is_slowed(tgt) else None)

        def on_attack(source=None, targets=(), rider=False, **kw):
            if rider or source is None:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            hit_weightless = False
            for e in targets:
                if not e.alive or not e.effects.has(KEY_WEIGHTLESS):
                    continue
                hit_weightless = True
                u = params_at(self._skills()['100403'], self._levels(me)['Ultra'])
                n = self._weightless_hits.get(e.id, 0)
                if n < int(u[5]):
                    self._weightless_hits[e.id] = n + 1
                    battle.delay_action(e, u[4])
            if a2 and hit_weightless:
                per, cap, turns = a2['params'][0][:3]
                battle.apply_effect(owner, Effect(key=KEY_A2 + owner.id, label='懲戒・与ダメージ', stats=StatSheet.of(dmg_pct=per), duration=Duration(turns=int(turns)), stacking=Stacking.STACK, max_stacks=int(cap), source_id=me.id))

        def on_turn(actor=None, **kw):
            if actor is not None and actor in battle.enemies:
                self._weightless_hits.pop(actor.id, None)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=me.id)

    def _slow_speed(self, battle, e, effect: Effect) -> None:
        before = e.speed()
        battle.apply_effect(e, effect)
        if any((sl.actor is e for sl in battle.queue.slots)):
            battle.queue.rescale(e, before)

    def _after_hit(self, me, battle, target, *, big: bool) -> None:
        if target is None or not target.alive:
            return
        t = self._talent(me)
        if battle.is_slowed(target):
            dealt = battle.deal_damage(me, target, ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, t[0]),))
            battle._log(me.name, '時空の歪み・付加ダメージ', dealt)
            if me.eidolon >= 2:
                battle.gain_energy(me, self._rank(2)[0], apply_regen=False)
        if big and me.eidolon >= 1 and target.effects.has(KEY_WEIGHTLESS):
            u = params_at(self._skills()['100403'], self._levels(me)['Ultra'])
            dealt = battle.deal_damage(me, target, ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, u[0] * self._rank(1)[0]),))
            battle._log(me.name, '星魂1・付加ダメージ', dealt)

    def basic(self, me, battle) -> None:
        s = self._skills()['100401']
        lv = self._levels(me)['Normal']
        mult = p(s, lv, 1)
        target = battle.target
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, mult),), target=target, toughness=s.get('toughness'), label=s['name'])
        a4 = self._traces().get('1004102')
        if a4 and target is not None:
            dealt = battle.deal_damage(me, target, ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, mult * a4['params'][0][0]),))
            battle._log(me.name, '審判・付加ダメージ', dealt)
        self._after_hit(me, battle, target, big=False)
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['100402']
        lv = self._levels(me)['BPSkill']
        mult, _, slow, turns = (p(s, lv, i) for i in range(1, 5))
        battle.spend_sp(battle.skill_cost(me), actor=me)
        target = battle.target
        self._in_big = True
        try:
            battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, mult),), random=((StatKey.ATK, mult),), random_hits=4, target=target, toughness=s.get('toughness'), label=s['name'])
            for e in battle.alive_enemies:
                self._slow_speed(battle, e, Effect(key=KEY_SLOW, label='虚空断界・減速', stats=StatSheet.of(spd_pct=-slow), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
            a4 = self._traces().get('1004102')
            if a4 and target is not None:
                dealt = battle.deal_damage(me, target, ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, mult * a4['params'][0][1]),))
                battle._log(me.name, '審判・付加ダメージ', dealt)
            self._after_hit(me, battle, target, big=True)
        finally:
            self._in_big = False
        battle.gain_energy(me, (s['energy'] or 0) * 5)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['100403']
        lv = self._levels(me)['Ultra']
        mult, delay, _, spd_down, _, _, w_turns = (p(s, lv, i) for i in range(1, 8))
        t = self._talent(me)
        self._in_big = True
        try:
            battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
            for e in battle.alive_enemies:
                self._slow_speed(battle, e, Effect(key=KEY_IMPRISON, label='禁錮', stats=StatSheet.of(spd_pct=-spd_down), duration=Duration(turns=1), stacking=Stacking.REFRESH, debuff=True, control=CONTROL_IMPRISON, source_id=me.id))
                battle.delay_action(e, delay)
                stats = StatSheet.of(def_down=t[1], spd_pct=-t[2])
                if me.eidolon >= 4:
                    stats.add(StatKey.RES_DOWN, self._rank(4)[0])
                self._slow_speed(battle, e, Effect(key=KEY_WEIGHTLESS, label='無重力', stats=stats, duration=Duration(turns=int(w_turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
            self._after_hit(me, battle, battle.target, big=True)
        finally:
            self._in_big = False
        battle.gain_energy(me, s['energy'])
        a6 = self._traces().get('1004103')
        if a6:
            battle.gain_energy(me, a6['params'][0][4], apply_regen=False)

    def technique(self, me, battle) -> None:
        tech = params_at(self._skills()['100407'], 1)
        _, delay, spd_down = tech[:3]
        for e in battle.alive_enemies:
            self._slow_speed(battle, e, Effect(key=KEY_IMPRISON, label='禁錮', stats=StatSheet.of(spd_pct=-spd_down), duration=Duration(turns=1), stacking=Stacking.REFRESH, debuff=True, control=CONTROL_IMPRISON, source_id=me.id))
            battle.delay_action(e, delay)
