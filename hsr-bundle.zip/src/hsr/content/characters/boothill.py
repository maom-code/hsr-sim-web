from __future__ import annotations
from ...data import loader
from ...engine import damage as dmg
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1315'
ELEMENT = Element.PHYSICAL
POCKET = 'ポケットアドバンテージ'
KEY_STANDOFF = 'boothill.standoff'
KEY_STANDOFF_ENEMY = 'boothill.standoff.enemy'
KEY_A2 = 'boothill.trace.crit'
KEY_E1_DEF = 'boothill.e1.def_ignore'
KEY_E2_BE = 'boothill.e2.be'

@register(CHAR_ID)
class Boothill:
    unimplemented = ('九死の決闘の「挑発」と、ブートヒルの受けるダメージ増減（敵の攻撃は 1 ダメージ固定）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        self._foe = None
        self._e2_turn = -1
        me.counter(POCKET, maximum=3)
        if me.eidolon >= 1:
            battle.gain_counter(me, POCKET, 1, maximum=3)
            battle.apply_effect(me, Effect(key=KEY_E1_DEF, label='星魂1・防御無視', stats=StatSheet.of(def_ignore=self._rank(1)[0]), source_id=me.id))
        self._refresh_a2(me, battle)

        def on_break(target=None, **kw):
            if target is None or target is not self._foe:
                return
            self._gain_pocket(me, battle)
            self._end_standoff(me, battle)
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)

    def on_turn_start(self, me, battle) -> None:
        self._refresh_a2(me, battle)
        if self._foe is not None and (not me.effects.has(KEY_STANDOFF)):
            self._end_standoff(me, battle)

    def _refresh_a2(self, me, battle) -> None:
        a2 = self._traces().get('1315101')
        if not a2:
            return
        cr_r, cr_cap, cd_r, cd_cap = a2['params'][0][:4]
        battle.remove_effect(me, KEY_A2)
        be = me.stats[StatKey.BREAK_EFFECT]
        battle.apply_effect(me, Effect(key=KEY_A2, label='ゴーストロード', stats=StatSheet.of(crit_rate=min(cr_cap, be * cr_r), crit_dmg=min(cd_cap, be * cd_r)), source_id=me.id))

    def _gain_pocket(self, me, battle) -> None:
        battle.gain_counter(me, POCKET, 1, maximum=3)
        a6 = self._traces().get('1315103')
        if a6:
            battle.gain_energy(me, a6['params'][0][0], apply_regen=False)
        if me.eidolon >= 2 and self._e2_turn != battle._turn_no:
            self._e2_turn = battle._turn_no
            _, be, turns = self._rank(2)[:3]
            battle.gain_sp(1, actor=me)
            battle.apply_effect(me, Effect(key=KEY_E2_BE, label='星魂2・撃破特効', stats=StatSheet.of(break_effect=be), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))

    def _end_standoff(self, me, battle) -> None:
        if self._foe is not None:
            battle.remove_effect(self._foe, KEY_STANDOFF_ENEMY)
        battle.remove_effect(me, KEY_STANDOFF)
        self._foe = None

    def _standoff_factor(self, me, battle):
        s = params_at(self._skills()['131502'], self._levels(me)['BPSkill'])
        up = s[0] + (self._rank(4)[0] if me.eidolon >= 4 else 0.0)

        def factor(e) -> float:
            if e is not self._foe:
                return 1.0
            base = dmg.vulnerability_multiplier(e.stats)
            return (base + up) / base
        return factor

    def can_use_skill(self, me, battle) -> bool:
        return self._foe is None

    def basic(self, me, battle) -> None:
        if self._foe is not None and self._foe.alive:
            self._fanning(me, battle)
            return
        s = self._skills()['131501']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'], independent=self._standoff_factor(me, battle))
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def _fanning(self, me, battle) -> None:
        s = self._skills()['131508']
        lv = self._levels(me)['Normal']
        foe = self._foe
        pockets = battle.counter_value(me, POCKET)
        t = params_at(self._skills()['131504'], self._levels(me)['Talent'])
        tough = {k: v * (1 + t[3] * pockets) for k, v in (s.get('toughness') or {}).items()}
        was_broken = foe.is_broken
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), target=foe, toughness=tough, label=s['name'], independent=self._standoff_factor(me, battle))
        if (was_broken or foe.is_broken) and pockets > 0 and foe.alive:
            ratio = (t[0], t[1], t[2])[min(3, int(pockets)) - 1]
            cap = 30 * t[5]
            base = dmg.break_damage_base(ELEMENT, me.level, min(foe.max_toughness, cap))
            dealt = battle.deal_damage(me, foe, ELEMENT, DamageType.BREAK, (), break_base=base * ratio)
            if me.eidolon >= 6:
                e6_main, e6_adj = self._rank(6)[:2]
                dealt += battle.deal_damage(me, foe, ELEMENT, DamageType.BREAK, (), break_base=base * ratio * e6_main)
                for adj in battle.adjacent_to(foe):
                    dealt += battle.deal_damage(me, adj, ELEMENT, DamageType.BREAK, (), break_base=base * ratio * e6_adj)
            if dealt:
                battle._log(me.name, '5発の銃弾・撃破ダメージ', dealt)
        battle.gain_energy(me, s.get('energy') or 30)

    def skill(self, me, battle) -> None:
        s = self._skills()['131502']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        foe = battle.target
        if foe is None:
            return
        turns = int(p(s, lv, 3))
        self._foe = foe
        battle.apply_effect(me, Effect(key=KEY_STANDOFF, label='九死の決闘', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_effect(foe, Effect(key=KEY_STANDOFF_ENEMY, label='九死の決闘', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        with battle.attack_action(me):
            self._fanning(me, battle)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['131503']
        lv = self._levels(me)['Ultra']
        mult, delay = (p(s, lv, 1), p(s, lv, 2))
        target = self._foe if self._foe is not None else battle.target
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, main=((StatKey.ATK, mult),), target=target, toughness=s.get('toughness'), label=s['name'], independent=self._standoff_factor(me, battle))
        if target is not None:
            battle.delay_action(target, delay)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        return
