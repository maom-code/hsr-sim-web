from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1015'
ELEMENT = Element.QUANTUM
CHARGE = 'チャージ'
KEY_CIRCUIT = 'archer.skill.circuit'
KEY_A6_CD = 'archer.trace.crit_dmg'
KEY_E2_RES = 'archer.e2.res_down'
KEY_E4_ULT = 'archer.e4.ult_dmg'

@register(CHAR_ID)
class Archer:
    unimplemented = ('星魂 2 の「量子属性弱点を付与する」（弱点撃破をオンにしたときは全属性弱点なので差が出ない）',)
    manual_play_note = '回路接続で何回撃つか・連携追加攻撃（SP 3 以下で発動）をどこで起こすかで伸び方が変わる。このシミュは SP が続く限り最大 5 回撃ち、連携は条件を満たした最初の戦闘スキルで起こす'
    relic_sets = {'108': 4, '324': 2}
    circuit_casts = 0

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _max_charge(self) -> float:
        return p(self._skills()['101503'], 1, 3)

    def on_battle_start(self, me, battle) -> None:
        self.circuit_casts = 0
        a2 = self._traces().get('1015101')
        if a2:
            battle.sp.maximum += int(a2['params'][0][0])
        a4 = self._traces().get('1015102')
        if a4:
            battle.gain_counter(me, CHARGE, a4['params'][0][0], maximum=self._max_charge())
        if me.eidolon >= 4:
            battle.apply_effect(me, Effect(key=KEY_E4_ULT, label='星魂4・必殺技ダメージ', stats=StatSheet.of(dmg_pct_ultimate=self._rank(4)[0]), source_id=me.id))

        def on_ally_attack(source=None, rider=False, targets=None, **kw):
            if source is None or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner is me or owner not in battle.team:
                return
            if battle.counter_value(me, CHARGE) < 1:
                return
            battle.spend_counter(me, CHARGE, 1)
            alive = [e for e in targets or [] if e.alive]
            t = self._skills()['101504']
            with battle.attack_action(me):
                battle.attack(me, ELEMENT, DamageType.FOLLOWUP, main=((StatKey.ATK, p(t, self._levels(me)['Talent'], 1)),), target=alive[0] if alive else None, toughness=t.get('toughness'), label=t['name'])
            battle.gain_energy(me, t['energy'])
            battle.gain_sp(1, actor=me)
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)
        a6 = self._traces().get('1015103')
        if a6:
            cd, turns, need = a6['params'][0][:3]

            def on_sp_gain(**kw):
                if battle.sp.current >= need:
                    battle.apply_effect(me, Effect(key=KEY_A6_CD, label='守護者・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
            battle.bus.subscribe(Event.ON_SP_GAIN, on_sp_gain, owner_id=me.id)

    def on_turn_start(self, me, battle) -> None:
        if me.eidolon >= 6:
            battle.gain_sp(1, actor=me)

    def basic(self, me, battle) -> None:
        s = self._skills()['101501']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['101502']
        lv = self._levels(me)['BPSkill']
        mult, dmg_up, max_stacks, _, max_casts = (p(s, lv, i) for i in (1, 2, 3, 4, 5))
        if me.eidolon >= 6:
            max_stacks += self._rank(6)[0]
        cost = battle.skill_cost(me)
        self.circuit_casts = 0
        try:
            while True:
                battle.spend_sp(cost, actor=me)
                self.circuit_casts += 1
                if self.circuit_casts > 1:
                    battle._log(me.name, f'戦闘スキル（回路接続 {self.circuit_casts} 回目）')
                battle.apply_effect(me, Effect(key=KEY_CIRCUIT, label='回路接続・戦闘スキルダメージ', stats=StatSheet.of(dmg_pct_skill=dmg_up), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id))
                with battle.attack_action(me):
                    battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'], independent=self._def_ignore_factor(me, battle))
                battle.gain_energy(me, s['energy'])
                if me.eidolon >= 1 and self.circuit_casts == int(self._rank(1)[0]):
                    battle.gain_sp(int(self._rank(1)[1]), actor=me)
                if self.circuit_casts >= int(max_casts) or not battle.sp.can_spend(cost):
                    break
                battle.bus.emit(Event.ON_SKILL_USED, source_id=me.id, actor=me)
        finally:
            battle.remove_effect(me, KEY_CIRCUIT)
            self.circuit_casts = 0

    def _def_ignore_factor(self, me, battle):
        if me.eidolon < 6:
            return 1.0
        from ...engine import damage as dmg
        ignore = self._rank(6)[1]

        def factor(e) -> float:
            base = me.stats[StatKey.DEF_IGNORE]
            d = e.stats[StatKey.DEF_DOWN]
            with_e6 = dmg.defense_multiplier(me.level, e.level, def_down=d, def_ignore=base + ignore)
            without = dmg.defense_multiplier(me.level, e.level, def_down=d, def_ignore=base)
            return with_e6 / without if without else 1.0
        return factor

    def ultimate(self, me, battle) -> None:
        s = self._skills()['101503']
        lv = self._levels(me)['Ultra']
        target = battle.target
        if me.eidolon >= 2 and target is not None:
            down, turns = self._rank(2)[:2]
            battle.apply_effect(target, Effect(key=KEY_E2_RES, label='星魂2・量子耐性ダウン', stats=StatSheet.of(res_down=down), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_counter(me, CHARGE, p(s, lv, 2), maximum=p(s, lv, 3))
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['101507']
        mult, charge = params_at(tech, 1)[:2]
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult),), toughness=tech.get('toughness'), label=tech['name'])
        battle.gain_counter(me, CHARGE, charge, maximum=self._max_charge())
