from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import RES_DOWN_BY_ELEMENT, StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1006'
ELEMENT = Element.QUANTUM
KEY_IMPLANT = 'silverwolf.skill.implant'
KEY_SKILL_RES = 'silverwolf.skill.res_down'
KEY_ULT_DEF = 'silverwolf.ult.def_down'
KEY_BUG = 'silverwolf.bug.'
KEY_A6_ATK = 'silverwolf.trace.atk'
KEY_E2_VULN = 'silverwolf.e2.vuln'
BUG_ORDER = ('def', 'atk', 'spd')

@register(CHAR_ID)
class SilverWolf:
    unimplemented = ('天賦の「倒された敵に付与した弱点を別の敵に移す」（敵が倒れない前提）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        a4 = self._traces().get('1006102')
        if a4:
            battle.gain_energy(me, a4['params'][0][0], apply_regen=False)
        a6 = self._traces().get('1006103')
        if a6:
            step, per, cap = a6['params'][0][:3]
            hit = me.stats[StatKey.EFFECT_HIT]
            battle.apply_effect(me, Effect(key=KEY_A6_ATK, label='アノテーション・攻撃力', stats=StatSheet.of(atk_pct=min(cap, int(hit / step + 1e-09) * per)), source_id=me.id))
        if me.eidolon >= 2:
            for e in battle.enemies:
                battle.apply_effect(e, Effect(key=KEY_E2_VULN, label='星魂2・被ダメージ', stats=StatSheet.of(vulnerability=self._rank(2)[0]), debuff=True, source_id=me.id))
        if me.eidolon >= 6:
            per = self._rank(6)[0]
            battle.add_target_bonus(me, lambda src, tgt: StatSheet.of(dmg_pct=min(per * 5, per * battle.debuff_count(tgt))))

        def on_attack(source=None, targets=None, rider=False, **kw):
            if rider or source is None:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner is me or (me.eidolon >= 2 and owner in battle.team):
                for e in targets or []:
                    if e.alive:
                        self._bug(me, battle, e)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)

        def on_break(target=None, **kw):
            if target is not None and self._traces().get('1006101'):
                self._bug(me, battle, target)
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)

    def on_turn_start(self, me, battle) -> None:
        a4 = self._traces().get('1006102')
        if a4:
            battle.gain_energy(me, a4['params'][0][1], apply_regen=False)

    def _bug(self, me, battle, enemy) -> None:
        t = params_at(self._skills()['100604'], self._levels(me)['Talent'])
        atk, dfn, spd, _, turns = t[:5]
        a2 = self._traces().get('1006101')
        if a2:
            turns += a2['params'][0][0]
        missing = [k for k in BUG_ORDER if not enemy.effects.has(KEY_BUG + k)]
        if missing:
            kind = missing[0]
        else:
            kind = min(BUG_ORDER, key=lambda k: enemy.effects.get(KEY_BUG + k).duration.turns)
        stats = {'atk': StatSheet.of(atk_pct=-atk), 'def': StatSheet.of(def_down=dfn), 'spd': StatSheet.of(spd_pct=-spd)}[kind]
        label = {'atk': '欠陥・攻撃力', 'def': '欠陥・防御力', 'spd': '欠陥・速度'}[kind]
        before = enemy.speed()
        battle.apply_effect(enemy, Effect(key=KEY_BUG + kind, label=label, stats=stats, duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        if kind == 'spd' and any((sl.actor is enemy for sl in battle.queue.slots)):
            battle.queue.rescale(enemy, before)

    def basic(self, me, battle) -> None:
        s = self._skills()['100601']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['100602']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        mult, _, implant_turns, implant_down, _, res_down, res_turns = (p(s, lv, i) for i in range(1, 8))
        target = battle.target
        if target is not None:
            element = battle.team[0].built.element
            battle.remove_effect(target, KEY_IMPLANT)
            battle.apply_effect(target, Effect(key=KEY_IMPLANT, label=f'弱点埋め込み（{element.value}）', stats=StatSheet({RES_DOWN_BY_ELEMENT[element]: implant_down}), duration=Duration(turns=int(implant_turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
            battle.apply_effect(target, Effect(key=KEY_SKILL_RES, label='全属性耐性ダウン', stats=StatSheet.of(res_down=res_down), duration=Duration(turns=int(res_turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, mult),), target=target, toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['100603']
        lv = self._levels(me)['Ultra']
        mult, _, def_down, turns = (p(s, lv, i) for i in range(1, 5))
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_ULT_DEF, label='アカウントがBANされた・防御力ダウン', stats=StatSheet.of(def_down=def_down), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        if me.eidolon >= 1:
            per, cap = self._rank(1)[:2]
            n = min(cap, sum((battle.debuff_count(e) for e in battle.alive_enemies)))
            battle.gain_energy(me, per * n, apply_regen=False)
        if me.eidolon >= 4:
            per, cap = self._rank(4)[:2]
            total = 0.0
            for e in battle.alive_enemies:
                n = min(cap, battle.debuff_count(e))
                if n:
                    total += battle.deal_damage(me, e, ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, per * n),))
            if total:
                battle._log(me.name, '星魂4・付加ダメージ', total)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['100607']
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, params_at(tech, 1)[0]),), toughness=tech.get('toughness'), label=tech['name'])
