from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1321'
ELEMENT = Element.FIRE
KEY_PARTNER = 'dahlia.dance_partner'
KEY_ZONE = 'dahlia.zone'
KEY_ZONE_TEAM = 'dahlia.zone.team'
KEY_WILT = 'dahlia.wilt'
KEY_FOLLOWUP = 'dahlia.followup'
KEY_A2_BE = 'dahlia.trace.be'
KEY_A6_SPD = 'dahlia.trace.spd'
KEY_E2_RES = 'dahlia.e2.res'
KEY_E4_VULN = 'dahlia.e4.vuln'
KEY_E6_BE = 'dahlia.e6.be'
TOUGHNESS_UNIT = 3.0

@register(CHAR_ID)
class Dahlia:
    target_override_label = '共に舞う者'
    target_override_priority = ()
    target_override_default = '撃破特効が最も高い味方'
    unimplemented = ('秘技の「戦闘開始時の削靭値の 60% を超撃破に」。結界の展開だけ入れている',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['132104'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._me = me
        self._partners = [me]
        self._followup_turn = -1
        self._followups = 0
        self._a2_turn = -1
        self._a6_energy = 0.0
        self._e1_done: set[str] = set()
        self._added: dict[str, set] = {}
        t = self._talent(me)
        battle.gain_energy(me, t[3], apply_regen=False)

        def on_start(**kw):
            others = [c for c in battle.team if c is not me]
            picked = battle.target_override.get(me.id)
            chosen = next((c for c in others if c.id == picked), None)
            if chosen is None and others:
                chosen = max(others, key=lambda c: c.stats[StatKey.BREAK_EFFECT])
            if chosen is not None:
                self._partners.append(chosen)
            rate = t[4] + (self._rank(1)[3] if me.eidolon >= 1 else 0.0)
            holders = battle.team if me.eidolon >= 1 else self._partners
            for c in holders:
                battle.apply_effect(c, Effect(key=KEY_PARTNER, label='共に舞う者' if c in self._partners else '共に舞う者の倍率', stats=StatSheet.of(super_break_rate=rate), source_id=me.id))
            if me.eidolon >= 6:
                for c in self._partners:
                    battle.apply_effect(c, Effect(key=KEY_E6_BE, label='星魂6・撃破特効', stats=StatSheet.of(break_effect=self._rank(6)[0]), source_id=me.id))
            self._a2(me, battle, turns=1)
            if me.eidolon >= 2:
                res, turns = self._rank(2)[:2]
                for e in battle.enemies:
                    battle.apply_effect(e, Effect(key=KEY_E2_RES, label='星魂2・全属性耐性ダウン', stats=StatSheet.of(res_down=res), debuff=True, source_id=me.id))
                    self._wilt(me, battle, e, int(turns))

        def on_attack(source=None, targets=None, rider=False, **kw):
            if rider or source is None or source is me or (source not in self._partners):
                return
            hit = [e for e in targets or [] if e.alive]
            if me.eidolon >= 1:
                ratio, lo, hi = self._rank(1)[:3]
                for e in hit:
                    if e.id in self._e1_done or not e.breakable:
                        continue
                    self._e1_done.add(e.id)
                    amount = min(hi * TOUGHNESS_UNIT, max(lo * TOUGHNESS_UNIT, e.max_toughness * ratio))
                    battle.reduce_toughness(source, e, amount, getattr(source, 'element', ELEMENT))
            if self._followup_turn == battle._turn_no:
                return
            self._followup_turn = battle._turn_no
            self._followup(me, battle)

        def on_support(target=None, source=None, healer=None, **kw):
            giver = healer if healer is not None else source
            if target is me and giver is not None and (giver is not me):
                self._a2(me, battle, turns=3)

        def on_expired(holder=None, effect=None, **kw):
            if effect is None:
                return
            if holder is me and effect.key == KEY_ZONE:
                battle.super_break_unbroken.discard(me.id)
            if effect.key == KEY_WILT and holder is not None:
                holder.weaknesses = set(holder.weaknesses) - self._added.pop(holder.id, set())
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.bus.subscribe(Event.ON_HEAL, on_support, owner_id=me.id)
        battle.bus.subscribe(Event.ON_SHIELD, on_support, owner_id=me.id)
        battle.bus.subscribe(Event.ON_EFFECT_EXPIRED, on_expired, owner_id=me.id)

    def _a2(self, me, battle, *, turns: int) -> None:
        a2 = self._traces().get('1321101')
        if not a2:
            return
        if turns > 1:
            if self._a2_turn == battle._turn_no:
                return
            self._a2_turn = battle._turn_no
        ratio, _, flat, _ = a2['params'][0][:4]
        be = me.stats[StatKey.BREAK_EFFECT] * ratio + flat
        battle.apply_to_team(lambda who: Effect(key=KEY_A2_BE, label='葬礼またひとつ', stats=StatSheet.of(break_effect=be), duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=me.id), exclude=me)

    def _wilt(self, me, battle, e, turns: int) -> None:
        u = params_at(self._skills()['132103'], self._levels(me)['Ultra'])
        added = {c.element for c in self._partners} - set(e.weaknesses)
        self._added[e.id] = self._added.get(e.id, set()) | added
        e.weaknesses = set(e.weaknesses) | added
        battle.apply_effect(e, Effect(key=KEY_WILT, label='凋落', stats=StatSheet.of(def_down=u[2]), duration=Duration(turns=turns), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))

    def _followup(self, me, battle) -> None:
        s = self._skills()['132104']
        t = self._talent(me)
        hits = int(t[1] + (self._rank(4)[2] if me.eidolon >= 4 else 0))
        battle.apply_effect(me, Effect(key=KEY_FOLLOWUP, label='天賦・追加攻撃の超撃破', stats=StatSheet.of(super_break_rate=t[2]), source_id=me.id))
        if me.eidolon >= 4:
            vuln, turns = self._rank(4)[:2]
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_E4_VULN, label='星魂4・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        try:
            with battle.attack_action(me):
                battle.attack(me, ELEMENT, DamageType.FOLLOWUP, random=((StatKey.ATK, t[0]),), random_hits=hits, toughness={'all': (s.get('toughness') or {}).get('main', 9)}, label=f'{s['name']}・追加攻撃（{hits} ヒット）')
        finally:
            battle.remove_effect(me, KEY_FOLLOWUP)
        battle.gain_energy(me, s.get('energy') or 2)
        self._followups += 1
        a4 = self._traces().get('1321102')
        if a4 and self._followups % int(a4['params'][0][0]) == 0:
            battle.gain_sp(1, actor=me)
        if me.eidolon >= 6:
            for c in self._partners:
                battle.advance_forward(c, self._rank(6)[1])

    def basic(self, me, battle) -> None:
        s = self._skills()['132101']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def _deploy_zone(self, me, battle) -> None:
        s = self._skills()['132102']
        lv = self._levels(me)['BPSkill']
        turns, eff = (int(p(s, lv, 2)), p(s, lv, 3))
        battle.apply_effect(me, Effect(key=KEY_ZONE, label='結界', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, lambda who: Effect(key=KEY_ZONE_TEAM, label='結界・弱点撃破効率', stats=StatSheet.of(break_efficiency=eff), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_ZONE)
        battle.super_break_unbroken.add(me.id)

    def skill(self, me, battle) -> None:
        s = self._skills()['132102']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        self._deploy_zone(me, battle)
        mult = p(s, lv, 1)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, mult),), adjacent=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['132103']
        lv = self._levels(me)['Ultra']
        mult, turns = (p(s, lv, 1), int(p(s, lv, 2)))
        enemies = list(battle.alive_enemies)
        for e in enemies:
            self._wilt(me, battle, e, turns)
        battle.bus.emit(Event.ON_WEAKNESS_IMPLANT, source_id=me.id, source=me, targets=enemies)
        n = max(1, len(enemies))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult / n),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])
        a6 = self._traces().get('1321103')
        if a6:
            cap, ep, spd, spd_turns, tough = a6['params'][0][:5]
            before = me.speed()
            battle.apply_effect(me, Effect(key=KEY_A6_SPD, label='古きを捨て、新しきに恋する・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=int(spd_turns)), stacking=Stacking.REFRESH, source_id=me.id))
            if any((sl.actor is me for sl in battle.queue.slots)):
                battle.queue.rescale(me, before)
            for e in battle.alive_enemies:
                battle.reduce_toughness(me, e, tough * TOUGHNESS_UNIT, ELEMENT)
            maximum = getattr(me.resource, 'maximum', 0.0)
            gain = min(maximum * ep, maximum * cap - self._a6_energy)
            if gain > 0:
                self._a6_energy += gain
                battle.gain_energy(me, gain, apply_regen=False)

    def technique(self, me, battle) -> None:
        self._deploy_zone(me, battle)
