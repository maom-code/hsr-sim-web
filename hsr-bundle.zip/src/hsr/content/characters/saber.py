from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1014'
ELEMENT = Element.WIND
CORE = '炉心共鳴'
KEY_TALENT_DMG = 'saber.talent.dmg'
KEY_A2_CR = 'saber.trace.crit_rate'
KEY_A2_BURST = 'saber.trace.mana_burst'
KEY_A6_CD = 'saber.trace.crit_dmg'
KEY_A6_STACK = 'saber.trace.crit_dmg_stack'
KEY_E1_ULT = 'saber.e1.ult_dmg'
KEY_E2_DEF = 'saber.e2.def_ignore'
KEY_E4_PEN = 'saber.e4.res_pen'
KEY_E4_STACK = 'saber.e4.res_pen_stack'
KEY_E6_ULT_PEN = 'saber.e6.ult_pen'
KEY_TECH_ATK = 'saber.technique.atk'
KEY_GIL_ULT = 'saber.gilgamesh.next_ult'

@register(CHAR_ID)
class Saber:
    self_crit_rate_buff = 0.2
    relic_set_options = ({'key': '110', 'sets': {'110': 4, '328': 2}}, {'key': '126', 'sets': {'126': 4, '328': 2}})
    manual_play_note = '炉心共鳴を溜める・吐く順番と必殺技のタイミングで伸び方が変わる。このシミュは満タンにできる戦闘スキルで即座に EP に変え、溜まり次第すぐ必殺技を撃つ。ギルガメッシュとの連携追加攻撃（攻撃 8 回）の位置も成り行き'
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['101404'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._enhanced_basic = False
        self._overflow = 0.0
        self._ult_count = 0
        t = self._talent(me)
        a2 = self._traces().get('1014101')
        if a2:
            battle.apply_effect(me, Effect(key=KEY_A2_CR, label='竜の騎士・会心率', stats=StatSheet.of(crit_rate=a2['params'][0][0]), source_id=me.id))
            battle.apply_effect(me, Effect(key=KEY_A2_BURST, label='魔力放出', source_id=me.id))
        if me.eidolon >= 1:
            battle.apply_effect(me, Effect(key=KEY_E1_ULT, label='星魂1・必殺技ダメージ', stats=StatSheet.of(dmg_pct_ultimate=self._rank(1)[0]), source_id=me.id))
        if me.eidolon >= 4:
            battle.apply_effect(me, Effect(key=KEY_E4_PEN, label='星魂4・風耐性貫通', stats=StatSheet.of(res_pen_wind=self._rank(4)[0]), source_id=me.id))
        a4 = self._traces().get('1014102')
        pool = me.resource
        if a4 and getattr(pool, 'maximum', None):
            floor = pool.maximum * a4['params'][0][2]
            if float(pool.current) < floor:
                pool.current = floor

            def on_energy(who=None, overflow=0.0, **kw):
                if who is me and overflow > 0:
                    self._overflow = min(self._overflow_cap(me), self._overflow + overflow)
            battle.bus.subscribe(Event.ON_ENERGY_GAIN, on_energy, owner_id=me.id)

        def on_ult(source_id=None, **kw):
            battle.apply_effect(me, Effect(key=KEY_TALENT_DMG, label='竜の炉心・与ダメージ', stats=StatSheet.of(dmg_pct=t[2]), duration=Duration(turns=int(t[3])), stacking=Stacking.REFRESH, source_id=me.id))
            self._gain_core(me, battle, t[0])
        battle.bus.subscribe(Event.ON_ULT_USED, on_ult, owner_id=me.id)
        self._gain_core(me, battle, t[7])

    def _overflow_cap(self, me) -> float:
        a4 = self._traces().get('1014102')
        cap = a4['params'][0][0] if a4 else 0.0
        if me.eidolon >= 6:
            cap = self._rank(6)[3]
        return cap

    def _core(self, me, battle) -> float:
        return battle.counter_value(me, CORE)

    def _fills(self, me, battle) -> bool:
        pool = me.resource
        core = self._core(me, battle)
        return core > 0 and float(pool.current) + core * self._talent(me)[4] >= pool.maximum

    def _gain_core(self, me, battle, n: float) -> None:
        gained = battle.gain_counter(me, CORE, n, maximum=self._talent(me)[6])
        if gained <= 0:
            return
        a6 = self._traces().get('1014103')
        if a6:
            battle.apply_effect(me, Effect(key=KEY_A6_STACK, label='星の冠・累積', stats=StatSheet.of(crit_dmg=a6['params'][0][2]), stacking=Stacking.STACK, max_stacks=int(a6['params'][0][3]), stacks=int(gained), source_id=me.id))
        if me.eidolon >= 2:
            e2 = self._rank(2)
            battle.apply_effect(me, Effect(key=KEY_E2_DEF, label='星魂2・防御無視', stats=StatSheet.of(def_ignore=e2[1]), stacking=Stacking.STACK, max_stacks=int(e2[2]), stacks=int(gained), source_id=me.id))
        if me.effects.has(KEY_A2_BURST) and self._fills(me, battle):
            battle.remove_effect(me, KEY_A2_BURST)
            battle.gain_sp(1, actor=me)
            battle.act_next(me)

    def can_use_skill(self, me, battle) -> bool:
        return not self._enhanced_basic

    def basic(self, me, battle) -> None:
        if self._enhanced_basic:
            self._golden(me, battle)
            return
        s = self._skills()['101401']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 1:
            self._gain_core(me, battle, self._rank(1)[1])

    def _golden(self, me, battle) -> None:
        self._enhanced_basic = False
        s = self._skills()['101408']
        lv = self._levels(me)['Normal']
        mult, core, two, one = (p(s, lv, i) for i in (1, 2, 3, 4))
        self._gain_core(me, battle, core)
        n = len(battle.alive_enemies)
        extra = two if n == 2 else one if n == 1 else 0.0
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult + extra),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s.get('sp_gain') or 1, actor=me)
        battle.gain_energy(me, s['energy'])
        if self._traces().get('1014101'):
            battle.apply_effect(me, Effect(key=KEY_A2_BURST, label='魔力放出', source_id=me.id))
        if me.eidolon >= 1:
            self._gain_core(me, battle, self._rank(1)[1])

    def skill(self, me, battle) -> None:
        s = self._skills()['101402']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        main, adj, gain, per = (p(s, lv, i) for i in (1, 2, 3, 4))
        a6 = self._traces().get('1014103')
        if a6:
            battle.apply_effect(me, Effect(key=KEY_A6_CD, label='星の冠・会心ダメージ', stats=StatSheet.of(crit_dmg=a6['params'][0][0]), duration=Duration(turns=int(a6['params'][0][1])), stacking=Stacking.REFRESH, source_id=me.id))
        fills = self._fills(me, battle)
        core = self._core(me, battle)
        bonus = 0.0
        if fills:
            per_stack = per + (self._rank(2)[0] if me.eidolon >= 2 else 0.0)
            bonus = per_stack * core
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, main + bonus),), adjacent=((StatKey.ATK, adj + bonus),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])
        if fills:
            battle.spend_counter(me, CORE, core)
            battle.gain_energy(me, core * self._talent(me)[4], apply_regen=False)
        else:
            self._gain_core(me, battle, gain)
        if me.eidolon >= 1:
            self._gain_core(me, battle, self._rank(1)[1])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['101403']
        lv = self._levels(me)['Ultra']
        if me.eidolon >= 6:
            battle.apply_effect(me, Effect(key=KEY_E6_ULT_PEN, label='星魂6・必殺技の風耐性貫通', stats=StatSheet.of(res_pen_wind=self._rank(6)[0]), source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, p(s, lv, 1)),), random=((StatKey.ATK, p(s, lv, 2)),), random_hits=int(p(s, lv, 3)), toughness=s.get('toughness'), label=s['name'])
        battle.remove_effect(me, KEY_E6_ULT_PEN)
        battle.remove_effect(me, KEY_GIL_ULT)
        self._enhanced_basic = True
        battle.gain_energy(me, s['energy'])
        if self._overflow > 0:
            stored, self._overflow = (self._overflow, 0.0)
            battle.gain_energy(me, stored, apply_regen=False)
        if me.eidolon >= 4:
            e4 = self._rank(4)
            battle.apply_effect(me, Effect(key=KEY_E4_STACK, label='星魂4・風耐性貫通（累積）', stats=StatSheet.of(res_pen_wind=e4[1]), stacking=Stacking.STACK, max_stacks=int(e4[2]), source_id=me.id))
        if me.eidolon >= 6:
            e6 = self._rank(6)
            if self._ult_count % int(e6[1]) == 0:
                battle.gain_energy(me, e6[2], apply_regen=False)
        self._ult_count += 1

    def technique(self, me, battle) -> None:
        tech = self._skills()['101407']
        atk, turns, core = params_at(tech, 1)[:3]
        battle.apply_effect(me, Effect(key=KEY_TECH_ATK, label='騎士王の出陣・攻撃力', stats=StatSheet.of(atk_pct=atk), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        self._gain_core(me, battle, core)
