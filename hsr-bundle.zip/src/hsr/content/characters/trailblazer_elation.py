from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, elation_members, reward_total
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '8009'
ELEMENT = Element.LIGHTNING
KEY_TRACE_RATE = 'tb_elation.trace.elation_rate'
KEY_TRACE_CR = 'tb_elation.trace.crit_rate'
KEY_ULT_CD = 'tb_elation.ult.crit_dmg'
KEY_ULT_RATE = 'tb_elation.e2.elation_rate'
KEY_E4_VULN = 'tb_elation.e4.vuln'
KEY_E6_CD = 'tb_elation.e6.crit_dmg'
KEY_TECHNIQUE = 'tb_elation.technique'
TWIN_ID = '8010'

@register(CHAR_ID)
@register(TWIN_ID)
class TrailblazerElation:
    speed_target = 160.0
    substat_priority = ['CriticalChanceBase', 'CriticalDamageBase', 'AttackAddedRatio']
    relic_sets = {'133': 4, '325': 2}
    light_cone = '24006'
    fixed_superimpose = 5
    fixed_eidolon = 6
    target_override_label = '必殺技の対象'
    target_override_priority = ()
    target_override_default = '与ダメージが最も多い愉悦キャラ'
    self_crit_rate_buff = 0.15
    unimplemented = ('必殺技の行動制限系デバフ解除（敵がデバフを撒かない）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _elation_level(self, me) -> int:
        return self._levels(me).get('ElationDamage', 10)

    def on_battle_start(self, me, battle) -> None:
        self._skill_stacks = 0.0
        self._bonus_reward = 0.0
        self._refresh_elation_rate(me, battle)
        a4 = self._traces().get('8009102')
        if a4:
            battle.apply_effect(me, Effect(key=KEY_TRACE_CR, label='軌跡・会心率', stats=StatSheet.of(crit_rate=a4['params'][0][0]), source_id=me.id))
        a6 = self._traces().get('8009103')
        if a6:
            bonus = a6['params'][0][0]

            def on_elation_skill(**kw):
                self._bonus_reward = bonus
            battle.bus.subscribe(Event.ON_ELATION_SKILL, on_elation_skill, owner_id=me.id)
        talent = self._skills()['800904']
        tlv = self._levels(me)['Talent']
        energy, notes = (p(talent, tlv, 1), p(talent, tlv, 2))

        def on_attack(source=None, dmg_type=None, targets_hit: int=0, rider=False, **kw):
            if rider:
                return
            if source is not me or not targets_hit:
                return
            if dmg_type is DamageType.ELATION:
                return
            battle.gain_energy(me, energy)
            battle.gain_shared(NOTES, notes)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id, per_turn=1)

    def _refresh_elation_rate(self, me, battle) -> None:
        a2 = self._traces().get('8009101')
        if not a2:
            return
        threshold, step, per, cap = a2['params'][0]
        atk = me.stats[StatKey.ATK]
        if atk <= threshold:
            return
        amount = min((atk - threshold) / step * per, cap)
        battle.apply_effect(me, Effect(key=KEY_TRACE_RATE, label='軌跡・愉悦度', stats=StatSheet.of(elation_rate=amount), stacking=Stacking.REFRESH, source_id=me.id))

    def basic(self, me, battle) -> None:
        s = self._skills()['800901']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['800902']
        lv = self._levels(me)['BPSkill']
        mult, reward = (p(s, lv, 1), p(s, lv, 2))
        battle.spend_sp(s['sp_cost'])
        battle.aha.grant_reward(me, reward + self._bonus_reward)
        self._bonus_reward = 0.0
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        if reward_total(me) > 0:
            talent = self._skills()['800904']
            notes = max((reward_total(c) for c in battle.team), default=0.0)
            battle.attack(me, ELEMENT, DamageType.ELATION, elation=(p(talent, self._levels(me)['Talent'], 3), notes), elation_shape='aoe', label='天賦・愉悦ダメージ', rider=True)
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 1:
            per, cap = self._char()['ranks']['1']['params']
            self._skill_stacks = min(cap, self._skill_stacks + 1)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['800903']
        lv = self._levels(me)['Ultra']
        crit_dmg, turns, advance, reward, notes, gain = (p(s, lv, i) for i in (1, 2, 3, 4, 5, 6))
        battle.gain_shared(NOTES, gain)
        target = self._ult_target(me, battle)
        if target is None:
            battle.gain_energy(me, s['energy'])
            return
        battle.apply_effect(target, Effect(key=KEY_ULT_CD, label='必殺技・会心ダメージ', stats=StatSheet.of(crit_dmg=crit_dmg), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 2:
            rate, e2_turns = self._char()['ranks']['2']['params']
            battle.apply_effect(target, Effect(key=KEY_ULT_RATE, label='星魂2・愉悦度', stats=StatSheet.of(elation_rate=rate), duration=Duration(turns=int(e2_turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.target_ally(me, target)
        if battle.aha.has_elation_skill(target):
            extra = 0.0
            if me.eidolon >= 1:
                extra = self._char()['ranks']['1']['params'][0] * self._skill_stacks
                self._skill_stacks = 0.0
            battle.aha.grant_reward(target, reward + extra)
            battle.aha.fire_elation_skill(target, notes)
        else:
            battle.advance_forward(target, advance)
        battle.gain_energy(me, s['energy'])
        a4 = self._traces().get('8009102')
        if a4:
            battle.gain_sp(int(a4['params'][0][1]))

    def _ult_target(self, me, battle):
        picked = battle.target_override.get(me.id)
        if picked:
            chosen = next((c for c in battle.team if c.id == picked and c is not me), None)
            if chosen is not None:
                return chosen
        pool = [c for c in elation_members(battle) if c.id != me.id and battle.aha.has_elation_skill(c)]
        if not pool:
            pool = [c for c in battle.team if c.id != me.id]
        if not pool:
            return None
        return max(pool, key=lambda c: battle.damage_by_character.get(c.name, 0.0))

    def elation_skill(self, me, battle, notes: float) -> None:
        s = self._skills()['800920']
        lv = self._elation_level(me)
        hits, single, aoe = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        boost = battle.aha.skill_multiplier
        if me.eidolon >= 4:
            vuln, turns = self._char()['ranks']['4']['params']
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_E4_VULN, label='星魂4・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 6:
            cd, turns = self._char()['ranks']['6']['params']
            battle.apply_effect(me, Effect(key=KEY_E6_CD, label='星魂6・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(single, notes), elation_shape='random', random_hits=int(hits), independent=boost, toughness=s.get('toughness'), label=s['name'])
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(aoe, notes), elation_shape='aoe', independent=boost / max(1, len(battle.alive_enemies)), toughness=s.get('toughness'), label=s['name'] + '（全体）')
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        s = self._skills()['800907']
        lv = self._levels(me)['Normal']
        amount, turns = (p(s, lv, 1), p(s, lv, 5))
        battle.apply_to_team(lambda who: Effect(key=KEY_TECHNIQUE, label='秘技・愉悦度', stats=StatSheet.of(elation_rate=amount), duration=Duration(turns=int(turns), tick_owner_id=me.id), source_id=me.id))
