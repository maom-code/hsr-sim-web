from __future__ import annotations
from ...data import loader
from ...engine.effects import Effect, Stacking
from ...engine.elation import NOTES, elation_members, reward_total
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1503'
ELEMENT = Element.ICE
CHARGES = '深層学習'
KEY_TRACE_RATE = 'pearl.trace.elation_rate'
KEY_STUDY = 'pearl.study'
KEY_MODEL = 'pearl.model'
KEY_E1_SHARE = 'pearl.e1.share'
KEY_E2_UP = 'pearl.e2.elation_up'
KEY_E6_RESPEN = 'pearl.e6.res_pen'
KEY_ELATION_PROC = 'pearl.elation.next_attack'
KEY_ULT_REWARD = 'pearl.ult.extra_reward'
KEY_WALL = 'pearl.trace.wall'

@register(CHAR_ID)
class Pearl:
    target_override_label = '深層学習の対象'
    target_override_priority = ()
    target_override_default = '与ダメージが最も多い愉悦キャラ'
    main_stats = {'BODY': 'CriticalDamageBase'}
    speed_target = 140.0
    def_target = 3600.0
    substat_priority = ['CriticalChanceBase', 'CriticalDamageBase']
    unimplemented = ('天賦の防護値と被ダメージ軽減（味方が落ちない前提の DPA では効かない）', '軌跡「感受性の許容差」のデバフ解除（敵がデバフを撒かない）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _model(self, battle):
        for c in battle.team:
            if c.effects.has(KEY_MODEL):
                return c
        return None

    def _tier(self, battle) -> int:
        return len(elation_members(battle))

    def on_battle_start(self, me, battle) -> None:
        talent = self._skills()['150304']
        tlv = self._levels(me)['Talent']
        battle.aha.reward_permanent.add(me.id)
        battle.aha.reward_cap[me.id] = p(talent, tlv, 3)
        self._refresh_elation_rate(me, battle)
        if me.eidolon >= 2:
            up = self._char()['ranks']['2']['params'][0]
            battle.apply_to_team(lambda who: Effect(key=KEY_E2_UP, label='星魂2・上笑', stats=StatSheet.of(dmg_pct_elation=up), source_id=me.id))
        a4 = self._traces().get('1503102')
        if a4:
            per_turn = a4['params'][0][0]

            def on_ally_turn(actor=None, **kw):
                if actor is not None and actor in battle.team:
                    battle.aha.grant_reward(me, per_turn)
            battle.bus.subscribe(Event.ON_ACTION_START, on_ally_turn, owner_id=me.id)
        a6 = self._traces().get('1503103')
        if a6:
            energy = a6['params'][0][0]

            def on_ally_ult(actor=None, source_id=None, **kw):
                if actor is None or not actor.effects.has(KEY_WALL):
                    return
                actor.effects.remove(KEY_WALL)
                battle.gain_energy(me, energy, apply_regen=False)
            battle.bus.subscribe(Event.ON_ULT_USED, on_ally_ult, owner_id=me.id)
            self._arm_wall(me, battle)
        if me.eidolon >= 1:
            self._apply_e1(me, battle)

    def _arm_wall(self, me, battle) -> None:
        if not self._traces().get('1503103'):
            return
        for c in battle.team:
            c.effects.remove(KEY_WALL)
        model = self._model(battle)
        if model is None or model not in elation_members(battle):
            return
        battle.apply_effect(model, Effect(key=KEY_WALL, label='芸術という壁', stacking=Stacking.UNIQUE, source_id=me.id))

    def _refresh_elation_rate(self, me, battle) -> None:
        a2 = self._traces().get('1503101')
        if not a2:
            return
        threshold, base, step, per, cap = a2['params'][0]
        defence = me.stats[StatKey.DEF]
        if defence < threshold:
            return
        over = min(defence - threshold, cap)
        battle.apply_effect(me, Effect(key=KEY_TRACE_RATE, label='軌跡・愉悦度', stats=StatSheet.of(elation_rate=base + over / step * per), stacking=Stacking.REFRESH, source_id=me.id))

    def _apply_e1(self, me, battle) -> None:
        shares = self._char()['ranks']['1']['params']
        tier = self._tier(battle)
        if tier < 2:
            return
        ratio = shares[min(tier, 4) - 2]
        amount = min(me.stats[StatKey.ELATION_RATE] * ratio, shares[3])

        def make(_who=None) -> Effect:
            return Effect(key=KEY_E1_SHARE, label='星魂1・愉悦度', stats=StatSheet.of(elation_rate=amount), stacking=Stacking.REFRESH, source_id=me.id)
        battle.apply_aura(me, make, key=None)

    def basic(self, me, battle) -> None:
        if not me.effects.has(KEY_STUDY):
            self._plain_basic(me, battle)
            return
        model = self._model(battle)
        elation = model is not None and model in elation_members(battle)
        self._enhanced_basic(me, battle, model, elation=elation)
        battle.spend_counter(me, CHARGES, 1)
        if battle.counter_value(me, CHARGES) <= 0:
            me.effects.remove(KEY_STUDY)
            if model is not None:
                model.effects.remove(KEY_MODEL)
            if me.eidolon >= 6:
                for c in battle.team:
                    c.effects.remove(KEY_E6_RESPEN)

    def _plain_basic(self, me, battle) -> None:
        s = self._skills()['150301']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.DEF, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def _enhanced_basic(self, me, battle, model, *, elation: bool) -> None:
        s = self._skills()['150308' if elation else '150310']
        lv = self._levels(me)['Normal']
        mult, heal_pct, _, heal_flat = (p(s, lv, i) for i in (1, 2, 3, 4))
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.DEF, mult),), toughness=s.get('toughness'), label=s['name'])
        if elation and model is not None:
            notes = reward_total(model) or reward_total(me)
            battle.attack(model, ELEMENT, DamageType.ELATION, elation=(p(s, lv, 5), notes), elation_shape='aoe', toughness=s.get('toughness'), label=s['name'] + '（愉悦）', rider=True)
            if me.eidolon >= 6:
                extra = self._char()['ranks']['6']['params'][1]
                battle.attack(model, ELEMENT, DamageType.ELATION, elation=(extra, notes), elation_shape='aoe', label='星魂6・愉悦ダメージ', rider=True)
        self._heal_team(me, battle, heal_pct, heal_flat, s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['150302']
        lv = self._levels(me)['BPSkill']
        reward, heal_pct, heal_flat = (p(s, lv, i) for i in (1, 2, 3))
        battle.spend_sp(s['sp_cost'])
        battle.aha.grant_reward(me, reward)
        self._heal_team(me, battle, heal_pct, heal_flat, s['name'])
        battle.gain_energy(me, s['energy'])

    def _heal_team(self, me, battle, pct: float, flat: float, label: str) -> None:
        amount = me.stats[StatKey.DEF] * pct + flat
        for c in battle.team:
            battle.heal(me, c, amount, label=label)
        lowest = min(battle.team, key=lambda c: c.hp / c.stats[StatKey.HP])
        battle.heal(me, lowest, amount, label=label)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150303']
        lv = self._levels(me)['Ultra']
        charges, _, reward = (p(s, lv, i) for i in (1, 2, 3))
        advances = [p(s, lv, i) for i in (4, 5, 6)]
        notes_gain, reward_gain = (p(s, lv, 7), p(s, lv, 8))
        battle.aha.grant_reward(me, reward)
        battle.gain_energy(me, s['energy'])
        self._begin_study(me, battle, charges)
        model = self._model(battle)
        if model is None:
            return
        tier = self._tier(battle)
        ratio = advances[min(tier, 3) - 1] if tier >= 1 else 0.0
        battle.advance_forward(model, ratio)
        if me.eidolon >= 2:
            for c in elation_members(battle):
                if c.id not in (me.id, model.id):
                    battle.advance_forward(c, ratio)
        if tier < 4:
            return
        boost = 2.0 if me.eidolon >= 2 else 1.0
        battle.gain_shared(NOTES, notes_gain * boost)
        battle.aha.grant_reward(model, reward_gain * boost, key=KEY_ULT_REWARD)
        try:
            battle.extra_turn(model)
        finally:
            battle.spend_shared(NOTES, notes_gain * boost)
            model.effects.remove(KEY_ULT_REWARD)

    def _model_target(self, me, battle):
        picked = battle.target_override.get(me.id)
        if picked:
            chosen = next((c for c in battle.team if c.id == picked and c is not me), None)
            if chosen is not None:
                return chosen
        pool = [c for c in elation_members(battle) if c.id != me.id and battle.aha.has_elation_skill(c)]
        if not pool:
            pool = [c for c in battle.team if c.id != me.id]
        if not pool:
            return None
        return max(pool, key=lambda c: battle.damage_by_character.get(c.name, 0.0))

    def _begin_study(self, me, battle, charges: float) -> None:
        for c in battle.team:
            c.effects.remove(KEY_MODEL)
        model = self._model_target(me, battle)
        if model is None:
            return
        battle.apply_effect(model, Effect(key=KEY_MODEL, label='美学の底本', source_id=me.id))
        battle.target_ally(me, model)
        battle.apply_effect(me, Effect(key=KEY_STUDY, label='深層学習', stacking=Stacking.REFRESH, source_id=me.id))
        counter = me.counter(CHARGES)
        counter.current = 0.0
        battle.gain_counter(me, CHARGES, charges)
        self._arm_wall(me, battle)
        if me.eidolon >= 6:
            pen = self._char()['ranks']['6']['params'][0]
            battle.apply_to_team(lambda who: Effect(key=KEY_E6_RESPEN, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=pen), stacking=Stacking.REFRESH, source_id=me.id))

    def elation_skill(self, me, battle, notes: float) -> None:
        s = self._skills()['150320']
        lv = self._levels(me).get('ElationDamage', 10)
        tier = self._tier(battle)
        if tier < 1:
            return
        mult = p(s, lv, min(tier, 4)) * battle.aha.skill_multiplier
        armed = {c.id for c in battle.team}
        holder: dict[str, int] = {}

        def on_attack(source=None, dmg_type=None, targets_hit: int=0, rider=False, **kw):
            if source is None or not targets_hit or rider:
                return
            if dmg_type is DamageType.ELATION:
                return
            if source.id not in armed:
                return
            armed.discard(source.id)
            if not armed:
                battle.bus.unsubscribe(holder['id'])
            battle.attack(source, getattr(source, 'element', None) or ELEMENT, DamageType.ELATION, elation=(mult, notes), elation_shape='main', label='愉悦の脱構築')
        holder['id'] = battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        s = self._skills()['150307']
        lv = self._levels(me)['Normal']
        charges, reward = (p(s, lv, 1), p(s, lv, 2))
        battle.aha.grant_reward(me, reward)
        self._begin_study(me, battle, charges)
    rotation_label = '深層学習中は強化通常攻撃、それ以外はスキル'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        if me.effects.has(KEY_STUDY) and battle.counter_value(me, CHARGES) > 0:
            return Action.BASIC
        return Action.SKILL
