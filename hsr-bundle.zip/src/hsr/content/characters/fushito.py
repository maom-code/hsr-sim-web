from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1504'
ELEMENT = Element.LIGHTNING
CHARGE = 'チャージ'
GLUTTONY = '暴食'
KEY_PREY = 'fushito.prey'
KEY_PREY_DEF = 'fushito.prey.def_down'
KEY_TRACE_FUA = 'fushito.trace.followup'
KEY_TRACE_TEAM = 'fushito.trace.team'
KEY_E1_VULN = 'fushito.e1.vuln'
KEY_E4_ATK = 'fushito.e4.atk'
KEY_E6_RES = 'fushito.e6.res_down'
KEY_E6_DMG = 'fushito.e6.dmg'

@register(CHAR_ID)
class Fushito:
    relic_sets = {'115': 4, '326': 2}
    unimplemented = ('必殺技「饗宴の幕」の撃破連鎖（敵を倒すと次の「餌食」へ続けて撃つ）。敵が落ちない前提で DPA を測るので発動しない', '軌跡「罪の道」の後半（追撃中に敵を倒すたびに「暴食」+1 層）。同上')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _talent(self, me) -> tuple[dict, int]:
        return (self._skills()['150404'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._prey = None
        self._gluttony_total = 0.0
        s, lv = self._talent(me)
        initial, cap = (p(s, lv, 1), p(s, lv, 2))
        battle.gain_counter(me, CHARGE, initial, maximum=cap)
        battle.gain_counter(me, GLUTTONY, 0, maximum=self._gluttony_cap(me))
        a6 = self._traces().get('1504103')
        if a6:
            crit_dmg, fua_crit_dmg = a6['params'][0]
            battle.apply_aura(me, lambda who: Effect(key=KEY_TRACE_TEAM, label='長の狼', stats=StatSheet.of(crit_dmg=crit_dmg, crit_dmg_followup=fua_crit_dmg), source_id=me.id))
        if me.eidolon >= 1:
            vuln = self._char()['ranks']['1']['params'][0]
            for e in battle.enemies:
                battle.apply_effect(e, Effect(key=KEY_E1_VULN, label='星魂1・脆弱', stats=StatSheet.of(vulnerability=vuln), source_id=me.id))
        self._refresh_gluttony_buffs(me, battle)

        def on_damage(source=None, dmg_type=None, targets=None, rider=False, **kw):
            if source is None or source is me or (not targets) or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            if self._prey is None or not self._prey.alive:
                return
            if self._prey not in targets:
                return
            self._talent_followup(me, battle)
        battle.bus.subscribe(Event.ON_ATTACK, on_damage, owner_id=me.id)

    def _mark_prey(self, me, battle, target) -> None:
        if target is None:
            return
        if self._prey is not None and self._prey is not target:
            battle.remove_effect(self._prey, KEY_PREY)
        self._prey = target
        battle.apply_effect(target, Effect(key=KEY_PREY, label='餌食', stacking=Stacking.REFRESH, source_id=me.id))
        s = self._skills()['150402']
        def_down = p(s, self._levels(me)['BPSkill'], 4)
        res_down = self._char()['ranks']['6']['params'][0] if me.eidolon >= 6 else 0.0
        for e in battle.enemies:
            battle.apply_effect(e, Effect(key=KEY_PREY_DEF, label='餌食・防御力ダウン', stats=StatSheet.of(def_down=def_down, res_down=res_down), source_id=me.id))

    def _gluttony_cap(self, me) -> float:
        s, lv = self._talent(me)
        cap = p(s, lv, 6)
        if me.eidolon >= 2:
            cap = self._char()['ranks']['2']['params'][0]
        return cap

    def _gain_gluttony(self, me, battle, amount: float) -> None:
        gained = battle.gain_counter(me, GLUTTONY, amount, maximum=self._gluttony_cap(me))
        if gained:
            self._gluttony_total += gained
        self._refresh_gluttony_buffs(me, battle)

    def _refresh_gluttony_buffs(self, me, battle) -> None:
        a4 = self._traces().get('1504102')
        if a4:
            base, per_stack, per_bonus = a4['params'][0]
            stacks = battle.counter_value(me, GLUTTONY)
            battle.apply_effect(me, Effect(key=KEY_TRACE_FUA, label=f'影の腕（暴食 {stacks:.0f}）', stats=StatSheet.of(dmg_pct_followup=base + per_bonus * (stacks / per_stack)), source_id=me.id))
        if me.eidolon >= 6:
            _res, per, cap = self._char()['ranks']['6']['params']
            battle.apply_effect(me, Effect(key=KEY_E6_DMG, label='星魂6・与ダメージ', stats=StatSheet.of(dmg_pct=per * min(self._gluttony_total, cap)), source_id=me.id))

    def _talent_followup(self, me, battle, *, free: bool=False) -> None:
        s, lv = self._talent(me)
        cost, mult, gluttony, energy = (p(s, lv, 3), p(s, lv, 4), p(s, lv, 5), p(s, lv, 7))
        battle.gain_energy(me, energy, apply_regen=False)
        if not free:
            if battle.counter_value(me, CHARGE) < cost:
                return
            battle.spend_counter(me, CHARGE, cost)
        battle.attack(me, ELEMENT, DamageType.FOLLOWUP, main=((StatKey.ATK, mult),), target=self._prey, toughness=s.get('toughness'), label=s['name'])
        self._gain_gluttony(me, battle, gluttony)

    def basic(self, me, battle) -> None:
        s = self._skills()['150401']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['150402']
        lv = self._levels(me)['BPSkill']
        first, extra, sp_back = (p(s, lv, 1), p(s, lv, 3), p(s, lv, 5))
        battle.spend_sp(s['sp_cost'])
        target = battle.target
        already = self._prey is target and target is not None
        self._mark_prey(me, battle, target)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, first),), target=target, toughness=s.get('toughness'), label=s['name'])
        if already:
            battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, extra),), target=target, toughness=s.get('toughness'), label=s['name'] + '（追撃ぶん）')
            battle.gain_sp(int(sp_back))
        battle.gain_energy(me, s['energy'])
        a2 = self._traces().get('1504101')
        if a2:
            self._gain_gluttony(me, battle, a2['params'][0][0])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150403']
        lv = self._levels(me)['Ultra']
        mult, charge, per_bite, bite_mult = (p(s, lv, i) for i in (1, 2, 3, 4))
        if me.eidolon >= 4:
            atk_up, turns = self._char()['ranks']['4']['params']
            battle.apply_effect(me, Effect(key=KEY_E4_ATK, label='星魂4・攻撃力', stats=StatSheet.of(atk_pct=atk_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        target = battle.target
        self._mark_prey(me, battle, target)
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, main=((StatKey.ATK, mult),), target=target, toughness=s.get('toughness'), label=s['name'])
        a2 = self._traces().get('1504101')
        if a2:
            self._gain_gluttony(me, battle, a2['params'][0][1])
        battle.gain_counter(me, CHARGE, charge, maximum=self._talent_charge_cap(me))
        self._talent_followup(me, battle, free=True)
        bites = 0
        while battle.counter_value(me, GLUTTONY) >= per_bite:
            battle.spend_counter(me, GLUTTONY, per_bite)
            bites += 1
            battle.attack(me, ELEMENT, DamageType.FOLLOWUP, main=((StatKey.ATK, bite_mult),), target=self._prey, toughness=s.get('toughness'), label=s['name'] + '（暴食）')
        if me.eidolon >= 2 and bites:
            _cap, refund = self._char()['ranks']['2']['params']
            self._gain_gluttony(me, battle, per_bite * bites * refund)
        else:
            self._refresh_gluttony_buffs(me, battle)
        battle.gain_energy(me, s['energy'])

    def _talent_charge_cap(self, me) -> float:
        s, lv = self._talent(me)
        return p(s, lv, 2)

    def technique(self, me, battle) -> None:
        s = self._skills()['150407']
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, p(s, 1, 2)),), label='秘技・憎き手よ、食らうがいい')
        battle.gain_counter(me, CHARGE, p(s, 1, 3), maximum=self._talent_charge_cap(me))
