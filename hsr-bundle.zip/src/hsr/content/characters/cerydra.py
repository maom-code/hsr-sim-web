from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
from .sparkle import SKILL_PRIORITY
CHAR_ID = '1412'
ELEMENT = Element.WIND
CHARGE = 'チャージ'
KEY_MERIT = 'cerydra.merit'
KEY_PEERAGE = 'cerydra.peerage'
KEY_A2_CD = 'cerydra.trace.crit_dmg'
KEY_A4_CR = 'cerydra.trace.crit_rate'
KEY_A6_SPD = 'cerydra.trace.spd'
KEY_E2_SELF = 'cerydra.e2.self'
KEY_E6_SELF = 'cerydra.e6.self'
KEY_LAW_CD = 'cerydra.poem.law'

@register(CHAR_ID)
class Cerydra:
    target_override_label = '軍功の対象'
    target_override_priority = SKILL_PRIORITY
    unimplemented = ('「奇襲」の中身（説明文から読めないので、爵位の戦闘スキルを撃ってチャージ 6 を消費するだけにしている）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _skill_params(self, me) -> list[float]:
        return params_at(self._skills()['141202'], self._levels(me)['BPSkill'])

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['141204'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._holder = None
        self._coup = False
        self._extra_left = int(self._talent(me)[3])
        self._a4_used = False
        self._law: tuple[float, float] | None = None
        me.counter(CHARGE, maximum=self._skill_params(me)[2])
        a4 = self._traces().get('1412102')
        if a4:
            battle.apply_effect(me, Effect(key=KEY_A4_CR, label='見た者・会心率', stats=StatSheet.of(crit_rate=a4['params'][0][0]), source_id=me.id))
        self._refresh_self(me, battle)

        def on_action(actor=None, action=None, **kw):
            from ...engine.battle import Action
            if actor is None or actor is not self._holder:
                return
            if action in (Action.BASIC, Action.SKILL):
                if action is Action.SKILL and self._holder.effects.has(KEY_PEERAGE):
                    self._coup = True
                else:
                    self._gain(me, battle, self._talent(me)[0])
                a6 = self._traces().get('1412103')
                if a6:
                    battle.gain_energy(me, a6['params'][0][0], apply_regen=False)
            elif action is Action.ULTIMATE and a4 and (not self._a4_used):
                cap = self._skill_params(me)[2]
                if battle.counter_value(me, CHARGE) < cap:
                    self._a4_used = True
                    self._gain(me, battle, a4['params'][0][1])

        def on_skill_used(source_id=None, **kw):
            if self._coup and self._holder is not None and (source_id == self._holder.id):
                self._coup = False
                need = self._skill_params(me)[3]
                battle.spend_counter(me, CHARGE, need)
                battle.remove_effect(self._holder, KEY_PEERAGE)
                battle._log(me.name, '奇襲終了・爵位を軍功に戻す')
                if self._law is not None:
                    self._gain(me, battle, self._law[1])

        def on_attack(source=None, rider=False, **kw):
            if rider or source is None or source is not self._holder or (self._extra_left <= 0):
                return
            self._extra_left -= 1
            t = self._talent(me)
            mult = t[2] + (self._rank(6)[1] if me.eidolon >= 6 else 0.0)
            focus = battle.target
            if focus is not None:
                dealt = battle.deal_damage(me, focus, ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, mult),))
                if dealt:
                    battle._log(me.name, '軍功・付加ダメージ', dealt)
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=me.id)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill_used, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)

    def on_turn_start(self, me, battle) -> None:
        self._refresh_self(me, battle)

    def _refresh_self(self, me, battle) -> None:
        a2 = self._traces().get('1412101')
        if a2:
            floor, step, per, cap = a2['params'][0][:4]
            battle.remove_effect(me, KEY_A2_CD)
            over = max(0.0, me.stats[StatKey.ATK] - floor)
            battle.apply_effect(me, Effect(key=KEY_A2_CD, label='来た者・会心ダメージ', stats=StatSheet.of(crit_dmg=min(cap, int(over // step) * per)), source_id=me.id))

    def _merit_stats(self, me) -> StatSheet:
        stats = StatSheet.of(atk=me.stats[StatKey.ATK] * self._talent(me)[1])
        if me.eidolon >= 1:
            stats.add(StatKey.DEF_IGNORE, self._rank(1)[0])
        if me.eidolon >= 2:
            stats.add(StatKey.DMG_PCT, self._rank(2)[0])
        if me.eidolon >= 6:
            stats.add(StatKey.RES_PEN, self._rank(6)[0])
        return stats

    def _give_merit(self, me, battle, target) -> None:
        if self._holder is not None and self._holder is not target:
            for key in (KEY_MERIT, KEY_PEERAGE, KEY_LAW_CD):
                battle.remove_effect(self._holder, key)
            battle.spend_counter(me, CHARGE)
        self._holder = target
        battle.apply_effect(target, Effect(key=KEY_MERIT, label='軍功', stats=self._merit_stats(me), stacking=Stacking.REFRESH, source_id=me.id))
        if getattr(self, '_law', None) is not None:
            self._apply_law(me, battle, target)
        if target is not me:
            if me.eidolon >= 2:
                battle.apply_effect(me, Effect(key=KEY_E2_SELF, label='星魂2・与ダメージ', stats=StatSheet.of(dmg_pct=self._rank(2)[1]), source_id=me.id))
            if me.eidolon >= 6:
                battle.apply_effect(me, Effect(key=KEY_E6_SELF, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=self._rank(6)[0]), source_id=me.id))

    def grant_law_poem(self, me, battle, *, crit_dmg: float, charge: float) -> None:
        self._law = (crit_dmg, charge)
        if self._holder is not None:
            self._apply_law(me, battle, self._holder)

    def _apply_law(self, me, battle, holder) -> None:
        battle.apply_effect(holder, Effect(key=KEY_LAW_CD, label='詩・会心ダメージ', stats=StatSheet.of(crit_dmg=self._law[0]), stacking=Stacking.REFRESH, source_id=me.id))

    def _gain(self, me, battle, n: float) -> None:
        sp = self._skill_params(me)
        battle.gain_counter(me, CHARGE, n, maximum=sp[2])
        holder = self._holder
        if holder is not None and battle.counter_value(me, CHARGE) >= sp[3] and (not holder.effects.has(KEY_PEERAGE)):
            stats = StatSheet.of(crit_dmg_skill=sp[0], res_pen=sp[4])
            if me.eidolon >= 1:
                stats.add(StatKey.DEF_IGNORE, self._rank(1)[1])
            battle.apply_effect(holder, Effect(key=KEY_PEERAGE, label='爵位', stats=stats, stacking=Stacking.REFRESH, source_id=me.id))

    def basic(self, me, battle) -> None:
        s = self._skills()['141201']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['141202']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        self._cast_skill(me, battle)
        battle.gain_energy(me, s['energy'])

    def _cast_skill(self, me, battle) -> None:
        target = battle.resolve_target_override(me, self.target_override_priority) or me
        battle.target_ally(me, target)
        self._give_merit(me, battle, target)
        self._gain(me, battle, self._skill_params(me)[1])
        a6 = self._traces().get('1412103')
        if a6:
            _, spd, turns = a6['params'][0][:3]
            for who in [me] if target is me else [me, target]:
                before = who.speed()
                battle.apply_effect(who, Effect(key=KEY_A6_SPD, label='征した者・速度', stats=StatSheet.of(spd=spd), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
                if any((sl.actor is who for sl in battle.queue.slots)):
                    battle.queue.rescale(who, before)
        if me.eidolon >= 1:
            battle.gain_energy(target, self._rank(1)[2], apply_regen=False)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['141203']
        lv = self._levels(me)['Ultra']
        mult, charge = (p(s, lv, 1), p(s, lv, 2))
        if me.eidolon >= 4:
            mult += self._rank(4)[0]
        self._extra_left = int(self._talent(me)[3])
        if self._holder is None and battle.team:
            self._give_merit(me, battle, battle.team[0])
        self._gain(me, battle, charge)
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        self._cast_skill(me, battle)
