from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, reward_total
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1502'
ELEMENT = Element.PHYSICAL
KEY_ZONE = 'yaoguang.skill.zone'
KEY_ZONE_RATE = 'yaoguang.skill.zone_rate'
KEY_ZONE_SPD = 'yaoguang.e2.speed'
KEY_ULT_RESPEN = 'yaoguang.ult.res_pen'
KEY_TRACE_RATE = 'yaoguang.trace.elation_rate'
KEY_TRACE_CD = 'yaoguang.trace.crit_dmg'
KEY_E1_DEF = 'yaoguang.e1.def_ignore'
KEY_E6_UP = 'yaoguang.e6.elation_up'

@register(CHAR_ID)
class Yaoguang:
    speed_target = 200.0
    substat_priority = ['CriticalChanceBase', 'CriticalDamageBase']
    relic_sets = {'130': 4, '317': 2}
    unimplemented = ()
    rotation_label = 'バフが切れるならスキル'

    def buff_expiring(self, me, battle) -> bool:
        eff = me.effects.get(KEY_ZONE)
        return eff is None or eff.duration is None or eff.duration.turns <= 1

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self.buff_expiring(me, battle) else Action.BASIC

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _elation_level(self, me) -> int:
        return self._levels(me).get('ElationDamage', 10)

    def on_battle_start(self, me, battle) -> None:
        self._sp_used = False
        a2 = self._traces().get('1502101')
        if a2:
            threshold, base, step, per, cap = a2['params'][0]
            spd = me.stats[StatKey.SPD]
            if spd >= threshold:
                over = min(max(0.0, spd - threshold), cap)
                battle.apply_effect(me, Effect(key=KEY_TRACE_RATE, label='軌跡・愉悦度', stats=StatSheet.of(elation_rate=base + over / step * per), source_id=me.id))
        a4 = self._traces().get('1502102')
        if a4:
            battle.apply_effect(me, Effect(key=KEY_TRACE_CD, label='軌跡・会心ダメージ', stats=StatSheet.of(crit_dmg=a4['params'][0][3]), source_id=me.id))
        a6 = self._traces().get('1502103')
        if a6:
            battle.aha.reward_turn_bonus[me.id] = int(a6['params'][0][1])
        if me.eidolon >= 6:
            up = self._char()['ranks']['6']['params'][0]
            battle.apply_to_team(lambda who: Effect(key=KEY_E6_UP, label='星魂6・上笑', stats=StatSheet.of(dmg_pct_elation=up), source_id=me.id))
        if me.eidolon >= 1:
            ignore = self._char()['ranks']['1']['params'][0]
            battle.apply_to_team(lambda who: Effect(key=KEY_E1_DEF, label='星魂1・防御無視', stats=StatSheet.of(def_ignore_elation=ignore), source_id=me.id))

        def on_action(actor=None, action=None, **kw):
            from ...engine.battle import Action
            self._sp_used = bool(action is Action.SKILL and actor is not None and (getattr(actor, 'built', None) is not None) and (battle.skill_cost(actor) > 0))
        battle.bus.subscribe(Event.ON_ACTION_START, on_action, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ATTACK, lambda **kw: self._great_fortune(me, battle, **kw), owner_id=me.id)

    def _great_fortune(self, me, battle, *, source=None, dmg_type=None, targets_hit: int=0, rider: bool=False, **kw) -> None:
        if source is None or not targets_hit or rider:
            return
        if dmg_type is DamageType.ELATION:
            return
        if reward_total(me) <= 0:
            return
        s = self._skills()['150204']
        mult = p(s, self._levels(me)['Talent'], 1)
        notes = reward_total(me)
        rate = me.stats[StatKey.ELATION_RATE]
        element = getattr(source, 'element', None) or ELEMENT
        hits = 2 if self._sp_used else 1
        for _ in range(hits):
            battle.attack(source, element, DamageType.ELATION, elation=(mult, notes), elation_shape='random', random_hits=1, elation_rate=rate, label='大吉大利', counts_as_attack=False)

    def basic(self, me, battle) -> None:
        s = self._skills()['150201']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), adjacent=((StatKey.ATK, p(s, lv, 2)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])
        self._gain_notes(me, battle)

    def skill(self, me, battle) -> None:
        s = self._skills()['150202']
        lv = self._levels(me)['BPSkill']
        turns, share, notes = (p(s, lv, i) for i in (1, 2, 3))
        battle.spend_sp(s['sp_cost'])
        rate = me.stats[StatKey.ELATION_RATE] * share
        spd_up = 0.0
        if me.eidolon >= 2:
            extra_rate, spd_up = self._char()['ranks']['2']['params']
            rate += extra_rate

        def make(_who=None) -> Effect:
            return Effect(key=KEY_ZONE_RATE, label='結界・愉悦度', stats=StatSheet.of(elation_rate=rate, spd_pct=spd_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id)
        battle.apply_effect(me, Effect(key=KEY_ZONE, label='結界', duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, make, key=KEY_ZONE)
        battle.gain_energy(me, s['energy'])
        self._gain_notes(me, battle, amount=notes)

    def _gain_notes(self, me, battle, amount: float | None=None) -> None:
        if not me.effects.has(KEY_ZONE):
            return
        if amount is None:
            s = self._skills()['150202']
            amount = p(s, self._levels(me)['BPSkill'], 3)
        battle.gain_shared(NOTES, amount)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150203']
        lv = self._levels(me)['Ultra']
        notes, res_pen, turns, fixed = (p(s, lv, i) for i in (1, 2, 3, 4))
        battle.gain_shared(NOTES, notes)
        battle.apply_to_team(lambda who: Effect(key=KEY_ULT_RESPEN, label='必殺技・耐性貫通', stats=StatSheet.of(res_pen=res_pen), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 1:
            fixed = max(fixed, self._char()['ranks']['1']['params'][1])
        multiplier = self._char()['ranks']['4']['params'][0] if me.eidolon >= 4 else 1.0
        battle.aha.aha_time(extra=True, notes=fixed, multiplier=multiplier)

    def elation_skill(self, me, battle, notes: float) -> None:
        s = self._skills()['150220']
        lv = self._elation_level(me)
        aoe, vuln, turns, hits, single = (p(s, lv, i) for i in (2, 3, 4, 5, 6))
        if me.eidolon >= 6:
            up = 1.0 + self._char()['ranks']['6']['params'][1]
            aoe, single = (aoe * up, single * up)
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key='yaoguang.elation.vuln', label='凶星の囁き', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        boost = battle.aha.skill_multiplier
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(aoe, notes), elation_shape='aoe', independent=boost, toughness=s.get('toughness'), label=s['name'])
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(single, notes), elation_shape='random', random_hits=int(hits), independent=boost, toughness=s.get('toughness'), label=s['name'] + '（追撃）')
        a4 = self._traces().get('1502102')
        if a4:
            battle.gain_sp(int(a4['params'][0][0]))

    def technique(self, me, battle) -> None:
        sp_before = battle.sp.current
        self.skill(me, battle)
        battle.sp.current = sp_before
