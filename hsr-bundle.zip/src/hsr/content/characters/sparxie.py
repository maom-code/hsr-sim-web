from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, elation_members, reward_total
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1501'
ELEMENT = Element.FIRE
SHOCK = '衝撃ネタ'
GRASSLAND_EVERY = 5
KEY_TRACE_RATE = 'sparxie.trace.elation_rate'
KEY_TRACE_TEAM_CD = 'sparxie.trace.team_crit_dmg'
KEY_E1_RESPEN = 'sparxie.e1.res_pen'
KEY_E2_CD = 'sparxie.e2.crit_dmg'
KEY_E4_RATE = 'sparxie.e4.elation_rate'
KEY_E6_RESPEN = 'sparxie.e6.res_pen'

@register(CHAR_ID)
class Sparxie:
    skill_counts_as_skill = False
    speed_target = 134.0
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _rank(self, n: int) -> list:
        return self._char()['ranks'][str(n)]['params']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def on_battle_start(self, me, battle) -> None:
        self._broadcasting = False
        self._traps = 0
        self._trap_total = 0
        me.counter(SHOCK)
        if self._traces().get('1501101'):
            self._refresh_atk_rate(me, battle)

            def on_changed(effect=None, **kw):
                if effect is not None and getattr(effect, 'key', None) == KEY_TRACE_RATE:
                    return
                self._refresh_atk_rate(me, battle)
            battle.bus.subscribe(Event.ON_EFFECT_APPLIED, on_changed, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_START, on_changed, owner_id=me.id)

        def refresh(name=None, **kw):
            if name == NOTES:
                self._refresh_note_buffs(me, battle)
        battle.bus.subscribe(Event.ON_SHARED_GAIN, refresh, owner_id=me.id)
        battle.bus.subscribe(Event.ON_SHARED_SPEND, refresh, owner_id=me.id)
        self._refresh_note_buffs(me, battle)
        if me.eidolon >= 1:

            def on_aha_end(**kw):
                battle.gain_shared(NOTES, self._rank(1)[0])
                if me.eidolon >= 2:
                    battle.gain_counter(me, SHOCK, self._rank(2)[0])
                    battle.extra_turn(me)
            battle.bus.subscribe(Event.ON_AHA_TIME_END, on_aha_end, owner_id=me.id)
        if me.eidolon >= 6:
            battle.apply_effect(me, Effect(key=KEY_E6_RESPEN, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=self._rank(6)[2]), source_id=me.id))

    def _refresh_atk_rate(self, me, battle) -> None:
        threshold, step, per, cap = self._traces()['1501101']['params'][0]
        rate = min(max(0.0, me.stats[StatKey.ATK] - threshold) / step * per, cap)
        current = me.effects.get(KEY_TRACE_RATE)
        if current is not None and abs(current.contribution()[StatKey.ELATION_RATE] - rate) < 1e-09:
            return
        battle.apply_effect(me, Effect(key=KEY_TRACE_RATE, label='軌跡・愉悦度', stats=StatSheet.of(elation_rate=rate), stacking=Stacking.REFRESH, source_id=me.id))

    def _refresh_note_buffs(self, me, battle) -> None:
        notes = battle.shared_value(NOTES)
        a6 = self._traces().get('1501103')
        if a6:
            per, cap = a6['params'][0]
            cd = min(notes * per, cap)
            battle.apply_to_team(lambda who: Effect(key=KEY_TRACE_TEAM_CD, label='軌跡・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 1:
            _, per, cap = self._rank(1)
            pen = min(notes * per, cap)
            battle.apply_to_team(lambda who: Effect(key=KEY_E1_RESPEN, label='星魂1・耐性貫通', stats=StatSheet.of(res_pen=pen), stacking=Stacking.REFRESH, source_id=me.id))

    def _payable(self, me, battle) -> float:
        return battle.counter_value(me, SHOCK) + battle.sp.current

    def can_pay_skill(self, me, battle) -> bool:
        return self._payable(me, battle) >= 1
    rotation_label = 'SP か衝撃ネタがあればスキル'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self.can_pay_skill(me, battle) else Action.BASIC

    def _pay(self, me, battle, n: int=1) -> None:
        from_shock = min(float(n), battle.counter_value(me, SHOCK))
        if from_shock:
            battle.spend_counter(me, SHOCK, from_shock)
            battle.notify_sp_spent(from_shock, actor=me)
            self._on_shock_spent(me, battle, from_shock)
        rest = int(n - from_shock)
        if rest:
            battle.spend_sp(rest, actor=me)

    def _on_shock_spent(self, me, battle, amount: float) -> None:
        if me.eidolon < 2:
            return
        _, cd, turns, cap = self._rank(2)
        for _ in range(int(amount)):
            battle.apply_effect(me, Effect(key=KEY_E2_CD, label='星魂2・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.STACK, max_stacks=int(cap), source_id=me.id))

    def basic(self, me, battle) -> None:
        s = self._skills()['150101']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'] or 0)

    def skill(self, me, battle) -> None:
        s = self._skills()['150102']
        cap = int(p(s, self._levels(me)['BPSkill'], 1))
        with battle.sp_batch(me):
            self._pay(me, battle, int(s['sp_cost']))
            self._broadcasting = True
            self._traps = 0
            battle._log(me.name, 'コラボ配信開始')
            self._trap(me, battle)
            trap_cost = int(self._skills()['150109']['sp_cost'])
            while self._traps < cap and self._payable(me, battle) >= trap_cost:
                self._pay(me, battle, trap_cost)
                self._trap(me, battle)
            self._enhanced_basic(me, battle)
            battle.gain_energy(me, s['energy'] or 0)

    def _trap(self, me, battle) -> None:
        s = self._skills()['150109']
        lv = self._levels(me)['BPSkill']
        sp_gain, lol_notes, grass_notes = (p(s, lv, i) for i in (1, 2, 3))
        self._traps += 1
        self._trap_total += 1
        if self._trap_total % GRASSLAND_EVERY == 0:
            battle._log(me.name, f'トラップ {self._traps}: 大草原')
            battle.gain_shared(NOTES, grass_notes)
            battle.gain_sp(int(sp_gain))
        else:
            battle._log(me.name, f'トラップ {self._traps}: 大爆笑')
            battle.gain_shared(NOTES, lol_notes)

    def _enhanced_basic(self, me, battle) -> None:
        s = self._skills()['150108']
        trap = self._skills()['150109']
        nlv, slv = (self._levels(me)['Normal'], self._levels(me)['BPSkill'])
        main = p(s, nlv, 1) + p(trap, slv, 4) * self._traps
        adj = p(s, nlv, 2) + p(trap, slv, 5) * self._traps
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, main),), adjacent=((StatKey.ATK, adj),), label=f'{s['name']}（トラップ{self._traps}回）')
        notes = reward_total(me)
        if notes > 0:
            t = self._skills()['150104']
            tlv = self._levels(me)['Talent']
            extra, _, main_e, adj_e = (p(t, tlv, i) for i in (1, 2, 3, 4))
            battle.attack(me, ELEMENT, DamageType.ELATION, elation=(main_e, notes), elation_shape='main', label='天賦・愉悦ダメージ', rider=True)
            battle.attack(me, ELEMENT, DamageType.ELATION, elation=(adj_e, notes), elation_shape='adjacent', label='天賦・愉悦ダメージ（隣接）', rider=True)
            if self._traps:
                battle.attack(me, ELEMENT, DamageType.ELATION, elation=(extra, notes), elation_shape='random', random_hits=self._traps, label='天賦・トラップ追撃', rider=True)
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'] or 0)
        self._broadcasting = False
        self._traps = 0

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150103']
        lv = self._levels(me)['Ultra']
        notes, flat, coef = (p(s, lv, i) for i in (1, 2, 3))
        battle.gain_shared(NOTES, notes)
        a4 = self._traces().get('1501102')
        if a4:
            values = a4['params'][0]
            idx = min(max(len(elation_members(battle)), 1), 3) - 1
            battle.gain_shared(NOTES, values[idx])
            battle.gain_counter(me, SHOCK, values[3 + idx])
        if me.eidolon >= 4:
            extra_notes, rate, turns = self._rank(4)
            battle.gain_shared(NOTES, extra_notes)
            battle.apply_effect(me, Effect(key=KEY_E4_RATE, label='星魂4・愉悦度', stats=StatSheet.of(elation_rate=rate), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        mult = coef * me.stats[StatKey.ELATION_RATE] + flat
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        reward = reward_total(me)
        if reward > 0:
            t = self._skills()['150104']
            battle.attack(me, ELEMENT, DamageType.ELATION, elation=(p(t, self._levels(me)['Talent'], 2), reward), elation_shape='aoe', label='天賦・必殺技の愉悦ダメージ', rider=True)
        battle.gain_energy(me, s['energy'] or 0)

    def elation_skill(self, me, battle, notes: float) -> None:
        s = self._skills()['150120']
        lv = self._levels(me).get('ElationDamage', 10)
        per_hit, aoe, hits, shock = (p(s, lv, i) for i in (1, 2, 3, 4))
        if me.eidolon >= 6:
            step, cap = (self._rank(6)[0], self._rank(6)[1])
            hits = min(hits + notes // step, cap)
        boost = battle.aha.skill_multiplier
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(aoe, notes), elation_shape='aoe', independent=boost, toughness=s.get('toughness'), label=s['name'])
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(per_hit, notes), elation_shape='random', random_hits=int(hits), independent=boost, toughness=s.get('toughness'), label=s['name'] + '（追加ヒット）')
        battle.gain_counter(me, SHOCK, shock)

    def technique(self, me, battle) -> None:
        s = self._skills()['150107']
        sp, mult = (params_at(s, 1)[0], params_at(s, 1)[1])
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(int(sp))
