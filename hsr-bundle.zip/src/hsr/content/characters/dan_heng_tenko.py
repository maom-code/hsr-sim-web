from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
from .sparkle import SKILL_PRIORITY
CHAR_ID = '1414'
ELEMENT = Element.PHYSICAL
KEY_COMRADE = 'danheng_t.comrade'
KEY_A2_ATK = 'danheng_t.trace.comrade_atk'
KEY_E1_PEN = 'danheng_t.e1.res_pen'
KEY_E6_VULN = 'danheng_t.e6.vuln'
KEY_E6_DEF = 'danheng_t.e6.def_ignore'

@register(CHAR_ID)
class DanHengTenko:
    target_override_label = '同袍の対象'
    target_override_priority = SKILL_PRIORITY
    unimplemented = ('バリアの耐久値で被ダメージを吸収する処理（敵が攻撃しない前提。付与の記録だけ持つ）', '龍霊のデバフ解除（敵がデバフを撒かない）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        self._comrade = None
        self._dragon: Countdown | None = None
        self._enhanced = 0
        a4 = self._traces().get('1414102')
        if a4:
            battle.advance_forward(me, a4['params'][0][0])

            def on_attack(source=None, rider=False, **kw):
                if rider or source is None or source is not self._comrade:
                    return
                battle.gain_energy(me, a4['params'][0][1], apply_regen=False)
                if self._dragon is not None:
                    battle.advance_forward(self._dragon, a4['params'][0][2])
            battle.bus.subscribe(Event.ON_ATTACK_START, on_attack, owner_id=me.id)

    def _skill_cap(self, me) -> float:
        s = self._skills()['141402']
        lv = self._levels(me)['BPSkill']
        return (me.stats[StatKey.ATK] * p(s, lv, 1) + p(s, lv, 2)) * p(s, lv, 4)

    def _shield_team(self, me, battle, ratio: float, flat: float, turns: int, scale: float=1.0) -> None:
        amount = (me.stats[StatKey.ATK] * ratio + flat) * scale
        cap = self._skill_cap(me)
        for who in battle.team:
            battle.apply_shield(me, who, amount, turns=turns, cap=cap)

    def _make_comrade(self, me, battle, target) -> None:
        prev = self._comrade
        if prev is not None and prev is not target:
            for key in (KEY_COMRADE, KEY_A2_ATK, KEY_E6_DEF):
                battle.remove_effect(prev, key)
        self._comrade = target
        battle.apply_effect(target, Effect(key=KEY_COMRADE, label='同袍', source_id=me.id))
        a2 = self._traces().get('1414101')
        if a2:
            battle.apply_effect(target, Effect(key=KEY_A2_ATK, label='偉観・攻撃力', stats=StatSheet.of(atk=me.stats[StatKey.ATK] * a2['params'][0][0]), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 6:
            e6 = self._rank(6)
            battle.apply_effect(target, Effect(key=KEY_E6_DEF, label='星魂6・防御無視', stats=StatSheet.of(def_ignore=e6[2]), source_id=me.id))
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_E6_VULN, label='星魂6・被ダメージ', stats=StatSheet.of(vulnerability=e6[0]), source_id=me.id))
        if self._dragon is None:
            t = params_at(self._skills()['141404'], self._levels(me)['Talent'])
            self._dragon = battle.add_countdown(Countdown(name='龍霊', spd=t[4], on_turn=lambda: self._dragon_turn(me, battle)), order=me.position)

    def _dragon_turn(self, me, battle) -> None:
        t = params_at(self._skills()['141404'], self._levels(me)['Talent'])
        scale = 2.0 if self._enhanced > 0 and me.eidolon >= 2 else 1.0
        self._shield_team(me, battle, t[0], t[1], int(t[2]), scale)
        a6 = self._traces().get('1414103')
        if a6:
            extra_amount = (me.stats[StatKey.ATK] * a6['params'][0][1] + a6['params'][0][2]) * scale
            lowest = min(battle.team, key=lambda c: sum((e.value for e in c.effects if e.key.startswith('shield.'))))
            battle.apply_shield(me, lowest, extra_amount, turns=int(a6['params'][0][3]), cap=self._skill_cap(me))
        if self._enhanced <= 0 or self._comrade is None:
            return
        self._enhanced -= 1
        u = self._skills()['141403']
        lv = self._levels(me)['Ultra']
        comrade = self._comrade
        ind = self._rank(2)[2] if me.eidolon >= 2 else 1.0
        with battle.attack_action(me):
            battle.attack(me, ELEMENT, DamageType.FOLLOWUP, aoe=((StatKey.ATK, p(u, lv, 2)),), label='龍霊・追加攻撃')
        total = 0.0
        for e in battle.alive_enemies:
            total += battle.deal_damage(comrade, e, comrade.element, DamageType.ADDITIONAL, ((StatKey.ATK, p(u, lv, 8)),), independent=ind)
        if total:
            battle._log(comrade.name, '龍霊・同袍の付加ダメージ', total)
        if a6 and battle.alive_enemies:
            top = max(battle.alive_enemies, key=lambda e: e.hp)
            dealt = battle.deal_damage(comrade, top, comrade.element, DamageType.ADDITIONAL, ((StatKey.ATK, a6['params'][0][0]),), independent=ind)
            if dealt:
                battle._log(comrade.name, '屹立・付加ダメージ', dealt)

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self._comrade is None else Action.BASIC
    rotation_label = '同袍がいなければスキル'

    def basic(self, me, battle) -> None:
        s = self._skills()['141401']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['141402']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        self._cast_skill(me, battle)
        battle.gain_energy(me, s['energy'])

    def _cast_skill(self, me, battle) -> None:
        s = self._skills()['141402']
        lv = self._levels(me)['BPSkill']
        target = battle.resolve_target_override(me, self.target_override_priority) or me
        battle.target_ally(me, target)
        self._make_comrade(me, battle, target)
        self._shield_team(me, battle, p(s, lv, 1), p(s, lv, 2), int(p(s, lv, 3)))

    def ultimate(self, me, battle) -> None:
        s = self._skills()['141403']
        lv = self._levels(me)['Ultra']
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        self._shield_team(me, battle, p(s, lv, 4), p(s, lv, 5), int(p(s, lv, 6)))
        self._enhanced = int(p(s, lv, 3)) + (int(self._rank(2)[0]) if me.eidolon >= 2 else 0)
        comrade = self._comrade
        if me.eidolon >= 1:
            battle.gain_sp(1, actor=me)
            if comrade is not None:
                e1 = self._rank(1)
                battle.apply_effect(comrade, Effect(key=KEY_E1_PEN, label='星魂1・耐性貫通', stats=StatSheet.of(res_pen=e1[1]), duration=Duration(turns=int(e1[2])), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 2 and self._dragon is not None:
            battle.advance_forward(self._dragon, 1.0)
        if me.eidolon >= 6 and comrade is not None:
            total = 0.0
            for e in battle.alive_enemies:
                total += battle.deal_damage(comrade, e, comrade.element, DamageType.ADDITIONAL, ((StatKey.ATK, self._rank(6)[1]),))
            if total:
                battle._log(comrade.name, '星魂6・付加ダメージ', total)
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        self._cast_skill(me, battle)
