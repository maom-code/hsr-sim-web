from __future__ import annotations
from ...data import loader
from ...engine import break_effects
from ...engine import damage as dmg
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1225'
ELEMENT = Element.FIRE
TARGET_PRIORITY = ('1310', '1317', '1315', '1321')
KEY_TALENT = 'fugue.talent.super_break'
KEY_SCORCH = 'fugue.scorch'
KEY_FOXIAN = 'fugue.foxian_prayer'
KEY_DEF_DOWN = 'fugue.def_down'
KEY_A4 = 'fugue.trace.be'
KEY_A6 = 'fugue.trace.team_be'

@register(CHAR_ID)
class Fugue:
    target_override_label = '戦闘スキル（狐の祈り）の対象'
    target_override_priority = TARGET_PRIORITY
    unimplemented = ('狐の祈りの「弱点属性を持たない敵の靭性も本来の 50% 削る」。弱点撃破は全属性弱点で回すので差が出ない', '狐の祈りの防御力ダウンは、その攻撃の後に付ける（1 発目には乗らない）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _skill(self, me) -> list[float]:
        return params_at(self._skills()['122502'], self._levels(me)['BPSkill'])

    def on_battle_start(self, me, battle) -> None:
        self._me = me
        self._foxian = None
        self._first_skill = True
        self._cloud: dict[str, float] = {}
        t = params_at(self._skills()['122504'], self._levels(me)['Talent'])
        rate, cloud_ratio = t[:2]
        a4 = self._traces().get('1225102')
        stats = StatSheet()
        if a4:
            stats.add(StatKey.BREAK_EFFECT, a4['params'][0][0])
        if me.eidolon >= 6:
            stats.add(StatKey.BREAK_EFFICIENCY, self._rank(6)[0])
        battle.apply_effect(me, Effect(key=KEY_A4, label='塗山の玄設', stats=stats, source_id=me.id))

        def on_start(**kw):
            battle.apply_to_team(lambda who: Effect(key=KEY_TALENT, label='善満ちる所福来たる', stats=StatSheet.of(super_break_rate=rate), source_id=me.id))
            for e in battle.enemies:
                self._cloud[e.id] = e.max_toughness * cloud_ratio

        def on_broken_hit(source=None, target=None, element=None, amount=0.0, **kw):
            left = self._cloud.get(getattr(target, 'id', ''), 0.0)
            if left <= 0 or source is None:
                return
            left = max(0.0, left - amount)
            self._cloud[target.id] = left
            if left > 0:
                return
            base = dmg.break_damage_base(element or ELEMENT, getattr(source, 'level', 80), target.max_toughness)
            dealt = battle.deal_damage(source, target, element or ELEMENT, DamageType.BREAK, (), break_base=base)
            battle._log(getattr(source, 'name', ''), '雲火昭瑞・撃破ダメージ', dealt)

        def on_recover(target=None, **kw):
            if target is not None and target.id in self._cloud:
                self._cloud[target.id] = target.max_toughness * cloud_ratio

        def on_break(target=None, **kw):
            if target is None:
                return
            a2 = self._traces().get('1225101')
            if a2:
                battle.delay_action(target, a2['params'][0][0])
            a6 = self._traces().get('1225103')
            if a6:
                base_be, turns, max_stacks, need, extra = a6['params'][0][:5]
                be = base_be + (extra if me.stats[StatKey.BREAK_EFFECT] >= need else 0.0)
                battle.apply_to_team(lambda who: Effect(key=KEY_A6, label='璣星の太素', stats=StatSheet.of(break_effect=be), duration=Duration(turns=int(turns)), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id), exclude=me)
            if me.eidolon >= 2:
                battle.gain_energy(me, self._rank(2)[0], apply_regen=False)

        def on_attack(source=None, targets=None, rider=False, **kw):
            owner = getattr(source, 'attributed_to', source)
            if rider or owner is None or (not owner.effects.has(KEY_FOXIAN)):
                return
            s = self._skill(me)
            for e in targets or []:
                battle.apply_effect(e, Effect(key=KEY_DEF_DOWN, label='狐の祈り・防御力ダウン', stats=StatSheet.of(def_down=s[3]), duration=Duration(turns=int(s[4])), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))

        def on_expired(holder=None, effect=None, **kw):
            if holder is me and effect is not None and (effect.key == KEY_SCORCH):
                self._clear_foxian(me, battle)
        battle.bus.subscribe(Event.BATTLE_START, on_start, owner_id=me.id)
        battle.bus.subscribe(Event.ON_BROKEN_TOUGHNESS, on_broken_hit, owner_id=me.id)
        battle.bus.subscribe(Event.ON_BREAK_RECOVER, on_recover, owner_id=me.id)
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        battle.bus.subscribe(Event.ON_EFFECT_EXPIRED, on_expired, owner_id=me.id)

    def _foxian_effect(self, me) -> Effect:
        s = self._skill(me)
        stats = StatSheet.of(break_effect=s[1])
        if me.eidolon >= 1:
            stats.add(StatKey.BREAK_EFFICIENCY, self._rank(1)[0])
        if me.eidolon >= 4:
            stats.add(StatKey.BREAK_DMG_PCT, self._rank(4)[0])
        return Effect(key=KEY_FOXIAN, label='狐の祈り', stats=stats, source_id=me.id)

    def _clear_foxian(self, me, battle) -> None:
        for c in battle.team:
            battle.remove_effect(c, KEY_FOXIAN)
        self._foxian = None

    def basic(self, me, battle) -> None:
        if me.effects.has(KEY_SCORCH):
            s = self._skills()['122508']
            lv = self._levels(me)['Normal']
            battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), adjacent=((StatKey.ATK, p(s, lv, 2)),), toughness=s.get('toughness'), label=s['name'])
        else:
            s = self._skills()['122501']
            lv = self._levels(me)['Normal']
            battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if not me.effects.has(KEY_SCORCH) else Action.BASIC
    rotation_label = '灼熱が切れていればスキル'

    def skill(self, me, battle) -> None:
        s = self._skills()['122502']
        turns = int(self._skill(me)[0])
        battle.spend_sp(battle.skill_cost(me), actor=me)
        target = battle.resolve_target_override(me, self.target_override_priority)
        self._clear_foxian(me, battle)
        holders = list(battle.team) if me.eidolon >= 6 else [target] if target is not None else []
        for c in holders:
            battle.apply_effect(c, self._foxian_effect(me))
        self._foxian = target
        battle.apply_effect(me, Effect(key=KEY_SCORCH, label='灼熱', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        a4 = self._traces().get('1225102')
        if a4 and self._first_skill:
            battle.gain_sp(int(a4['params'][0][1]), actor=me)
        self._first_skill = False
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['122503']
        lv = self._levels(me)['Ultra']
        battle.apply_effect(me, Effect(key=break_effects.IGNORE_WEAKNESS_KEY, label='弱点無視', source_id=me.id))
        try:
            battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        finally:
            battle.remove_effect(me, break_effects.IGNORE_WEAKNESS_KEY)
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 2:
            for c in battle.team:
                battle.advance_forward(c, self._rank(2)[1])

    def technique(self, me, battle) -> None:
        tech = self._skills()['122507']
        _, _, turns, adv = params_at(tech, 1)[:4]
        s = self._skill(me)
        for e in battle.enemies:
            battle.apply_effect(e, Effect(key=KEY_DEF_DOWN, label='狐の祈り・防御力ダウン', stats=StatSheet.of(def_down=s[3]), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.advance_forward(me, adv)
