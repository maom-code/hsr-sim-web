from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1222'
ELEMENT = Element.FIRE
FUYUAN = '浮元'
KEY_BEFOG = 'lingsha.befog'
KEY_A2 = 'lingsha.trace.atk_heal'
KEY_E1_DEF = 'lingsha.e1.def_down'
KEY_E2_BE = 'lingsha.e2.be'
KEY_E6_RES = 'lingsha.e6.res'

@register(CHAR_ID)
class Lingsha:
    unimplemented = ('浮元のデバフ解除。デバフを撃つ敵を実装していない', '浮元の単体攻撃の「炎弱点で靭性が残っている敵を優先」。ランダム対象は均等按分', '浮元の単体攻撃（75%）の削靭値。データに全体ぶん（30）しか無いので、単体ぶんは削らない')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['122204'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._timer: Countdown | None = None
        self._charges = 0
        self._a6_ready_turn = -1
        self._refresh_a2(me, battle)
        if me.eidolon >= 1:
            battle.apply_effect(me, Effect(key='lingsha.e1.eff', label='星魂1・弱点撃破効率', stats=StatSheet.of(break_efficiency=self._rank(1)[1]), source_id=me.id))

            def on_break(target=None, **kw):
                if target is not None:
                    battle.apply_effect(target, Effect(key=KEY_E1_DEF, label='星魂1・防御力ダウン', stats=StatSheet.of(def_down=self._rank(1)[0]), debuff=True, source_id=me.id))

            def on_recover(target=None, **kw):
                if target is not None:
                    battle.remove_effect(target, KEY_E1_DEF)
            battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)
            battle.bus.subscribe(Event.ON_BREAK_RECOVER, on_recover, owner_id=me.id)

        def on_hurt(target=None, **kw):
            a6 = self._traces().get('1222103')
            if not a6 or self._timer is None or target not in battle.team:
                return
            threshold, cooldown = a6['params'][0][:2]
            if battle._turn_no < self._a6_ready_turn:
                return
            if not any((c.hp <= c.max_hp * threshold for c in battle.team)):
                return
            self._a6_ready_turn = battle._turn_no + int(cooldown) + 1
            battle._log(FUYUAN, '余香・追加攻撃')
            with battle.attack_action(me):
                self._fuyuan_attack(me, battle)
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hurt, owner_id=me.id)
        battle.bus.subscribe(Event.ON_HP_LOSS, on_hurt, owner_id=me.id)

    def on_turn_start(self, me, battle) -> None:
        self._refresh_a2(me, battle)

    def _refresh_a2(self, me, battle) -> None:
        a2 = self._traces().get('1222101')
        if not a2:
            return
        atk_r, heal_r, atk_cap, heal_cap = a2['params'][0][:4]
        battle.remove_effect(me, KEY_A2)
        be = me.stats[StatKey.BREAK_EFFECT]
        battle.apply_effect(me, Effect(key=KEY_A2, label='朱炎', stats=StatSheet.of(atk_pct=min(atk_cap, be * atk_r), heal_boost=min(heal_cap, be * heal_r)), source_id=me.id))

    def _heal_team(self, me, battle, ratio: float, flat: float, label: str) -> None:
        amount = me.stats[StatKey.ATK] * ratio + flat
        for c in battle.team:
            battle.heal(me, c, amount, label=label)

    def _summon(self, me, battle, charges: int) -> None:
        t = self._talent(me)
        cap = int(t[4])
        if self._timer is None:
            self._charges = min(cap, charges)
            self._timer = battle.add_countdown(Countdown(name=FUYUAN, spd=t[0], on_turn=lambda: self._fuyuan_turn(me, battle)), order=me.position)
            if me.eidolon >= 6:
                for e in battle.enemies:
                    battle.apply_effect(e, Effect(key=KEY_E6_RES, label='星魂6・全属性耐性ダウン', stats=StatSheet.of(res_down=self._rank(6)[0]), debuff=True, source_id=me.id))
        else:
            self._charges = min(cap, self._charges + charges)
        battle._log(FUYUAN, f'行動可能回数 {self._charges}')

    def _dismiss(self, me, battle) -> None:
        if self._timer is not None:
            battle.remove_countdown(self._timer)
            self._timer = None
        for e in battle.enemies:
            battle.remove_effect(e, KEY_E6_RES)

    def _fuyuan_attack(self, me, battle) -> None:
        s = self._skills()['122204']
        t = self._talent(me)
        battle.attack(me, ELEMENT, DamageType.FOLLOWUP, aoe=((StatKey.ATK, t[1]),), toughness=s.get('toughness'), label=f'{FUYUAN}・全体')
        battle.attack(me, ELEMENT, DamageType.FOLLOWUP, random=((StatKey.ATK, t[7]),), random_hits=1, label=f'{FUYUAN}・単体')
        if me.eidolon >= 6:
            _, hits, mult, tough = self._rank(6)[:4]
            battle.attack(me, ELEMENT, DamageType.FOLLOWUP, random=((StatKey.ATK, mult),), random_hits=int(hits), toughness={'all': tough * 3}, label=f'{FUYUAN}・星魂6')
        self._heal_team(me, battle, t[2], t[3], FUYUAN)
        if me.eidolon >= 4:
            low = min(battle.team, key=lambda c: c.hp / c.max_hp, default=None)
            if low is not None:
                battle.heal(me, low, me.stats[StatKey.ATK] * self._rank(4)[0], label='星魂4')

    def _fuyuan_turn(self, me, battle) -> None:
        if self._timer is None:
            return
        battle._log(FUYUAN, '行動')
        with battle.attack_action(me):
            self._fuyuan_attack(me, battle)
        self._charges -= 1
        if self._charges <= 0:
            self._dismiss(me, battle)

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self._timer is None or self._charges <= 1 else Action.BASIC
    rotation_label = '浮元が消えそうならスキル'

    def basic(self, me, battle) -> None:
        s = self._skills()['122201']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        energy = s['energy']
        a4 = self._traces().get('1222102')
        if a4:
            energy += a4['params'][0][0]
        battle.gain_energy(me, energy)

    def skill(self, me, battle) -> None:
        s = self._skills()['122202']
        lv = self._levels(me)['BPSkill']
        mult, ratio, flat, adv = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3), p(s, lv, 4))
        battle.spend_sp(battle.skill_cost(me), actor=me)
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        self._heal_team(me, battle, ratio, flat, s['name'])
        had = self._timer is not None
        self._summon(me, battle, int(self._talent(me)[6]))
        if had and self._timer is not None:
            battle.advance_forward(self._timer, adv)
        battle.gain_energy(me, s['energy'])

    def _befog(self, me, battle, up: float, turns: int) -> None:
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_BEFOG, label='芳酔', stats=StatSheet.of(break_taken=up), duration=Duration(turns=turns), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))

    def ultimate(self, me, battle) -> None:
        s = self._skills()['122203']
        lv = self._levels(me)['Ultra']
        mult, ratio, flat, up, turns, adv = (p(s, lv, i) for i in range(1, 7))
        self._befog(me, battle, up, int(turns))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        self._heal_team(me, battle, ratio, flat, s['name'])
        if self._timer is not None:
            battle.advance_forward(self._timer, adv)
        if me.eidolon >= 2:
            be, e2_turns = self._rank(2)[:2]
            battle.apply_to_team(lambda who: Effect(key=KEY_E2_BE, label='星魂2・撃破特効', stats=StatSheet.of(break_effect=be), duration=Duration(turns=int(e2_turns)), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['122207']
        turns = int(params_at(tech, 1)[0])
        u = params_at(self._skills()['122203'], self._levels(me)['Ultra'])
        self._summon(me, battle, int(self._talent(me)[6]))
        self._befog(me, battle, u[3], turns)
