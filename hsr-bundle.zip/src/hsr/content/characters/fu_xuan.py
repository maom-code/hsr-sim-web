from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1208'
ELEMENT = Element.QUANTUM
KEY_MATRIX = 'fuxuan.matrix'
KEY_KNOWLEDGE = 'fuxuan.knowledge'
KEY_MISFORTUNE = 'fuxuan.talent.dmg_red'

@register(CHAR_ID)
class FuXuan:
    unimplemented = ('戦闘スキルのダメージ分担（65%）', '天賦の HP 回復（HP 50% 以下で失った HP の 90%）', '軌跡「六壬神課」（行動制限系デバフへの抵抗）', '星魂 2（戦闘不能にならず HP 70% 回復）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        self._lost = 0.0
        t = params_at(self._skills()['120804'], self._levels(me)['Talent'])
        battle.apply_aura(me, lambda who: Effect(key=KEY_MISFORTUNE, label='避邪', stats=StatSheet.of(dmg_reduction=t[0]), source_id=me.id))

        def on_hp_loss(target=None, amount=0.0, **kw):
            if me.eidolon >= 6 and me.effects.has(KEY_MATRIX):
                cap = me.max_hp * self._rank(6)[1]
                self._lost = min(cap, self._lost + amount)

        def on_hit(target=None, **kw):
            if me.eidolon >= 4 and target is not me and me.effects.has(KEY_MATRIX):
                battle.gain_energy(me, self._rank(4)[0], apply_regen=False)
        battle.bus.subscribe(Event.ON_HP_LOSS, on_hp_loss, owner_id=me.id)
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hit, owner_id=me.id)

    def _matrix(self, me, battle, turns: int) -> None:
        s = self._skills()['120802']
        lv = self._levels(me)['BPSkill']
        hp_share, cr = (p(s, lv, 4), p(s, lv, 5))
        stats = StatSheet.of(hp=me.max_hp * hp_share, crit_rate=cr)
        if me.eidolon >= 1:
            stats.add(StatKey.CRIT_DMG, self._rank(1)[0])
        battle.apply_effect(me, Effect(key=KEY_MATRIX, label='窮観の陣', duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, lambda who: Effect(key=KEY_KNOWLEDGE, label='鑑知', stats=stats, duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_MATRIX)
    rotation_label = '陣が無い・残り 1 ターン以下なら戦闘スキル、あとは通常攻撃'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        m = me.effects.get(KEY_MATRIX)
        if m is None or m.duration is None or m.duration.turns <= 1:
            return Action.SKILL
        return Action.BASIC

    def basic(self, me, battle) -> None:
        s = self._skills()['120801']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['120802']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        active = me.effects.has(KEY_MATRIX)
        battle.target_team(me)
        self._matrix(me, battle, int(p(s, lv, 3)))
        battle.gain_energy(me, s['energy'])
        a2 = self._traces().get('1208101')
        if a2 and active:
            battle.gain_energy(me, a2['params'][0][0], apply_regen=False)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['120803']
        lv = self._levels(me)['Ultra']
        flat = self._lost * self._rank(6)[0] if me.eidolon >= 6 else 0.0
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.HP, p(s, lv, 1)),), flat_aoe=flat, toughness=s.get('toughness'), label=s['name'])
        self._lost = 0.0
        a4 = self._traces().get('1208102')
        if a4:
            ratio, base = a4['params'][0][:2]
            for c in battle.team:
                if c is not me:
                    battle.heal(me, c, me.max_hp * ratio + base, label='奇門遁甲')
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = params_at(self._skills()['120807'], 1)
        self._matrix(me, battle, int(tech[1]))
