from __future__ import annotations
from ...data import loader
from ...engine.effects import Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
KEY_FIGHT = 'tb_destruction.trace.fight'
KEY_TALENT_ATK = 'tb_destruction.talent.atk'
KEY_TRACE_DEF = 'tb_destruction.trace.tough'
KEY_E4_CRIT = 'tb_destruction.e4.crit'

class _TrailblazerDestruction:
    unimplemented = ('星魂 1「必殺技で敵を倒した時に EP+10」・星魂 6「敵を倒した時も天賦が発動」。このシミュは敵を倒さない', '星魂 2（攻撃後に攻撃力 5% 分の HP 回復）。回復だけでダメージには効かない')

    def _trace_fight(self, me):
        trace = loader.character(me.id)['traces']['abilities'].get(f'{me.id}103')
        return trace['params'][0][0] if trace else None

    def _skills(self, me) -> dict:
        return loader.character(me.id)['skills']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, me.id)

    def on_battle_start(self, me, battle) -> None:
        traces = loader.character(me.id)['traces']['abilities']
        trace = traces.get(f'{me.id}101')
        if trace:
            battle.gain_energy(me, trace['params'][0][0], apply_regen=False)
        talent = self._skills(me)[f'{me.id}04']
        atk_up, max_stacks = (p(talent, self._levels(me)['Talent'], 1), p(talent, self._levels(me)['Talent'], 2))
        tough_trace = traces.get(f'{me.id}102')
        def_up = tough_trace['params'][0][0] if tough_trace else 0.0

        def on_break(**kw):
            eff = battle.apply_effect(me, Effect(key=KEY_TALENT_ATK, label='天賦・攻撃力', stats=StatSheet.of(atk_pct=atk_up), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id))
            if def_up and eff is not None:
                battle.apply_effect(me, Effect(key=KEY_TRACE_DEF, label='軌跡・堅靭', stats=StatSheet.of(def_pct=def_up * eff.stacks), source_id=me.id))
        battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, on_break, owner_id=me.id)
        if me.eidolon >= 4:
            crit_up = self._char_ranks(me)['4']['params'][0]

            def refresh_e4(**kw):
                if any((e.is_broken for e in battle.alive_enemies)):
                    battle.apply_effect(me, Effect(key=KEY_E4_CRIT, label='星魂4・会心率', stats=StatSheet.of(crit_rate=crit_up), source_id=me.id))
                else:
                    battle.remove_effect(me, KEY_E4_CRIT)
            battle.bus.subscribe(Event.ON_WEAKNESS_BREAK, refresh_e4, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_START, refresh_e4, owner_id=me.id)

    def _char_ranks(self, me) -> dict:
        return loader.character(me.id)['ranks']

    def technique(self, me, battle) -> None:
        s = self._skills(me)[f'{me.id}07']
        ratio = params_at(s, 1)[0]
        for ally in battle.team:
            battle.heal(me, ally, ally.stats[StatKey.HP] * ratio, label='秘技')

    def basic(self, me, battle) -> None:
        s = self._skills(me)[f'{me.id}01']
        battle.attack(me, Element.PHYSICAL, DamageType.BASIC, main=((StatKey.ATK, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills(me)[f'{me.id}02']
        battle.spend_sp(s['sp_cost'])
        mult = p(s, self._levels(me)['BPSkill'], 1)
        self._attack_with_fight(me, battle, DamageType.SKILL, mult, mult, s['name'], tough=s.get('toughness'))
        battle.gain_energy(me, s['energy'])

    def _attack_with_fight(self, me, battle, dmg_type, main_mult, adj_mult, label, target=None, tough: dict | None=None) -> None:
        up = self._trace_fight(me)
        focus = target or (battle.alive_enemies[0] if battle.alive_enemies else None)
        if focus is None:
            return
        if up:
            battle.apply_effect(me, Effect(key=KEY_FIGHT, label='軌跡・闘志', stats=StatSheet.of(dmg_pct=up), source_id=me.id))
        battle.attack(me, Element.PHYSICAL, dmg_type, main=((StatKey.ATK, main_mult),), target=focus, toughness={'main': tough.get('main', 0.0)} if tough else None, label=label)
        if up:
            battle.remove_effect(me, KEY_FIGHT)
        if adj_mult and battle.adjacent_to(focus):
            battle.attack(me, Element.PHYSICAL, dmg_type, adjacent=((StatKey.ATK, adj_mult),), target=focus, toughness={'adjacent': tough.get('adjacent', 0.0)} if tough else None, label=label)

    def ultimate(self, me, battle) -> None:
        lv = self._levels(me)['Ultra']
        single = self._skills(me)[f'{me.id}08']
        blast = self._skills(me)[f'{me.id}09']
        alive = battle.alive_enemies
        if not alive:
            return
        focus = max(alive, key=lambda e: len(battle.adjacent_to(e)))
        blast_total = p(blast, lv, 1) + p(blast, lv, 2) * len(battle.adjacent_to(focus))
        if blast_total > p(single, lv, 1):
            self._attack_with_fight(me, battle, DamageType.ULTIMATE, p(blast, lv, 1), p(blast, lv, 2), blast['name'], target=focus, tough=blast.get('toughness'))
            s = blast
        else:
            battle.attack(me, Element.PHYSICAL, DamageType.ULTIMATE, main=((StatKey.ATK, p(single, lv, 1)),), toughness=single.get('toughness'), label=single['name'])
            s = single
        battle.gain_energy(me, s['energy'])

@register('8001')
class TrailblazerDestructionF(_TrailblazerDestruction):
    pass

@register('8002')
class TrailblazerDestructionM(_TrailblazerDestruction):
    pass
