from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.memosprite import Memosprite, MemospriteSpec
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1512'
ELEMENT = Element.WIND
MOOD = 'ムード'
GROOVE = 'グルーヴ'
BIRDS = ('ベーシー', 'ドラミー', 'パディー')
MEMBERS = '夏空フライトのメンバー'
GUEST_PRIORITY = ('1413',)
KEY_GUEST = 'robin.ult.special_guest'
KEY_FEVER_DMG = 'robin.memo.fever_dmg'
KEY_FEVER_VULN = 'robin.memo.fever_vuln'
KEY_FEVER_ZONE = 'robin.talent.zone'
KEY_TRACE_ATK = 'robin.trace.atk'
KEY_TRACE_CD = 'robin.trace.crit_dmg'
KEY_TRACE_CRIT = 'robin.trace.crit_rate'
KEY_E2_RESPEN = 'robin.e2.res_pen'
RECORD = 'ダメージ記録値'

@register(CHAR_ID)
class SummerRobin:
    self_crit_rate_buff = 0.5
    speed_target = 160.0
    target_override_label = '必殺技の対象'
    target_override_priority = GUEST_PRIORITY
    unimplemented = ('軌跡「アドリブのブルース」の「バリアの付与を受けた時」。バリアを張るキャラを実装していないので発動条件を作れない', '天賦のムード獲得のうち「初めてバリアを付与する時」。同上')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _memo_skills(self) -> dict:
        return self._char()['memosprite']['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _mood(self, me, battle) -> float:
        return battle.counter_value(me, MOOD)

    def on_battle_start(self, me, battle) -> None:
        self._fever = False
        self._timer: Countdown | None = None
        self._heal_this_turn = False
        self._mood_this_turn = False
        self._skill_mood_this_turn = False
        talent = self._skills()['151204']
        lv = self._levels(me)['Talent']
        cap = p(talent, lv, 5)
        if me.eidolon >= 2:
            cap += self._char()['ranks']['2']['params'][0]
        me.counter(MOOD, maximum=cap)
        a6 = self._traces().get('1512103')
        if a6:
            battle.apply_effect(me, Effect(key=KEY_TRACE_CRIT, label='軌跡・会心率', stats=StatSheet.of(crit_rate=a6['params'][0][0]), source_id=me.id))
        if me.eidolon >= 2:
            res_pen = self._char()['ranks']['2']['params'][2]
            battle.apply_to_team(lambda who: Effect(key=KEY_E2_RESPEN, label='星魂2・耐性貫通', stats=StatSheet.of(res_pen=res_pen), source_id=me.id))
        record_ratio = self._char()['ranks']['1']['params'][2] if me.eidolon >= 1 else 0.0

        def on_ally_attack(source=None, amount: float=0.0, dmg_type=None, **kw):
            if source is None:
                return
            if record_ratio and amount > 0 and (dmg_type is not DamageType.TRUE):
                battle.gain_counter(me, RECORD, amount * record_ratio)
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)

        def on_ally_attack_start(source=None, **kw):
            if source is None:
                return
            owner = getattr(source, 'attributed_to', source)
            self._gain_mood(me, battle, 1.0, actor=source)
            if owner.effects.has(KEY_GUEST):
                extra = p(self._skills()['151203'], self._levels(me)['Ultra'], 2)
                self._gain_mood(me, battle, extra, actor=source)
        battle.bus.subscribe(Event.ON_ATTACK_START, on_ally_attack_start, owner_id=me.id)

        def on_heal(healer=None, target=None, **kw):
            if healer is None or self._heal_this_turn:
                return
            self._heal_this_turn = True
            owner = getattr(healer, 'attributed_to', healer)
            self._gain_mood(me, battle, 1.0, actor=owner)
            if target is not None and healer is not me:
                owner_t = getattr(target, 'attributed_to', target)
                if owner_t is me:
                    self._gain_groove(me, battle)
        battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=me.id)

        def on_skill(source_id=None, **kw):
            if me.eidolon < 2 or self._skill_mood_this_turn:
                return
            self._skill_mood_this_turn = True
            self._gain_mood(me, battle, self._char()['ranks']['2']['params'][1], actor=None)
        battle.bus.subscribe(Event.ON_SKILL_USED, on_skill, owner_id=me.id)

        def reset(**kw):
            self._heal_this_turn = False
            self._mood_this_turn = False
            self._skill_mood_this_turn = False
        battle.bus.subscribe(Event.TURN_START, reset, owner_id=me.id)

    def _gain_mood(self, me, battle, amount: float, *, actor=None) -> None:
        gained = battle.gain_counter(me, MOOD, amount)
        if gained <= 0:
            return
        if not self._mood_this_turn:
            self._mood_this_turn = True
            trace = self._traces().get('1512102')
            if trace and battle.counter_value(me, GROOVE) >= 1:
                battle.spend_counter(me, GROOVE, 1)
                battle.gain_energy(me, trace['params'][0][1], apply_regen=False)
        if actor is not None and actor is not me and (getattr(actor, 'summoner', None) is not me):
            self._trace_buff(me, battle, actor)
        self._check_flock(me, battle)
        self._refresh_fever_numbers(me, battle)

    def _gain_groove(self, me, battle) -> None:
        trace = self._traces().get('1512102')
        if not trace:
            return
        gain, _energy, cap = trace['params'][0]
        battle.gain_counter(me, GROOVE, gain, maximum=cap)

    def _trace_buff(self, me, battle, ally) -> None:
        trace = self._traces().get('1512101')
        if trace is None:
            return
        atk_base, atk_per, cd_base, cd_per, turns = trace['params'][0]
        mood = self._mood(me, battle)
        if ally.stats[StatKey.ATK] > me.stats[StatKey.ATK]:
            battle.apply_effect(ally, Effect(key=KEY_TRACE_ATK, label='軌跡・攻撃力', stats=StatSheet.of(atk=me.stats[StatKey.HP] * (atk_base + mood * atk_per)), duration=Duration(turns=int(turns), tick_owner_id=ally.id), stacking=Stacking.REFRESH, source_id=me.id))
        else:
            battle.apply_effect(ally, Effect(key=KEY_TRACE_CD, label='軌跡・会心ダメージ', stats=StatSheet.of(crit_dmg=cd_base + mood * cd_per), duration=Duration(turns=int(turns), tick_owner_id=ally.id), stacking=Stacking.REFRESH, source_id=me.id))

    def skips_turn(self, me, battle) -> bool:
        return self._fever

    def _bird_spec(self, me) -> MemospriteSpec:
        s = self._skills()['151204']
        lv = self._levels(me)['Talent']
        return MemospriteSpec(name='夏空フライト', hp_ratio=p(s, lv, 1), hp_from=StatKey.HP, spd_ratio=p(s, lv, 2), spd_from=StatKey.SPD, aggro=self._char()['memosprite']['aggro'])

    def _bird(self, me, battle) -> Memosprite | None:
        return battle.memosprite_of(me)

    def _members(self, me, battle) -> int:
        return int(battle.counter_value(me, MEMBERS))

    def _add_member(self, me, battle) -> None:
        if self._members(me, battle) >= len(BIRDS):
            return
        if self._bird(me, battle) is None:
            battle.summon_memosprite(me, self._bird_spec(me))
        battle.gain_counter(me, MEMBERS, 1, maximum=len(BIRDS))
        energy = p(self._memo_skills()['1151205'], self._levels(me)['ServantTalent'], 1)
        battle.gain_energy(me, energy, apply_regen=False)

    def _check_flock(self, me, battle) -> None:
        if self._members(me, battle) < 1 or self._fever:
            return
        s = self._skills()['151204']
        lv = self._levels(me)['Talent']
        second, third = (p(s, lv, 6), p(s, lv, 7))
        mood = self._mood(me, battle)
        if mood >= second and self._members(me, battle) < 2:
            self._add_member(me, battle)
        if mood >= third and self._members(me, battle) < 3:
            self._add_member(me, battle)
        if self._members(me, battle) >= len(BIRDS):
            self._start_fever(me, battle)

    def _start_fever(self, me, battle) -> None:
        if self._fever:
            return
        self._fever = True
        battle._log(me.name, 'フィーバー開始')
        if me.eidolon >= 4:
            gain, spd_base, spd_per = self._char()['ranks']['4']['params']
            battle.gain_counter(me, MOOD, gain)
            bonus = spd_base + self._mood(me, battle) * spd_per
            bird = self._bird(me, battle)
            if bird is not None:
                battle.apply_effect(bird, Effect(key='robin.e4.speed', label='星魂4・速度', stats=StatSheet.of(spd_pct=bonus), source_id=me.id))
        if me.eidolon >= 6 and hasattr(me.resource, 'set_stock'):
            me.resource.set_stock(2)
        self._eidolon_6_energy(me, battle)
        memo_talent = self._memo_skills()['1151203']
        spd = p(memo_talent, self._levels(me)['ServantTalent'], 9)
        self._timer = battle.add_countdown(Countdown(name='フィーバー', spd=spd, on_turn=lambda: self._countdown_turn(me, battle)), order=me.position)
        self._refresh_fever_numbers(me, battle)

    def _end_fever(self, me, battle) -> None:
        if not self._fever:
            return
        self._fever = False
        bird = self._bird(me, battle)
        if bird is not None:
            bird.hp = 0.0
            battle.dismiss_memosprite(bird)
            forward = p(self._memo_skills()['1151206'], self._levels(me)['ServantTalent'], 1)
            battle.advance_forward(me, forward)
        battle.spend_counter(me, MEMBERS)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
            self._timer = None
        for e in battle.enemies:
            battle.remove_effect(e, KEY_FEVER_VULN)
        battle.remove_effect(me, KEY_FEVER_ZONE)
        for c in battle.team:
            battle.remove_effect(c, KEY_FEVER_ZONE)
        if hasattr(me.resource, 'set_stock'):
            me.resource.set_stock(1)
        battle._log(me.name, 'フィーバー終了')

    def _refresh_fever_numbers(self, me, battle) -> None:
        if not self._fever:
            return
        mood = self._mood(me, battle)
        lv = self._levels(me)['ServantTalent']
        mt = self._memo_skills()['1151203']
        dmg_base, dmg_per = (p(mt, lv, 1), p(mt, lv, 2))
        vulns = [p(mt, lv, i) for i in (3, 4, 5)]
        dmg_up = dmg_base + mood * dmg_per
        bird = self._bird(me, battle)
        for who in (me, bird) if bird is not None else (me,):
            battle.apply_effect(who, Effect(key=KEY_FEVER_DMG, label='フィーバー・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), source_id=me.id))
        count = self._members(me, battle)
        if count:
            vuln = vulns[min(count, len(vulns)) - 1]
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_FEVER_VULN, label='夏空フライト・被ダメージ増加', stats=StatSheet.of(vulnerability=vuln), source_id=me.id))
        s = self._skills()['151204']
        base, per = (p(s, self._levels(me)['Talent'], 8), p(s, self._levels(me)['Talent'], 9))
        ignore = base + mood * per
        battle.apply_aura(me, lambda who: Effect(key=KEY_FEVER_ZONE, label='結界・防御無視', stats=StatSheet.of(def_ignore=ignore), source_id=me.id))

    def _countdown_turn(self, me, battle) -> None:
        mt = self._memo_skills()['1151203']
        lv = self._levels(me)['ServantTalent']
        floor, ratio = (p(mt, lv, 6), p(mt, lv, 10))
        cost = max(self._mood(me, battle) * ratio, floor)
        battle.spend_counter(me, MOOD, cost)
        self._eidolon_6_energy(me, battle)
        if self._mood(me, battle) <= 0:
            self._end_fever(me, battle)
        else:
            self._refresh_fever_numbers(me, battle)

    def _eidolon_6_energy(self, me, battle) -> None:
        if me.eidolon >= 6:
            battle.gain_energy(me, self._char()['ranks']['6']['params'][1], apply_regen=False)

    def can_use_skill(self, me, battle) -> bool:
        return True

    def basic(self, me, battle) -> None:
        s = self._skills()['151201']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['151202']
        lv = self._levels(me)['BPSkill']
        heal_ratio, mood = (p(s, lv, 1), p(s, lv, 2))
        battle.spend_sp(s['sp_cost'])
        bird = self._bird(me, battle)
        if bird is not None:
            bird.heal(bird.max_hp * heal_ratio)
            self._gain_mood(me, battle, mood)
        else:
            self._add_member(me, battle)
            self._check_flock(me, battle)
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['151203']
        lv = self._levels(me)['Ultra']
        forward, _mood, energy_ratio = (p(s, lv, i) for i in (1, 2, 3))
        target = self._guest_target(me, battle)
        if target is None:
            return
        battle.advance_forward(target, forward)
        pool = target.resource
        if hasattr(pool, 'maximum') and getattr(pool, 'current', None) is not None:
            pool.gain(pool.maximum * energy_ratio, apply_regen=False)
        battle.apply_effect(target, Effect(key=KEY_GUEST, label='スペシャルゲスト', duration=Duration(turns=2, tick_owner_id=target.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, s['energy'])

    def _guest_target(self, me, battle):
        return battle.resolve_target_override(me, GUEST_PRIORITY)

    def memo_turn(self, memo, battle) -> None:
        me = memo.summoner
        s = self._memo_skills()['1151201']
        mult = p(s, self._levels(me)['Servant'], 2)
        if me.eidolon >= 6:
            mult *= 1.0 + self._char()['ranks']['6']['params'][0]
        battle.attack(memo, ELEMENT, DamageType.MEMO, aoe=((StatKey.HP, mult),), toughness=s.get('toughness'), label=s['name'])
        self._eidolon_1(me, memo, battle)

    def _eidolon_1(self, me, memo, battle) -> None:
        if me.eidolon < 1:
            return
        base, per_mood, _record, clear = self._char()['ranks']['1']['params']
        pool = battle.counter_value(me, RECORD)
        alive = battle.alive_enemies
        if pool <= 0 or not alive:
            return
        top = max(alive, key=lambda e: e.hp)
        share = base + self._mood(me, battle) * per_mood
        dealt = battle.deal_damage(memo, top, ELEMENT, DamageType.TRUE, (), flat=pool * share)
        if dealt:
            battle._log(memo.name, '星魂1・確定ダメージ', dealt)
        battle.spend_counter(me, RECORD, pool * clear)

    def technique(self, me, battle) -> None:
        mood, dmg_up, forward = params_at(self._skills()['151207'], 1)[:3]
        battle.advance_forward(me, forward)
        battle.apply_to_team(lambda who: Effect(key='robin.technique.dmg', label='秘技・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=2, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        self._gain_mood(me, battle, mood)
