from __future__ import annotations
from ...data import loader
from ...engine.effects import DOT_ARCANA, DOT_KINDS_BASIC, Duration, Effect, Stacking, has_dot_kind
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import RES_PEN_BY_ELEMENT, StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1307'
ELEMENT = Element.WIND
KEY_ARCANA = 'blackswan.arcana'
KEY_SKILL_DEF = 'blackswan.skill.def_down'
KEY_EPIPHANY = 'blackswan.ult.epiphany'
KEY_A6_DMG = 'blackswan.trace.dmg'
KIND_ELEMENT = {'wind_shear': Element.WIND, 'bleed': Element.PHYSICAL, 'burn': Element.FIRE, 'shock': Element.LIGHTNING}

@register(CHAR_ID)
class BlackSwan:
    unimplemented = ('星魂 4 の「開示の敵が倒された時の EP」（敵が倒れない前提）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['130704'], self._levels(me)['Talent'])

    def _ult(self, me) -> list[float]:
        return params_at(self._skills()['130703'], self._levels(me)['Ultra'])

    def _chance(self, me, base: float) -> float:
        return min(1.0, base * (1.0 + me.stats[StatKey.EFFECT_HIT]))

    def _cap(self, me) -> float:
        return self._talent(me)[7] + (self._rank(6)[3] if me.eidolon >= 6 else 0.0)

    def _stacks(self, enemy) -> float:
        eff = enemy.effects.get(KEY_ARCANA)
        return eff.value if eff is not None else 0.0

    def _set_arcana(self, me, battle, enemy, stacks: float) -> None:
        t = self._talent(me)
        if stacks <= 0:
            battle.remove_effect(enemy, KEY_ARCANA)
            return
        base = me.stats[StatKey.ATK] * (t[0] + t[2] * stacks)
        eff = enemy.effects.get(KEY_ARCANA)
        if eff is None:
            battle.apply_effect(enemy, Effect(key=KEY_ARCANA, label=f'アルカナ {stacks:.1f} 層', value=stacks, dot_base=base, dot_element=ELEMENT, dot_kind=DOT_ARCANA, debuff=True, source_id=me.id))
        else:
            eff.value, eff.dot_base, eff.label = (stacks, base, f'アルカナ {stacks:.1f} 層')

    def _add_arcana(self, me, battle, enemy, n: float, *, base_chance: float) -> None:
        if not enemy.alive:
            return
        n *= self._chance(me, base_chance)
        if n <= 0:
            return
        if enemy.effects.has(KEY_EPIPHANY):
            n += self._ult(me)[3]
        if me.eidolon >= 6:
            n += self._rank(6)[2]
        self._set_arcana(me, battle, enemy, self._stacks(enemy) + n)

    def on_battle_start(self, me, battle) -> None:
        t = self._talent(me)
        a6 = self._traces().get('1307103')
        if a6:
            ratio, cap = a6['params'][0][:2]
            up = min(cap, me.stats[StatKey.EFFECT_HIT] * ratio)
            battle.apply_to_team(lambda who: Effect(key=KEY_A6_DMG, label='ロウソクの影が示す予兆', stats=StatSheet.of(dmg_pct=up), source_id=me.id))
        ignore = t[6]

        def on_dot(source=None, target=None, effect=None, detonated=False, **kw):
            if target is None or effect is None:
                return
            if effect.key == KEY_ARCANA and (not detonated):
                for adj in battle.adjacent_to(target):
                    dealt = battle.deal_damage(me, adj, ELEMENT, DamageType.DOT, ((StatKey.ATK, t[4]),))
                    if dealt:
                        battle._log(me.name, 'アルカナ・隣接', dealt)
                    self._add_arcana(me, battle, adj, 1, base_chance=t[1])
            self._add_arcana(me, battle, target, 1, base_chance=t[1])
            if effect.key == KEY_ARCANA:
                stacks = min(self._stacks(target), self._cap(me))
                if not detonated and (not target.effects.has(KEY_EPIPHANY)):
                    stacks /= 2
                self._set_arcana(me, battle, target, stacks)
        battle.bus.subscribe(Event.ON_DOT_DAMAGE, on_dot, owner_id=me.id)

        def bonus(src, tgt):
            if src is not me or not tgt.effects.has(KEY_ARCANA):
                return None
            return StatSheet.of(def_ignore_dot=ignore)
        battle.add_target_bonus(me, bonus)

        def on_attack(source=None, targets=None, rider=False, dmg_type=None, **kw):
            if source is None or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner is me:
                a2 = self._traces().get('1307101')
                if a2:
                    for e in targets or []:
                        self._add_arcana(me, battle, e, a2['params'][0][1], base_chance=a2['params'][0][0])
                if dmg_type in (DamageType.BASIC, DamageType.ULTIMATE) and self._traces().get('1307102'):
                    for e in targets or []:
                        self._def_down(me, battle, e)
            elif owner in battle.team and me.eidolon >= 6:
                for e in targets or []:
                    self._add_arcana(me, battle, e, 1, base_chance=self._rank(6)[1])
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        if me.eidolon >= 1:
            down = self._rank(1)[0]

            def e1(src, tgt):
                pens = {RES_PEN_BY_ELEMENT[el]: down for kind, el in KIND_ELEMENT.items() if has_dot_kind(tgt, kind)}
                return StatSheet(pens) if pens else None
            for c in battle.team:
                battle.add_target_bonus(c, e1)
        if me.eidolon >= 4:

            def on_turn(actor=None, **kw):
                if actor is not None and actor in battle.enemies and actor.effects.has(KEY_EPIPHANY):
                    battle.gain_energy(me, self._rank(4)[1], apply_regen=False)
            battle.bus.subscribe(Event.TURN_START, on_turn, owner_id=me.id)
        a4 = self._traces().get('1307102')
        for e in battle.enemies:
            if a4:
                self._add_arcana(me, battle, e, a4['params'][0][1], base_chance=a4['params'][0][0])
                self._def_down(me, battle, e)
            if me.eidolon >= 2:
                self._add_arcana(me, battle, e, self._rank(2)[1], base_chance=self._rank(2)[0])

    def _def_down(self, me, battle, enemy) -> None:
        s = self._skills()['130702']
        lv = self._levels(me)['BPSkill']
        battle.apply_effect(enemy, Effect(key=KEY_SKILL_DEF, label='失墜・防御力ダウン', stats=StatSheet.of(def_down=p(s, lv, 4)), duration=Duration(turns=int(p(s, lv, 2))), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))

    def basic(self, me, battle) -> None:
        s = self._skills()['130701']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['130702']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        focus = battle.target
        if focus is not None:
            for e in [focus, *battle.adjacent_to(focus)]:
                self._def_down(me, battle, e)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, p(s, lv, 1)),), adjacent=((StatKey.ATK, p(s, lv, 1)),), target=focus, toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['130703']
        u = self._ult(me)
        vuln = u[2] + (self._rank(4)[0] if me.eidolon >= 4 else 0.0)
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_EPIPHANY, label='開示', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(u[1])), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, u[0]),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def technique(self, me, battle) -> None:
        tech = self._skills()['130707']
        base, ratio = params_at(tech, 1)[:2]
        for e in battle.enemies:
            expected, reach, chance = (0.0, 1.0, base)
            for _ in range(40):
                success = self._chance(me, chance)
                reach *= success
                if reach < 1e-06:
                    break
                expected += reach
                chance *= ratio
            self._add_arcana(me, battle, e, expected, base_chance=1000000000.0)
