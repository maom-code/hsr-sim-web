from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.memosprite import MemospriteSpec
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '8007'
TWIN_ID = '8008'
ELEMENT = Element.ICE
CHARGE = 'ミュリオンのチャージ'
CHARGE_MAX = 100.0

def pct(value: float) -> float:
    return value * 100.0
EPIC = '叙事詩'
KEY_MEMO_CD = 'tb_memory.memo.crit_dmg'
KEY_CHEER = 'tb_memory.cheer'
KEY_CHEER_CR = 'tb_memory.cheer.crit_rate'
KEY_LC_BASIC = 'tb_memory.lc.enhanced_basic'

@register(CHAR_ID)
@register(TWIN_ID)
class TrailblazerMemory:
    light_cone = '22006'
    fixed_superimpose = 5
    fixed_eidolon = 6
    speed_target = 160.0
    target_override_label = '応援の対象'
    target_override_priority = ()
    relic_set_options = ({'key': '127', 'sets': {'127': 4, '323': 2}}, {'key': '123', 'sets': {'123': 4, '323': 2}})
    unimplemented = ('秘技の「タイムストップ」領域（戦闘前の探索用。戦闘に入った後の遅延とダメージだけ実装している）', '強化通常攻撃のミュリオンの行動制限デバフ解除。敵がデバフを撒かない')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _memo_skills(self) -> dict:
        return self._char()['memosprite']['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _talent(self, me) -> tuple[dict, int]:
        return (self._skills()['800704'], self._levels(me)['Talent'])

    def on_battle_start(self, me, battle) -> None:
        self._summoned_once = False
        self._energy_pool = 0.0
        self._epic = 0
        self._e2_left = 0
        self._firing = False
        me.counter(CHARGE, maximum=CHARGE_MAX)
        a2 = self._traces().get('8007101')
        if a2:
            battle.advance_forward(me, a2['params'][0][0])
        s, lv = self._talent(me)
        per_energy = p(s, lv, 3)

        def on_energy(who=None, amount: float=0.0, **kw):
            if amount <= 0 or who not in battle.team:
                return
            if battle.memosprite_of(me) is None:
                return
            self._energy_pool += amount
            gained = int(self._energy_pool // per_energy)
            if gained:
                self._energy_pool -= gained * per_energy
                self._gain_charge(me, battle, float(gained))
        battle.bus.subscribe(Event.ON_ENERGY_GAIN, on_energy, owner_id=me.id)
        if me.eidolon >= 2:
            energy, times = self._char()['ranks']['2']['params']
            self._e2_left = int(times)

            def on_memo_skill(memo=None, **kw):
                if memo is None or memo.summoner is me or self._e2_left <= 0:
                    return
                self._e2_left -= 1
                battle.gain_energy(me, energy)

            def reset_e2(actor=None, **kw):
                if actor is me:
                    self._e2_left = int(times)
            battle.bus.subscribe(Event.ON_MEMO_SKILL, on_memo_skill, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_START, reset_e2, owner_id=me.id)
        if me.eidolon >= 4:
            charge, _dmg_up = self._char()['ranks']['4']['params']

            def on_ally_skill(actor=None, **kw):
                if actor is None or actor not in battle.team:
                    return
                if getattr(actor.resource, 'maximum', None):
                    return
                self._gain_charge(me, battle, pct(charge))
            battle.bus.subscribe(Event.ON_SKILL_USED, on_ally_skill, owner_id=me.id)
        self._setup_cheer_damage(me, battle)

    def _summon(self, me, battle):
        memo = battle.memosprite_of(me)
        if memo is not None:
            return memo
        s, lv = self._talent(me)
        spd, hp_ratio, _per_energy, hp_base = (p(s, lv, i) for i in (1, 2, 3, 4))
        spec = MemospriteSpec(name=self._char()['memosprite']['name'], hp_base=hp_base, hp_ratio=hp_ratio, spd_base=spd, aggro=self._char()['memosprite']['aggro'])
        memo = battle.summon_memosprite(me, spec)
        boost = self._memo_skills().get('1800705')
        gain = p(boost, self._levels(me)['ServantTalent'], 1) if boost else 0.0
        a2 = self._traces().get('8007101')
        if a2 and (not self._summoned_once):
            gain += a2['params'][0][1]
        self._summoned_once = True
        self._refresh_memo_crit_dmg(me, battle, memo)
        self._gain_charge(me, battle, pct(gain))
        return memo

    def _refresh_memo_crit_dmg(self, me, battle, memo) -> None:
        talent = self._memo_skills().get('1800703')
        if talent is None:
            return
        lv = self._levels(me)['ServantTalent']
        ratio, flat = (p(talent, lv, 1), p(talent, lv, 2))
        value = memo.stats[StatKey.CRIT_DMG] * ratio + flat
        battle.apply_aura(memo, lambda who: Effect(key=KEY_MEMO_CD, label='精霊天賦・会心ダメージ', stats=StatSheet.of(crit_dmg=value), source_id=me.id))

    def _gain_charge(self, me, battle, amount: float) -> None:
        if amount <= 0:
            return
        battle.gain_counter(me, CHARGE, amount, maximum=CHARGE_MAX)
        if self._firing or battle.counter_value(me, CHARGE) < CHARGE_MAX:
            return
        memo = battle.memosprite_of(me)
        if memo is None:
            return
        self._firing = True
        try:
            battle.act_now(memo)
        finally:
            self._firing = False

    def memo_turn(self, memo, battle) -> None:
        me = memo.summoner
        if battle.counter_value(me, CHARGE) >= CHARGE_MAX:
            self._memo_support(me, memo, battle)
        else:
            self._memo_attack(me, memo, battle)

    def _memo_attack(self, me, memo, battle) -> None:
        s = self._memo_skills()['1800701']
        lv = self._levels(me)['Servant']
        single, hits, aoe = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        battle.attack(memo, ELEMENT, DamageType.MEMO, random=((StatKey.ATK, single),), random_hits=int(hits), toughness=s.get('toughness'), label=s['name'])
        battle.attack(memo, ELEMENT, DamageType.MEMO, aoe=((StatKey.ATK, aoe),), toughness=s.get('toughness'), label=s['name'] + '（全体）')
        battle.gain_energy(me, s.get('energy') or 0)
        a4 = self._traces().get('8007102')
        if a4:
            self._gain_charge(me, battle, pct(a4['params'][0][0]))

    def _memo_support(self, me, memo, battle) -> None:
        s = self._memo_skills()['1800707']
        lv = self._levels(me)['Servant']
        _ratio, turns, forward = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        battle.spend_counter(me, CHARGE)
        target = battle.resolve_target_override(me, self.target_override_priority)
        if target is None:
            return
        battle.advance_forward(target, forward)
        battle.apply_effect(target, Effect(key=KEY_CHEER, label='ミュリオンの応援', duration=Duration(turns=int(turns), tick_owner_id=target.id), stacking=Stacking.REFRESH, source_id=me.id))
        if me.eidolon >= 1:
            crit = self._char()['ranks']['1']['params'][0]
            battle.apply_effect(target, Effect(key=KEY_CHEER_CR, label='星魂1・会心率', stats=StatSheet.of(crit_rate=crit), duration=Duration(turns=int(turns), tick_owner_id=target.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, s.get('energy') or 0)

    def _cheer_ratio(self, me, holder) -> float:
        s = self._memo_skills()['1800707']
        ratio = p(s, self._levels(me)['Servant'], 1)
        maximum = float(getattr(holder.resource, 'maximum', 0.0) or 0.0)
        a6 = self._traces().get('8007103')
        if a6 and maximum:
            floor, step, per, cap = a6['params'][0]
            if maximum > floor:
                ratio += min((maximum - floor) // step * per, cap)
        if me.eidolon >= 4 and (not maximum):
            ratio += self._char()['ranks']['4']['params'][1]
        return ratio

    def _setup_cheer_damage(self, me, battle) -> None:

        def holder_of(source):
            if source is None:
                return None
            owner = getattr(source, 'summoner', source)
            if owner not in battle.team:
                return None
            if source.effects.has(KEY_CHEER):
                return owner
            if me.eidolon >= 1 and owner.effects.has(KEY_CHEER):
                return owner
            return None

        def on_damage(source=None, amount: float=0.0, dmg_type=None, targets=None, **kw):
            if amount <= 0 or dmg_type is DamageType.TRUE or (not targets):
                return
            holder = holder_of(source)
            if holder is None:
                return
            share = amount * self._cheer_ratio(me, holder) / len(targets)
            for enemy in targets:
                battle.deal_damage(source, enemy, ELEMENT, DamageType.TRUE, (), flat=share)
        battle.bus.subscribe(Event.AFTER_DAMAGE, on_damage, owner_id=me.id)
    rotation_label = '最初だけスキル'

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if battle.skill_uses.get(me.id, 0) == 0 else Action.BASIC

    def can_use_skill(self, me, battle) -> bool:
        return not self.enhanced_basic_ready(me, battle)

    def enhanced_basic_ready(self, me, battle) -> bool:
        return self._epic > 0 and battle.memosprite_of(me) is not None

    def basic(self, me, battle) -> None:
        if self.enhanced_basic_ready(me, battle):
            self._enhanced_basic(me, battle)
            return
        s = self._skills()['800701']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def _enhanced_basic(self, me, battle) -> None:
        s = self._skills()['800708']
        lv = self._levels(me)['Normal']
        mine, theirs, charge = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        memo = battle.memosprite_of(me)
        self._epic -= 1
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mine),), toughness=s.get('toughness'), label=s['name'])
        if memo is not None:
            battle.attack(memo, ELEMENT, DamageType.MEMO, aoe=((StatKey.ATK, theirs),), label=s['name'] + '（ミュリオン）', rider=True)
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])
        self._gain_charge(me, battle, pct(charge))

    def skill(self, me, battle) -> None:
        s = self._skills()['800702']
        lv = self._levels(me)['BPSkill']
        heal_ratio, charge = (p(s, lv, 1), p(s, lv, 2))
        battle.spend_sp(s['sp_cost'])
        memo = battle.memosprite_of(me)
        if memo is None:
            self._summon(me, battle)
        else:
            battle.heal(me, memo, memo.max_hp * heal_ratio, label=s['name'])
            self._gain_charge(me, battle, pct(charge))
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['800703']
        lv = self._levels(me)['Ultra']
        mult, charge = (p(s, lv, 1), p(s, lv, 2))
        self._summon(me, battle)
        override = 1.0 if me.eidolon >= 6 else None
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), crit_rate_override=override, toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])
        a6 = self._traces().get('8007501')
        if a6:
            self._epic = min(self._epic + 1, int(a6['params'][0][0]))
        self._gain_charge(me, battle, pct(charge))

    def technique(self, me, battle) -> None:
        s = self._skills()['800707']
        _seconds, delay, mult = (p(s, 1, i) for i in (1, 2, 3))
        for enemy in battle.alive_enemies:
            battle.delay_action(enemy, delay)
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult),), label='秘技・こだまする記憶')
