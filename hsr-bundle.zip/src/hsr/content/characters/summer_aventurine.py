from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, elation_members, reward_total
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, register, skill_levels_for
CHAR_ID = '1513'
ELEMENT = Element.QUANTUM
HEAT = '熱気'
SKILL_CHEERS = '151320'
SKILL_ALL_IN = '151321'
KEY_TRACE_RATE = 'summer_aventurine.trace.elation_rate'
KEY_TRACE_TEAM_RATE = 'summer_aventurine.trace.team_rate'
KEY_TRACE_CD = 'summer_aventurine.trace.crit_dmg'
KEY_TRACE_TEAM_CD = 'summer_aventurine.trace.team_crit_dmg'
KEY_ULT_SPD = 'summer_aventurine.ult.speed'
KEY_E1_RESPEN = 'summer_aventurine.e1.res_pen'
KEY_E4_DEF = 'summer_aventurine.e4.def_ignore'
KEY_E6_UP = 'summer_aventurine.e6.elation_up'

@register(CHAR_ID)
class SummerAventurine:
    speed_target = 180.0
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _refresh_speed_rate(self, me, battle) -> None:
        a2 = self._traces().get('1513101')
        if not a2:
            return
        threshold, base, step, per, cap = a2['params'][0]
        spd = me.stats[StatKey.SPD]
        rate = 0.0
        if spd >= threshold:
            rate = base + min(spd - threshold, cap) / step * per
        current = me.effects.get(KEY_TRACE_RATE)
        if current is not None:
            if abs(current.contribution()[StatKey.ELATION_RATE] - rate) < 1e-09:
                return
            if rate <= 0.0:
                battle.remove_effect(me, KEY_TRACE_RATE)
                return
        elif rate <= 0.0:
            return
        battle.apply_effect(me, Effect(key=KEY_TRACE_RATE, label='軌跡・愉悦度', stats=StatSheet.of(elation_rate=rate), source_id=me.id))

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _talent(self, me) -> tuple[dict, int]:
        return (self._skills()['151304'], self._levels(me)['Talent'])

    def _elation_level(self, me) -> int:
        return self._levels(me).get('ElationDamage', 10)

    def on_battle_start(self, me, battle) -> None:
        self.last_elation_skill_id: str | None = None
        self._heat_mark = 0.0
        self._enhanced_next = False
        self._auto_firing = False
        self._elation_count = 0
        self._panning_left = 0.0
        s, lv = self._talent(me)
        battle.gain_counter(me, HEAT, 0, maximum=self._heat_cap(me))
        battle.aha.reward_turn_bonus[me.id] = 1
        if self._traces().get('1513101'):
            self._refresh_speed_rate(me, battle)

            def on_speed_changed(effect=None, **kw):
                if effect is not None and getattr(effect, 'key', None) == KEY_TRACE_RATE:
                    return
                self._refresh_speed_rate(me, battle)
            battle.bus.subscribe(Event.ON_EFFECT_APPLIED, on_speed_changed, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_START, on_speed_changed, owner_id=me.id)
        a4 = self._traces().get('1513102')
        if a4:
            self._setup_waves(me, battle, a4['params'][0])
        a6 = self._traces().get('1513103')
        if a6:
            battle.apply_effect(me, Effect(key=KEY_TRACE_CD, label='軌跡・会心ダメージ', stats=StatSheet.of(crit_dmg=a6['params'][0][0]), source_id=me.id))
            self._panning_left = a6['params'][0][4]
        if me.eidolon >= 1:
            battle.apply_effect(me, Effect(key=KEY_E1_RESPEN, label='星魂1・耐性貫通', stats=StatSheet.of(res_pen=self._char()['ranks']['1']['params'][0]), source_id=me.id))
        if me.eidolon >= 6:
            battle.apply_effect(me, Effect(key=KEY_E6_UP, label='星魂6・上笑', stats=StatSheet.of(dmg_pct_elation=self._char()['ranks']['6']['params'][1]), source_id=me.id))
        heat_per, notes_per = (p(s, lv, 7), p(s, lv, 6))

        def on_ally_attack(source=None, targets_hit: int=0, rider=False, **kw):
            if source is None or source is me or (not targets_hit) or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team or owner is me:
                return
            battle.gain_shared(NOTES, notes_per)
            self._gain_heat(me, battle, heat_per)
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)

        def on_ally_action(actor=None, **kw):
            if a6 is None or actor is me or actor not in battle.team:
                return
            if self._panning_left <= 0:
                return
            _cd_self, cd_team, turns, heat, _cap = a6['params'][0]
            self._panning_left -= 1
            battle.apply_to_team(lambda who: Effect(key=KEY_TRACE_TEAM_CD, label='古き夢の淘金', stats=StatSheet.of(crit_dmg=cd_team), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
            self._gain_heat(me, battle, heat)
        for event in (Event.ON_BASIC_USED, Event.ON_SKILL_USED, Event.ON_ULT_USED):
            battle.bus.subscribe(event, on_ally_action, owner_id=me.id)

        def on_ally_followup(source=None, dmg_type=None, rider=False, **kw):
            if dmg_type is DamageType.FOLLOWUP and source is not me and (not rider):
                on_ally_action(actor=source)
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_followup, owner_id=me.id)

    def _setup_waves(self, me, battle, params) -> None:
        self_rate, reward, aha_spd, notes, team_rate = params
        others = [c for c in elation_members(battle) if c is not me]
        if others:
            battle.apply_aura(me, lambda who: Effect(key=KEY_TRACE_TEAM_RATE, label='荒波を満喫しよう', stats=StatSheet.of(elation_rate=team_rate), source_id=me.id))
            battle.apply_effect(me, Effect(key=f'{KEY_TRACE_TEAM_RATE}.self', label='荒波・自身の愉悦度', stats=StatSheet.of(elation_rate=self_rate), source_id=me.id))
            return

        def on_ally_attack(source=None, targets_hit: int=0, rider=False, **kw):
            if source is None or source is me or (not targets_hit) or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team or owner is me:
                return
            battle.aha.grant_reward(me, reward)
            battle.gain_shared(NOTES, notes)
            battle.aha.add_speed(aha_spd)
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)

    def _heat_cap(self, me) -> float:
        s, lv = self._talent(me)
        cap = p(s, lv, 4)
        if me.eidolon >= 2:
            cap = self._char()['ranks']['2']['params'][0]
        return cap

    def _heat_thresholds(self, me) -> list[float]:
        s, lv = self._talent(me)
        step = p(s, lv, 1)
        if me.eidolon >= 2:
            return [step * i for i in range(1, 6)]
        if me.eidolon >= 1:
            return [step * i for i in range(1, 4)]
        return [step]

    def _gain_heat(self, me, battle, amount: float) -> None:
        battle.gain_counter(me, HEAT, amount, maximum=self._heat_cap(me))
        heat = battle.counter_value(me, HEAT)
        for t in self._heat_thresholds(me):
            if heat >= t > self._heat_mark:
                self._heat_mark = t
                self._auto_fire(me, battle)

    def _auto_fire(self, me, battle) -> None:
        s, lv = self._talent(me)
        fixed = p(s, lv, 5)
        self._auto_firing = True
        try:
            battle.aha.fire_elation_skill(me, fixed)
        finally:
            self._auto_firing = False
        self._enhanced_next = True

    def basic(self, me, battle) -> None:
        s = self._skills()['151301']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['151302']
        lv = self._levels(me)['BPSkill']
        mult, notes, heat = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        battle.spend_sp(s['sp_cost'])
        if me.eidolon >= 4:
            ignore, turns = self._char()['ranks']['4']['params']
            battle.apply_to_team(lambda who: Effect(key=KEY_E4_DEF, label='星魂4・防御無視', stats=StatSheet.of(def_ignore=ignore), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        self._bonus_elation(me, battle, index=2, label=s['name'] + '（追加）')
        battle.gain_shared(NOTES, notes)
        self._gain_heat(me, battle, heat)
        battle.gain_energy(me, s['energy'])
        a6 = self._traces().get('1513103')
        if a6:
            self._panning_left = a6['params'][0][4]

    def ultimate(self, me, battle) -> None:
        s = self._skills()['151303']
        lv = self._levels(me)['Ultra']
        mult, heat, notes, spd_up, turns = (p(s, lv, i) for i in (1, 2, 3, 4, 5))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, mult),), toughness=s.get('toughness'), label=s['name'])
        self._bonus_elation(me, battle, index=3, label=s['name'] + '（追加）')
        battle.gain_shared(NOTES, notes)
        battle.apply_effect(me, Effect(key=KEY_ULT_SPD, label='必殺技・速度', stats=StatSheet.of(spd_pct=spd_up), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        self._gain_heat(me, battle, heat)
        battle.gain_energy(me, s['energy'])

    def _bonus_elation(self, me, battle, *, index: int, label: str) -> None:
        notes = reward_total(me)
        if notes <= 0:
            return
        s, lv = self._talent(me)
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(p(s, lv, index), notes), elation_shape='aoe', label=label, rider=True)

    def elation_skill(self, me, battle, notes: float) -> None:
        all_in = self._use_all_in(me)
        boost = battle.aha.skill_multiplier
        lv = self._elation_level(me)
        if all_in:
            s = self._skills()[SKILL_ALL_IN]
            aoe, per_heat, hits, single = (p(s, lv, i) for i in (1, 2, 3, 4))
        else:
            s = self._skills()[SKILL_CHEERS]
            aoe, hits, single = (p(s, lv, i) for i in (1, 2, 3))
            per_heat = 0.0
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(aoe, notes), elation_shape='aoe', independent=boost, toughness=s.get('toughness'), label=s['name'])
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(single, notes), elation_shape='random', random_hits=int(hits), independent=boost, toughness=s.get('toughness'), label=s['name'] + '（追撃）')
        if all_in:
            heat = battle.counter_value(me, HEAT)
            if not self._all_in_is_free(me, battle):
                battle.spend_counter(me, HEAT)
                self._heat_mark = 0.0
            if heat > 0:
                battle.attack(me, ELEMENT, DamageType.ELATION, elation=(per_heat, notes), elation_shape='random', random_hits=int(heat), independent=boost, toughness=s.get('toughness'), label=s['name'] + '（熱気）')
        self.last_elation_skill_id = SKILL_ALL_IN if all_in else SKILL_CHEERS
        self._elation_count += 1
        if me.eidolon >= 2:
            self._gain_heat(me, battle, self._char()['ranks']['2']['params'][1])

    def _use_all_in(self, me) -> bool:
        if me.eidolon >= 6 and self._elation_count >= self._char()['ranks']['6']['params'][0]:
            return True
        if self._auto_firing:
            return False
        if self._enhanced_next:
            self._enhanced_next = False
            return True
        return False

    def _all_in_is_free(self, me, battle) -> bool:
        if me.eidolon < 6:
            return False
        return not battle.aha.in_aha_time

    def technique(self, me, battle) -> None:
        s = self._skills()['151307']
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, p(s, 1, 1)),), label='秘技・凪に波風を巻き起こせ')
        battle.aha.grant_reward(me, p(s, 1, 3))
        self._gain_heat(me, battle, p(s, 1, 2))
