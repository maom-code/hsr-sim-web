from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element, Path
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
from .sparkle import SKILL_PRIORITY
CHAR_ID = '1313'
ELEMENT = Element.IMAGINARY
TARGET_PRIORITY = SKILL_PRIORITY
KEY_SKILL_DMG = 'sunday.skill.dmg'
KEY_TALENT_CR = 'sunday.talent.crit_rate'
KEY_E6_CD = 'sunday.e6.crit_dmg'
KEY_BLESSED = 'sunday.ult.blessed'
KEY_BLESSED_MARK = 'sunday.ult.blessed_mark'
KEY_E1 = 'sunday.e1.def_ignore'
KEY_TECH = 'sunday.technique.dmg'

@register(CHAR_ID)
class Sunday:
    target_override_label = '戦闘スキル・必殺技の対象'
    target_override_priority = TARGET_PRIORITY
    unimplemented = ('軌跡「掌上の安息」（デバフ解除）。敵がデバフを撒かない前提なので効きようがない',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _target(self, me, battle):
        return battle.resolve_target_override(me, self.target_override_priority)

    def on_battle_start(self, me, battle) -> None:
        self._blessed = None
        self._first_ult = True
        self._technique_pending = False
        a4 = self._traces().get('1313102')
        if a4:
            battle.gain_energy(me, a4['params'][0][0], apply_regen=False)

    def on_turn_start(self, me, battle) -> None:
        if me.eidolon >= 4:
            battle.gain_energy(me, self._rank(4)[0], apply_regen=False)

    def basic(self, me, battle) -> None:
        s = self._skills()['131301']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['131302']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        target = self._target(me, battle)
        if target is None:
            battle.gain_energy(me, s['energy'])
            return
        memos = battle.memosprites_of(target)
        battle.target_ally(me, target)
        dmg = p(s, lv, 2) + (p(s, lv, 4) if memos else 0.0)
        turns = int(p(s, lv, 3))
        for who in (target, *memos):
            battle.apply_effect(who, Effect(key=KEY_SKILL_DMG, label='紙と式典の賜物・与ダメージ', stats=StatSheet.of(dmg_pct=dmg), duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=me.id))
        if self._technique_pending:
            self._technique_pending = False
            tech = self._skills()['131307']
            up, t_turns = params_at(tech, 1)[:2]
            battle.apply_effect(target, Effect(key=KEY_TECH, label='秘技・与ダメージ', stats=StatSheet.of(dmg_pct=up), duration=Duration(turns=int(t_turns)), stacking=Stacking.REFRESH, source_id=me.id))
        self._talent(me, battle, target)
        if me.eidolon >= 1:
            e1_turns, char_ign, memo_ign = self._rank(1)[:3]
            for who, ign in ((target, char_ign), *((m, memo_ign) for m in memos)):
                battle.apply_effect(who, Effect(key=KEY_E1, label='星魂1・防御無視', stats=StatSheet.of(def_ignore=ign), duration=Duration(turns=int(e1_turns)), stacking=Stacking.REFRESH, source_id=me.id))
        if target.effects.has(KEY_BLESSED):
            battle.gain_sp(1, actor=me)
        if target.built.path is not Path.HARMONY:
            battle.act_next(target)
            for m in memos:
                battle.act_next(m)
        battle.gain_energy(me, s['energy'])

    def _talent(self, me, battle, target) -> None:
        for who in (target, *battle.memosprites_of(target)):
            self._talent_one(me, battle, who)

    def _talent_one(self, me, battle, target) -> None:
        t = self._skills()['131304']
        lv = self._levels(me)['Talent']
        cr, turns = (p(t, lv, 1), int(p(t, lv, 2)))
        max_stacks, stacking = (1, Stacking.REFRESH)
        if me.eidolon >= 6:
            e6 = self._rank(6)
            max_stacks, stacking = (int(e6[0]), Stacking.STACK)
            turns += int(e6[2])
        battle.apply_effect(target, Effect(key=KEY_TALENT_CR, label='肉体の告解・会心率', stats=StatSheet.of(crit_rate=cr), duration=Duration(turns=turns), stacking=stacking, max_stacks=max_stacks, source_id=me.id))
        if me.eidolon >= 6:
            battle.remove_effect(target, KEY_E6_CD)
            over = target.stats[StatKey.CRIT_RATE] - 1.0
            if over > 0:
                battle.apply_effect(target, Effect(key=KEY_E6_CD, label='星魂6・会心率超過', stats=StatSheet.of(crit_dmg=over * 100 * self._rank(6)[1]), duration=Duration(turns=turns), stacking=Stacking.REFRESH, source_id=me.id))

    def ultimate(self, me, battle) -> None:
        s = self._skills()['131303']
        lv = self._levels(me)['Ultra']
        target = self._target(me, battle)
        if target is None:
            battle.gain_energy(me, s['energy'])
            return
        battle.target_ally(me, target)
        pool = target.resource
        maximum = getattr(pool, 'maximum', None)
        if maximum is not None and getattr(pool, 'current', None) is not None:
            amount = maximum * p(s, lv, 1)
            a2 = self._traces().get('1313101')
            if a2:
                amount = max(amount, a2['params'][0][0])
            battle.gain_energy(target, amount, apply_regen=False)
        self._bless(me, battle, target, p(s, lv, 2), p(s, lv, 4), int(p(s, lv, 3)))
        if me.eidolon >= 6:
            self._talent(me, battle, target)
        if me.eidolon >= 2 and self._first_ult:
            battle.gain_sp(int(self._rank(2)[1]), actor=me)
        self._first_ult = False
        battle.gain_energy(me, s['energy'])

    def _bless(self, me, battle, target, ratio: float, flat: float, turns: int) -> None:
        prev = self._blessed
        if prev is not None and prev is not target:
            for who in (prev, *battle.memosprites_of(prev)):
                battle.remove_effect(who, KEY_BLESSED)
        self._blessed = target
        stats = StatSheet.of(crit_dmg=me.stats[StatKey.CRIT_DMG] * ratio + flat)
        if me.eidolon >= 2:
            stats.add(StatKey.DMG_PCT, self._rank(2)[0])

        def make() -> Effect:
            return Effect(key=KEY_BLESSED, label='祝福されし者', stats=StatSheet(dict(stats.values)), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id)
        for who in (target, *battle.memosprites_of(target)):
            battle.apply_effect(who, make())
        mark = battle.apply_effect(me, Effect(key=KEY_BLESSED_MARK, label='祝福されし者（付与中）', duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))

        def follow(memo=None, **kw):
            if memo is not None and memo.summoner is self._blessed:
                battle.apply_effect(memo, make())
        if mark is not None:
            battle._drop_listeners(mark)
            mark.listener_ids.append(battle.bus.subscribe(Event.ON_MEMO_SUMMON, follow, owner_id=me.id))

    def technique(self, me, battle) -> None:
        self._technique_pending = True
