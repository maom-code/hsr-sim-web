from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1508'
ARCHER_ID = '1015'
ELEMENT = Element.QUANTUM
GEMS = '宝石エネルギー'
SHADOW = '影の宝石'
KEY_TALENT_CD = 'rin.talent.crit_dmg'
KEY_A2 = 'rin.trace.elegance'
KEY_A4_SPD = 'rin.trace.spd'
KEY_ULT_VULN = 'rin.ult.vuln'
KEY_E2_SKILL = 'rin.e2.skill_dmg'
KEY_E2_TEAM = 'rin.e2.skill_mult'
KEY_E6_PEN = 'rin.e6.res_pen'

@register(CHAR_ID)
class TohsakaRin:
    manual_play_note = 'アーチャーとの連携追加攻撃と、強化戦闘スキルで SP を宝石エネルギーに変えるタイミングで伸び方が変わる。このシミュは条件を満たし次第すぐ使う'
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['150804'], self._levels(me)['Talent'])

    def _enhanced(self, me, battle) -> bool:
        t = self._talent(me)
        return battle.counter_value(me, GEMS) >= t[4] or battle.sp.current >= t[3] or battle.counter_value(me, SHADOW) > 0

    @property
    def skill_sp_cost(self):
        me, battle = (getattr(self, '_me', None), getattr(self, '_battle', None))
        if me is not None and battle is not None and self._enhanced(me, battle):
            return 0
        return None

    def on_battle_start(self, me, battle) -> None:
        self._me, self._battle = (me, battle)
        self._joint_ready = True
        t = self._talent(me)
        battle.gain_counter(me, GEMS, t[0])
        a2 = self._traces().get('1508101')
        if a2:
            extra_sp, atk, pen = a2['params'][0][:3]
            battle.sp.maximum += int(extra_sp)
            for c in battle.team:
                if c is me or c.id == ARCHER_ID:
                    battle.apply_effect(c, Effect(key=KEY_A2, label='優雅たれ', stats=StatSheet.of(atk_pct=atk, res_pen_quantum=pen), source_id=me.id))
        if me.eidolon >= 2:
            battle.apply_effect(me, Effect(key=KEY_E2_SKILL, label='星魂2・戦闘スキルダメージ', stats=StatSheet.of(dmg_pct_skill=self._rank(2)[0]), source_id=me.id))
            battle.apply_to_team(lambda who: Effect(key=KEY_E2_TEAM, label='星魂2・戦闘スキルダメージ 130%', type_multiplier={DamageType.SKILL: self._rank(2)[1]}, source_id=me.id))
        if me.eidolon >= 6:
            battle.apply_effect(me, Effect(key=KEY_E6_PEN, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=self._rank(6)[0]), source_id=me.id))

        def on_sp(actor=None, n=0.0):
            if n <= 0:
                return
            battle.gain_counter(me, GEMS, n)
            who = actor if actor is not None else battle.acting
            if who is None or who not in battle.team:
                return
            stacking, max_stacks = (Stacking.REFRESH, 1)
            if who is me and me.eidolon >= 4:
                stacking, max_stacks = (Stacking.STACK, int(self._rank(4)[0]))
            battle.apply_effect(who, Effect(key=KEY_TALENT_CD, label='宝石魔術・会心ダメージ', stats=StatSheet.of(crit_dmg=t[2]), duration=Duration(turns=int(t[1])), stacking=stacking, max_stacks=max_stacks, source_id=me.id))
        battle.bus.subscribe(Event.ON_SP_CHANGE, lambda spent=0, actor=None, **kw: on_sp(actor, float(spent)), owner_id=me.id)
        battle.bus.subscribe(Event.ON_SP_GAIN, lambda amount=0, actor=None, **kw: on_sp(actor, float(amount)), owner_id=me.id)

        def on_attack(source=None, dmg_type=None, rider=False, **kw):
            if source is None or rider or source.id != ARCHER_ID or (dmg_type is not DamageType.SKILL):
                return
            if not self._joint_ready:
                return
            archer_impl = battle.impl_of(source)
            casts = getattr(archer_impl, 'circuit_casts', 0)
            j = params_at(self._skills()['150805'], self._levels(me)['Talent'])
            if not (battle.sp.current <= j[2] or casts >= 5):
                return
            self._joint_ready = False
            battle._log(me.name, '自在遠坂流・連携追加攻撃')
            with battle.attack_action(me):
                battle.attack(me, ELEMENT, DamageType.FOLLOWUP, aoe=((StatKey.ATK, j[0]),), label='自在遠坂流（遠坂凛）')
            with battle.attack_action(source):
                battle.attack(source, ELEMENT, DamageType.FOLLOWUP, aoe=((StatKey.ATK, j[3]),), label='自在遠坂流（アーチャー）')
            battle.gain_energy(me, self._skills()['150805']['energy'])
            battle.gain_sp(int(j[1]), actor=me)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)

        def on_turn_end(actor=None, **kw):
            if actor is me:
                self._joint_ready = True
        battle.bus.subscribe(Event.TURN_END, on_turn_end, owner_id=me.id)
        self._speed_up(me, battle)

    def _speed_up(self, me, battle) -> None:
        a4 = self._traces().get('1508102')
        if not a4:
            return
        spd, turns = a4['params'][0][:2]
        before = me.speed()
        battle.apply_effect(me, Effect(key=KEY_A4_SPD, label='淑女らしく・速度', stats=StatSheet.of(spd_pct=spd), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        if any((s.actor is me for s in battle.queue.slots)):
            battle.queue.rescale(me, before)

    def basic(self, me, battle) -> None:
        s = self._skills()['150801']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        if self._enhanced(me, battle):
            self._second_magic(me, battle)
            return
        s = self._skills()['150802']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(1, actor=me)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])

    def _second_magic(self, me, battle) -> None:
        s = self._skills()['150809']
        lv = self._levels(me)['BPSkill']
        aoe, cost, bounce, floor, per_sp, cap = (p(s, lv, i) for i in (1, 2, 3, 4, 5, 6))
        shadow = battle.counter_value(me, SHADOW)
        if shadow > 0:
            battle.spend_counter(me, SHADOW)
            pool = shadow
            use_gems = False
        else:
            extra = battle.sp.current - int(floor)
            if extra > 0:
                battle.spend_sp(int(extra), actor=me)
                battle.gain_counter(me, GEMS, extra * per_sp)
            pool = battle.counter_value(me, GEMS)
            use_gems = True
        hits = int(min(cap, pool // cost))
        battle.attack(me, ELEMENT, DamageType.SKILL, aoe=((StatKey.ATK, aoe),), random=((StatKey.ATK, bounce),), random_hits=hits, toughness=s.get('toughness'), label=f'{s['name']}（{hits} 回）')
        consumed = hits * cost
        if use_gems and consumed:
            battle.spend_counter(me, GEMS, consumed)
            if me.eidolon >= 1 and consumed >= self._rank(1)[0]:
                battle.gain_counter(me, SHADOW, consumed)
        battle.gain_energy(me, s['energy'])
        self._speed_up(me, battle)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['150803']
        lv = self._levels(me)['Ultra']
        main, others, _, sp, vuln, turns = (p(s, lv, i) for i in (1, 2, 3, 4, 5, 6))
        battle.gain_sp(int(sp), actor=me)
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_ULT_VULN, label='山脈震撼す明星の薪・被ダメージ', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, main=((StatKey.ATK, main),), others=((StatKey.ATK, others),), toughness=s.get('toughness'), label=s['name'])
        a6 = self._traces().get('1508103')
        if a6:
            battle.gain_counter(me, GEMS, a6['params'][0][0])
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 6:
            battle.gain_counter(me, GEMS, self._rank(6)[1])
            battle.extra_turn(me)

    def technique(self, me, battle) -> None:
        battle.gain_counter(me, GEMS, params_at(self._skills()['150807'], 1)[0])
