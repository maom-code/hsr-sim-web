from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1403'
ELEMENT = Element.QUANTUM
KEY_REVELATION = 'tribbie.skill.revelation'
KEY_REVELATION_TEAM = 'tribbie.skill.revelation.team'
KEY_ZONE = 'tribbie.ult.zone'
KEY_ZONE_HOOK = 'tribbie.ult.zone_hook'
KEY_ZONE_HP = 'tribbie.trace.zone_hp'
KEY_A2_DMG = 'tribbie.trace.followup_dmg'
KEY_E6_FOLLOWUP = 'tribbie.e6.followup_dmg'
ZONE_EXTRA_HITS = '結界の追加付加ダメージ'

@register(CHAR_ID)
class Tribbie:
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def on_battle_start(self, me, battle) -> None:
        self._talent_listener = battle.bus.subscribe(Event.ON_ULT_USED, lambda source_id=None, **kw: self._talent_followup(me, battle, source_id), owner_id=me.id, per_source=1)
        a6 = self._traces().get('1403103')
        if a6:
            start_energy, per_hit = a6['params'][0]
            battle.gain_energy(me, start_energy, apply_regen=False)

            def on_ally_attack(source_id=None, source=None, hits=0, rider=False, **kw):
                if source is None or hits <= 0:
                    return
                if rider:
                    return
                owner = getattr(source, 'attributed_to', source)
                if owner.id == me.id:
                    return
                battle.gain_energy(me, per_hit * hits, apply_regen=False)
            battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)

    def _talent_followup(self, me, battle, source_id: str | None) -> None:
        if source_id == me.id:
            return
        self._followup(me, battle)

    def _followup(self, me, battle) -> None:
        s = self._skills()['140304']
        battle.attack(me, ELEMENT, DamageType.FOLLOWUP, aoe=((StatKey.HP, p(s, self._levels(me)['Talent'], 1)),), label='天賦・追加攻撃')
        battle.gain_energy(me, s['energy'])
        a2 = self._traces().get('1403101')
        if a2:
            dmg_up, max_stacks, turns = a2['params'][0]
            battle.apply_effect(me, Effect(key=KEY_A2_DMG, label='軌跡・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns)), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id))

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if self.buff_expiring(me, battle) else Action.BASIC
    rotation_label = 'バフが切れるならスキル'

    def buff_expiring(self, me, battle) -> bool:
        eff = me.effects.get(KEY_REVELATION)
        return eff is None or eff.duration is None or eff.duration.turns <= 1

    def basic(self, me, battle) -> None:
        s = self._skills()['140301']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, lv, 1)),), adjacent=((StatKey.HP, p(s, lv, 2)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['140302']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(s['sp_cost'])
        res_pen = p(s, lv, 1)
        turns = int(p(s, lv, 2))
        self._grant_revelation(me, battle, turns, res_pen)
        battle.gain_energy(me, s['energy'])

    def _grant_revelation(self, me, battle, turns: int, res_pen: float) -> None:
        stats = StatSheet.of(res_pen=res_pen)
        if me.eidolon >= 4:
            stats.add(StatKey.DEF_IGNORE, self._char()['ranks']['4']['params'][0])
        battle.apply_effect(me, Effect(key=KEY_REVELATION, label='神の啓示', duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))

        def make(_who=None) -> Effect:
            return Effect(key=KEY_REVELATION_TEAM, label='神の啓示・耐性貫通', stats=StatSheet(dict(stats.values)), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id)
        battle.apply_aura(me, make, key=KEY_REVELATION)

    def technique(self, me, battle) -> None:
        tech = self._skills()['140307']
        skill = self._skills()['140302']
        turns = params_at(tech, 1)[0]
        res_pen = p(skill, self._levels(me)['BPSkill'], 1)
        self._grant_revelation(me, battle, int(turns), res_pen)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['140303']
        lv = self._levels(me)['Ultra']
        dmg_mult = p(s, lv, 1)
        vuln = p(s, lv, 2)
        extra_mult = p(s, lv, 3)
        turns = int(p(s, lv, 4))

        def duration() -> Duration:
            return Duration(turns=turns, tick_owner_id=me.id)
        for e in battle.alive_enemies:
            battle.apply_effect(e, Effect(key=KEY_ZONE, label='結界', stats=StatSheet.of(vulnerability=vuln), duration=duration(), stacking=Stacking.REFRESH, source_id=me.id))
        a4 = self._traces().get('1403102')
        if a4:
            battle.remove_effect(me, KEY_ZONE_HP)
            team_hp = sum((c.stats[StatKey.HP] for c in battle.team))
            battle.apply_effect(me, Effect(key=KEY_ZONE_HP, label='軌跡・結界中の最大HP', stats=StatSheet.of(hp=team_hp * a4['params'][0][0]), duration=duration(), stacking=Stacking.REFRESH, source_id=me.id))
        hook = Effect(key=KEY_ZONE_HOOK, label='結界(付加ダメージ)', duration=duration(), stacking=Stacking.REFRESH, source_id=me.id)
        applied = battle.apply_effect(me, hook)
        if applied is not None:
            battle._drop_listeners(applied)
            applied.listener_ids.append(battle.bus.subscribe(Event.ON_ATTACK, lambda **kw: self._zone_extra(me, battle, extra_mult, **kw), owner_id=me.id))
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.HP, dmg_mult),), toughness=s.get('toughness'), label=s['name'])
        listener = battle.bus.find(getattr(self, '_talent_listener', -1))
        if listener is not None:
            listener.reset_source_counts()
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 6:
            self._followup(me, battle)

    def _zone_extra(self, me, battle, mult: float, *, hits: int=0, dmg_type=None, amount: float=0.0, targets_struck: int=1, **kw) -> None:
        if dmg_type in (DamageType.ADDITIONAL, DamageType.TRUE) or not hits:
            return
        if not battle.alive_enemies:
            return
        independent, extra_hits = (1.0, 0)
        if me.eidolon >= 2:
            ratio, more = self._char()['ranks']['2']['params']
            independent, extra_hits = (ratio, int(more))
        if dmg_type is DamageType.FOLLOWUP:
            extra_hits += int(battle.counter_value(me, ZONE_EXTRA_HITS))
        total = 0.0
        top = None
        for _ in range(targets_struck * (1 + extra_hits)):
            alive = battle.alive_enemies
            if not alive:
                break
            top = max(alive, key=lambda e: e.hp)
            total += battle.deal_damage(me, top, ELEMENT, DamageType.ADDITIONAL, ((StatKey.HP, mult),), independent=independent)
        if total:
            battle._log(me.name, '結界・付加ダメージ', total)
        if me.eidolon >= 1 and amount > 0 and (top is not None):
            share = self._char()['ranks']['1']['params'][0]
            dealt = battle.deal_damage(me, top, ELEMENT, DamageType.TRUE, (), flat=amount * share)
            if dealt:
                battle._log(me.name, '星魂1・確定ダメージ', dealt)

    def eidolon_6(self, me, battle) -> None:
        bonus = self._char()['ranks']['6']['params'][0]
        battle.apply_effect(me, Effect(key=KEY_E6_FOLLOWUP, label='星魂6・追加攻撃ダメージ', stats=StatSheet.of(dmg_pct_followup=bonus), source_id=me.id))
