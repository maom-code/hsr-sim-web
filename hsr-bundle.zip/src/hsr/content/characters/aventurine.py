from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1304'
ELEMENT = Element.IMAGINARY
BETS = 'ブラインドベット'
KEY_UNNERVED = 'aventurine.ult.unnerved'
KEY_A2_CR = 'aventurine.trace.crit_rate'
KEY_E1_CD = 'aventurine.e1.crit_dmg'
KEY_E2_RES = 'aventurine.e2.res_down'
KEY_E4_DEF = 'aventurine.e4.def'
KEY_E6_DMG = 'aventurine.e6.dmg'
KEY_TECH_DEF = 'aventurine.technique.def'

@register(CHAR_ID)
class Aventurine:
    unimplemented = ('天賦の効果抵抗と、行動制限系デバフへの抵抗（敵がデバフを撒かない）', 'バリアの耐久値で被ダメージを吸収する処理（付与の記録だけ）')

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> list[float]:
        return params_at(self._skills()['130404'], self._levels(me)['Talent'])

    def _has_chip(self, me, who) -> bool:
        return who.effects.has(f'shield.{me.id}')

    def on_battle_start(self, me, battle) -> None:
        self._bingo_left = 3
        me.counter(BETS, maximum=10)
        self._refresh_crit(me, battle)
        u = params_at(self._skills()['130403'], self._levels(me)['Ultra'])
        for c in battle.team:
            battle.add_target_bonus(c, lambda src, tgt, cd=u[2]: StatSheet.of(crit_dmg=cd) if tgt.effects.has(KEY_UNNERVED) else None)
        if me.eidolon >= 1:

            def on_shield(source=None, target=None, turns=0, **kw):
                if source is me and target is not None:
                    battle.apply_effect(target, Effect(key=KEY_E1_CD, label='星魂1・会心ダメージ', stats=StatSheet.of(crit_dmg=self._rank(1)[0]), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
            battle.bus.subscribe(Event.ON_SHIELD, on_shield, owner_id=me.id)

        def on_hit(target=None, **kw):
            if target is None:
                return
            owner = getattr(target, 'attributed_to', target)
            if self._has_chip(me, owner):
                self._gain_bets(me, battle, 1)
            if owner is me:
                self._gain_bets(me, battle, self._talent(me)[0])
        battle.bus.subscribe(Event.ON_ENEMY_HIT, on_hit, owner_id=me.id)

        def on_attack(source=None, as_followup=False, rider=False, **kw):
            if source is None or rider or (not as_followup):
                return
            owner = getattr(source, 'attributed_to', source)
            if owner is me or owner not in battle.team or (not self._has_chip(me, owner)):
                return
            if self._traces().get('1304103') and self._bingo_left > 0:
                self._bingo_left -= 1
                self._gain_bets(me, battle, 1)
        battle.bus.subscribe(Event.ON_ATTACK, on_attack, owner_id=me.id)
        a4 = self._traces().get('1304102')
        if a4:
            self._chips(me, battle, scale=a4['params'][0][1])

    def on_turn_start(self, me, battle) -> None:
        self._bingo_left = 3
        self._refresh_crit(me, battle)

    def _refresh_crit(self, me, battle) -> None:
        a2 = self._traces().get('1304101')
        if not a2:
            return
        per, cap, floor = a2['params'][0][:3]
        battle.remove_effect(me, KEY_A2_CR)
        over = max(0.0, me.stats[StatKey.DEF] - floor)
        battle.apply_effect(me, Effect(key=KEY_A2_CR, label='レバレッジ・会心率', stats=StatSheet.of(crit_rate=min(cap, int(over // 100) * per)), source_id=me.id))
        if me.eidolon >= 6:
            per6, cap6 = self._rank(6)[:2]
            n = sum((1 for c in battle.team if c is not me and battle.has_shield(c)))
            battle.apply_effect(me, Effect(key=KEY_E6_DMG, label='星魂6・与ダメージ', stats=StatSheet.of(dmg_pct=min(cap6, per6 * n)), stacking=Stacking.REFRESH, source_id=me.id))

    def _chips(self, me, battle, *, scale: float=1.0) -> None:
        s = self._skills()['130402']
        lv = self._levels(me)['BPSkill']
        ratio, flat, turns, cap = (p(s, lv, i) for i in range(1, 5))
        amount = me.stats[StatKey.DEF] * ratio + flat
        for c in battle.team:
            battle.apply_shield(me, c, amount * scale, turns=int(turns), cap=amount * cap)

    def _gain_bets(self, me, battle, n: float) -> None:
        battle.gain_counter(me, BETS, n, maximum=10)
        need = self._talent(me)[1]
        while battle.counter_value(me, BETS) >= need:
            battle.spend_counter(me, BETS, need)
            self._followup(me, battle)

    def _followup(self, me, battle) -> None:
        t = self._talent(me)
        hits = int(t[1]) + (int(self._rank(4)[2]) if me.eidolon >= 4 else 0)
        if me.eidolon >= 4:
            dfn, turns = self._rank(4)[:2]
            battle.apply_effect(me, Effect(key=KEY_E4_DEF, label='星魂4・防御力', stats=StatSheet.of(def_pct=dfn), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        self._refresh_crit(me, battle)
        s = self._skills()['130404']
        with battle.attack_action(me):
            battle.attack(me, ELEMENT, DamageType.FOLLOWUP, random=((StatKey.DEF, t[2]),), random_hits=hits, toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'] * hits)
        a6 = self._traces().get('1304103')
        if a6:
            r1, f1, _, r2, f2 = a6['params'][0][:5]
            dfn = me.stats[StatKey.DEF]
            s2 = self._skills()['130402']
            lv = self._levels(me)['BPSkill']
            cap = (dfn * p(s2, lv, 1) + p(s2, lv, 2)) * p(s2, lv, 4)
            for c in battle.team:
                battle.apply_shield(me, c, dfn * r1 + f1, turns=3, cap=cap)
            lowest = min(battle.team, key=lambda c: sum((e.value for e in c.effects if e.key.startswith('shield.'))))
            battle.apply_shield(me, lowest, dfn * r2 + f2, turns=3, cap=cap)

    def rotation(self, me, battle):
        from ...engine.battle import Action
        return Action.SKILL if any((not self._has_chip(me, c) for c in battle.team)) else Action.BASIC
    rotation_label = 'チップが切れていればスキル'

    def basic(self, me, battle) -> None:
        s = self._skills()['130401']
        lv = self._levels(me)['Normal']
        target = battle.target
        if me.eidolon >= 2 and target is not None:
            _, down, turns = self._rank(2)[:3]
            battle.apply_effect(target, Effect(key=KEY_E2_RES, label='星魂2・全属性耐性ダウン', stats=StatSheet.of(res_down=down), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.DEF, p(s, lv, 1)),), target=target, toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['130402']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        battle.target_team(me)
        self._chips(me, battle)
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        s = self._skills()['130403']
        lv = self._levels(me)['Ultra']
        max_bets, mult, _, turns = (p(s, lv, i) for i in range(1, 5))
        target = battle.target
        if target is not None:
            battle.apply_effect(target, Effect(key=KEY_UNNERVED, label='動揺', duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, debuff=True, source_id=me.id))
        self._refresh_crit(me, battle)
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, main=((StatKey.DEF, mult),), target=target, toughness=s.get('toughness'), label=s['name'])
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 1:
            self._chips(me, battle)
        self._gain_bets(me, battle, (1 + max_bets) / 2)

    def technique(self, me, battle) -> None:
        tech = self._skills()['130407']
        _, _, best, turns = params_at(tech, 1)[:4]
        battle.apply_to_team(lambda who: Effect(key=KEY_TECH_DEF, label='秘技・防御力', stats=StatSheet.of(def_pct=best), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
