from __future__ import annotations
from contextlib import contextmanager
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.timer import Countdown
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1309'
ELEMENT = Element.PHYSICAL
KEY_SKILL = 'robin.skill.dmg'
KEY_TALENT_CD = 'robin.talent.crit_dmg'
KEY_CONCERTO = 'robin.ult.concerto'
KEY_CONCERTO_TEAM = 'robin.ult.concerto.team'

@register(CHAR_ID)
class Robin:
    unimplemented = ('星魂 4 の行動制限系デバフの解除（敵がデバフを撒かない前提なので効きようがない）',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def on_battle_start(self, me, battle) -> None:
        self._concerto = False
        self._timer: Countdown | None = None
        self._e6_left = 0
        talent = self._skills()['130904']
        lv = self._levels(me)['Talent']
        cd, energy = (p(talent, lv, 1), p(talent, lv, 2))
        battle.apply_to_team(lambda who: Effect(key=KEY_TALENT_CD, label='調和の純正律・会心ダメージ', stats=StatSheet.of(crit_dmg=cd), source_id=me.id))

        def on_ally_attack(source=None, rider=False, targets=None, **kw):
            if source is None or rider:
                return
            owner = getattr(source, 'attributed_to', source)
            if owner not in battle.team:
                return
            gain = energy
            if self._concerto and me.eidolon >= 2:
                gain += self._rank(2)[1]
            battle.gain_energy(me, gain, apply_regen=False)
            if self._concerto:
                self._concerto_hit(me, battle, targets)
        battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)
        a2 = self._traces().get('1309101')
        if a2:
            battle.advance_forward(me, a2['params'][0][0])

    def skips_turn(self, me, battle) -> bool:
        return self._concerto

    def can_use_ultimate(self, me, battle) -> bool:
        return not self._concerto

    def basic(self, me, battle) -> None:
        s = self._skills()['130901']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        s = self._skills()['130902']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        dmg, turns = (p(s, lv, 1), int(p(s, lv, 2)))
        battle.target_team(me)
        battle.apply_to_team(lambda who: Effect(key=KEY_SKILL, label='飛翔のアリア', stats=StatSheet.of(dmg_pct=dmg), duration=Duration(turns=turns, tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        energy = s['energy']
        a6 = self._traces().get('1309103')
        if a6:
            energy += a6['params'][0][0]
        battle.gain_energy(me, energy)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['130903']
        lv = self._levels(me)['Ultra']
        atk_ratio, cd_spd, atk_flat = (p(s, lv, 1), p(s, lv, 2), p(s, lv, 3))
        stats = StatSheet.of(atk=me.stats[StatKey.ATK] * atk_ratio + atk_flat)
        a4 = self._traces().get('1309102')
        if a4:
            stats.add(StatKey.CRIT_DMG_FOLLOWUP, a4['params'][0][0])
        if me.eidolon >= 1:
            stats.add(StatKey.RES_PEN, self._rank(1)[0])
        if me.eidolon >= 2:
            stats.add(StatKey.SPD_PCT, self._rank(2)[0])
        if me.eidolon >= 4:
            stats.add(StatKey.EFFECT_RES, self._rank(4)[0])
        self._concerto = True
        self._e6_left = int(self._rank(6)[0]) if me.eidolon >= 6 else 0
        battle.target_team(me)
        battle.apply_effect(me, Effect(key=KEY_CONCERTO, label='協奏', stacking=Stacking.REFRESH, source_id=me.id))
        with self._rescaling(battle):
            battle.apply_aura(me, lambda who: Effect(key=KEY_CONCERTO_TEAM, label='協奏・攻撃力', stats=StatSheet(dict(stats.values)), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_CONCERTO)
        battle.leave_action_bar(me)
        for c in battle.team:
            if c is not me:
                battle.act_next(c)
        for m in battle.memosprites:
            if m.alive:
                battle.act_next(m)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
        self._timer = battle.add_countdown(Countdown(name='協奏', spd=cd_spd, on_turn=lambda: self._end_concerto(me, battle)), order=me.position)
        battle.gain_energy(me, s['energy'])

    def _end_concerto(self, me, battle) -> None:
        self._concerto = False
        battle.remove_effect(me, KEY_CONCERTO)
        with self._rescaling(battle):
            for who in [*battle.team, *battle.memosprites]:
                battle.remove_effect(who, KEY_CONCERTO_TEAM)
        if self._timer is not None:
            battle.remove_countdown(self._timer)
            self._timer = None
        battle.return_to_action_bar(me, av=0.0)

    @contextmanager
    def _rescaling(self, battle):
        units = [u for u in (*battle.team, *battle.memosprites) if any((sl.actor is u for sl in battle.queue.slots))]
        before = {id(u): u.speed() for u in units}
        yield
        for u in units:
            battle.queue.rescale(u, before[id(u)])

    def _concerto_hit(self, me, battle, targets) -> None:
        alive = [e for e in targets or [] if e.alive] or battle.alive_enemies
        if not alive:
            return
        s = self._skills()['130903']
        lv = self._levels(me)['Ultra']
        mult, cr, cd = (p(s, lv, 4), p(s, lv, 5), p(s, lv, 6))
        if self._e6_left > 0:
            cd += self._rank(6)[1]
            self._e6_left -= 1
        dealt = battle.deal_damage(me, alive[0], ELEMENT, DamageType.ADDITIONAL, ((StatKey.ATK, mult),), crit_rate_override=cr, crit_dmg_override=cd)
        if dealt:
            battle._log(me.name, '協奏・付加ダメージ', dealt)

    def technique(self, me, battle) -> None:
        tech = self._skills()['130907']
        battle.gain_energy(me, params_at(tech, 1)[1], apply_regen=False)
