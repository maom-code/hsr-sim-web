from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.elation import NOTES, REWARD_PREFIX, elation_members, reward_total
from ...engine.events import Event
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1505'
ELEMENT = Element.PHYSICAL
KEY_RATE = 'hiei.talent.elation_rate'
KEY_A2_CR = 'hiei.trace.crit_rate'
KEY_A4_VULN = 'hiei.trace.vuln'
KEY_E1_PEN = 'hiei.e1.res_pen'
KEY_E2_CD = 'hiei.e2.crit_dmg'
KEY_E4_DEF = 'hiei.e4.def_ignore'
KEY_E6_UP = 'hiei.e6.elation'
TALLY = 'キツネ先生の累計EP'

@register(CHAR_ID)
class Hiei:
    self_crit_rate_buff = 0.3
    manual_play_note = 'キツネ先生の発動と必殺技の順番で伸び方が変わる。このシミュは EP が溜まり次第すぐ必殺技を撃ち、キツネ先生は累計 EP 240 で自動に出す'
    unimplemented = ()

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _traces(self) -> dict:
        return self._char()['traces']['abilities']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _elation_level(self, me) -> int:
        return self._levels(me).get('ElationDamage', 10)

    def _rank(self, n: int) -> list[float]:
        return self._char()['ranks'][str(n)]['params']

    def _talent(self, me) -> tuple[float, ...]:
        t = self._skills()['150504']
        return tuple(params_at(t, self._levels(me)['Talent']))

    def on_battle_start(self, me, battle) -> None:
        self._tally = 0.0
        self._guard = False
        self._ult_count = 0
        a2 = self._traces().get('1505101')
        if a2:
            battle.apply_effect(me, Effect(key=KEY_A2_CR, label='軌跡・会心率', stats=StatSheet.of(crit_rate=a2['params'][0][0]), source_id=me.id))
        if me.eidolon >= 1:
            battle.apply_effect(me, Effect(key=KEY_E1_PEN, label='星魂1・耐性貫通', stats=StatSheet.of(res_pen=self._rank(1)[0]), source_id=me.id))
        if me.eidolon >= 2:
            battle.apply_effect(me, Effect(key=KEY_E2_CD, label='星魂2・会心ダメージ', stats=StatSheet.of(crit_dmg=self._rank(2)[0]), source_id=me.id))
        if me.eidolon >= 4:
            battle.apply_effect(me, Effect(key=KEY_E4_DEF, label='星魂4・防御無視', stats=StatSheet.of(def_ignore=self._rank(4)[0]), source_id=me.id))
        if me.eidolon >= 6:
            battle.aha.reward_turn_bonus[me.id] = battle.aha.reward_turn_bonus.get(me.id, 0) + int(self._rank(6)[1])
        self._refresh_rate(me, battle)

        def on_energy(who=None, amount=0.0, overflow=0.0, **kw):
            if who is not me:
                return
            requested = float(amount) + float(overflow)
            if requested <= 0:
                return
            if not self._guard:
                self._guard = True
                try:
                    battle.aha.grant_reward(me, requested)
                finally:
                    self._guard = False
            cap = self._talent(me)[2]
            self._tally += min(requested, cap)
            while self._tally >= cap:
                self._tally -= cap
                self._fox(me, battle)

        def on_reward(who=None, amount=0.0, **kw):
            if who is me:
                if not self._guard and amount > 0:
                    self._guard = True
                    try:
                        battle.gain_energy(me, min(amount, 100.0), apply_regen=False)
                    finally:
                        self._guard = False
                return
            if a2 and who is not None and (who in elation_members(battle)) and (who.id < me.id):
                share = a2['params'][0][4]
                if me.eidolon >= 2:
                    share *= 1.0 + self._rank(2)[1]
                self._grant(me, battle, amount * share)
        battle.bus.subscribe(Event.ON_ENERGY_GAIN, on_energy, owner_id=me.id)
        battle.bus.subscribe(Event.ON_REWARD_GAIN, on_reward, owner_id=me.id)
        a6 = self._traces().get('1505103')
        if a6:

            def on_expired(holder=None, effect=None, **kw):
                if holder is None or holder is me or effect is None:
                    return
                if not effect.key.startswith(REWARD_PREFIX) or holder not in battle.team:
                    return
                share = a6['params'][0][0]
                if me.eidolon >= 2:
                    share *= 1.0 + self._rank(2)[2]
                self._grant(me, battle, effect.value * share)
            battle.bus.subscribe(Event.ON_EFFECT_EXPIRED, on_expired, owner_id=me.id)

    def _grant(self, me, battle, amount: float) -> None:
        if amount > 0:
            battle.aha.grant_reward(me, amount)

    def _refresh_rate(self, me, battle) -> None:
        battle.remove_effect(me, KEY_RATE)
        rate = me.stats[StatKey.CRIT_DMG] * self._talent(me)[4]
        battle.apply_effect(me, Effect(key=KEY_RATE, label='天賦・愉悦度', stats=StatSheet.of(elation_rate=rate), source_id=me.id))
        if me.eidolon >= 6:
            e6 = self._rank(6)
            held = min(reward_total(me), 1000.0)
            battle.apply_effect(me, Effect(key=KEY_E6_UP, label='星魂6・上笑', stats=StatSheet.of(dmg_pct_elation=e6[0] + int(held // 100) * e6[2]), stacking=Stacking.REFRESH, source_id=me.id))

    def on_turn_start(self, me, battle) -> None:
        self._refresh_rate(me, battle)

    def _fox(self, me, battle) -> None:
        t = self._talent(me)
        with battle.attack_action(me):
            battle.attack(me, ELEMENT, DamageType.FOLLOWUP, aoe=((StatKey.ATK, t[0]),), label='キツネ先生・追加攻撃')
            held = reward_total(me)
            if held > 0:
                battle.attack(me, ELEMENT, DamageType.ELATION, elation=(t[1], held), elation_shape='aoe', label='キツネ先生・愉悦ダメージ', rider=True)
        a4 = self._traces().get('1505102')
        if a4:
            vuln, turns = a4['params'][0][:2]
            for e in battle.alive_enemies:
                battle.apply_effect(e, Effect(key=KEY_A4_VULN, label='裁きを下す', stats=StatSheet.of(vulnerability=vuln), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))
        battle.gain_energy(me, t[3], apply_regen=False)
        if me.eidolon >= 1:
            battle.aha.fire_elation_skill(me, battle.shared_value(NOTES))

    def basic(self, me, battle) -> None:
        self._refresh_rate(me, battle)
        s = self._skills()['150501']
        lv = self._levels(me)['Normal']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.ATK, p(s, lv, 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'], actor=me)
        battle.gain_energy(me, s['energy'])

    def skill(self, me, battle) -> None:
        self._refresh_rate(me, battle)
        s = self._skills()['150502']
        lv = self._levels(me)['BPSkill']
        battle.spend_sp(battle.skill_cost(me), actor=me)
        battle.attack(me, ELEMENT, DamageType.SKILL, main=((StatKey.ATK, p(s, lv, 2)),), adjacent=((StatKey.ATK, p(s, lv, 3)),), toughness=s.get('toughness'), label=s['name'])
        held = reward_total(me)
        if held > 0:
            mult = self._talent(me)[6]
            for shape in ('main', 'adjacent'):
                battle.attack(me, ELEMENT, DamageType.ELATION, elation=(mult, held), elation_shape=shape, label='天賦・愉悦ダメージ', rider=True)
        battle.gain_shared(NOTES, p(s, lv, 4))
        battle.gain_energy(me, s['energy'])

    def ultimate(self, me, battle) -> None:
        self._refresh_rate(me, battle)
        s = self._skills()['150503']
        lv = self._levels(me)['Ultra']
        hits = int(p(s, lv, 2))
        a2 = self._traces().get('1505101')
        if a2:
            n = len(battle.alive_enemies)
            hits += int(a2['params'][0][1] if n >= 3 else a2['params'][0][2] if n == 2 else a2['params'][0][3])
        battle.attack(me, ELEMENT, DamageType.ULTIMATE, aoe=((StatKey.ATK, p(s, lv, 1)),), random=((StatKey.ATK, p(s, lv, 3)),), random_hits=hits, toughness=s.get('toughness'), label=s['name'])
        held = reward_total(me)
        if held > 0:
            t = self._talent(me)
            counted = max(held, float(me.resource.maximum))
            battle.attack(me, ELEMENT, DamageType.ELATION, elation=(t[5], counted), elation_shape='aoe', label='天賦・愉悦ダメージ', rider=True)
            battle.attack(me, ELEMENT, DamageType.ELATION, elation=(t[7], counted), elation_shape='random', random_hits=hits, label='天賦・愉悦ダメージ（追加ヒット）', rider=True)
        battle.gain_energy(me, s['energy'])
        if me.eidolon >= 6:
            e6 = self._rank(6)
            if self._ult_count % int(e6[4]) == 0:
                battle.gain_energy(me, e6[3], apply_regen=False)
        self._ult_count += 1

    def elation_skill(self, me, battle, notes: float) -> None:
        self._refresh_rate(me, battle)
        s = self._skills()['150520']
        lv = self._elation_level(me)
        battle.attack(me, ELEMENT, DamageType.ELATION, elation=(p(s, lv, 2), notes), elation_shape='aoe', independent=battle.aha.skill_multiplier, toughness=s.get('toughness'), label=s['name'])
        reward = p(s, lv, 1) + (self._rank(1)[1] if me.eidolon >= 1 else 0.0)
        self._grant(me, battle, reward)

    def technique(self, me, battle) -> None:
        tech = self._skills()['150507']
        mult, reward = params_at(tech, 1)[:2]
        battle.attack(me, ELEMENT, DamageType.BASIC, aoe=((StatKey.ATK, mult),), toughness=tech.get('toughness'), label=tech['name'])
        self._grant(me, battle, reward)
