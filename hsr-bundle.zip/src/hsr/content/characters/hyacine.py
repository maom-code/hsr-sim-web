from __future__ import annotations
from ...data import loader
from ...engine.effects import Duration, Effect, Stacking
from ...engine.events import Event
from ...engine.memosprite import MemospriteSpec, spec_from_curated
from ...model.enums import DamageType, Element
from ...model.stats import StatKey, StatSheet
from ..base import p, params_at, register, skill_levels_for
CHAR_ID = '1409'
ELEMENT = Element.WIND
KEY_TRACE_CRIT = 'hyacine.trace.crit_rate'
KEY_TRACE_A6_HP = 'hyacine.trace.a6_hp'
KEY_TRACE_A6_HEAL = 'hyacine.trace.a6_heal'
KEY_AFTER_RAIN = 'hyacine.ult.after_rain'
KEY_AFTER_RAIN_HP = 'hyacine.ult.after_rain_hp'
KEY_TALENT_DMG = 'hyacine.talent.memo_dmg'
KEY_E2_SPD = 'hyacine.e2.speed'
KEY_E1_HEAL = 'hyacine.e1.heal_after_attack'
KEY_E4_CRIT_DMG = 'hyacine.e4.crit_dmg'
KEY_E6_RESPEN = 'hyacine.e6.res_pen'
KEY_TECH_HP = 'hyacine.technique.max_hp'

@register(CHAR_ID)
class Hyacine:
    self_crit_rate_buff = 1.0
    speed_target = 184.0
    unimplemented = ('軌跡「優しい雷雨」（効果抵抗と、戦闘スキル・必殺技でのデバフ解除）。敵がデバフを撒かないので効きようがない',)

    def _char(self) -> dict:
        return loader.character(CHAR_ID)

    def _skills(self) -> dict:
        return self._char()['skills']

    def _memo_skills(self) -> dict:
        return self._char()['memosprite']['skills']

    def _levels(self, me) -> dict[str, int]:
        return skill_levels_for(me.eidolon, CHAR_ID)

    def _memo_spec(self, me) -> MemospriteSpec:
        char = self._char()
        m = char['memosprite']
        ref = char['skills'].get(m['ref_skill']) if m['ref_skill'] else None
        return spec_from_curated(m, ref, self._levels(me)['Talent'])

    def _refresh_speed_trace(self, me, battle) -> None:
        a6 = self._char()['traces']['abilities'].get('1409103')
        if not a6:
            return
        threshold, hp_up, step, heal_per, cap = a6['params'][0]
        over = min(max(0.0, me.stats[StatKey.SPD] - threshold), cap)
        heal = over / step * heal_per if over > 0 else 0.0
        crit_dmg = 0.0
        if over > 0 and me.eidolon >= 4:
            e4_step, e4_cd = self._char()['ranks']['4']['params']
            crit_dmg = over / e4_step * e4_cd
        for who in (me, *[m for m in battle.memosprites if m.summoner is me]):
            for key, label, sheet, value, stat in ((KEY_TRACE_A6_HP, '軌跡A6・最大HP', StatSheet.of(hp_pct=hp_up), hp_up if over > 0 else 0.0, StatKey.HP_PCT), (KEY_TRACE_A6_HEAL, '軌跡A6・治癒量', StatSheet.of(heal_boost=heal), heal, StatKey.HEAL_BOOST), (KEY_E4_CRIT_DMG, '星魂4・会心ダメージ', StatSheet.of(crit_dmg=crit_dmg), crit_dmg, StatKey.CRIT_DMG)):
                current = who.effects.get(key)
                if current is not None and abs(current.contribution()[stat] - value) < 1e-09:
                    continue
                if value <= 0:
                    if current is not None:
                        battle.remove_effect(who, key)
                    continue
                battle.apply_effect(who, Effect(key=key, label=label, stats=sheet, source_id=me.id))

    def technique(self, me, battle) -> None:
        s = self._skills()['140907']
        ratio, flat, hp_up, turns = params_at(s, 1)[:4]
        amount = me.stats[StatKey.HP] * ratio + flat
        for ally in battle.team:
            battle.heal(me, ally, amount, label='秘技')
        battle.apply_to_team(lambda who: Effect(key=KEY_TECH_HP, label='秘技・最大HP', stats=StatSheet.of(hp_pct=hp_up), duration=Duration(turns=int(turns)), stacking=Stacking.REFRESH, source_id=me.id))

    def on_battle_start(self, me, battle) -> None:
        traces = self._char()['traces']['abilities']
        a2 = traces.get('1409101')
        if a2:
            battle.apply_effect(me, Effect(key=KEY_TRACE_CRIT, label='軌跡・会心率', stats=StatSheet.of(crit_rate=a2['params'][0][0]), source_id=me.id))
        if traces.get('1409103'):
            self._refresh_speed_trace(me, battle)

            def on_speed_changed(effect=None, **kw):
                if effect is not None and getattr(effect, 'key', None) in (KEY_TRACE_A6_HP, KEY_TRACE_A6_HEAL, KEY_E4_CRIT_DMG):
                    return
                self._refresh_speed_trace(me, battle)
            battle.bus.subscribe(Event.ON_EFFECT_APPLIED, on_speed_changed, owner_id=me.id)
            battle.bus.subscribe(Event.TURN_START, on_speed_changed, owner_id=me.id)
            battle.bus.subscribe(Event.ON_MEMO_SUMMON, on_speed_changed, owner_id=me.id)
        if me.eidolon >= 6:
            res_pen = self._char()['ranks']['6']['params'][1]

            def refresh_e6(**kw):
                if battle.memosprite_of(me) is not None:
                    battle.apply_aura(me, lambda who: Effect(key=KEY_E6_RESPEN, label='星魂6・耐性貫通', stats=StatSheet.of(res_pen=res_pen), source_id=me.id))
                else:
                    for who in (*battle.team, *battle.memosprites):
                        battle.remove_effect(who, KEY_E6_RESPEN)
            refresh_e6()
            battle.bus.subscribe(Event.ON_MEMO_SUMMON, refresh_e6, owner_id=me.id)
            battle.bus.subscribe(Event.ON_MEMO_DISMISS, refresh_e6, owner_id=me.id)
        s = self._skills()['140904']
        lv = self._levels(me)['Talent']
        dmg_up, turns, max_stacks = (p(s, lv, i) for i in (3, 4, 5))

        def on_heal(healer=None, source_id=None, **kw):
            memo = battle.memosprite_of(me)
            if memo is None or healer is None:
                return
            if healer is not me and healer is not memo:
                return
            battle.apply_effect(memo, Effect(key=KEY_TALENT_DMG, label='天賦・与ダメージ', stats=StatSheet.of(dmg_pct=dmg_up), duration=Duration(turns=int(turns), tick_owner_id=memo.id), stacking=Stacking.STACK, max_stacks=int(max_stacks), source_id=me.id))
        battle.bus.subscribe(Event.ON_HEAL, on_heal, owner_id=me.id)
        self._wounded: list = []

        def remember_wound(target=None, **kw):
            memo = battle.memosprite_of(me)
            if target is None or target is memo:
                return
            if not any((target is w for w in self._wounded)):
                self._wounded.append(target)
        battle.bus.subscribe(Event.ON_HP_LOSS, remember_wound, owner_id=me.id, priority=-10)
        battle.bus.subscribe(Event.TURN_START, lambda **kw: self._servant_heal(me, battle), owner_id=me.id)
        if me.eidolon >= 1:
            heal_ratio = self._char()['ranks']['1']['params'][1]

            def on_ally_attack(source=None, source_id=None, rider=False, **kw):
                if not me.effects.has(KEY_AFTER_RAIN) or source is None or rider:
                    return
                if not any((c is source for c in battle.team)):
                    return
                battle.heal(me, source, me.stats[StatKey.HP] * heal_ratio, label='星魂1')
            battle.bus.subscribe(Event.ON_ATTACK, on_ally_attack, owner_id=me.id)
        if me.eidolon >= 2:
            spd_up, spd_turns = self._char()['ranks']['2']['params']

            def on_hp_loss(target=None, **kw):
                if target is None or not hasattr(target, 'built'):
                    return
                battle.apply_effect(target, Effect(key=KEY_E2_SPD, label='星魂2・速度', stats=StatSheet.of(spd_pct=spd_up), duration=Duration(turns=int(spd_turns), tick_owner_id=target.id), stacking=Stacking.REFRESH, source_id=me.id))
            battle.bus.subscribe(Event.ON_HP_LOSS, on_hp_loss, owner_id=me.id)

    def _summon(self, me, battle):
        first = not getattr(self, '_summoned_once', False)
        existed = battle.memosprite_of(me) is not None
        memo = battle.summon_memosprite(me, self._memo_spec(me))
        if not existed:
            s = self._memo_skills()['1140905']
            lv = self._levels(me)['ServantTalent']
            battle.gain_energy(me, p(s, lv, 1), apply_regen=False)
            if first:
                battle.gain_energy(me, p(s, lv, 2), apply_regen=False)
            self._summoned_once = True
        return memo

    def _heal_team(self, me, battle, ratio: float, flat: float, label: str) -> None:
        base = me.stats[StatKey.HP] * ratio + flat
        own = battle.memosprite_of(me)
        for target in (*battle.team, *battle.memosprites):
            if target is own:
                continue
            battle.heal(me, target, base, label=label)

    def _servant_heal(self, me, battle) -> None:
        memo = battle.memosprite_of(me)
        if memo is None or not self._wounded:
            return
        s = self._memo_skills()['1140903']
        lv = self._levels(me)['ServantTalent']
        cost, ratio, flat, all_ratio, all_flat = (p(s, lv, i) for i in (1, 2, 3, 4, 5))
        battle.spend_hp(memo, amount=memo.max_hp * cost)
        amount = me.stats[StatKey.HP] * ratio + flat
        for target in list(self._wounded):
            battle.heal(memo, target, amount, label='精霊天賦')
        self._wounded.clear()
        if me.effects.has(KEY_AFTER_RAIN):
            extra = me.stats[StatKey.HP] * all_ratio + all_flat
            own = battle.memosprite_of(me)
            for target in (*battle.team, *battle.memosprites):
                if target is own:
                    continue
                battle.heal(memo, target, extra, label='精霊天賦(雨上がり)')

    def basic(self, me, battle) -> None:
        s = self._skills()['140901']
        battle.attack(me, ELEMENT, DamageType.BASIC, main=((StatKey.HP, p(s, self._levels(me)['Normal'], 1)),), toughness=s.get('toughness'), label=s['name'])
        battle.gain_sp(s['sp_gain'])
        battle.gain_energy(me, s['energy'])
        self._after_action(me, battle)

    def skill(self, me, battle) -> None:
        s = self._skills()['140902']
        lv = self._levels(me)['BPSkill']
        team_ratio, team_flat, memo_ratio, memo_flat = (p(s, lv, i) for i in (1, 2, 3, 4))
        battle.spend_sp(s['sp_cost'])
        memo = self._summon(me, battle)
        self._heal_team(me, battle, team_ratio, team_flat, s['name'])
        battle.heal(me, memo, me.stats[StatKey.HP] * memo_ratio + memo_flat, label=s['name'])
        battle.gain_energy(me, s['energy'])
        self._after_action(me, battle)

    def ultimate(self, me, battle) -> None:
        s = self._skills()['140903']
        lv = self._levels(me)['Ultra']
        team_ratio, team_flat, hp_ratio, hp_flat, turns, memo_ratio, memo_flat = (p(s, lv, i) for i in (1, 2, 3, 4, 5, 6, 7))
        memo = self._summon(me, battle)
        self._heal_team(me, battle, team_ratio, team_flat, s['name'])
        battle.heal(me, memo, me.stats[StatKey.HP] * memo_ratio + memo_flat, label=s['name'])
        if me.eidolon >= 1:
            hp_ratio += self._char()['ranks']['1']['params'][0]
        battle.apply_effect(me, Effect(key=KEY_AFTER_RAIN, label='雨上がり', duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id))
        battle.apply_aura(me, lambda who: Effect(key=KEY_AFTER_RAIN_HP, label='雨上がり・最大HP', stats=StatSheet.of(hp_pct=hp_ratio, hp=hp_flat), duration=Duration(turns=int(turns), tick_owner_id=me.id), stacking=Stacking.REFRESH, source_id=me.id), key=KEY_AFTER_RAIN)
        battle.gain_energy(me, s['energy'])
        self._after_action(me, battle)

    def ult_expiring(self, me, battle) -> bool:
        rain = me.effects.get(KEY_AFTER_RAIN)
        if rain is None or rain.duration is None:
            return True
        return rain.duration.turns <= 1

    def _after_action(self, me, battle) -> None:
        if not me.effects.has(KEY_AFTER_RAIN):
            return
        memo = battle.memosprite_of(me)
        if memo is not None:
            battle.act_now(memo)

    def memo_turn(self, memo, battle) -> None:
        me = memo.summoner
        s = self._memo_skills()['1140901']
        lv = self._levels(me)['Servant']
        ratio, clear = (p(s, lv, 1), p(s, lv, 2))
        if me.eidolon >= 6:
            clear = self._char()['ranks']['6']['params'][0]
        pool = battle.healing_by(me, memo)
        battle.attack(memo, ELEMENT, DamageType.MEMO, aoe=(), flat_aoe=pool * ratio, label=f'{s['name']}（治癒量{pool:,.0f}）')
        battle.gain_energy(me, s['energy'])
        battle.clear_healing(me, memo, ratio=clear)
        battle.tick_own_effects(memo)
        self._servant_heal(me, battle)
