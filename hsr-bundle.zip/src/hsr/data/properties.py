from __future__ import annotations
from ..model.stats import StatKey
PROPERTY_TO_STAT: dict[str, StatKey] = {'HPDelta': StatKey.HP, 'AttackDelta': StatKey.ATK, 'DefenceDelta': StatKey.DEF, 'SpeedDelta': StatKey.SPD, 'HPAddedRatio': StatKey.HP_PCT, 'AttackAddedRatio': StatKey.ATK_PCT, 'DefenceAddedRatio': StatKey.DEF_PCT, 'SpeedAddedRatio': StatKey.SPD_PCT, 'CriticalChanceBase': StatKey.CRIT_RATE, 'CriticalDamageBase': StatKey.CRIT_DMG, 'BreakDamageAddedRatioBase': StatKey.BREAK_EFFECT, 'StatusProbabilityBase': StatKey.EFFECT_HIT, 'StatusResistanceBase': StatKey.EFFECT_RES, 'SPRatioBase': StatKey.ENERGY_REGEN, 'HealRatioBase': StatKey.HEAL_BOOST, 'PhysicalAddedRatio': StatKey.DMG_PCT_PHYSICAL, 'FireAddedRatio': StatKey.DMG_PCT_FIRE, 'IceAddedRatio': StatKey.DMG_PCT_ICE, 'ThunderAddedRatio': StatKey.DMG_PCT_THUNDER, 'WindAddedRatio': StatKey.DMG_PCT_WIND, 'QuantumAddedRatio': StatKey.DMG_PCT_QUANTUM, 'ImaginaryAddedRatio': StatKey.DMG_PCT_IMAGINARY, 'ElationDamageAddedRatioBase': StatKey.ELATION_RATE}

class UnknownProperty(KeyError):
    pass

def to_stat(property_name: str) -> StatKey:
    try:
        return PROPERTY_TO_STAT[property_name]
    except KeyError:
        raise UnknownProperty(f'未知の property 名: {property_name!r}。src/hsr/data/properties.py の PROPERTY_TO_STAT に追加してください') from None
