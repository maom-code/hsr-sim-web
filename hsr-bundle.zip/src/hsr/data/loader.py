from __future__ import annotations
import json
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any
REPO_ROOT = Path(__file__).resolve().parents[3]
CURATED = REPO_ROOT / 'data' / 'curated'

class DataNotFound(FileNotFoundError):
    pass

def _read(path: Path) -> Any:
    if not path.exists():
        raise DataNotFound(f'{path} がありません。先に tools/fetch_data.py と tools/build_curated.py を実行してください')
    return json.loads(path.read_text(encoding='utf-8'))

@lru_cache(maxsize=1)
def index() -> dict:
    return _read(CURATED / 'index.json')

@lru_cache(maxsize=1)
def relic_sets() -> dict:
    return _read(CURATED / 'relic_sets.json')

@lru_cache(maxsize=1)
def relic_affixes() -> dict:
    return _read(CURATED / 'relic_affixes.json')

@lru_cache(maxsize=256)
def character(id_or_name: str) -> dict:
    cid = _resolve(id_or_name, index()['characters'], 'キャラ')
    return _read(CURATED / 'characters' / f'{cid}.json')

@lru_cache(maxsize=256)
def light_cone(id_or_name: str) -> dict:
    lid = _resolve(id_or_name, index()['light_cones'], '光円錐')
    return _read(CURATED / 'light_cones' / f'{lid}.json')

def _resolve(key: str, table: dict[str, str], label: str) -> str:
    key = str(key)
    if key in table:
        return key
    hits = [k for k, name in table.items() if name == key]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1 and all((h.startswith('8') for h in hits)):
        return min(hits)
    if not hits:
        near = [name for name in table.values() if key in name][:5]
        hint = f' 候補: {near}' if near else ''
        raise KeyError(f'{label}が見つかりません: {key!r}.{hint}')
    raise KeyError(f'{label}名が一意になりません: {key!r} -> {[table[h] for h in hits]}')
PROMOTION_MAX_LEVEL = (20, 30, 40, 50, 60, 70, 80)

def promotion_for(level: int) -> int:
    for i, cap in enumerate(PROMOTION_MAX_LEVEL):
        if level < cap:
            return i
    return len(PROMOTION_MAX_LEVEL) - 1

@dataclass(frozen=True)
class BaseStats:
    hp: float
    atk: float
    dfn: float
    spd: float
    crit_rate: float
    crit_dmg: float
    aggro: float = 100.0

def character_base_stats(char: dict, level: int, promotion: int | None=None) -> BaseStats:
    tier = promotion_for(level) if promotion is None else promotion
    st = char['stats'][str(tier)]

    def grow(key: str) -> float:
        return st[f'{key}_base'] + st[f'{key}_add'] * (level - 1)
    return BaseStats(hp=grow('hp'), atk=grow('attack'), dfn=grow('defence'), spd=st['speed_base'], crit_rate=st['critical_chance'], crit_dmg=st['critical_damage'], aggro=st.get('base_aggro', 100.0))

def light_cone_base_stats(lc: dict, level: int, promotion: int | None=None) -> BaseStats:
    tier = promotion_for(level) if promotion is None else promotion
    entries = lc['stats']
    st = entries[min(tier, len(entries) - 1)]

    def grow(key: str) -> float:
        return st[f'base_{key}'] + st[f'base_{key}_add'] * (level - 1)
    return BaseStats(hp=grow('hp'), atk=grow('attack'), dfn=grow('defence'), spd=0.0, crit_rate=0.0, crit_dmg=0.0)

@dataclass(frozen=True)
class MainAffix:
    base: float
    step: float

    def value_at(self, level: int) -> float:
        return self.base + self.step * level

def main_affix(property_name: str, slot: str, rarity: int=5) -> MainAffix:
    table = relic_affixes()['main'][str(rarity)][slot]
    try:
        a = table[property_name]
    except KeyError:
        raise KeyError(f'{slot} に {property_name} のメインステータスは存在しません。 選べるのは {sorted(table)}') from None
    return MainAffix(a['base'], a['step'])

def sub_roll_value(property_name: str, rarity: int=5) -> float:
    return relic_affixes()['sub_roll'][str(rarity)][property_name]

def relic_max_level(rarity: int=5) -> int:
    return relic_affixes()['max_level'][str(rarity)]
