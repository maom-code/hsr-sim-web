from __future__ import annotations
from enum import StrEnum

class Element(StrEnum):
    PHYSICAL = 'Physical'
    FIRE = 'Fire'
    ICE = 'Ice'
    LIGHTNING = 'Thunder'
    WIND = 'Wind'
    QUANTUM = 'Quantum'
    IMAGINARY = 'Imaginary'

class Path(StrEnum):
    DESTRUCTION = 'Warrior'
    HUNT = 'Rogue'
    ERUDITION = 'Mage'
    HARMONY = 'Shaman'
    NIHILITY = 'Warlock'
    PRESERVATION = 'Knight'
    ABUNDANCE = 'Priest'
    REMEMBRANCE = 'Memory'
    ELATION = 'Elation'

class DamageType(StrEnum):
    BASIC = 'basic'
    SKILL = 'skill'
    ULTIMATE = 'ultimate'
    TALENT = 'talent'
    FOLLOWUP = 'followup'
    MEMO = 'memo'
    ELATION = 'elation'
    DOT = 'dot'
    ADDITIONAL = 'additional'
    BREAK = 'break'
    SUPER_BREAK = 'super_break'
    TRUE = 'true'

class RelicSlot(StrEnum):
    HEAD = 'HEAD'
    HAND = 'HAND'
    BODY = 'BODY'
    FOOT = 'FOOT'
    SPHERE = 'NECK'
    ROPE = 'OBJECT'
BREAK_ELEMENT_COEF: dict[Element, float] = {Element.PHYSICAL: 2.0, Element.FIRE: 2.0, Element.ICE: 1.0, Element.LIGHTNING: 1.0, Element.WIND: 1.5, Element.QUANTUM: 0.5, Element.IMAGINARY: 0.5}
