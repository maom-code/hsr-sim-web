from __future__ import annotations
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from .enums import Element

class StatKey(StrEnum):
    HP = 'hp'
    ATK = 'atk'
    DEF = 'def'
    SPD = 'spd'
    HP_PCT = 'hp_pct'
    ATK_PCT = 'atk_pct'
    DEF_PCT = 'def_pct'
    SPD_PCT = 'spd_pct'
    CRIT_RATE = 'crit_rate'
    CRIT_DMG = 'crit_dmg'
    BREAK_EFFECT = 'break_effect'
    BREAK_EFFICIENCY = 'break_efficiency'
    SUPER_BREAK_RATE = 'super_break_rate'
    BREAK_DMG_PCT = 'break_dmg_pct'
    SUPER_BREAK_DMG_PCT = 'super_break_dmg_pct'
    EFFECT_HIT = 'effect_hit'
    EFFECT_RES = 'effect_res'
    ENERGY_REGEN = 'energy_regen'
    HEAL_BOOST = 'heal_boost'
    ELATION_RATE = 'elation_rate'
    HEAL_TAKEN = 'heal_taken'
    DMG_PCT = 'dmg_pct'
    DEF_IGNORE = 'def_ignore'
    DEF_IGNORE_ELATION = 'def_ignore_elation'
    DEF_IGNORE_ULTIMATE = 'def_ignore_ultimate'
    DEF_IGNORE_BREAK = 'def_ignore_break'
    DEF_IGNORE_SUPER_BREAK = 'def_ignore_super_break'
    DEF_DOWN = 'def_down'
    RES_PEN = 'res_pen'
    RES_DOWN = 'res_down'
    VULNERABILITY = 'vulnerability'
    CRIT_DMG_TAKEN = 'crit_dmg_taken'
    CRIT_DMG_TAKEN_FROM_SOURCE = 'crit_dmg_taken_from_source'
    CRIT_DMG_FOLLOWUP = 'crit_dmg_followup'
    CRIT_DMG_ULTIMATE = 'crit_dmg_ultimate'
    CRIT_DMG_SKILL = 'crit_dmg_skill'
    ELATION_TAKEN = 'elation_taken'
    DMG_REDUCTION = 'dmg_reduction'
    DMG_PCT_PHYSICAL = 'dmg_pct_physical'
    DMG_PCT_FIRE = 'dmg_pct_fire'
    DMG_PCT_ICE = 'dmg_pct_ice'
    DMG_PCT_THUNDER = 'dmg_pct_thunder'
    DMG_PCT_WIND = 'dmg_pct_wind'
    DMG_PCT_QUANTUM = 'dmg_pct_quantum'
    DMG_PCT_IMAGINARY = 'dmg_pct_imaginary'
    DMG_PCT_BASIC = 'dmg_pct_basic'
    DMG_PCT_SKILL = 'dmg_pct_skill'
    DMG_PCT_ULTIMATE = 'dmg_pct_ultimate'
    DMG_PCT_FOLLOWUP = 'dmg_pct_followup'
    DMG_PCT_DOT = 'dmg_pct_dot'
    DMG_PCT_MEMO = 'dmg_pct_memo'
    DMG_PCT_ELATION = 'dmg_pct_elation'
    RES_PEN_PHYSICAL = 'res_pen_physical'
    RES_PEN_FIRE = 'res_pen_fire'
    RES_PEN_ICE = 'res_pen_ice'
    RES_PEN_THUNDER = 'res_pen_thunder'
    RES_PEN_WIND = 'res_pen_wind'
    RES_PEN_QUANTUM = 'res_pen_quantum'
    RES_PEN_IMAGINARY = 'res_pen_imaginary'
DMG_PCT_BY_ELEMENT: dict[Element, StatKey] = {Element.PHYSICAL: StatKey.DMG_PCT_PHYSICAL, Element.FIRE: StatKey.DMG_PCT_FIRE, Element.ICE: StatKey.DMG_PCT_ICE, Element.LIGHTNING: StatKey.DMG_PCT_THUNDER, Element.WIND: StatKey.DMG_PCT_WIND, Element.QUANTUM: StatKey.DMG_PCT_QUANTUM, Element.IMAGINARY: StatKey.DMG_PCT_IMAGINARY}
RES_PEN_BY_ELEMENT: dict[Element, StatKey] = {Element.PHYSICAL: StatKey.RES_PEN_PHYSICAL, Element.FIRE: StatKey.RES_PEN_FIRE, Element.ICE: StatKey.RES_PEN_ICE, Element.LIGHTNING: StatKey.RES_PEN_THUNDER, Element.WIND: StatKey.RES_PEN_WIND, Element.QUANTUM: StatKey.RES_PEN_QUANTUM, Element.IMAGINARY: StatKey.RES_PEN_IMAGINARY}

@dataclass
class StatSheet:
    values: dict[StatKey, float] = field(default_factory=dict)

    def __getitem__(self, key: StatKey) -> float:
        return self.values.get(key, 0.0)

    def __setitem__(self, key: StatKey, value: float) -> None:
        self.values[key] = value

    def __contains__(self, key: StatKey) -> bool:
        return key in self.values

    def __iter__(self) -> Iterator[StatKey]:
        return iter(self.values)

    def add(self, key: StatKey, value: float) -> None:
        self.values[key] = self.values.get(key, 0.0) + value

    def merged(self, other: 'StatSheet | Mapping[StatKey, float]') -> 'StatSheet':
        out = StatSheet(dict(self.values))
        items = other.values.items() if isinstance(other, StatSheet) else other.items()
        for k, v in items:
            out.add(k, v)
        return out

    def dmg_pct_for(self, element: Element, dmg_type_key: StatKey | None) -> float:
        total = self[StatKey.DMG_PCT] + self[DMG_PCT_BY_ELEMENT[element]]
        if dmg_type_key is not None:
            total += self[dmg_type_key]
        return total

    def res_pen_for(self, element: Element) -> float:
        return self[StatKey.RES_PEN] + self[RES_PEN_BY_ELEMENT[element]]

    @classmethod
    def of(cls, **kwargs: float) -> 'StatSheet':
        return cls({StatKey(k): v for k, v in kwargs.items()})

def finalize_base_stats(sheet: StatSheet, base: StatSheet) -> StatSheet:
    out = StatSheet(dict(sheet.values))
    for flat, pct in ((StatKey.HP, StatKey.HP_PCT), (StatKey.ATK, StatKey.ATK_PCT), (StatKey.DEF, StatKey.DEF_PCT), (StatKey.SPD, StatKey.SPD_PCT)):
        out[flat] = base[flat] * (1.0 + sheet[pct]) + sheet[flat]
        out.values.pop(pct, None)
    return out
