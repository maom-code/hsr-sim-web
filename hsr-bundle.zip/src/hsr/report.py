from __future__ import annotations
import html
import json
from dataclasses import dataclass, field
ICON_BASE = 'https://raw.githubusercontent.com/Mar-7th/StarRailRes/master'
SERIES_LIGHT = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#4a3aa7', '#e34948']
NARROW_SEGMENT_PCT = 4.5

@dataclass
class Member:
    char_id: str
    name: str
    eidolon: int
    light_cone_id: str | None
    superimpose: int

    @property
    def badge(self) -> str:
        return f'E{self.eidolon}S{self.superimpose}'

@dataclass
class Row:
    label: str
    members: list[Member]
    dpa: float
    total_damage: float
    cycles: float
    breakdown: dict[str, float] = field(default_factory=dict)

@dataclass
class ChartSpec:
    title: str
    enemy_level: int
    enemy_count: int
    enemy_hp: float
    cycles: int
    rows: list[Row]
    note: str = ''

def _series_map(rows: list[Row]) -> dict[str, int]:
    order: list[str] = []
    for row in rows:
        for name in row.breakdown:
            if name not in order:
                order.append(name)
    return {name: i for i, name in enumerate(order[:len(SERIES_LIGHT)])}

def _fmt(value: float) -> str:
    return f'{value:,.0f}'

def render(spec: ChartSpec) -> str:
    slots = _series_map(spec.rows)
    baseline = (spec.rows[0].dpa if spec.rows else 0.0) or 1.0
    top_total = max((r.total_damage for r in spec.rows), default=0.0) or 1.0
    legend = ''.join((f'<span class="key"><i style="background:var(--series-{i + 1})"></i>{html.escape(name)}</span>' for name, i in slots.items()))
    body: list[str] = []
    for row in spec.rows:
        units = ''.join((_unit_html(m) for m in row.members))
        segs: list[str] = []
        for name, dmg in sorted(row.breakdown.items(), key=lambda kv: -kv[1]):
            if dmg <= 0:
                continue
            slot = slots.get(name)
            color = f'var(--series-{slot + 1})' if slot is not None else 'var(--muted)'
            width = dmg / top_total * 100.0
            share = dmg / row.total_damage if row.total_damage else 0.0
            per_av = dmg / (row.total_damage / row.dpa) if row.dpa else 0.0
            value = f'<span class="v">{_fmt(per_av)}</span>' if width >= NARROW_SEGMENT_PCT else ''
            segs.append(f'<div class="seg" style="width:{width:.4f}%;background:{color}" tabindex="0">{value}<span class="tip">{html.escape(name)}<br>DPA {_fmt(per_av)} ／ {share:.1%}</span></div>')
        pct = row.dpa / baseline
        body.append(f'<div class="row"><div class="team">{units}</div><div class="track">{''.join(segs)}</div><div class="total"><b>{_fmt(row.dpa)}</b><span class="pct">{pct:.1%}</span></div></div>')
    table_rows = ''.join(('<tr><th scope="row">' + html.escape(r.label) + '</th>' + f'<td>{_fmt(r.dpa)}</td><td>{_fmt(r.total_damage)}</td>' + f'<td>{r.cycles:.2f}</td>' + ''.join((f'<td>{_fmt(r.breakdown.get(name, 0.0))}</td>' for name in slots)) + '</tr>' for r in spec.rows))
    table_head = ''.join((f'<th>{html.escape(n)}</th>' for n in slots))
    meta = f'敵 Lv{spec.enemy_level} ／ {spec.enemy_count} 体 ／ HP {_fmt(spec.enemy_hp)} ／ {spec.cycles} サイクル'
    return _TEMPLATE.format(title=html.escape(spec.title), meta=html.escape(meta), note=html.escape(spec.note), legend=legend, rows=''.join(body), table_head=table_head, table_rows=table_rows, palette=json.dumps(SERIES_LIGHT))

def _unit_html(m: Member) -> str:
    portrait = f'{ICON_BASE}/icon/character/{m.char_id}.png'
    short = html.escape(_short_name(m.name))
    lc = f'<img class="lc" src="{ICON_BASE}/icon/light_cone/{m.light_cone_id}.png" alt="" loading="lazy" onerror="this.remove()">' if m.light_cone_id else ''
    return f'<div class="unit" title="{html.escape(m.name)} {m.badge}"><div class="art"><span class="fallback">{short}</span><img src="{portrait}" alt="{html.escape(m.name)}" loading="lazy" onerror="this.remove()">{lc}</div><div class="badge">{m.badge}</div></div>'

def _short_name(name: str) -> str:
    name = name.replace('開拓者・', '')
    return name[:4]
_TEMPLATE = '<!doctype html>\n<html lang="ja" data-theme="light"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>{title}</title>\n<style>\n  /* **白背景・黒文字に固定する。** 見比べる用途なので、環境で見え方が\n     変わらないほうがいい（2026-09-09 ユーザー指定）。\n     配色は data-viz の既定カテゴリカルパレット（light 側）。\n     light では一部が 3:1 を下回るので、各段に直接ラベルを出し表も併記する */\n  .viz-root {{\n    color-scheme: light;\n    --surface-1: #ffffff;\n    --surface-2: #f2f1ee;\n    --line: #dedcd6;\n    --text-primary: #000000;\n    --text-secondary: #3d3c3a;\n    --muted: #6f6e68;\n    --series-1: #2a78d6; --series-2: #eb6834; --series-3: #1baf7a;\n    --series-4: #eda100; --series-5: #e87ba4; --series-6: #008300;\n    --series-7: #4a3aa7; --series-8: #e34948;\n  }}\n  * {{ box-sizing: border-box; }}\n  body {{ margin: 0; background: var(--surface-1); }}\n  .viz-root {{\n    background: var(--surface-1); color: var(--text-primary);\n    font: 14px/1.5 "Yu Gothic UI", "Hiragino Sans", system-ui, sans-serif;\n    padding: 28px 24px 40px; max-width: 1180px; margin: 0 auto;\n  }}\n  h1 {{ font-size: 19px; margin: 0 0 4px; letter-spacing: .01em; }}\n  .meta {{ color: var(--text-secondary); font-size: 13px; margin: 0 0 2px; }}\n  .note {{ color: var(--muted); font-size: 12px; margin: 0 0 18px; }}\n  .legend {{ display: flex; flex-wrap: wrap; gap: 6px 16px; margin: 0 0 16px; }}\n  .key {{ display: inline-flex; align-items: center; gap: 6px;\n          color: var(--text-secondary); font-size: 12px; }}\n  .key i {{ width: 10px; height: 10px; border-radius: 3px; display: inline-block; }}\n\n  .row {{ display: grid; grid-template-columns: 232px 1fr 118px;\n          gap: 14px; align-items: center; padding: 9px 0;\n          border-top: 1px solid var(--line); }}\n  .team {{ display: flex; gap: 5px; }}\n  .unit {{ width: 52px; }}\n  .art {{ position: relative; width: 52px; height: 52px; border-radius: 7px;\n          overflow: hidden; background: var(--surface-2); }}\n  .art img {{ width: 100%; height: 100%; object-fit: cover; display: block;\n              position: relative; z-index: 1; }}\n  /* アイコンが 404 のときだけ見える。img が載れば下に隠れる */\n  .art .fallback {{ position: absolute; inset: 0; display: flex;\n                    align-items: center; justify-content: center;\n                    font-size: 11px; line-height: 1.15; text-align: center;\n                    color: var(--text-secondary); padding: 2px; }}\n  .art .lc {{ position: absolute; right: 0; bottom: 0; width: 21px; height: 21px;\n              z-index: 2;\n              border-radius: 4px 0 0 0; background: var(--surface-1);\n              object-fit: contain; }}\n  .badge {{ text-align: center; font-size: 10px; color: var(--text-secondary);\n            margin-top: 2px; letter-spacing: .02em; }}\n\n  /* 積み上げの段どうしは 2px あける。塗りが直接触れると境目が読めない */\n  .track {{ display: flex; gap: 2px; align-items: stretch; height: 30px; }}\n  .seg {{ position: relative; min-width: 3px; border-radius: 2px;\n          display: flex; align-items: center; justify-content: flex-end;\n          padding: 0 6px; overflow: visible; }}\n  .seg:first-child {{ border-radius: 4px 2px 2px 4px; }}\n  .seg:last-child {{ border-radius: 2px 4px 4px 2px; }}\n  .seg .v {{ font-size: 11px; color: #fff; font-variant-numeric: tabular-nums;\n             text-shadow: 0 1px 2px rgba(0,0,0,.45); white-space: nowrap; }}\n  .seg:focus-visible {{ outline: 2px solid var(--text-primary); outline-offset: 2px; }}\n  .seg .tip {{ position: absolute; bottom: calc(100% + 8px); left: 50%;\n               transform: translateX(-50%); background: #000000;\n               color: #ffffff; padding: 6px 9px; border-radius: 6px;\n               font-size: 12px; white-space: nowrap; opacity: 0;\n               pointer-events: none; transition: opacity .12s; z-index: 5; }}\n  .seg:hover .tip, .seg:focus-visible .tip {{ opacity: 1; }}\n\n  .total {{ text-align: right; font-variant-numeric: tabular-nums; }}\n  .total b {{ font-size: 16px; display: block; }}\n  .total .pct {{ font-size: 11px; color: var(--text-secondary); }}\n\n  details {{ margin-top: 24px; }}\n  summary {{ cursor: pointer; color: var(--text-secondary); font-size: 13px; }}\n  table {{ border-collapse: collapse; margin-top: 10px; font-size: 12px;\n           font-variant-numeric: tabular-nums; }}\n  th, td {{ border: 1px solid var(--line); padding: 5px 9px; text-align: right; }}\n  th[scope="row"] {{ text-align: left; font-weight: 500; }}\n  thead th {{ color: var(--text-secondary); font-weight: 500; }}\n  .wrap {{ overflow-x: auto; }}\n</style></head>\n<body data-palette=\'{palette}\'>\n<div class="viz-root">\n  <h1>{title}</h1>\n  <p class="meta">{meta}</p>\n  <p class="note">{note}</p>\n  <div class="legend">{legend}</div>\n  <div class="wrap">{rows}</div>\n  <details>\n    <summary>数値で見る</summary>\n    <div class="wrap"><table>\n      <thead><tr><th scope="col">編成</th><th>DPA</th><th>総ダメージ</th>\n      <th>サイクル</th>{table_head}</tr></thead>\n      <tbody>{table_rows}</tbody>\n    </table></div>\n  </details>\n</div>\n</body></html>\n'
