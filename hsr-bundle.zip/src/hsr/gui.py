from __future__ import annotations
import json
import threading
import time
import webbrowser
from datetime import datetime
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from .build.assemble import BuildSpec, build
from .data import loader
from .data.properties import to_stat
from .model.enums import Element, RelicSlot
from .report import ICON_BASE, SERIES_LIGHT, ChartSpec, Member, Row, render
from .engine.rotation import ROTATION_LABELS, ULT_LABELS, auto_label, available_modes, available_ult_modes, policy_for, ult_policy_for
from .screen import SCREEN_STATS, adjusted, screen_values, stats_for
BREAK_TRIAL = True
DEFAULT_TOUGHNESS = 360
DEFAULTS = {'enemies': 3, 'enemy_level': 95, 'enemy_hp': 1000000000, 'enemy_res': 0.2, 'cycles': 2, 'technique': True, 'enemy_attacks': False, 'enemy_hit_energy': False, 'weakness_break': False, 'toughness': DEFAULT_TOUGHNESS}
PRESETS = [{'label': 'トリビー記憶', 'members': ['1415', '1409', '1403', '1413']}, {'label': 'ロビン記憶', 'members': ['1415', '1409', '1512', '1413']}, {'label': 'キャストリス記憶', 'members': ['1409', '1407', '1403', '1413']}, {'label': '刃・不死途', 'members': ['1507', '1504', '1513', '1403']}, {'label': '刃・ギルガメッシュ', 'members': ['1507', '1509', '1403', '1504']}, {'label': '愉悦（火花）', 'members': ['1501', '1506', '8009', '1502']}]
OUT_DIR = loader.REPO_ROOT / 'out'
SUBSTAT_LABELS = {'HPDelta': 'HP', 'AttackDelta': '攻撃力', 'DefenceDelta': '防御力', 'HPAddedRatio': 'HP%', 'AttackAddedRatio': '攻撃%', 'DefenceAddedRatio': '防御%', 'SpeedDelta': '速度', 'CriticalChanceBase': '会心率', 'CriticalDamageBase': '会心ダメージ', 'StatusProbabilityBase': '効果命中', 'StatusResistanceBase': '効果抵抗', 'BreakDamageAddedRatioBase': '撃破特効'}

def _gear_of(built) -> dict:
    all_sets = loader.relic_sets()
    sets = []
    for set_id, count in sorted(built.relic_sets.items(), key=lambda kv: -kv[1]):
        info = all_sets.get(str(set_id)) or {}
        sets.append({'id': str(set_id), 'name': info.get('name') or str(set_id), 'count': int(count)})
    sub_sheet = built.sources.get('遺物サブ')
    subs = []
    for key, rolls in sorted(built.substat_rolls.items(), key=lambda kv: -kv[1]):
        stat = to_stat(key)
        value = float(sub_sheet[stat]) if sub_sheet is not None else 0.0
        subs.append({'key': key, 'label': SUBSTAT_LABELS.get(key, key), 'rolls': int(rolls), 'value': value, 'percent': not key.endswith('Delta')})
    return {'sets': sets, 'substats': subs}
EDITABLE_SLOTS = {'FOOT': '足', 'NECK': '球', 'OBJECT': '縄'}
MAIN_STAT_LABELS = {'HPAddedRatio': 'HP%', 'AttackAddedRatio': '攻撃%', 'DefenceAddedRatio': '防御%', 'SpeedDelta': '速度', 'BreakDamageAddedRatioBase': '撃破', 'SPRatioBase': 'EP効率', 'PhysicalAddedRatio': '物理', 'FireAddedRatio': '炎', 'IceAddedRatio': '氷', 'ThunderAddedRatio': '雷', 'WindAddedRatio': '風', 'QuantumAddedRatio': '量子', 'ImaginaryAddedRatio': '虚数'}

@lru_cache(maxsize=1)
def options() -> dict:
    from .content.base import REGISTRY
    from .content.equipment import LC_REGISTRY
    implemented_lcs = {str(lid) for lid in LC_REGISTRY}
    characters: list[dict] = []
    seen: set[str] = set()
    lc_ids: set[str] = set()
    for cid in sorted(REGISTRY):
        char = loader.character(cid)
        if char['name'] in seen:
            continue
        seen.add(char['name'])
        impl = REGISTRY[cid]
        default_built = build(BuildSpec(character=cid))
        default_lc = default_built.light_cone_id
        choices = _lc_choices(char, default_lc, implemented_lcs)
        lc_ids.update(choices)
        characters.append({'id': str(cid), 'name': char['name'], 'path': char['path'], 'element': char['element'], 'fixed_eidolon': getattr(impl, 'fixed_eidolon', None), 'fixed_superimpose': getattr(impl, 'fixed_superimpose', None), 'default_lc': str(default_lc) if default_lc else None, 'lc_choices': choices, 'main_stats': {slot: default_built.main_stats[RelicSlot(slot)] for slot in EDITABLE_SLOTS}, 'main_stat_choices': _main_stat_choices(char), 'rotations': [[mode, f'既定（{auto_label(impl)}）' if mode == 'auto' else ROTATION_LABELS[mode]] for mode in available_modes(impl)], 'ults': [[mode, ULT_LABELS[mode]] for mode in available_ult_modes(impl)]})
    light_cones = {}
    for lid in sorted(lc_ids):
        lc = loader.light_cone(lid)
        light_cones[lid] = {'name': lc['name'], 'rarity': lc['rarity'], 'path': lc['path']}
    return {'characters': characters, 'light_cones': light_cones, 'presets': PRESETS, 'defaults': DEFAULTS, 'break_trial': BREAK_TRIAL, 'icon_base': ICON_BASE, 'palette': SERIES_LIGHT, 'slots': EDITABLE_SLOTS, 'main_stat_labels': MAIN_STAT_LABELS, 'app': app_info(), 'screen_stats': [{'key': st.key, 'label': st.label, 'percent': st.percent} for st in SCREEN_STATS]}

def app_info() -> dict:
    data_version = str(loader.index().get('version', '?'))
    return {'version': APP_VERSION, 'build': _app_version(), 'data_version': data_version, 'data_version_short': '.'.join(data_version.split('.')[:2])}
APP_VERSION = '0.9'

@lru_cache(maxsize=1)
def _app_version() -> str:
    try:
        from . import _build_info
        return str(_build_info.VERSION)
    except ImportError:
        pass
    import subprocess
    try:
        rev = subprocess.run(['git', 'rev-parse', '--short', 'HEAD'], cwd=loader.REPO_ROOT, capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return 'dev'
    return rev.stdout.strip() if rev.returncode == 0 and rev.stdout.strip() else 'dev'

def _main_stat_choices(char: dict) -> dict[str, list[str]]:
    table = loader.relic_affixes()['main']['5']
    own = f'{char['element']}AddedRatio'
    out: dict[str, list[str]] = {}
    for slot in EDITABLE_SLOTS:
        props = list(table[slot])
        if slot == 'NECK':
            props = [x for x in props if not x.endswith('AddedRatio') or x == own or x in ('HPAddedRatio', 'AttackAddedRatio', 'DefenceAddedRatio')]
        out[slot] = props
    return out

def _lc_choices(char: dict, default_lc, implemented: set[str]) -> list[str]:
    ids = [str(default_lc)] if default_lc else []
    ids += [str(x) for x in char['recommend'].get('light_cones') or []]
    ids += sorted((lid for lid in implemented if loader.light_cone(lid)['path'] == char['path']))
    out: list[str] = []
    for lid in ids:
        if lid and lid not in out:
            out.append(lid)
    return out

def _settings(payload: dict) -> dict:
    s = {**DEFAULTS, **(payload.get('settings') or {})}
    s['enemies'] = int(s['enemies'])
    s['enemy_level'] = int(s['enemy_level'])
    s['enemy_hp'] = float(s['enemy_hp'])
    s['enemy_res'] = float(s['enemy_res'])
    s['cycles'] = int(s['cycles'])
    for key in ('technique', 'enemy_attacks', 'enemy_hit_energy', 'weakness_break'):
        s[key] = bool(s[key])
    s['toughness'] = float(s.get('toughness') or 0)
    if not BREAK_TRIAL:
        s['weakness_break'] = False
    if not s['weakness_break']:
        s['toughness'] = 0.0
    if s['toughness'] < 0 or s['toughness'] > 10000:
        raise ValueError(f'靭性は 0〜10000 です: {s['toughness']}')
    if not 1 <= s['enemies'] <= 5:
        raise ValueError(f'敵の数は 1〜5 体です: {s['enemies']}')
    if not 1 <= s['cycles'] <= 20:
        raise ValueError(f'サイクル数は 1〜20 です: {s['cycles']}')
    return s

def _run_rows(payload: dict) -> tuple[list[Row], list[dict], dict]:
    s = _settings(payload)
    rows: list[Row] = []
    extras: list[dict] = []
    for t in payload.get('teams') or []:
        if not t.get('members'):
            continue
        members, _, result, gear = _run_team(t, s)
        rows.append(Row(label=_team_label(t, members), members=members, dpa=result.dpa, total_damage=result.total_damage, cycles=result.cycles, breakdown=dict(result.damage_by_character)))
        notes = sorted({line.text.removeprefix('※ ').strip() for line in result.log if '未実装' in line.text})
        extras.append({'sp_balance': result.sp_balance, 'notes': notes, 'custom_notes': _custom_notes(t, members), 'gear': gear})
    return (rows, extras, s)

def _team_label(t: dict, members: list[Member]) -> str:
    label = (t.get('label') or '').strip()
    if label:
        return label
    label = ' / '.join((m.name for m in members))
    changed = _custom_notes(t, members)
    return label + (f'（{' ／ '.join(changed)}）' if changed else '')

def _custom_notes(t: dict, members: list[Member]) -> list[str]:
    notes = []
    for m_in, m in zip(t.get('members') or [], members):
        parts = [f'{EDITABLE_SLOTS[slot]} {MAIN_STAT_LABELS.get(prop, prop)}' for slot, prop in _changed_main_stats(m_in).items()]
        rot = m_in.get('rot') or 'auto'
        if rot != 'auto':
            parts.append(f'ローテ {ROTATION_LABELS.get(rot, rot)}')
        for key, value in _adjust_of(m_in).items():
            stat = _SCREEN_BY_KEY[key]
            parts.append(f'{stat.label} {value * 100:.1f}%' if stat.percent else f'{stat.label} {value:,.1f}')
        if parts:
            notes.append(f'{m.name}: ' + '・'.join(parts))
    return notes
_SCREEN_BY_KEY = {st.key: st for st in SCREEN_STATS}
_ADJUST_LIMIT = {False: 1000000.0, True: 100.0}

def _adjust_of(m: dict) -> dict[str, float]:
    import math
    adj = m.get('adj') or {}
    if not isinstance(adj, dict):
        raise ValueError('ステータス調整の指定が読めません')
    out: dict[str, float] = {}
    for key, value in adj.items():
        stat = _SCREEN_BY_KEY.get(key)
        if stat is None:
            raise ValueError(f'調整できないステータスです: {key}')
        try:
            v = float(value)
        except (TypeError, ValueError):
            raise ValueError(f'{stat.label} の値が数字ではありません: {value}') from None
        if not math.isfinite(v) or not 0 <= v <= _ADJUST_LIMIT[stat.percent]:
            raise ValueError(f'{stat.label} の値が範囲外です: {value}')
        out[key] = v
    return out

def _main_stats_of(m: dict) -> dict[RelicSlot, str]:
    ms = m.get('ms') or {}
    if not isinstance(ms, dict):
        raise ValueError('メインステの指定が読めません')
    out: dict[RelicSlot, str] = {}
    choices = None
    for slot, prop in ms.items():
        if slot not in EDITABLE_SLOTS:
            raise ValueError(f'メインステを変えられる部位は {'・'.join(EDITABLE_SLOTS.values())} だけです: {slot}')
        if choices is None:
            choices = _main_stat_choices(loader.character(str(m['id'])))
        if prop not in choices[slot]:
            label = MAIN_STAT_LABELS.get(prop, prop)
            raise ValueError(f'{EDITABLE_SLOTS[slot]}に {label} は選べません')
        out[RelicSlot(slot)] = prop
    return out

def _changed_main_stats(m: dict) -> dict[str, str]:
    ms = m.get('ms') or {}
    if not ms:
        return {}
    default = build(BuildSpec(character=str(m['id']))).main_stats
    return {slot: prop for slot, prop in ms.items() if default[RelicSlot(slot)] != prop}

def _member_spec(m: dict) -> BuildSpec:
    eidolon = int(m.get('e', 0))
    superimpose = int(m.get('s', 1))
    if not 0 <= eidolon <= 6:
        raise ValueError(f'星魂は 0〜6 です: {eidolon}')
    if not 1 <= superimpose <= 5:
        raise ValueError(f'重ね合わせは 1〜5 です: {superimpose}')
    return BuildSpec(character=str(m['id']), eidolon=eidolon, superimpose=superimpose, light_cone=str(m['lc']) if m.get('lc') else None, main_stats=_main_stats_of(m))

def member_screen(payload: dict) -> dict:
    m = payload.get('member') or {}
    if not m.get('id'):
        raise ValueError('キャラが指定されていません')
    built = build(_member_spec(m))
    values = screen_values(built)
    return {'name': built.name, 'stats': [{'key': st.key, 'label': st.label, 'percent': st.percent, 'value': values[st.key]} for st in stats_for(built)]}

def _run_team(t: dict, s: dict):
    from .engine.battle import Battle
    from .engine.entity import Character, make_enemies
    members_in = t.get('members') or []
    if not members_in:
        raise ValueError('編成が空です')
    if len(members_in) > 4:
        raise ValueError('編成は 4 人までです')
    team, members = ([], [])
    gear = []
    policies = {}
    ult_policies = {}
    for i, m in enumerate(members_in):
        built = build(adjusted(_member_spec(m), _adjust_of(m)))
        policy = _policy_of(m, built.id)
        if policy is not None:
            policies[built.id] = policy
        ult = _ult_policy_of(m, built.id)
        if ult is not None:
            ult_policies[built.id] = ult
        team.append(Character(built=built, position=i))
        gear.append(_gear_of(built))
        members.append(Member(char_id=built.id, name=built.name, eidolon=built.eidolon, light_cone_id=built.light_cone_id, superimpose=built.superimpose))
    battle = Battle(team=team, enemies=make_enemies(s['enemies'], level=s['enemy_level'], hp=s['enemy_hp'], res=s['enemy_res'], toughness=s['toughness'], weaknesses=set(Element) if s['toughness'] else set()), max_cycles=s['cycles'], use_technique=s['technique'], enemy_attacks=s['enemy_attacks'], enemy_hit_energy=s['enemy_hit_energy'], policy=policies, ult_policy=ult_policies)
    return (members, battle, battle.run(), gear)

def _policy_of(m: dict, char_id: str):
    from .content.base import REGISTRY
    mode = m.get('rot') or 'auto'
    impl = REGISTRY.get(str(char_id))
    if mode not in available_modes(impl):
        raise ValueError(f'このキャラは「{ROTATION_LABELS.get(mode, mode)}」を選べません')
    return policy_for(mode, impl)

def _ult_policy_of(m: dict, char_id: str):
    from .content.base import REGISTRY
    mode = m.get('ult') or 'asap'
    impl = REGISTRY.get(str(char_id))
    if mode not in available_ult_modes(impl):
        raise ValueError(f'このキャラは「{ULT_LABELS.get(mode, mode)}」を選べません')
    return ult_policy_for(mode, impl)
UPGRADE_MAX_EXTRA = 10

def upgrade(payload: dict) -> dict:
    from .invest import Unit, from_current, is_free, upgrade_candidates, _normalize_lc
    s = _settings(payload)
    t = payload.get('team') or {}
    members_in = t.get('members') or []
    if not members_in:
        raise ValueError('編成が空です')
    max_extra = int(payload.get('max_extra', 6))
    if not 1 <= max_extra <= UPGRADE_MAX_EXTRA:
        raise ValueError(f'追加コストは 1〜{UPGRADE_MAX_EXTRA} です: {max_extra}')
    units = []
    for m in members_in:
        built = build(_member_spec(m))
        units.append(Unit(name=built.name, char_id=built.id, eidolon=built.eidolon, superimpose=built.superimpose, free=is_free(built.id), light_cone=_normalize_lc(built.id, built.light_cone_id)))
    start = from_current(units)

    def as_members(team) -> list[dict]:
        out = []
        for m, u in zip(members_in, team):
            lc = None if u.light_cone is None else u.light_cone
            out.append({**m, 'e': u.eidolon, 's': u.superimpose, 'lc': lc if lc is not None else _default_lc(u.char_id)})
        return out

    def evaluate(team) -> float:
        _, _, result, _gear = _run_team({'members': as_members(team)}, s)
        return result.dpa
    base = evaluate(start)
    found = upgrade_candidates(start, evaluate, max_extra)

    def describe(team) -> list[str]:
        changes = []
        for before, after in zip(start, team):
            if after.eidolon != before.eidolon:
                changes.append(f'{after.name} E{before.eidolon}→E{after.eidolon}')
            if before.light_cone is not None and after.light_cone is None:
                changes.append(f'{after.name} モチーフ光円錐 S{after.superimpose}')
            elif after.superimpose != before.superimpose:
                changes.append(f'{after.name} S{before.superimpose}→S{after.superimpose}')
        return changes
    rows, best_so_far = ([], base)
    for cost in range(1, max_extra + 1):
        cands = []
        for dpa, team in found.get(cost, []):
            cands.append({'dpa': dpa, 'gain': dpa / base - 1 if base else 0.0, 'changes': describe(team), 'team': as_members(team), 'members': [{'char_id': u.char_id, 'name': u.name, 'badge': f'E{u.eidolon}S{u.superimpose}'} for u in team]})
        top = cands[0]['dpa'] if cands else 0.0
        rows.append({'cost': cost, 'candidates': cands, 'beats_cheaper': top > best_so_far})
        best_so_far = max(best_so_far, top)
    return {'label': _team_label(t, [Member(char_id=u.char_id, name=u.name, eidolon=u.eidolon, light_cone_id=None, superimpose=u.superimpose) for u in start]), 'start': {'dpa': base, 'members': [{'char_id': u.char_id, 'name': u.name, 'badge': f'E{u.eidolon}S{u.superimpose}', 'free': u.free} for u in start]}, 'rows': rows, 'settings': s}

@lru_cache(maxsize=64)
def _default_lc(char_id: str) -> str | None:
    lc = build(BuildSpec(character=char_id)).light_cone_id
    return str(lc) if lc else None

def battle_log(payload: dict) -> dict:
    s = _settings(payload)
    team = payload.get('team') or {}
    members, battle, result, _gear = _run_team(team, s)
    return {'label': _team_label(team, members), 'total_damage': result.total_damage, 'turns': [{'turn': n, 'actor': name, 'av': av} for n, (name, av) in sorted(battle.turn_actors.items())], 'lines': [{'av': ln.av, 'cycle': ln.cycle, 'turn': ln.turn, 'actor': ln.actor, 'text': ln.text, 'damage': ln.damage} for ln in result.log]}

def simulate(payload: dict) -> dict:
    started = time.perf_counter()
    rows, extras, s = _run_rows(payload)
    out = []
    for row, extra in zip(rows, extras):
        out.append({'label': row.label, 'dpa': row.dpa, 'total_damage': row.total_damage, 'cycles': row.cycles, 'breakdown': row.breakdown, 'members': [{'char_id': m.char_id, 'name': m.name, 'badge': m.badge, 'light_cone_id': m.light_cone_id} for m in row.members], **extra})
    return {'rows': out, 'settings': s, 'elapsed_ms': round((time.perf_counter() - started) * 1000)}

def export(payload: dict, *, out_dir: Path | None=None, png: bool=True) -> dict:
    rows, _, s = _run_rows(payload)
    if not rows:
        raise ValueError('書き出す編成がありません')
    out_dir = Path(out_dir) if out_dir else OUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    html_path = out_dir / f'gui_{stamp}.html'
    note = ' ／ '.join(['秘技あり' if s['technique'] else '秘技なし', f'敵の耐性 {s['enemy_res']:.0%}', *(['敵の攻撃あり'] if s['enemy_attacks'] else []), *([f'靭性 {s['toughness']:.0f}（全属性弱点）'] if s['weakness_break'] else [])])
    chart = ChartSpec(title=(payload.get('title') or '編成比較').strip(), enemy_level=s['enemy_level'], enemy_count=s['enemies'], enemy_hp=s['enemy_hp'], cycles=s['cycles'], rows=rows, note=note)
    html_path.write_text(render(chart), encoding='utf-8')
    result = {'html': str(html_path), 'png': None, 'png_error': None}
    if png:
        from .shot import PlaywrightMissing, html_to_png
        try:
            result['png'] = str(html_to_png(html_path, html_path.with_suffix('.png')))
        except PlaywrightMissing as exc:
            result['png_error'] = str(exc)
    return result
API = {'options': lambda payload: options(), 'simulate': simulate, 'log': battle_log, 'screen': member_screen, 'upgrade': upgrade, 'export': export}
USER_ERRORS = (KeyError, ValueError, NotImplementedError)

def dispatch(name: str, payload: dict) -> dict:
    route = API.get(name)
    if route is None:
        raise ValueError(f'ありません: {name}')
    return route(payload)

def dispatch_json(name: str, payload_json: str, *, allow_export: bool=False) -> str:
    try:
        if name == 'export' and (not allow_export):
            raise ValueError('画像の書き出しはローカル版（hsr gui）だけで使えます')
        data = dispatch(name, json.loads(payload_json or '{}'))
    except USER_ERRORS as exc:
        return json.dumps({'error': str(exc).strip('\'"')}, ensure_ascii=False)
    return json.dumps({'ok': data}, ensure_ascii=False)

class Handler(BaseHTTPRequestHandler):

    def do_GET(self) -> None:
        path = self.path.split('?', 1)[0]
        if path in ('/', '/index.html'):
            self._send(200, PAGE.encode('utf-8'), 'text/html; charset=utf-8')
        elif path == '/api/options':
            self._json(200, options())
        else:
            self._json(404, {'error': 'ありません'})

    def do_POST(self) -> None:
        name = self.path.removeprefix('/api/')
        if not self.path.startswith('/api/') or name not in API:
            self._json(404, {'error': 'ありません'})
            return
        length = int(self.headers.get('Content-Length') or 0)
        try:
            payload = json.loads(self.rfile.read(length) or b'{}')
        except json.JSONDecodeError:
            self._json(400, {'error': '送られてきた JSON が読めません'})
            return
        try:
            self._json(200, dispatch(name, payload))
        except USER_ERRORS as exc:
            self._json(400, {'error': str(exc).strip('\'"')})

    def log_message(self, format: str, *args) -> None:
        pass

    def _json(self, status: int, data: dict) -> None:
        self._send(status, json.dumps(data, ensure_ascii=False).encode('utf-8'), 'application/json; charset=utf-8')

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

def serve(port: int=8765, *, open_browser: bool=True) -> None:
    server = None
    for p in range(port, port + 20):
        try:
            server = HTTPServer(('127.0.0.1', p), Handler)
            break
        except OSError:
            continue
    if server is None:
        raise OSError(f'ポート {port}〜{port + 19} がすべて使用中です')
    url = f'http://127.0.0.1:{server.server_address[1]}/'
    print(f'GUI を起動しました: {url}')
    print('止めるときは Ctrl+C')
    options()
    if open_browser:
        threading.Timer(0.3, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n止めました')
    finally:
        server.server_close()
PAGE = '<!doctype html>\n<html lang="ja"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>hsr-sim 編成くらべ</title>\n<style>\n  /* 白背景・黒文字に固定（`hsr chart` と同じ。見比べる用途なので環境で変えない）。\n     配色は data-viz の既定カテゴリカルパレット（report.py と同じ並び） */\n  :root {\n    color-scheme: light;\n    --surface-1: #ffffff; --surface-2: #f2f1ee; --line: #dedcd6;\n    --text-primary: #000000; --text-secondary: #3d3c3a; --muted: #6f6e68;\n    --danger: #a3261c;\n  }\n  * { box-sizing: border-box; }\n  [hidden] { display: none !important; }\n  body { margin: 0; background: var(--surface-1); color: var(--text-primary);\n         font: 14px/1.5 "Yu Gothic UI", "Hiragino Sans", system-ui, sans-serif; }\n  .app { max-width: 1240px; margin: 0 auto; padding: 20px 20px 56px; }\n  header { display: flex; flex-wrap: wrap; align-items: baseline; gap: 4px 16px; margin: 0 0 12px; }\n  h1 { font-size: 19px; margin: 0; }\n  h2 { font-size: 15px; margin: 0; }\n  .sub { color: var(--muted); font-size: 12px; }\n\n  .settings { display: flex; flex-wrap: wrap; gap: 10px 20px; align-items: center;\n              padding: 10px 14px; background: var(--surface-2); border-radius: 10px; margin: 0 0 18px; }\n  .field { display: inline-flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-secondary); }\n  .seg-ctl { display: inline-flex; border: 1px solid var(--line); border-radius: 7px; overflow: hidden; background: #fff; }\n  .seg-ctl button { border: 0; background: none; padding: 4px 11px; font: inherit; cursor: pointer; color: var(--text-primary); }\n  .seg-ctl button + button { border-left: 1px solid var(--line); }\n  .seg-ctl button[aria-pressed="true"] { background: var(--text-primary); color: #fff; }\n  select, input[type="text"] { font: inherit; padding: 4px 6px; border: 1px solid var(--line);\n                               border-radius: 6px; background: #fff; color: inherit; min-width: 0; }\n  input[type="checkbox"] { width: 16px; height: 16px; accent-color: #000; }\n  button.btn { font: inherit; padding: 6px 13px; border: 1px solid var(--line); border-radius: 7px;\n               background: #fff; cursor: pointer; color: inherit; }\n  button.btn:hover { background: var(--surface-2); }\n  button.btn.primary { background: #000; color: #fff; border-color: #000; }\n  button.icon { border: 0; background: none; cursor: pointer; color: var(--text-secondary);\n                font: inherit; font-size: 12px; padding: 3px 7px; border-radius: 5px; }\n  button.icon:hover { background: var(--surface-2); color: #000; }\n  :focus-visible { outline: 2px solid #000; outline-offset: 2px; }\n\n  .section-head { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 12px; margin: 0 0 10px; }\n  .section-head .grow { flex: 1; }\n  .teams { display: flex; flex-direction: column; gap: 10px; margin: 0 0 26px; }\n  .card { border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px 12px; }\n  .card-head { display: flex; align-items: center; gap: 6px; margin: 0 0 10px; }\n  .card-head .no { font-size: 12px; color: var(--muted); width: 18px; text-align: right; }\n  .card-head input { flex: 1; }\n  .slots { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }\n  .slot { display: grid; grid-template-columns: 52px minmax(0, 1fr); gap: 8px; align-items: start; }\n  .slot .fields { display: flex; flex-direction: column; gap: 4px; min-width: 0; }\n  .slot .fields select { width: 100%; }\n  .slot .es { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }\n  .slot .ms { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px; }\n  .slot .ms label { display: flex; flex-direction: column; font-size: 10px; color: var(--muted); min-width: 0; }\n  .slot .ms select { width: 100%; font-size: 12px; padding: 3px 2px; }\n  .slot .ms select.changed { border-color: #000; font-weight: 600; }\n\n  .art { position: relative; width: 52px; height: 52px; border-radius: 8px; overflow: hidden; background: var(--surface-2); }\n  .art img { width: 100%; height: 100%; object-fit: cover; display: block; position: relative; z-index: 1; }\n  .art .fallback { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;\n                   font-size: 11px; line-height: 1.15; text-align: center; color: var(--text-secondary); padding: 2px; }\n  .art .lc { position: absolute; right: 0; bottom: 0; width: 21px; height: 21px; z-index: 2;\n             border-radius: 4px 0 0 0; background: #fff; object-fit: contain; }\n\n  .status { font-size: 12px; color: var(--muted); min-height: 18px; }\n  .status.error { color: var(--danger); }\n  .meta { color: var(--text-secondary); font-size: 13px; margin: 0 0 2px; }\n  .hint { color: var(--muted); font-size: 12px; margin: 0 0 12px; }\n  .legend { display: flex; flex-wrap: wrap; gap: 6px 16px; margin: 0 0 12px; }\n  .key { display: inline-flex; align-items: center; gap: 6px; color: var(--text-secondary); font-size: 12px; }\n  .key i { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }\n  .row { display: grid; grid-template-columns: 250px minmax(0, 1fr) 118px; gap: 14px; align-items: center;\n         padding: 10px 0; border-top: 1px solid var(--line); }\n  .rlabel { font-size: 12px; color: var(--text-secondary); margin: 0 0 4px; }\n  .units { display: flex; gap: 5px; }\n  .unit { width: 52px; }\n  .badge { text-align: center; font-size: 10px; color: var(--text-secondary); margin-top: 2px; }\n  .track { display: flex; gap: 2px; align-items: stretch; height: 30px; }\n  .seg { position: relative; min-width: 3px; border-radius: 2px; display: flex; align-items: center;\n         justify-content: flex-end; padding: 0 6px; }\n  .seg:first-child { border-radius: 4px 2px 2px 4px; }\n  .seg:last-child { border-radius: 2px 4px 4px 2px; }\n  .seg .v { font-size: 11px; color: #fff; font-variant-numeric: tabular-nums;\n            text-shadow: 0 1px 2px rgba(0,0,0,.45); white-space: nowrap; }\n  .seg .tip { position: absolute; bottom: calc(100% + 8px); left: 50%; transform: translateX(-50%);\n              background: #000; color: #fff; padding: 6px 9px; border-radius: 6px; font-size: 12px;\n              white-space: nowrap; opacity: 0; pointer-events: none; transition: opacity .12s; z-index: 5; }\n  .seg:hover .tip, .seg:focus-visible .tip { opacity: 1; }\n  .total { text-align: right; font-variant-numeric: tabular-nums; }\n  .total b { font-size: 17px; display: block; }\n  .total .pct { font-size: 11px; color: var(--text-secondary); }\n  .msnote { margin: 4px 0 0; font-size: 11px; color: var(--text-secondary); }\n  .gear { margin: 6px 0 0; font-size: 12px; color: var(--text-secondary); }\n  .gear summary { cursor: pointer; color: var(--muted); }\n  .gear table { border-collapse: collapse; margin-top: 4px; }\n  .gear td { padding: 1px 10px 1px 0; white-space: nowrap; }\n  .gear td.num { text-align: right; font-variant-numeric: tabular-nums; }\n  .gear .who { font-weight: 700; padding-top: 4px; }\n  .gear .sets { color: var(--muted); }\n  .notes { margin: 6px 0 0; font-size: 12px; color: var(--danger); }\n  .notes summary { cursor: pointer; }\n  .notes ul { margin: 4px 0 0; padding-left: 18px; color: var(--text-secondary); }\n  details.table { margin-top: 18px; }\n  details.table summary { cursor: pointer; color: var(--text-secondary); font-size: 13px; }\n  table { border-collapse: collapse; margin-top: 10px; font-size: 12px; font-variant-numeric: tabular-nums; }\n  th, td { border: 1px solid var(--line); padding: 5px 9px; text-align: right; }\n  th[scope="row"] { text-align: left; font-weight: 500; }\n  thead th { color: var(--text-secondary); font-weight: 500; }\n  .wrap { overflow-x: auto; }\n  .slot .fields select.rot { font-size: 12px; }\n  .slot .fields select.rot.changed { border-color: #000; font-weight: 600; }\n  .adj-toggle { font-size: 11px; padding: 2px 6px; justify-self: start; }\n  .adj-toggle.on { border-color: #000; font-weight: 600; }\n  .adj { border: 1px solid var(--line); border-radius: 8px; padding: 6px 8px; background: var(--surface-2); }\n  .adj .adj-grid { display: grid; grid-template-columns: minmax(0, 1fr) 76px 14px; gap: 3px 6px; align-items: center; font-size: 12px; }\n  .adj .adj-grid span.l { color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }\n  .adj .adj-grid input { width: 100%; font: inherit; font-size: 12px; padding: 2px 4px; border: 1px solid var(--line); border-radius: 5px; text-align: right; font-variant-numeric: tabular-nums; }\n  .adj .adj-grid input.changed { border-color: #000; font-weight: 600; }\n  .adj .adj-foot button { white-space: nowrap; }\n  .adj .adj-foot { display: flex; justify-content: space-between; align-items: center; gap: 6px; margin-top: 6px; font-size: 11px; color: var(--muted); }\n  .io { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }\n  footer.app-foot { margin-top: 28px; font-size: 11px; color: var(--muted); line-height: 1.8; }\n  footer.app-foot p { margin: 0 0 4px; }\n  footer.app-foot a { color: inherit; }\n  footer.app-foot .ver { opacity: .8; }\n  .caveats { margin-top: 24px; font-size: 12px; color: var(--muted); }\n  .caveats summary { cursor: pointer; font-weight: 700; }\n  .caveats ul { margin: 8px 0 0; padding-left: 1.2em; }\n  .caveats li { margin-bottom: 4px; }\n  .caveats b { color: var(--fg); }\n  .upgrade-btn { margin-top: 6px; font-size: 12px; padding: 3px 9px; }\n  #upgrade { margin: 22px 0 0; border: 1px solid var(--line); border-radius: 12px; padding: 12px 14px; }\n  #upgrade .up-head { display: flex; flex-wrap: wrap; gap: 8px 14px; align-items: center; margin: 0 0 6px; }\n  #upgrade .up-head h2 { flex: 1; min-width: 12em; }\n  table.up { width: 100%; margin-top: 8px; }\n  table.up td, table.up th { text-align: right; vertical-align: top; }\n  table.up td.c, table.up th.c { text-align: left; }\n  table.up tr.first td { border-top: 2px solid var(--line); }\n  table.up tr.top td { font-weight: 600; }\n  table.up .chg { display: block; }\n  table.up .weak { display: block; font-weight: 400; font-size: 11px; color: var(--muted); }\n  details.battlelog { margin: 0 0 6px; }\n  details.battlelog > summary { cursor: pointer; color: var(--text-secondary); font-size: 12px; padding: 2px 0; }\n  .log-ctl { display: flex; flex-wrap: wrap; gap: 6px 14px; align-items: center; margin: 6px 0; font-size: 12px; }\n  .log-ctl input[type="text"] { width: 200px; }\n  .log-scroll { max-height: 520px; overflow: auto; border: 1px solid var(--line); border-radius: 8px; }\n  table.log { margin: 0; width: 100%; font-size: 12px; }\n  table.log th, table.log td { border: 0; border-bottom: 1px solid var(--surface-2); padding: 2px 8px; }\n  table.log thead th { position: sticky; top: 0; background: #fff; border-bottom: 1px solid var(--line); z-index: 1; }\n  table.log td, table.log th { width: 1%; white-space: nowrap; }\n  table.log td.t, table.log th.t { width: auto; text-align: left; white-space: pre-wrap; }\n  table.log td.a { text-align: left; white-space: nowrap; }\n  table.log tr.turn td { background: var(--surface-2); text-align: left; font-weight: 600; color: #000; }\n  table.log tr.dmg td.d { font-weight: 600; }\n  .export { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin: 16px 0 0; }\n  .export input { width: 220px; }\n\n  @media (max-width: 980px) {\n    .slots { grid-template-columns: repeat(2, minmax(0, 1fr)); }\n    .row { grid-template-columns: minmax(0, 1fr) 100px; }\n    .row .track { grid-column: 1 / -1; order: 3; }\n  }\n  @media (max-width: 520px) {\n    .slots { grid-template-columns: minmax(0, 1fr); }\n  }\n</style></head>\n<body>\n<div class="app">\n  <header>\n    <h1>hsr-sim 編成くらべ</h1>\n    <span class="sub">キャラ・凸・光円錐・敵の数を切り替えると、その場で計算し直します</span>\n  </header>\n\n  <div class="settings" id="settings" aria-label="戦闘の条件"></div>\n\n  <div class="section-head">\n    <h2>編成</h2>\n    <span class="grow"></span>\n    <div class="io">\n      <button class="btn" id="save-file" title="編成と条件を JSON ファイルに保存">保存</button>\n      <button class="btn" id="load-file" title="保存した JSON ファイルを読み込む（いまの編成は置き換わります）">読み込み</button>\n      <input type="file" id="load-input" accept="application/json,.json" hidden>\n      <button class="btn" id="share" title="いまの編成と条件を入れたリンクをコピー">共有リンクをコピー</button>\n    </div>\n    <select id="preset" aria-label="プリセットから追加"></select>\n    <button class="btn" id="add">＋ 空の編成を追加</button>\n  </div>\n  <p class="status" id="io-status" role="status" aria-live="polite"></p>\n  <div class="teams" id="teams"></div>\n\n  <div class="section-head">\n    <h2>結果</h2>\n    <span class="status" id="status" role="status" aria-live="polite"></span>\n  </div>\n  <div id="results"></div>\n  <section id="upgrade" hidden aria-live="polite"></section>\n\n  <div class="export" id="export-box">\n    <input type="text" id="title" placeholder="画像のタイトル（例: 刃まわりの比較）" aria-label="書き出す画像のタイトル">\n    <button class="btn primary" id="export">画像で書き出す</button>\n    <span class="status" id="export-status" role="status" aria-live="polite"></span>\n  </div>\n  <details class="caveats">\n    <summary>この計算でやっていないこと</summary>\n    <ul>\n      <li><b>敵は倒れません。</b> HP を高くして殴り続けるので、弱点撃破・撃破ダメージ・超撃破は入れていません。\n        「敵を倒したら〜」「弱点撃破したら〜」で伸びるキャラ（不死途の撃破連鎖、長夜月の星魂 4、\n        キャストリスの星魂 6 など）は、そのぶん低く出ます</li>\n      <li><b>敵は既定では攻撃してきません。</b> 被弾で増える EP や、挑発・被ダメージ軽減・\n        バリア・治癒の価値は数字に出ません（「敵の攻撃」を入にすると一部は入ります）</li>\n      <li><b>敵はデバフを撒きません。</b> デバフ解除や効果抵抗を持つキャラは、そのぶんが効きません</li>\n      <li>味方は戦闘不能になりません。復活や「HP が 0 になっても倒れない」も効きません</li>\n      <li>会心は期待値で計算しています（乱数を振らず、会心率 × 会心ダメージで均します）</li>\n      <li id="caveat-break" hidden><b>弱点撃破は試験中です。</b>\n        敵 3 体は同じ靭性・全属性弱点で揃えています。撃破の行動遅延は 25% 固定、\n        「弱点撃破状態の敵に会心率アップ」は<b>撃破中の敵が 1 体でもいる間ずっと</b>\n        乗る近似です。超撃破と、撃破の属性別効果（裂傷・燃焼・纏縛など）はまだありません</li>\n    </ul>\n    <p>キャラごとの細かい未実装は、結果の行にある「未実装」の注記に出ます。</p>\n  </details>\n  <footer class="app-foot">\n    <p><b>非公式のファンメイドツールです。</b>個人が趣味で作ったもので、\n      HoYoverse や公式とは関係ありません。</p>\n    <p>数値は<b>自作シミュレータの計算値</b>です。実機と一致するとは限りません。\n      前提は上の「この計算でやっていないこと」を見てください。</p>\n    <p>キャラクターのアイコンは\n      <a href="https://github.com/Mar-7th/StarRailRes" target="_blank" rel="noopener noreferrer">StarRailRes</a>\n      のものを使わせてもらっています。ゲーム内の名称・画像は HoYoverse に帰属します。</p>\n    <p>間違いを見つけたら\n      <a href="https://x.com/houryu_ji" target="_blank" rel="noopener noreferrer">@houryu_ji</a>\n      まで教えてもらえると助かります。</p>\n    <p class="ver" id="app-foot-ver"></p>\n  </footer>\n</div>\n\n<script>\n"use strict";\nconst STORE = "hsr-gui-v1";\nconst state = { opts: null, teams: [], settings: {}, results: null,\n                /* 結果を出したときの編成と条件。ログはこれで回し直す（画面を触った後でもずれない） */\n                ran: null, logs: {}, openLogs: new Set(),\n                /* 手動調整の欄を開いているキャラ（"編成番号-枠番号"） */\n                openAdj: new Set() };\nconst $ = (s) => document.querySelector(s);\n\n/* 計算の呼び出し口。ローカルでは hsr gui の HTTP サーバー、静的サイト版では\n   ページが先に window.HSR_BACKEND（ブラウザ内の Python）を用意して差し替える。\n   どちらも「打ち間違いなど画面に出してよい失敗」は ApiError で投げる */\nclass ApiError extends Error {}\nconst backend = window.HSR_BACKEND || {\n  kind: "server",\n  offlineMessage: "サーバーに繋がりません。端末で hsr gui が動いているか確認してください",\n  async call(name, payload) {\n    const r = name === "options"\n      ? await fetch("/api/options")\n      : await fetch(`/api/${name}`, { method: "POST", headers: { "Content-Type": "application/json" },\n                                     body: JSON.stringify(payload || {}) });\n    const data = await r.json();\n    if (!r.ok) throw new ApiError(data.error || "計算に失敗しました");\n    return data;\n  },\n};\nfunction failMessage(e) {\n  if (e instanceof ApiError) return e.message;\n  if (e && e.userError) return e.userError;            /* 静的サイト版の打ち間違いなど */\n  return backend.offlineMessage || String(e);\n}\n\nfunction esc(s) {\n  return String(s).replace(/[&<>"\']/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", \'"\': "&quot;", "\'": "&#39;"}[c]));\n}\nfunction fmt(v) { return Math.round(v).toLocaleString("ja-JP"); }\nfunction shortName(n) { return n.replace("開拓者・", "").slice(0, 4); }\nfunction el(tag, cls) { const e = document.createElement(tag); if (cls) e.className = cls; return e; }\n\nfunction save() {\n  try { localStorage.setItem(STORE, JSON.stringify({ teams: state.teams, settings: state.settings })); } catch (e) {}\n}\nfunction load() {\n  try { return JSON.parse(localStorage.getItem(STORE) || "null"); } catch (e) { return null; }\n}\n\nfunction charById(id) { return state.opts.characters.find((c) => c.id === String(id)); }\nfunction lcName(id) {\n  const lc = state.opts.light_cones[id];\n  return lc ? `${"★".repeat(lc.rarity)} ${lc.name}` : id;\n}\nfunction newMember(id) {\n  const c = charById(id) || state.opts.characters[0];\n  return { id: c.id, e: c.fixed_eidolon ?? 0, s: c.fixed_superimpose ?? 1, lc: c.default_lc,\n           ms: { ...c.main_stats }, adj: {}, rot: "auto" };\n}\nfunction fromPreset(p) { return { label: p.label, members: p.members.map(newMember) }; }\n\n/* 保存しておいた編成に、もう選べないキャラが混ざっていたら差し替える */\nfunction sanitize(teams) {\n  return (teams || []).filter((t) => t && Array.isArray(t.members)).map((t) => ({\n    label: t.label || "",\n    members: t.members.slice(0, 4).map((m) => {\n      const c = charById(m.id);\n      if (!c) return newMember(state.opts.characters[0].id);\n      return {\n        id: c.id,\n        e: c.fixed_eidolon ?? Math.min(6, Math.max(0, +m.e || 0)),\n        s: c.fixed_superimpose ?? Math.min(5, Math.max(1, +m.s || 1)),\n        lc: c.lc_choices.includes(m.lc) ? m.lc : c.default_lc,\n        /* メインステは部位ごとに検証。選べない値や古い保存データはテンプレに戻す */\n        ms: Object.fromEntries(Object.keys(state.opts.slots).map((slot) => {\n          const v = m.ms && m.ms[slot];\n          return [slot, c.main_stat_choices[slot].includes(v) ? v : c.main_stats[slot]];\n        })),\n        /* ローテはそのキャラで選べるものだけ。古い保存データは既定に戻す */\n        rot: c.rotations.some(([v]) => v === (m && m.rot)) ? m.rot : "auto",\n        /* 必殺技の撃ち方。温存を選べないキャラや古い保存データは既定に戻す */\n        ult: c.ults.some(([v]) => v === (m && m.ult)) ? m.ult : "asap",\n        /* 手動調整は知っている項目の数字だけ残す（キャラに無い項目はサーバーが弾く） */\n        adj: Object.fromEntries(Object.entries((m && m.adj) || {}).filter(([k, v]) =>\n          state.opts.screen_stats.some((st) => st.key === k) && Number.isFinite(+v) && v !== "" && v !== null)\n          .map(([k, v]) => [k, +v])),\n      };\n    }),\n  }));\n}\n\nasync function init() {\n  if (backend.loadingMessage) setStatus(backend.loadingMessage);\n  try {\n    state.opts = await backend.call("options");\n  } catch (e) {\n    setStatus(failMessage(e), true);\n    return;\n  }\n  /* 共有リンクで開いたらそちらを優先する。読んだらアドレスから消す（編集後の再読み込みで戻らないように） */\n  let saved = null, fromLink = false;\n  try { saved = await readShareHash(); fromLink = !!saved; } catch (e) { ioStatus("共有リンクが読めませんでした", true); }\n  if (!saved) saved = load();\n  state.settings = Object.assign({}, state.opts.defaults, (saved && saved.settings) || {});\n  state.teams = sanitize(saved && saved.teams);\n  if (!state.teams.length) state.teams = state.opts.presets.slice(0, 2).map(fromPreset);\n  if (fromLink) {\n    history.replaceState(null, "", location.pathname + location.search);\n    save();\n    ioStatus("共有リンクの編成を読み込みました");\n  }\n  const app = state.opts.app || {};\n  const ver = $("#app-foot-ver");\n  ver.textContent =\n    `編成くらべ v${app.version || ""} ／ ゲームデータ ${app.data_version_short || app.data_version || ""}` +\n    (backend.kind === "server" ? "" : " ／ 計算はこのブラウザの中で行っています");\n  /* ビルドの識別子は表に出さず、問い合わせ用に title だけに入れる */\n  if (app.build) ver.title = `build ${app.build}`;\n  if (backend.kind !== "server") $("#export-box").hidden = true;   /* 画像の書き出しはローカル版だけ */\n  /* 弱点撃破の但し書きは試験機能を出しているときだけ */\n  $("#caveat-break").hidden = !state.opts.break_trial;\n  $("#save-file").addEventListener("click", saveFile);\n  $("#load-file").addEventListener("click", () => $("#load-input").click());\n  $("#load-input").addEventListener("change", loadFile);\n  $("#share").addEventListener("click", copyShareLink);\n\n  const preset = $("#preset");\n  preset.innerHTML = `<option value="">プリセットから追加…</option>` +\n    state.opts.presets.map((p, i) => `<option value="${i}">${esc(p.label)}</option>`).join("");\n  preset.addEventListener("change", () => {\n    if (preset.value === "") return;\n    state.teams.push(fromPreset(state.opts.presets[+preset.value]));\n    preset.value = "";\n    renderTeams(); changed();\n  });\n  $("#add").addEventListener("click", () => {\n    const last = state.teams[state.teams.length - 1];\n    state.teams.push(last ? { label: "", members: last.members.map((m) => ({ ...m })) }\n                          : fromPreset(state.opts.presets[0]));\n    renderTeams(); changed();\n  });\n  $("#export").addEventListener("click", exportImage);\n\n  renderSettings(); renderTeams(); run();\n}\n\n/* ---------------- 条件 ---------------- */\n\nfunction segmented(values, current, onPick, fmtLabel) {\n  const box = el("div", "seg-ctl");\n  values.forEach((v) => {\n    const b = el("button");\n    b.type = "button";\n    b.textContent = fmtLabel ? fmtLabel(v) : v;\n    b.setAttribute("aria-pressed", String(v === current));\n    b.addEventListener("click", () => { onPick(v); renderSettings(); changed(); });\n    box.appendChild(b);\n  });\n  return box;\n}\nfunction field(label, control) {\n  const f = el("label", "field");\n  const span = el("span"); span.textContent = label;\n  f.append(span, control);\n  return f;\n}\nfunction check(value, onChange, disabled) {\n  const c = el("input"); c.type = "checkbox"; c.checked = !!value; c.disabled = !!disabled;\n  c.addEventListener("change", () => { onChange(c.checked); renderSettings(); changed(); });\n  return c;\n}\nfunction selectOf(pairs, current, onChange, label) {\n  const s = el("select");\n  if (label) s.setAttribute("aria-label", label);\n  s.innerHTML = pairs.map(([v, t]) =>\n    `<option value="${esc(v)}"${String(v) === String(current) ? " selected" : ""}>${esc(t)}</option>`).join("");\n  s.addEventListener("change", () => onChange(s.value));\n  return s;\n}\n\nfunction renderSettings() {\n  const s = state.settings;\n  const root = $("#settings");\n  root.innerHTML = "";\n  const wrap = (label, ctl) => { const f = el("div", "field"); const t = el("span"); t.textContent = label; f.append(t, ctl); return f; };\n  root.append(\n    wrap("敵の数", segmented([1, 2, 3], s.enemies, (v) => { s.enemies = v; }, (v) => `${v} 体`)),\n    field("敵 Lv", selectOf([[90, "90"], [95, "95"]], s.enemy_level, (v) => { s.enemy_level = +v; changed(); }, "敵のレベル")),\n    field("敵の耐性", selectOf([[0.2, "20%（通常）"], [0, "0%（弱点）"]], s.enemy_res, (v) => { s.enemy_res = +v; changed(); }, "敵の耐性")),\n    field("サイクル", selectOf([[1, "1"], [2, "2"], [3, "3"], [5, "5"]], s.cycles, (v) => { s.cycles = +v; changed(); }, "サイクル数")),\n    field("秘技を使う", check(s.technique, (v) => { s.technique = v; })),\n    field("敵が攻撃する", check(s.enemy_attacks, (v) => { s.enemy_attacks = v; if (!v) s.enemy_hit_energy = false; })),\n    field("被弾で EP", check(s.enemy_hit_energy, (v) => { s.enemy_hit_energy = v; }, !s.enemy_attacks)),\n    /* 弱点撃破は試験機能。公開版ではスイッチごと出さない */\n    ...(state.opts.break_trial ? [\n      field("弱点撃破", check(s.weakness_break, (v) => { s.weakness_break = v; })),\n      field("靭性", selectOf([[120, "120（4本）"], [240, "240（8本）"], [360, "360（12本）"], [600, "600（20本）"]],\n        s.toughness, (v) => { s.toughness = +v; changed(); }, "敵の最大靭性（バー1本=30）")),\n    ] : []),\n  );\n}\n\n/* ---------------- 編成 ---------------- */\n\nfunction iconBtn(text, title, onClick) {\n  const b = el("button", "icon"); b.type = "button"; b.textContent = text; b.title = title;\n  b.setAttribute("aria-label", title);\n  b.addEventListener("click", onClick);\n  return b;\n}\n\nfunction renderTeams() {\n  const root = $("#teams");\n  root.innerHTML = "";\n  if (!state.teams.length) {\n    const p = el("p", "hint"); p.textContent = "編成がありません。右上のプリセットか「＋ 空の編成を追加」から始めてください";\n    root.appendChild(p);\n    return;\n  }\n  state.teams.forEach((t, ti) => root.appendChild(teamCard(t, ti)));\n}\n\nfunction teamCard(t, ti) {\n  const card = el("div", "card");\n  const head = el("div", "card-head");\n  const no = el("span", "no"); no.textContent = ti + 1;\n  const label = el("input"); label.type = "text"; label.value = t.label || "";\n  label.placeholder = "編成名（空ならキャラ名を並べる）";\n  label.setAttribute("aria-label", `編成 ${ti + 1} の名前`);\n  label.addEventListener("change", () => { t.label = label.value; changed(); });\n  const move = (d) => {\n    const j = ti + d;\n    if (j < 0 || j >= state.teams.length) return;\n    [state.teams[ti], state.teams[j]] = [state.teams[j], state.teams[ti]];\n    renderTeams(); changed();\n  };\n  head.append(no, label,\n    iconBtn("↑", "上へ（先頭の編成が 100% の基準）", () => move(-1)),\n    iconBtn("↓", "下へ", () => move(1)),\n    iconBtn("複製", "この編成を複製", () => {\n      state.teams.splice(ti + 1, 0, JSON.parse(JSON.stringify(t)));\n      renderTeams(); changed();\n    }),\n    iconBtn("削除", "この編成を削除", () => { state.teams.splice(ti, 1); renderTeams(); changed(); }));\n  const slots = el("div", "slots");\n  t.members.forEach((m, mi) => slots.appendChild(slot(t, m, mi)));\n  card.append(head, slots);\n  return card;\n}\n\nfunction artHtml(charId, name, lcId) {\n  const base = state.opts.icon_base;\n  const lc = lcId ? `<img class="lc" src="${base}/icon/light_cone/${esc(lcId)}.png" alt="" loading="lazy" onerror="this.remove()">` : "";\n  return `<span class="fallback">${esc(shortName(name))}</span>` +\n         `<img src="${base}/icon/character/${esc(charId)}.png" alt="" loading="lazy" onerror="this.remove()">${lc}`;\n}\n\nfunction slot(t, m, mi) {\n  const c = charById(m.id);\n  const wrap = el("div", "slot");\n  const art = el("div", "art");\n  art.innerHTML = artHtml(c.id, c.name, m.lc);\n  art.title = c.name;\n  const fields = el("div", "fields");\n  const who = selectOf(state.opts.characters.map((x) => [x.id, x.name]), m.id, (v) => {\n    t.members[mi] = newMember(v);\n    renderTeams(); changed();\n  }, `${mi + 1} 人目のキャラ`);\n  const es = el("div", "es");\n  /* 手動調整の欄が開いていたら、凸・重ね・メインステを変えたときに「元の値」を取り直す */\n  let refreshAdj = () => {};\n  const eSel = selectOf([0, 1, 2, 3, 4, 5, 6].map((v) => [v, `E${v}`]), m.e, (v) => { m.e = +v; refreshAdj(); changed(); }, "星魂");\n  const sSel = selectOf([1, 2, 3, 4, 5].map((v) => [v, `S${v}`]), m.s, (v) => { m.s = +v; refreshAdj(); changed(); }, "光円錐の重ね合わせ");\n  if (c.fixed_eidolon != null) { eSel.disabled = true; eSel.title = "このキャラは凸が固定です"; }\n  if (c.fixed_superimpose != null) { sSel.disabled = true; sSel.title = "このキャラの光円錐は重ねが固定です"; }\n  es.append(eSel, sSel);\n  const lc = selectOf(c.lc_choices.map((id) => [id, lcName(id)]), m.lc, (v) => {\n    m.lc = v; renderTeams(); changed();\n  }, "光円錐");\n  const ms = el("div", "ms");\n  Object.entries(state.opts.slots).forEach(([slotKey, slotName]) => {\n    const def = c.main_stats[slotKey];\n    const labels = state.opts.main_stat_labels;\n    const sel = selectOf(c.main_stat_choices[slotKey].map((v) =>\n      [v, labels[v] || v]), m.ms[slotKey], (v) => {\n      m.ms[slotKey] = v;\n      sel.classList.toggle("changed", v !== def);\n      refreshAdj();\n      changed();\n    }, `${slotName}のメインステ`);\n    sel.classList.toggle("changed", m.ms[slotKey] !== def);\n    sel.title = `${slotName}のメインステ（テンプレ: ${labels[def] || def}。変えると太枠になります）`;\n    const l = el("label"); l.append(document.createTextNode(slotName), sel);\n    ms.appendChild(l);\n  });\n  const rot = selectOf(c.rotations, m.rot || "auto", (v) => {\n    m.rot = v; rot.classList.toggle("changed", v !== "auto"); changed();\n  }, `${c.name}のローテ`);\n  rot.classList.add("rot");\n  rot.classList.toggle("changed", (m.rot || "auto") !== "auto");\n  rot.title = "戦闘スキルを振る頻度";\n  const ultSel = c.ults.length > 1 ? selectOf(c.ults, m.ult || "asap", (v) => {\n    m.ult = v; ultSel.classList.toggle("changed", v !== "asap"); changed();\n  }, `${c.name}の必殺技`) : null;\n  if (ultSel) {\n    ultSel.classList.add("rot");\n    ultSel.classList.toggle("changed", (m.ult || "asap") !== "asap");\n    ultSel.title = "必殺技を撃つタイミング";\n  }\n  const key = `${state.teams.indexOf(t)}-${mi}`;\n  const toggle = el("button", "btn adj-toggle"); toggle.type = "button";\n  const panel = el("div", "adj"); panel.hidden = !state.openAdj.has(key);\n  const label = () => {\n    const n = Object.keys(m.adj || {}).length;\n    toggle.textContent = n ? `ステータス調整中（${n}）` : "ステータスを調整";\n    toggle.classList.toggle("on", n > 0);\n    toggle.setAttribute("aria-expanded", String(!panel.hidden));\n  };\n  refreshAdj = () => { if (!panel.hidden) fillAdj(panel, m, label); };\n  toggle.addEventListener("click", () => {\n    panel.hidden = !panel.hidden;\n    if (panel.hidden) state.openAdj.delete(key); else state.openAdj.add(key);\n    label(); refreshAdj();\n  });\n  label();\n  fields.append(who, es, lc, ms, rot);\n  if (ultSel) fields.append(ultSel);\n  fields.append(toggle, panel);\n  wrap.append(art, fields);\n  if (!panel.hidden) fillAdj(panel, m, label);\n  return wrap;\n}\n\n/* ゲームのキャラ画面と同じ値を並べ、書き換えたところだけ m.adj に入れる。\n   空欄 = 調整しない。割合は画面どおり % で書く（中では 0.7 のような小数で持つ） */\nasync function fillAdj(panel, m, onChange) {\n  const token = (panel.dataset.token = String(Math.random()));\n  if (!panel.firstChild) panel.innerHTML = `<p class="hint">画面の値を計算中…</p>`;\n  let data;\n  try {\n    data = await backend.call("screen", { member: { ...m, adj: {} } });\n  } catch (e) {\n    panel.innerHTML = `<p class="hint">${esc(failMessage(e))}</p>`;\n    return;\n  }\n  if (panel.dataset.token !== token) return;     /* 連打したときは最後の結果だけ使う */\n  m.adj = m.adj || {};\n  const grid = el("div", "adj-grid");\n  data.stats.forEach((st) => {\n    const shown = st.percent ? st.value * 100 : st.value;\n    const digits = st.percent ? 1 : (st.key === "spd" ? 1 : 0);\n    const l = el("span", "l"); l.textContent = st.label; l.title = st.label;\n    const input = el("input"); input.type = "text"; input.inputMode = "decimal";\n    input.placeholder = shown.toFixed(digits);\n    input.setAttribute("aria-label", `${data.name}の${st.label}（画面の値。空欄なら調整しない）`);\n    if (m.adj[st.key] != null) input.value = String(+(st.percent ? m.adj[st.key] * 100 : m.adj[st.key]).toFixed(4));\n    input.classList.toggle("changed", m.adj[st.key] != null);\n    input.addEventListener("change", () => {\n      const raw = input.value.trim().replace(/[,%％]/g, "");\n      if (raw === "") delete m.adj[st.key];\n      else if (Number.isFinite(+raw) && +raw >= 0) m.adj[st.key] = st.percent ? +raw / 100 : +raw;\n      else { input.value = ""; delete m.adj[st.key]; }\n      input.classList.toggle("changed", m.adj[st.key] != null);\n      onChange(); changed();\n    });\n    const u = el("span", "l"); u.textContent = st.percent ? "%" : "";\n    grid.append(l, input, u);\n  });\n  const foot = el("div", "adj-foot");\n  const hint = el("span"); hint.textContent = "薄い数字が今の画面の値。書いた欄だけその値にします";\n  const reset = el("button", "icon"); reset.type = "button"; reset.textContent = "元に戻す";\n  reset.addEventListener("click", () => { m.adj = {}; onChange(); changed(); fillAdj(panel, m, onChange); });\n  foot.append(hint, reset);\n  panel.innerHTML = "";\n  panel.append(grid, foot);\n}\n\n/* ---------------- 計算 ---------------- */\n\nlet timer = null;\nlet seq = 0;\nfunction changed() { save(); clearTimeout(timer); timer = setTimeout(run, 250); }\nfunction setStatus(text, error) {\n  const s = $("#status"); s.textContent = text; s.classList.toggle("error", !!error);\n}\n\nasync function run() {\n  const my = ++seq;\n  if (!state.teams.length) { state.results = { rows: [] }; renderResults(); setStatus(""); return; }\n  setStatus("計算中…");\n  const sent = JSON.parse(JSON.stringify({ teams: state.teams.filter((t) => t.members.length), settings: state.settings }));\n  try {\n    const data = await backend.call("simulate", sent);\n    if (my !== seq) return;          // 古い結果は捨てる（切り替えを連打したとき）\n    state.results = data;\n    state.ran = sent;\n    state.logs = {};\n    renderResults();\n    setStatus(`${data.rows.length} 編成を計算しました（${data.elapsed_ms} ms）`);\n  } catch (e) {\n    if (my === seq) setStatus(failMessage(e), true);\n  }\n}\n\nfunction unitHtml(m) {\n  return `<div class="unit" title="${esc(m.name)} ${esc(m.badge)}"><div class="art">${artHtml(m.char_id, m.name, m.light_cone_id)}</div>` +\n         `<div class="badge">${esc(m.badge)}</div></div>`;\n}\n\nfunction renderResults() {\n  const root = $("#results");\n  const rows = (state.results && state.results.rows) || [];\n  if (!rows.length) { root.innerHTML = `<p class="hint">編成を追加すると、ここに比較が出ます</p>`; return; }\n  const palette = state.opts.palette;\n  /* 色はキャラに固定する。登場順に割り当て、行ごとに振り直さない */\n  const order = [];\n  rows.forEach((r) => Object.keys(r.breakdown).forEach((n) => { if (!order.includes(n)) order.push(n); }));\n  const slotOf = (n) => { const i = order.indexOf(n); return i >= 0 && i < palette.length ? i : -1; };\n  const base = rows[0].dpa || 1;\n  const top = Math.max(...rows.map((r) => r.total_damage)) || 1;\n  const s = state.results.settings;\n\n  const legend = order.slice(0, palette.length).map((n, i) =>\n    `<span class="key"><i style="background:${palette[i]}"></i>${esc(n)}</span>`).join("");\n  const body = rows.map((r, ri) => {\n    const segs = Object.entries(r.breakdown).filter(([, d]) => d > 0).sort((a, b) => b[1] - a[1]).map(([n, d]) => {\n      const i = slotOf(n);\n      const color = i >= 0 ? palette[i] : "var(--muted)";\n      const width = d / top * 100;\n      const share = r.total_damage ? d / r.total_damage : 0;\n      const perAv = r.dpa ? d / (r.total_damage / r.dpa) : 0;\n      const v = width >= 4.5 ? `<span class="v">${fmt(perAv)}</span>` : "";\n      return `<div class="seg" tabindex="0" style="width:${width.toFixed(4)}%;background:${color}">${v}` +\n             `<span class="tip">${esc(n)}<br>DPA ${fmt(perAv)} ／ ${(share * 100).toFixed(1)}%</span></div>`;\n    }).join("");\n    const notes = r.notes.length\n      ? `<details class="notes"><summary>未実装の効果 ${r.notes.length} 件（この編成の数字には入っていません）</summary><ul>` +\n        r.notes.map((n) => `<li>${esc(n)}</li>`).join("") + `</ul></details>` : "";\n    /* 遺物とサブステの伸び（表示だけ。2026-09-18 ユーザー指定） */\n    const gear = (r.gear || []).length\n      ? `<details class="gear"><summary>遺物とサブステ</summary>` +\n        r.gear.map((g, gi) => {\n          const who = (r.members[gi] || {}).name || "";\n          const sets = (g.sets || []).map((x) => `${esc(x.name)} ${x.count}`).join(" ／ ");\n          const subs = (g.substats || []).map((x) =>\n            `<tr><td>${esc(x.label)}</td><td class="num">${x.percent ? (x.value * 100).toFixed(1) + "%" : x.value.toFixed(0)}</td>` +\n            `<td class="num">${x.rolls} 回</td></tr>`).join("");\n          return `<div class="who">${esc(who)}</div><div class="sets">${sets}</div>` +\n                 `<table>${subs}</table>`;\n        }).join("") +\n        `<div class="sets">サブステは 30 回の成長をキャラごとの優先度で振った結果です</div></details>`\n      : "";\n    const msnote = (r.custom_notes || []).length\n      ? `<div class="msnote">テンプレから変更: ${r.custom_notes.map(esc).join(" ／ ")}</div>` : "";\n    return `<div class="row"><div><div class="rlabel">${esc(r.label)}</div><div class="units">${r.members.map(unitHtml).join("")}</div>${msnote}${gear}${notes}` +\n           `<button type="button" class="btn upgrade-btn" data-i="${ri}">この編成で凸を進める</button></div>` +\n           `<div class="track">${segs}</div>` +\n           `<div class="total"><b>${fmt(r.dpa)}</b><span class="pct">${(r.dpa / base * 100).toFixed(1)}%</span></div></div>` +\n           `<details class="battlelog" data-i="${ri}"${state.openLogs.has(ri) ? " open" : ""}><summary>戦闘ログ</summary><div class="logbody"></div></details>`;\n  }).join("");\n  const head = order.map((n) => `<th>${esc(n)}</th>`).join("");\n  const table = rows.map((r) => `<tr><th scope="row">${esc(r.label)}</th><td>${fmt(r.dpa)}</td><td>${fmt(r.total_damage)}</td>` +\n    `<td>${r.cycles.toFixed(2)}</td><td>${r.sp_balance >= 0 ? "+" : ""}${r.sp_balance.toFixed(1)}</td>` +\n    order.map((n) => `<td>${fmt(r.breakdown[n] || 0)}</td>`).join("") + `</tr>`).join("");\n\n  root.innerHTML =\n    `<p class="meta">敵 Lv${s.enemy_level} ／ ${s.enemies} 体 ／ 耐性 ${Math.round(s.enemy_res * 100)}% ／ ${s.cycles} サイクル ／ ` +\n    `${s.technique ? "秘技あり" : "秘技なし"}${s.enemy_attacks ? " ／ 敵の攻撃あり" : ""}</p>` +\n    `<p class="hint">数字は DPA（行動値あたりダメージ）。右の % は先頭の編成を 100% としたときの比。棒の各段にカーソルを乗せるとキャラごとの内訳が出ます</p>` +\n    `<div class="legend">${legend}</div><div class="wrap">${body}</div>` +\n    `<details class="table"><summary>数値で見る</summary><div class="wrap"><table><thead><tr><th scope="col">編成</th>` +\n    `<th>DPA</th><th>総ダメージ</th><th>サイクル</th><th>SP 収支</th>${head}</tr></thead><tbody>${table}</tbody></table></div></details>`;\n  root.querySelectorAll(".upgrade-btn").forEach((b) => {\n    b.addEventListener("click", () => openUpgrade(+b.dataset.i));\n  });\n  root.querySelectorAll("details.battlelog").forEach((d) => {\n    const i = +d.dataset.i;\n    d.addEventListener("toggle", () => {\n      if (d.open) { state.openLogs.add(i); loadLog(d, i); } else { state.openLogs.delete(i); }\n    });\n    if (d.open) loadLog(d, i);\n  });\n}\n\n/* ---------------- この編成で凸を進める ---------------- */\n\n/* 結果の行の編成（計算したときの形）を出発点にして、追加コスト別の候補を出す。\n   いまの編成をコスト 0 とし、1 凸・光円錐 1 重 = 1 コスト（開拓者は上げない） */\nfunction openUpgrade(i) {\n  if (!state.ran || !state.ran.teams[i]) return;\n  state.upgrade = {\n    team: JSON.parse(JSON.stringify(state.ran.teams[i])),\n    settings: { ...state.ran.settings },\n    label: state.results.rows[i].label,\n    maxExtra: (state.upgrade && state.upgrade.maxExtra) || 6,\n    data: null, error: "", token: 0,\n  };\n  const panel = $("#upgrade");\n  panel.hidden = false;\n  runUpgrade();\n  panel.scrollIntoView({ behavior: "smooth", block: "start" });\n}\n\nasync function runUpgrade() {\n  const up = state.upgrade;\n  const token = ++up.token;\n  up.data = null; up.error = "";\n  renderUpgrade();\n  try {\n    const data = await backend.call("upgrade", { team: up.team, settings: up.settings, max_extra: up.maxExtra });\n    if (state.upgrade !== up || up.token !== token) return;   /* 途中で選び直したら捨てる */\n    up.data = data;\n  } catch (e) {\n    if (state.upgrade !== up || up.token !== token) return;\n    up.error = failMessage(e);\n  }\n  renderUpgrade();\n}\n\nfunction renderUpgrade() {\n  const up = state.upgrade;\n  const panel = $("#upgrade");\n  if (!up) { panel.hidden = true; return; }\n  panel.innerHTML = "";\n  const head = el("div", "up-head");\n  const h = el("h2"); h.textContent = `凸を進める: ${up.label}`;\n  const limit = selectOf([3, 6, 10].map((v) => [v, `追加コスト ${v} まで`]), up.maxExtra, (v) => {\n    up.maxExtra = +v; runUpgrade();\n  }, "追加コストの上限");\n  const close = iconBtn("閉じる", "凸を進める候補を閉じる", () => { state.upgrade = null; renderUpgrade(); });\n  head.append(h, limit, close);\n  const hint = el("p", "hint");\n  hint.textContent = "いまの編成（凸・重ね・光円錐・メインステ・調整）をコスト 0 として、1 凸・光円錐 1 重 = 1 コストで数えます。" +\n    "モチーフ以外の光円錐は「モチーフに持ち替える」が 1 コスト。開拓者は上げません。" +\n    "コストごとに上位を残して広げた候補で、総当たりではありません。";\n  panel.append(head, hint);\n\n  if (up.error) { const p = el("p", "status error"); p.textContent = up.error; panel.append(p); return; }\n  if (!up.data) {\n    const p = el("p", "status");\n    p.textContent = `計算中…（追加コスト ${up.maxExtra} まで。1 コストごとに数十回戦うので、数秒〜数十秒かかります）`;\n    panel.append(p);\n    return;\n  }\n  const d = up.data;\n  const base = d.start.dpa || 1;\n  let html = `<div class="wrap"><table class="up"><thead><tr><th scope="col">追加コスト</th><th scope="col" class="c">候補</th>` +\n    `<th scope="col">DPA</th><th scope="col">伸び</th><th scope="col"></th></tr></thead><tbody>` +\n    `<tr class="first"><td>0</td><td class="c">いまの編成（${d.start.members.map((m) => esc(`${m.name} ${m.badge}`)).join("、")}）</td>` +\n    `<td>${fmt(d.start.dpa)}</td><td>—</td><td></td></tr>`;\n  d.rows.forEach((row) => {\n    if (!row.candidates.length) {\n      html += `<tr class="first"><td>+${row.cost}</td><td class="c" colspan="4">候補なし（上げられるキャラがいません）</td></tr>`;\n      return;\n    }\n    row.candidates.forEach((c, k) => {\n      const weak = k === 0 && !row.beats_cheaper\n        ? `<span class="weak">より安い候補のほうが DPA が高い</span>` : "";\n      html += `<tr class="${k === 0 ? "first top" : ""}">` +\n        (k === 0 ? `<td rowspan="${row.candidates.length}">+${row.cost}</td>` : "") +\n        `<td class="c">${c.changes.map((x) => `<span class="chg">${esc(x)}</span>`).join("")}${weak}</td>` +\n        `<td>${fmt(c.dpa)}</td><td>+${(c.gain * 100).toFixed(1)}%</td>` +\n        `<td><button type="button" class="icon up-add" data-cost="${row.cost}" data-k="${k}" title="この凸で編成を追加して、結果に並べる">編成に追加</button></td></tr>`;\n    });\n  });\n  html += `</tbody></table></div>`;\n  const wrap = el("div"); wrap.innerHTML = html;\n  panel.append(wrap);\n  panel.querySelectorAll(".up-add").forEach((b) => {\n    b.addEventListener("click", () => {\n      const row = d.rows.find((r) => r.cost === +b.dataset.cost);\n      const cand = row.candidates[+b.dataset.k];\n      const label = `${up.label} +${row.cost}（${cand.changes.join("・")}）`;\n      state.teams.push(...sanitize([{ label, members: cand.team }]));\n      renderTeams(); changed();\n      ioStatus(`「${label}」を編成に追加しました`);\n    });\n  });\n}\n\n/* ---------------- 戦闘ログ ---------------- */\n\nasync function loadLog(d, i) {\n  const body = d.querySelector(".logbody");\n  if (state.logs[i]) { renderLog(body, state.logs[i]); return; }\n  if (!state.ran || !state.ran.teams[i]) return;\n  body.innerHTML = `<p class="hint">ログを取得中…</p>`;\n  try {\n    const data = await backend.call("log", { team: state.ran.teams[i], settings: state.ran.settings });\n    data.filter = data.filter || { text: "", actor: "", dmgOnly: false };\n    state.logs[i] = data;\n    renderLog(body, data);\n  } catch (e) {\n    body.innerHTML = `<p class="hint">${esc(failMessage(e))}</p>`;\n  }\n}\n\nfunction logLineText(ln) {\n  const d = ln.damage ? fmt(ln.damage).padStart(12) : " ".repeat(12);\n  return `[${ln.av.toFixed(1).padStart(7)}] C${ln.cycle} T${ln.turn} ${ln.actor.padEnd(10)} ${d}  ${ln.text}`;\n}\n\nfunction renderLog(body, data) {\n  const f = data.filter;\n  const actors = [...new Set(data.lines.map((ln) => ln.actor))];\n  body.innerHTML = "";\n  const ctl = el("div", "log-ctl");\n  const q = el("input"); q.type = "text"; q.value = f.text; q.placeholder = "絞り込み（例: 憶質、会心、敵1）";\n  q.setAttribute("aria-label", "ログを文字で絞り込む");\n  const who = selectOf([["", "全員"], ...actors.map((a) => [a, a])], f.actor, (v) => { f.actor = v; draw(); }, "行動者で絞り込む");\n  const dmg = el("input"); dmg.type = "checkbox"; dmg.checked = f.dmgOnly;\n  const dmgLabel = el("label", "field"); dmgLabel.append(dmg, document.createTextNode("ダメージ行だけ"));\n  const count = el("span", "sub");\n  const copy = el("button", "btn"); copy.type = "button"; copy.textContent = "表示中の行をテキストでコピー";\n  ctl.append(q, who, dmgLabel, copy, count);\n  const scroll = el("div", "log-scroll");\n  body.append(ctl, scroll);\n\n  let shown = [];\n  function draw() {\n    const needle = f.text.trim();\n    shown = data.lines.filter((ln) =>\n      (!f.actor || ln.actor === f.actor) && (!f.dmgOnly || ln.damage > 0) &&\n      (!needle || ln.text.includes(needle) || ln.actor.includes(needle)));\n    const turns = Object.fromEntries(data.turns.map((t) => [t.turn, t]));\n    let last = -1, html = "";\n    for (const ln of shown) {\n      if (ln.turn !== last) {\n        last = ln.turn;\n        const t = turns[ln.turn];\n        const head = ln.turn === 0 ? "戦闘開始前（装備・秘技）" : `ターン ${ln.turn}\u3000${t ? t.actor : ""}\u3000（行動値 ${t ? t.av.toFixed(1) : ln.av.toFixed(1)}）`;\n        html += `<tr class="turn"><td colspan="5">${esc(head)}</td></tr>`;\n      }\n      html += `<tr class="${ln.damage ? "dmg" : ""}"><td>${ln.av.toFixed(1)}</td><td>C${ln.cycle}</td>` +\n              `<td class="a">${esc(ln.actor)}</td><td class="d">${ln.damage ? fmt(ln.damage) : ""}</td><td class="t">${esc(ln.text)}</td></tr>`;\n    }\n    scroll.innerHTML = `<table class="log"><thead><tr><th scope="col">行動値</th><th scope="col">サイクル</th>` +\n      `<th scope="col">対象</th><th scope="col">ダメージ</th><th scope="col" class="t">内容</th></tr></thead><tbody>${html}</tbody></table>`;\n    const sum = shown.reduce((a, ln) => a + ln.damage, 0);\n    count.textContent = `${shown.length} / ${data.lines.length} 行 ／ 表示中のダメージ合計 ${fmt(sum)}`;\n  }\n  let typing = null;\n  q.addEventListener("input", () => { clearTimeout(typing); typing = setTimeout(() => { f.text = q.value; draw(); }, 150); });\n  dmg.addEventListener("change", () => { f.dmgOnly = dmg.checked; draw(); });\n  copy.addEventListener("click", async () => {\n    try {\n      await navigator.clipboard.writeText(shown.map(logLineText).join("\\n"));\n      copy.textContent = `${shown.length} 行コピーしました`;\n    } catch (e) {\n      copy.textContent = "コピーできませんでした";\n    }\n    setTimeout(() => { copy.textContent = "表示中の行をテキストでコピー"; }, 2000);\n  });\n  draw();\n}\n\n/* ---------------- 保存・読み込み・共有 ---------------- */\n\nconst FILE_FORMAT = "hsr-sim.teams";\nconst FILE_VERSION = 1;\n\nfunction ioStatus(text, error) {\n  const s = $("#io-status"); s.textContent = text; s.classList.toggle("error", !!error);\n}\n\nfunction snapshot() {\n  const app = state.opts.app || {};\n  return { format: FILE_FORMAT, version: FILE_VERSION, app_version: app.version,\n    app_build: app.build, data_version: app.data_version,\n           saved_at: new Date().toISOString(), settings: state.settings, teams: state.teams };\n}\n\n/* 読み込んだものを画面に入れる。形式が違うファイルは拒む。版が違えば数字が変わりうると知らせる */\nfunction applySnapshot(data, source) {\n  if (!data || (data.format && data.format !== FILE_FORMAT) || !Array.isArray(data.teams)) {\n    throw new Error("hsr-sim の保存ファイルではありません");\n  }\n  if ((data.version || 1) > FILE_VERSION) throw new Error("新しい版で保存されたファイルです。ページを更新してください");\n  state.settings = Object.assign({}, state.opts.defaults, data.settings || {});\n  state.teams = sanitize(data.teams);\n  state.openAdj.clear();\n  renderSettings(); renderTeams(); changed();\n  const app = state.opts.app || {};\n  const note = data.data_version && data.data_version !== app.data_version\n    ? `（保存時のゲームデータ ${data.data_version} と今の ${app.data_version} が違うので、数字が変わることがあります）` : "";\n  ioStatus(`${source}を読み込みました${note}`);\n}\n\nfunction saveFile() {\n  const blob = new Blob([JSON.stringify(snapshot(), null, 2)], { type: "application/json" });\n  const a = document.createElement("a");\n  const d = new Date();\n  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}_${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}`;\n  a.href = URL.createObjectURL(blob);\n  a.download = `hsr-sim_${stamp}.json`;\n  document.body.appendChild(a); a.click(); a.remove();\n  setTimeout(() => URL.revokeObjectURL(a.href), 1000);\n  ioStatus(`${a.download} を保存しました`);\n}\n\nasync function loadFile(ev) {\n  const file = ev.target.files && ev.target.files[0];\n  ev.target.value = "";\n  if (!file) return;\n  try {\n    applySnapshot(JSON.parse(await file.text()), `「${file.name}」`);\n  } catch (e) {\n    ioStatus(`読み込めませんでした: ${e.message}`, true);\n  }\n}\n\n/* 共有リンク: 編成と条件を圧縮して # の後ろに入れる（サーバーには送られない） */\nfunction toBase64Url(bytes) {\n  let bin = ""; bytes.forEach((b) => { bin += String.fromCharCode(b); });\n  return btoa(bin).replace(/\\+/g, "-").replace(/\\//g, "_").replace(/=+$/, "");\n}\nfunction fromBase64Url(text) {\n  const bin = atob(text.replace(/-/g, "+").replace(/_/g, "/"));\n  return Uint8Array.from(bin, (c) => c.charCodeAt(0));\n}\nasync function pipe(bytes, stream) {\n  return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer());\n}\nasync function copyShareLink() {\n  const { settings, teams } = snapshot();\n  const json = new TextEncoder().encode(JSON.stringify({ v: FILE_VERSION, settings, teams }));\n  let hash;\n  if (typeof CompressionStream === "function") hash = "#z=" + toBase64Url(await pipe(json, new CompressionStream("deflate-raw")));\n  else hash = "#j=" + toBase64Url(json);\n  const url = location.href.split("#")[0] + hash;\n  try {\n    await navigator.clipboard.writeText(url);\n    ioStatus("共有リンクをコピーしました");\n  } catch (e) {\n    window.prompt("このリンクをコピーしてください", url);\n  }\n}\nasync function readShareHash() {\n  const m = location.hash.match(/^#([zj])=([A-Za-z0-9_-]+)$/);\n  if (!m) return null;\n  let bytes = fromBase64Url(m[2]);\n  if (m[1] === "z") bytes = await pipe(bytes, new DecompressionStream("deflate-raw"));\n  const data = JSON.parse(new TextDecoder().decode(bytes));\n  return { format: FILE_FORMAT, version: data.v, settings: data.settings, teams: data.teams };\n}\n\nasync function exportImage() {\n  const st = $("#export-status");\n  st.classList.remove("error");\n  st.textContent = "書き出し中…（画像はアイコンの読み込みを待つので数秒かかります）";\n  try {\n    const data = await backend.call("export", { teams: state.teams, settings: state.settings, title: $("#title").value });\n    st.textContent = data.png ? `書き出しました: ${data.png}` : `HTML だけ書き出しました: ${data.html}（画像: ${data.png_error}）`;\n  } catch (e) {\n    st.textContent = failMessage(e); st.classList.add("error");\n  }\n}\n\ninit();\n</script>\n</body></html>\n'
