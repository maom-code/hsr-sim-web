from __future__ import annotations
from dataclasses import dataclass, replace
from .build.assemble import BuildSpec, BuiltCharacter, build
from .model.enums import Element, Path
from .model.stats import DMG_PCT_BY_ELEMENT, StatKey, StatSheet, finalize_base_stats

@dataclass(frozen=True)
class ScreenStat:
    key: str
    label: str
    percent: bool
    adjusts: StatKey | None
SCREEN_STATS: tuple[ScreenStat, ...] = (ScreenStat('hp', 'HP', False, StatKey.HP), ScreenStat('atk', '攻撃力', False, StatKey.ATK), ScreenStat('def', '防御力', False, StatKey.DEF), ScreenStat('spd', '速度', False, StatKey.SPD), ScreenStat('crit_rate', '会心率', True, StatKey.CRIT_RATE), ScreenStat('crit_dmg', '会心ダメージ', True, StatKey.CRIT_DMG), ScreenStat('break_effect', '撃破特効', True, StatKey.BREAK_EFFECT), ScreenStat('heal_boost', '治癒量', True, StatKey.HEAL_BOOST), ScreenStat('energy_regen', 'EP回復効率', True, StatKey.ENERGY_REGEN), ScreenStat('effect_hit', '効果命中', True, StatKey.EFFECT_HIT), ScreenStat('effect_res', '効果抵抗', True, StatKey.EFFECT_RES), ScreenStat('elem_dmg', '属性与ダメージ', True, None), ScreenStat('elation_rate', '愉悦度', True, StatKey.ELATION_RATE))
_BY_KEY = {s.key: s for s in SCREEN_STATS}

def stats_for(built: BuiltCharacter) -> list[ScreenStat]:
    return [s for s in SCREEN_STATS if s.key != 'elation_rate' or built.path is Path.ELATION]

def _equipment_sheet(built: BuiltCharacter) -> StatSheet:
    from .engine.battle import Battle
    from .engine.entity import Character, make_enemies
    battle = Battle(team=[Character(built=built, position=0)], enemies=make_enemies(1, hp=10 ** 9), use_technique=False)
    sheet = StatSheet()
    for eff in battle.team[0].effects:
        if eff.duration is not None or not eff.pre_battle:
            continue
        parts = eff.key.split('.')
        is_lc = parts[0] == 'lc'
        is_set_2pc = parts[0] == 'set' and len(parts) > 2 and (parts[2] == '2')
        if is_lc or is_set_2pc:
            sheet = sheet.merged(eff.contribution())
    return sheet

def screen_values(built: BuiltCharacter) -> dict[str, float]:
    total = finalize_base_stats(built.pre_final.merged(_equipment_sheet(built)), built.base)
    out: dict[str, float] = {}
    for s in stats_for(built):
        if s.key == 'elem_dmg':
            out[s.key] = total[DMG_PCT_BY_ELEMENT[Element(built.element)]] + total[StatKey.DMG_PCT]
        elif s.key == 'energy_regen':
            out[s.key] = 1.0 + total[StatKey.ENERGY_REGEN]
        else:
            out[s.key] = total[s.adjusts]
    return out

def adjusted(spec: BuildSpec, targets: dict[str, float]) -> BuildSpec:
    if not targets:
        return spec
    base_spec = replace(spec, stat_adjust={})
    built = build(base_spec)
    now = screen_values(built)
    adjust: dict[StatKey, float] = {}
    for key, target in targets.items():
        s = _BY_KEY.get(key)
        if s is None or key not in now:
            raise ValueError(f'{built.name} の画面に「{(s.label if s else key)}」はありません')
        delta = float(target) - now[key]
        if abs(delta) < 1e-09:
            continue
        stat = s.adjusts or DMG_PCT_BY_ELEMENT[Element(built.element)]
        adjust[stat] = adjust.get(stat, 0.0) + delta
    return replace(base_spec, stat_adjust=adjust)
