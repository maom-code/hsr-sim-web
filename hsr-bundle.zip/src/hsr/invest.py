from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, replace
FREE_PREFIX = '80'
MAX_EIDOLON = 6
MAX_SUPERIMPOSE = 5

def is_free(char_id: str) -> bool:
    return str(char_id).startswith(FREE_PREFIX)

@dataclass(frozen=True)
class Unit:
    name: str
    char_id: str
    eidolon: int
    superimpose: int
    free: bool = False
    discount: int = 0
    light_cone: str | None = None

    def raw_cost(self) -> int:
        if self.free:
            return 0
        lc = self.superimpose if self.light_cone is None else 0
        return self.eidolon + 1 + lc

    def cost(self) -> int:
        return max(0, self.raw_cost() - self.discount)

    @property
    def badge(self) -> str:
        if self.light_cone is None:
            return f'E{self.eidolon}S{self.superimpose}'
        return f'E{self.eidolon}S{self.superimpose}（{_lc_name(self.light_cone)}）'
Team = tuple[Unit, ...]

def team_cost(team: Team) -> int:
    return sum((u.cost() for u in team))

def team_key(team: Team) -> tuple:
    return tuple(((u.char_id, u.eidolon, u.superimpose, u.light_cone) for u in team))

def _lc_name(lc_id: str) -> str:
    from .data import loader
    return loader.light_cone(str(lc_id))['name']

def _normalize_lc(char_id: str, lc: str | None) -> str | None:
    if not lc:
        return None
    from .build.assemble import BuildSpec, build
    from .data import loader
    lc_id = str(loader.light_cone(str(lc))['id'])
    default = build(BuildSpec(character=char_id)).light_cone_id
    return None if str(default) == lc_id else lc_id

@dataclass(frozen=True)
class Step:
    cost: int
    dpa: float
    team: Team
    change: str = ''

def resolve_unit(name: str, discount: int=0) -> Unit:
    from .content.base import REGISTRY
    from .data import loader
    char = loader.character(name)
    cid = str(char['id'])
    impl = REGISTRY.get(cid)
    eidolon = getattr(impl, 'fixed_eidolon', None)
    superimpose = getattr(impl, 'fixed_superimpose', None)
    return Unit(name=char['name'], char_id=cid, eidolon=int(eidolon) if eidolon is not None else 0, superimpose=int(superimpose) if superimpose is not None else 1, free=is_free(cid), discount=int(discount))

def baseline(names: list[str], discounts: dict[str, int] | None=None, owned: dict[str, tuple[int, int, str | None]] | None=None, light_cones: dict[str, str] | None=None) -> Team:
    from .data import loader
    discounts = discounts or {}
    owned = owned or {}
    light_cones = light_cones or {}
    out: list[Unit] = []
    for n in names:
        cid = str(loader.character(n)['id'])
        unit = resolve_unit(n, discounts.get(cid, 0))
        if cid in owned and (not unit.free):
            eidolon, superimpose, lc = owned[cid]
            unit = replace(unit, eidolon=int(eidolon), superimpose=int(superimpose), light_cone=_normalize_lc(cid, lc))
            unit = replace(unit, discount=unit.raw_cost())
        elif cid in light_cones and (not unit.free):
            unit = replace(unit, light_cone=_normalize_lc(cid, light_cones[cid]), superimpose=MAX_SUPERIMPOSE)
        out.append(unit)
    return tuple(out)

def moves(team: Team, *, max_eidolon: int=MAX_EIDOLON, max_superimpose: int=MAX_SUPERIMPOSE) -> list[tuple[Team, str]]:
    out: list[tuple[Team, str]] = []
    for i, u in enumerate(team):
        if u.free:
            continue
        for e in range(u.eidolon + 1, max_eidolon + 1):
            nxt = list(team)
            nxt[i] = replace(u, eidolon=e)
            out.append((tuple(nxt), f'{u.name} E{u.eidolon}→E{e}'))
        if u.light_cone is None:
            for s in range(u.superimpose + 1, max_superimpose + 1):
                nxt = list(team)
                nxt[i] = replace(u, superimpose=s)
                out.append((tuple(nxt), f'{u.name} S{u.superimpose}→S{s}'))
        else:
            for s in range(1, max_superimpose + 1):
                nxt = list(team)
                nxt[i] = replace(u, light_cone=None, superimpose=s)
                out.append((tuple(nxt), f'{u.name} モチーフ光円錐 S{s}'))
    return out

def invest_curve(start: Team, evaluate: Callable[[Team], float], max_cost: int, *, max_eidolon: int=MAX_EIDOLON, max_superimpose: int=MAX_SUPERIMPOSE, progress: Callable[[Step], None] | None=None) -> list[Step]:
    cache: dict[tuple, float] = {}

    def dpa(team: Team) -> float:
        key = team_key(team)
        if key not in cache:
            cache[key] = evaluate(team)
        return cache[key]
    current = start
    path = [Step(cost=team_cost(start), dpa=dpa(start), team=start)]
    if progress:
        progress(path[-1])
    while True:
        base_cost, base_dpa = (team_cost(current), dpa(current))
        best: tuple[float, int, Team, str] | None = None
        for nxt, change in moves(current, max_eidolon=max_eidolon, max_superimpose=max_superimpose):
            cost = team_cost(nxt)
            if cost > max_cost:
                continue
            spent = cost - base_cost
            if spent <= 0:
                continue
            gain = dpa(nxt) - base_dpa
            ratio = gain / spent
            rank = (round(ratio, 6), -spent)
            if best is None or rank > (round(best[0], 6), -best[1]):
                best = (ratio, spent, nxt, change)
        if best is None or best[0] <= 0:
            break
        _ratio, _spent, current, change = best
        path.append(Step(cost=team_cost(current), dpa=dpa(current), team=current, change=change))
        if progress:
            progress(path[-1])
    return path

def best_at(path: list[Step], budget: int) -> Step | None:
    fit = [s for s in path if s.cost <= budget]
    return max(fit, key=lambda s: s.dpa) if fit else None

def simulate_dpa(team: Team, *, enemies: int=3, enemy_level: int=95, enemy_hp: float=1000000000.0, cycles: int=2, use_technique: bool=True, enemy_attacks: bool=False, enemy_hit_energy: bool=False) -> float:
    from .build.assemble import BuildSpec, build
    from .engine.battle import Battle
    from .engine.entity import Character, make_enemies
    chars = [Character(built=build(BuildSpec(character=u.char_id, eidolon=u.eidolon, superimpose=u.superimpose, light_cone=u.light_cone)), position=i) for i, u in enumerate(team)]
    return Battle(team=chars, enemies=make_enemies(enemies, level=enemy_level, hp=enemy_hp), max_cycles=cycles, use_technique=use_technique, enemy_attacks=enemy_attacks, enemy_hit_energy=enemy_hit_energy).run().dpa

def from_current(units: list[Unit]) -> Team:
    return tuple((replace(u, discount=u.raw_cost()) for u in units))

def step_moves(team: Team, *, max_eidolon: int=MAX_EIDOLON, max_superimpose: int=MAX_SUPERIMPOSE) -> list[tuple[Team, int]]:
    out: list[tuple[Team, int]] = []
    for i, u in enumerate(team):
        if u.free:
            continue
        for de in (1, 2):
            if u.eidolon + de <= max_eidolon:
                nxt = list(team)
                nxt[i] = replace(u, eidolon=u.eidolon + de)
                out.append((tuple(nxt), de))
        if u.light_cone is None:
            if u.superimpose < max_superimpose:
                nxt = list(team)
                nxt[i] = replace(u, superimpose=u.superimpose + 1)
                out.append((tuple(nxt), 1))
        else:
            nxt = list(team)
            nxt[i] = replace(u, light_cone=None, superimpose=1)
            out.append((tuple(nxt), 1))
    return out

def upgrade_candidates(start: Team, evaluate: Callable[[Team], float], max_extra: int, *, beam: int=4, top: int=3, progress: Callable[[int, int], None] | None=None) -> dict[int, list[tuple[float, Team]]]:
    cache: dict[tuple, float] = {}

    def dpa(team: Team) -> float:
        key = team_key(team)
        if key not in cache:
            cache[key] = evaluate(team)
        return cache[key]
    buckets: dict[int, dict[tuple, Team]] = {0: {team_key(start): start}}
    dpa(start)
    for cost in range(0, max_extra):
        frontier = sorted(buckets.get(cost, {}).values(), key=dpa, reverse=True)[:beam]
        for team in frontier:
            for nxt, spent in step_moves(team):
                c = cost + spent
                if c > max_extra:
                    continue
                buckets.setdefault(c, {})[team_key(nxt)] = nxt
        if progress:
            progress(cost + 1, max_extra)
    out: dict[int, list[tuple[float, Team]]] = {}
    for c in range(1, max_extra + 1):
        ranked = sorted(((dpa(t), t) for t in buckets.get(c, {}).values()), key=lambda x: x[0], reverse=True)
        out[c] = ranked[:top]
    return out
