from __future__ import annotations
from dataclasses import dataclass, field
from enum import StrEnum
from ..build.assemble import BuiltCharacter
from ..model.enums import Element
from ..model.stats import StatKey, StatSheet, finalize_base_stats
from .effects import EffectContainer
from .resources import Counter, EnergyPool, NoUltimate, ResourcePool

class EnemyBehavior(StrEnum):
    PASSIVE = 'passive'
    AOE = 'aoe'
    SINGLE = 'single'

@dataclass
class Character:
    built: BuiltCharacter
    position: int
    resource: ResourcePool = field(init=False)
    effects: EffectContainer = field(default_factory=EffectContainer, init=False)
    counters: dict[str, Counter] = field(default_factory=dict, init=False)
    _hp: float | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        self.effects.holder_id = self.built.id
        if self.built.max_energy is None:
            self.resource = NoUltimate()
        else:
            self.resource = EnergyPool(maximum=float(self.built.max_energy), regen=self.built.stats[StatKey.ENERGY_REGEN])

    @property
    def id(self) -> str:
        return self.built.id

    @property
    def name(self) -> str:
        return self.built.name

    def speed(self) -> float:
        return self.stats[StatKey.SPD]

    @property
    def stats(self) -> StatSheet:
        buffs = self.effects.total()
        if not buffs.values:
            return self.built.stats
        return self.stats_with(buffs)

    def stats_with(self, extra: StatSheet) -> StatSheet:
        return finalize_base_stats(self.built.pre_final.merged(extra), self.built.base)

    @property
    def level(self) -> int:
        return self.built.level

    @property
    def eidolon(self) -> int:
        return self.built.eidolon

    @property
    def max_hp(self) -> float:
        return self.stats[StatKey.HP]

    @property
    def hp(self) -> float:
        return self.max_hp if self._hp is None else min(self._hp, self.max_hp)

    @hp.setter
    def hp(self, value: float) -> None:
        self._hp = value

    def spend_hp(self, *, ratio: float=0.0, amount: float=0.0) -> float:
        cost = self.hp * ratio + amount
        cost = min(cost, max(0.0, self.hp - 1.0))
        self._hp = self.hp - cost
        return cost

    def heal(self, amount: float) -> None:
        if self._hp is None:
            return
        self._hp = min(self._hp + amount, self.max_hp)
        if self._hp >= self.max_hp:
            self._hp = None

    def counter(self, name: str, *, maximum: float | None=None) -> Counter:
        c = self.counters.get(name)
        if c is None:
            c = Counter(name=name, maximum=maximum)
            self.counters[name] = c
        return c

    @property
    def element(self) -> Element:
        return self.built.element

@dataclass
class Enemy:
    name: str = '敵'
    level: int = 95
    max_hp: float = 2000000.0
    hp: float = field(default=0.0)
    spd: float = 120.0
    resistances: dict[Element, float] = field(default_factory=dict)
    default_res: float = 0.2
    weaknesses: set[Element] = field(default_factory=set)
    behavior: EnemyBehavior = EnemyBehavior.PASSIVE
    behavior_at_cycle: int = 1
    effects: EffectContainer = field(default_factory=EffectContainer)
    is_broken: bool = False
    max_toughness: float = 0.0
    toughness: float = field(default=0.0)
    break_turns_left: int = 0
    id: str = 'enemy'
    position: int = 0
    has_attacked: bool = False

    def __post_init__(self) -> None:
        if self.hp == 0.0:
            self.hp = self.max_hp
        if self.toughness == 0.0:
            self.toughness = self.max_toughness
        self.effects.holder_id = self.id

    @property
    def breakable(self) -> bool:
        return self.max_toughness > 0

    def speed(self) -> float:
        return self.spd

    @property
    def stats(self) -> StatSheet:
        return self.effects.total()

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def res_for(self, element: Element) -> float:
        return self.resistances.get(element, self.default_res)

    def take(self, damage: float) -> float:
        dealt = min(damage, self.hp)
        self.hp -= dealt
        return dealt

def make_enemies(count: int, *, level: int=95, hp: float=10000000.0, spd: float=120.0, res: float=0.2, weaknesses: set[Element] | None=None, toughness: float=0.0, behavior: EnemyBehavior=EnemyBehavior.PASSIVE, behavior_at_cycle: int=1) -> list[Enemy]:
    if count < 1:
        raise ValueError(f'敵は 1 体以上必要です: {count}')
    return [Enemy(name=f'敵{i + 1}' if count > 1 else '敵', id=f'enemy{i}', position=i, level=level, max_hp=hp, spd=spd, default_res=res, weaknesses=set(weaknesses or ()), max_toughness=toughness, behavior=behavior, behavior_at_cycle=behavior_at_cycle) for i in range(count)]
