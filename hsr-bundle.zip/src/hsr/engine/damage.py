from __future__ import annotations
from dataclasses import dataclass, field
from enum import StrEnum
from ..model.enums import BREAK_ELEMENT_COEF, DamageType, Element
from ..model.stats import StatKey, StatSheet
_DMG_PCT_KEY: dict[DamageType, StatKey] = {DamageType.BASIC: StatKey.DMG_PCT_BASIC, DamageType.SKILL: StatKey.DMG_PCT_SKILL, DamageType.ULTIMATE: StatKey.DMG_PCT_ULTIMATE, DamageType.FOLLOWUP: StatKey.DMG_PCT_FOLLOWUP, DamageType.DOT: StatKey.DMG_PCT_DOT, DamageType.MEMO: StatKey.DMG_PCT_MEMO, DamageType.ELATION: StatKey.DMG_PCT_ELATION}
_CRIT_DMG_KEY: dict[DamageType, StatKey] = {DamageType.FOLLOWUP: StatKey.CRIT_DMG_FOLLOWUP, DamageType.ULTIMATE: StatKey.CRIT_DMG_ULTIMATE}
_CAN_CRIT_DEFAULT: dict[DamageType, bool] = {DamageType.BASIC: True, DamageType.SKILL: True, DamageType.ULTIMATE: True, DamageType.TALENT: True, DamageType.FOLLOWUP: True, DamageType.MEMO: True, DamageType.ELATION: True, DamageType.DOT: False, DamageType.ADDITIONAL: True, DamageType.BREAK: False, DamageType.SUPER_BREAK: False, DamageType.TRUE: False}
_NO_DMG_BOOST = {DamageType.BREAK, DamageType.TRUE, DamageType.ELATION}
_USES_BREAK_EFFECT = {DamageType.BREAK, DamageType.SUPER_BREAK}

class CritMode(StrEnum):
    AVERAGE = 'average'
    CRIT = 'crit'
    NO_CRIT = 'no_crit'

@dataclass(frozen=True)
class Attacker:
    level: int
    stats: StatSheet

@dataclass(frozen=True)
class Defender:
    level: int
    res: float = 0.0
    stats: StatSheet = field(default_factory=StatSheet)
    is_broken: bool = False
    max_toughness: float = 0.0

@dataclass(frozen=True)
class DamageRequest:
    element: Element
    dmg_type: DamageType
    scalings: tuple[tuple[StatKey, float], ...] = ()
    flat: float = 0.0
    can_crit: bool | None = None
    break_base: float = 0.0
    elation_base: float = 0.0
    elation_coef: float = 1.0
    independent: float = 1.0
    extra_types: tuple[DamageType, ...] = ()

    def crits(self) -> bool:
        if self.can_crit is not None:
            return self.can_crit
        return _CAN_CRIT_DEFAULT.get(self.dmg_type, False)

@dataclass(frozen=True)
class DamageResult:
    damage: float
    base: float
    crit: float
    dmg_boost: float
    defense: float
    resistance: float
    vulnerability: float
    mitigation: float
    broken: float
    independent: float = 1.0

    def breakdown(self) -> str:
        return f'{self.damage:,.1f} = base {self.base:,.1f} × crit {self.crit:.4f} × dmg {self.dmg_boost:.4f} × def {self.defense:.4f} × res {self.resistance:.4f} × vuln {self.vulnerability:.4f} × mit {self.mitigation:.4f} × brk {self.broken:.4f}' + (f' × ind {self.independent:.4f}' if self.independent != 1.0 else '')

def base_damage(req: DamageRequest, stats: StatSheet) -> float:
    if req.dmg_type in _USES_BREAK_EFFECT:
        return req.break_base * (1.0 + stats[StatKey.BREAK_EFFECT])
    if req.dmg_type is DamageType.ELATION:
        return req.elation_base
    return sum((stats[key] * mult for key, mult in req.scalings)) + req.flat

def crit_multiplier(stats: StatSheet, mode: CritMode, can_crit: bool, *, taken: float=0.0, dmg_type: DamageType | None=None, extra_types: tuple[DamageType, ...]=()) -> float:
    if not can_crit:
        return 1.0
    crit_dmg = stats[StatKey.CRIT_DMG] + taken
    key = _CRIT_DMG_KEY.get(dmg_type) if dmg_type is not None else None
    if key is not None:
        crit_dmg += stats[key]
    for extra in extra_types:
        extra_key = _CRIT_DMG_KEY.get(extra)
        if extra_key is not None:
            crit_dmg += stats[extra_key]
    match mode:
        case CritMode.CRIT:
            return 1.0 + crit_dmg
        case CritMode.NO_CRIT:
            return 1.0
        case _:
            return 1.0 + min(stats[StatKey.CRIT_RATE], 1.0) * crit_dmg

def dmg_boost_multiplier(req: DamageRequest, stats: StatSheet) -> float:
    if req.dmg_type is DamageType.ELATION:
        return req.elation_coef
    if req.dmg_type in _NO_DMG_BOOST:
        return 1.0
    boost = stats.dmg_pct_for(req.element, _DMG_PCT_KEY.get(req.dmg_type))
    for extra in req.extra_types:
        key = _DMG_PCT_KEY.get(extra)
        if key is not None:
            boost += stats[key]
    return 1.0 + boost

def defense_multiplier(attacker_level: int, defender_level: int, def_down: float=0.0, def_ignore: float=0.0) -> float:
    atk_term = 20.0 + attacker_level
    reduction = max(0.0, 1.0 - def_down - def_ignore)
    return atk_term / ((20.0 + defender_level) * reduction + atk_term)

def resistance_multiplier(res: float, res_pen: float) -> float:
    return 1.0 - res + res_pen

def vulnerability_multiplier(defender_stats: StatSheet, dmg_type: DamageType | None=None) -> float:
    total = defender_stats[StatKey.VULNERABILITY]
    if dmg_type is DamageType.ELATION:
        total += defender_stats[StatKey.ELATION_TAKEN]
    return 1.0 + total

def mitigation_multiplier(reductions: tuple[float, ...]=()) -> float:
    total = 1.0
    for r in reductions:
        total *= 1.0 - r
    return total

def broken_multiplier(is_broken: bool) -> float:
    return 1.0 if is_broken else 0.9
BREAK_LEVEL_COEF: dict[int, float] = {80: 3767.5533}

def break_level_coef(level: int) -> float:
    try:
        return BREAK_LEVEL_COEF[level]
    except KeyError:
        raise NotImplementedError(f'レベル {level} の撃破ダメージ固有値が未取得です (持っているのは {sorted(BREAK_LEVEL_COEF)})。BREAK_LEVEL_COEF に足してください') from None
TOUGHNESS_SCALE_DIVISOR = 120.0

def break_damage_base(element: Element, attacker_level: int, max_toughness: float) -> float:
    toughness_coef = 0.5 + max(0.0, max_toughness) / TOUGHNESS_SCALE_DIVISOR
    return BREAK_ELEMENT_COEF[element] * break_level_coef(attacker_level) * toughness_coef
ELATION_BASE_FACTOR = 2.0
NOTE_COEF_SCALE = 240.0
NOTE_COEF_CAP = 5.0

def elation_damage_base(level: int, mult: float) -> float:
    return break_level_coef(level) * ELATION_BASE_FACTOR * mult

def note_coefficient(notes: float) -> float:
    if notes <= 0:
        return 1.0
    return 1.0 + NOTE_COEF_CAP * notes / (NOTE_COEF_SCALE + notes)

def elation_multiplier(stats: StatSheet, notes: float) -> float:
    return (1.0 + stats[StatKey.ELATION_RATE]) * (1.0 + stats[StatKey.DMG_PCT_ELATION]) * note_coefficient(notes)

def super_break_damage_base(attacker_level: int, toughness_reduced: float, conversion_rate: float=1.0) -> float:
    return break_level_coef(attacker_level) * (toughness_reduced / 10.0) * conversion_rate

def compute(req: DamageRequest, attacker: Attacker, defender: Defender, *, mode: CritMode=CritMode.AVERAGE, mitigations: tuple[float, ...]=()) -> DamageResult:
    a = attacker.stats
    d = defender.stats
    if req.dmg_type is DamageType.TRUE:
        value = req.flat + sum((a[k] * m for k, m in req.scalings))
        return DamageResult(value, value, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
    base = base_damage(req, a)
    crit = crit_multiplier(a, mode, req.crits(), taken=d[StatKey.CRIT_DMG_TAKEN], dmg_type=req.dmg_type, extra_types=req.extra_types)
    boost = dmg_boost_multiplier(req, a)
    defense = defense_multiplier(attacker.level, defender.level, def_down=d[StatKey.DEF_DOWN], def_ignore=a[StatKey.DEF_IGNORE] + (a[StatKey.DEF_IGNORE_ELATION] if req.dmg_type is DamageType.ELATION else 0.0) + (a[StatKey.DEF_IGNORE_ULTIMATE] if req.dmg_type is DamageType.ULTIMATE else 0.0))
    resistance = resistance_multiplier(defender.res, a.res_pen_for(req.element))
    vulnerability = vulnerability_multiplier(d, req.dmg_type)
    mitigation = mitigation_multiplier(mitigations)
    broken = broken_multiplier(defender.is_broken)
    damage = base * crit * boost * defense * resistance * vulnerability * mitigation * broken * req.independent
    return DamageResult(damage=max(0.0, damage), base=base, crit=crit, dmg_boost=boost, defense=defense, resistance=resistance, vulnerability=vulnerability, mitigation=mitigation, broken=broken, independent=req.independent)
