from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from itertools import count

class Event(StrEnum):
    BATTLE_START = 'battle_start'
    CYCLE_START = 'cycle_start'
    TURN_START = 'turn_start'
    TURN_END = 'turn_end'
    ON_ACTION_START = 'on_action_start'
    ON_BASIC_USED = 'on_basic_used'
    ON_SKILL_USED = 'on_skill_used'
    ON_ULT_USED = 'on_ult_used'
    ON_FOLLOWUP = 'on_followup'
    ON_ATTACK = 'on_attack'
    ON_ATTACK_START = 'on_attack_start'
    ON_ELATION_SKILL = 'on_elation_skill'
    ON_SHARED_GAIN = 'on_shared_gain'
    ON_SHARED_SPEND = 'on_shared_spend'
    ON_AHA_TIME_END = 'on_aha_time_end'
    ON_SP_BATCH_END = 'on_sp_batch_end'
    ON_ALLY_TARGETED = 'on_ally_targeted'
    BEFORE_DAMAGE = 'before_damage'
    AFTER_DAMAGE = 'after_damage'
    ON_KILL = 'on_kill'
    ON_HEAL = 'on_heal'
    ON_HP_LOSS = 'on_hp_loss'
    ON_ENEMY_HIT = 'on_enemy_hit'
    ON_ENERGY_GAIN = 'on_energy_gain'
    ON_SP_CHANGE = 'on_sp_change'
    ON_SP_GAIN = 'on_sp_gain'
    ON_REWARD_GAIN = 'on_reward_gain'
    ON_SHIELD = 'on_shield'
    ON_ASSIST_SKILL = 'on_assist_skill'
    ON_EFFECT_EXPIRED = 'on_effect_expired'
    ON_EFFECT_APPLIED = 'on_effect_applied'
    ON_MEMO_SKILL_START = 'on_memo_skill_start'
    ON_MEMO_SKILL = 'on_memo_skill'
    ON_MEMO_SUMMON = 'on_memo_summon'
    ON_MEMO_DISMISS = 'on_memo_dismiss'
    ON_WEAKNESS_BREAK = 'on_weakness_break'
    ON_BREAK_RECOVER_ATTEMPT = 'on_break_recover_attempt'
    ON_BREAK_RECOVER = 'on_break_recover'

@dataclass
class Listener:
    id: int
    event: Event
    fn: Callable[..., None]
    owner_id: str
    priority: int = 0
    per_turn: int | None = None
    per_battle: int | None = None
    per_source: int | None = None
    fired_this_turn: int = 0
    fired_total: int = 0
    fired_by_source: dict[str, int] = field(default_factory=dict)

    def can_fire(self, source_id: str | None) -> bool:
        if self.per_turn is not None and self.fired_this_turn >= self.per_turn:
            return False
        if self.per_battle is not None and self.fired_total >= self.per_battle:
            return False
        if self.per_source is not None:
            if self.fired_by_source.get(source_id or '', 0) >= self.per_source:
                return False
        return True

    def note_fired(self, source_id: str | None) -> None:
        self.fired_this_turn += 1
        self.fired_total += 1
        if self.per_source is not None:
            key = source_id or ''
            self.fired_by_source[key] = self.fired_by_source.get(key, 0) + 1

    def reset_turn(self) -> None:
        self.fired_this_turn = 0

    def reset_source_counts(self) -> None:
        self.fired_by_source.clear()

class EventBus:
    MAX_DEPTH = 24

    def __init__(self) -> None:
        self._listeners: dict[Event, list[Listener]] = {}
        self._ids = count(1)
        self._depth = 0

    def subscribe(self, event: Event, fn: Callable[..., None], *, owner_id: str, priority: int=0, per_turn: int | None=None, per_battle: int | None=None, per_source: int | None=None) -> int:
        listener = Listener(id=next(self._ids), event=event, fn=fn, owner_id=owner_id, priority=priority, per_turn=per_turn, per_battle=per_battle, per_source=per_source)
        self._listeners.setdefault(event, []).append(listener)
        return listener.id

    def unsubscribe(self, listener_id: int) -> None:
        for listeners in self._listeners.values():
            for x in list(listeners):
                if x.id == listener_id:
                    listeners.remove(x)

    def unsubscribe_owner(self, owner_id: str) -> None:
        for listeners in self._listeners.values():
            for x in list(listeners):
                if x.owner_id == owner_id:
                    listeners.remove(x)

    def find(self, listener_id: int) -> Listener | None:
        for listeners in self._listeners.values():
            for x in listeners:
                if x.id == listener_id:
                    return x
        return None

    def emit(self, event: Event, *, source_id: str | None=None, **payload) -> None:
        listeners = sorted(self._listeners.get(event, ()), key=lambda x: (x.priority, x.id))
        if not listeners:
            return
        if self._depth >= self.MAX_DEPTH:
            raise RuntimeError(f'イベントの入れ子が深すぎます ({event})。追加攻撃が追加攻撃を呼ぶループになっていないか確認してください')
        self._depth += 1
        try:
            for x in listeners:
                if not x.can_fire(source_id):
                    continue
                x.note_fired(source_id)
                x.fn(source_id=source_id, **payload)
        finally:
            self._depth -= 1

    def reset_turn_counters(self) -> None:
        for listeners in self._listeners.values():
            for x in listeners:
                x.reset_turn()
