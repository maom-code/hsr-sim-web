from __future__ import annotations
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import StrEnum
from .. import content
from ..content.base import CharacterImpl, impl_for, skill_sp_cost
from ..content.equipment import apply_light_cone, apply_relic_sets
from ..model.enums import DamageType, Element
from ..model.stats import StatKey, StatSheet
from . import damage as dmg
from .effects import Effect, EffectContainer, Stacking, TickTiming
from .entity import Character, Enemy, EnemyBehavior
from .events import Event, EventBus
from .memosprite import Memosprite, MemospriteSpec
from .queue import ActionQueue, TurnKind, av_budget, cycles_elapsed
from . import break_effects
from .elation import Aha
from .timer import Countdown
NON_ATTACK_TYPES = frozenset({DamageType.TRUE, DamageType.ADDITIONAL, DamageType.DOT, DamageType.BREAK, DamageType.SUPER_BREAK})
from .resources import ENERGY_ON_BEING_HIT, Counter, SkillPoints
BREAK_DELAY = 0.25

def _ignores_weakness(source) -> bool:
    effects = getattr(source, 'effects', None)
    return bool(effects is not None and effects.has(break_effects.IGNORE_WEAKNESS_KEY))

class Action(StrEnum):
    BASIC = 'basic'
    SKILL = 'skill'
    ULTIMATE = 'ultimate'

@dataclass
class LogLine:
    av: float
    cycle: int
    actor: str
    text: str
    damage: float = 0.0
    turn: int = 0

    def render(self) -> str:
        dmg_part = f'  {self.damage:>12,.0f}' if self.damage else ' ' * 14
        return f'[{self.av:7.1f}] C{self.cycle} {self.actor:<14}{dmg_part}  {self.text}'

@dataclass
class BattleResult:
    total_damage: float
    total_av: float
    cycles: float
    sp_balance: int
    sp_final: int
    damage_by_character: dict[str, float]
    damage_by_source: dict[str, float]
    log: list[LogLine]
    av_budget: float = 0.0

    @property
    def dpa(self) -> float:
        denom = self.av_budget or self.total_av
        return self.total_damage / denom if denom else 0.0

    def summary(self) -> str:
        lines = [f'総ダメージ   {self.total_damage:>14,.0f}', f'消費行動値   {self.total_av:>14,.1f}  ({self.cycles:.2f} サイクル／DPA の分母 {self.av_budget:,.0f})', f'DPA          {self.dpa:>14,.1f}', f'SP 収支      {self.sp_balance:>+14.1f}  (残 {self.sp_final:.1f})', '', '内訳']
        for name, value in sorted(self.damage_by_character.items(), key=lambda x: -x[1]):
            share = value / self.total_damage if self.total_damage else 0.0
            lines.append(f'  {name:<16} {value:>14,.0f}  {share:6.1%}')
        memo_only = {k: v for k, v in self.damage_by_source.items() if k not in self.damage_by_character}
        if memo_only:
            lines.append('')
            lines.append('  うち憶像 (内数)')
            for name, value in sorted(memo_only.items(), key=lambda x: -x[1]):
                share = value / self.total_damage if self.total_damage else 0.0
                lines.append(f'    {name:<14} {value:>14,.0f}  {share:6.1%}')
        return '\n'.join(lines)

@dataclass
class _AttackScope:
    source: object
    dmg_type: object = None
    hits: int = 0
    amount: float = 0.0
    target_ids: set = field(default_factory=set)
    struck_ids: set = field(default_factory=set)
    rider: bool = False

@dataclass
class Battle:
    team: list[Character]
    enemies: list[Enemy] = field(default_factory=list)
    max_cycles: int = 2
    sp: SkillPoints = field(default_factory=SkillPoints)
    shared: dict[str, Counter] = field(default_factory=dict)
    crit_mode: dmg.CritMode = dmg.CritMode.AVERAGE
    policy: dict[str, 'Policy'] = field(default_factory=dict)
    ult_policy: dict = field(default_factory=dict)
    ultimate_as_followup: bool = False
    use_technique: bool = True
    enemy_attacks: bool = False
    enemy_hit_ratio: float = 0.1
    enemy_hit_energy: bool = False
    target_override: dict[str, str] = field(default_factory=dict)
    queue: ActionQueue = field(default_factory=ActionQueue, init=False)
    bus: EventBus = field(default_factory=EventBus, init=False)
    log: list[LogLine] = field(default_factory=list, init=False)
    damage_by_character: dict[str, float] = field(default_factory=dict, init=False)
    damage_by_source: dict[str, float] = field(default_factory=dict, init=False)
    total_damage: float = field(default=0.0, init=False)
    _impls: dict[str, CharacterImpl] = field(default_factory=dict, init=False)
    memosprites: list[Memosprite] = field(default_factory=list, init=False)
    timers: list[Countdown] = field(default_factory=list, init=False)
    aha: 'Aha' = field(init=False, default=None)
    healing_done: dict[str, float] = field(default_factory=dict, init=False)
    _pre_battle: bool = field(default=True, init=False)
    _action_stack: list = field(default_factory=list, init=False)
    _turn_no: int = field(default=0, init=False)
    acting: Character | None = field(default=None, init=False)
    _sp_batch_depth: int = field(default=0, init=False)
    skill_uses: dict[str, int] = field(default_factory=dict, init=False)
    turn_actors: dict[int, tuple[str, float]] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        if not self.enemies:
            raise ValueError('敵が 1 体もいません。entity.make_enemies を使ってください')
        for i, c in enumerate(self.team):
            self.queue.add(c, order=i)
            self._impls[c.id] = impl_for(c.id, c.name)
        for j, e in enumerate(self.enemies):
            e.position = j
            self.queue.add(e, order=len(self.team) + j)
        self.aha = Aha(self)
        for c in self.team:
            for note in apply_light_cone(c, self) + apply_relic_sets(c, self):
                self._log(c.name, f'※ 未実装: {note}')
            for note in getattr(self._impls[c.id], 'unimplemented', ()):
                self._log(c.name, '※ 未実装: ' + note)
            impl = self._impls[c.id]
            setup = getattr(impl, 'on_battle_start', None)
            if setup is not None:
                setup(c, self)
            for rank in range(1, c.eidolon + 1):
                hook = getattr(impl, f'eidolon_{rank}', None)
                if hook is not None:
                    self._log(c.name, f'星魂{rank}')
                    hook(c, self)
        self._pre_battle = False
        if self.use_technique:
            for c in self.team:
                hook = getattr(self._impls[c.id], 'technique', None)
                if hook is None:
                    continue
                self._log(c.name, '秘技')
                with self.attack_action(c):
                    hook(c, self)
        self.aha.start()
        self.bus.emit(Event.BATTLE_START)

    @property
    def alive_enemies(self) -> list[Enemy]:
        return [e for e in self.enemies if e.alive]

    @property
    def target(self) -> Enemy | None:
        alive = self.alive_enemies
        return alive[0] if alive else None

    def adjacent_to(self, enemy: Enemy) -> list[Enemy]:
        return [e for e in self.enemies if e.alive and abs(e.position - enemy.position) == 1]

    def deal_damage(self, source: Character, target: Enemy, element: Element, dmg_type: DamageType, scalings: tuple[tuple[StatKey, float], ...], *, flat: float=0.0, break_base: float=0.0, can_crit: bool | None=None, crit_rate_override: float | None=None, weight: float=1.0, independent: float=1.0, elation: tuple[float, float] | None=None, elation_rate: float | None=None) -> float:
        elation_base = elation_coef = 0.0
        if dmg_type is DamageType.ELATION:
            mult, notes = elation or (0.0, 0.0)
            stats = source.stats
            if elation_rate is not None and elation_rate > stats[StatKey.ELATION_RATE]:
                stats = stats.merged(StatSheet.of(elation_rate=elation_rate - stats[StatKey.ELATION_RATE]))
            elation_base = dmg.elation_damage_base(source.level, mult)
            elation_coef = dmg.elation_multiplier(stats, notes)
        extra_types: tuple[DamageType, ...] = ()
        if self.ultimate_as_followup and dmg_type is DamageType.ULTIMATE and (getattr(source, 'attributed_to', source) in self.team):
            extra_types = (DamageType.FOLLOWUP,)
        req = dmg.DamageRequest(element=element, dmg_type=dmg_type, extra_types=extra_types, scalings=scalings, flat=flat, break_base=break_base, elation_base=elation_base, elation_coef=elation_coef or 1.0, can_crit=can_crit, crit_rate_override=crit_rate_override, independent=source.effects.damage_multiplier() * independent)
        target_stats = target.stats
        mine = sum((e.contribution()[StatKey.CRIT_DMG_TAKEN_FROM_SOURCE] for e in target.effects if e.source_id == source.id))
        if mine:
            target_stats = target_stats.merged(StatSheet.of(crit_dmg_taken=mine))
        result = dmg.compute(req, dmg.Attacker(level=source.level, stats=source.stats), dmg.Defender(level=target.level, res=target.res_for(element) - target_stats[StatKey.RES_DOWN], stats=target_stats, is_broken=target.is_broken), mode=self.crit_mode)
        dealt = target.take(result.damage * weight)
        self.total_damage += dealt
        owner = getattr(source, 'attributed_to', source)
        self.damage_by_character[owner.name] = self.damage_by_character.get(owner.name, 0.0) + dealt
        self.damage_by_source[source.name] = self.damage_by_source.get(source.name, 0.0) + dealt
        return dealt

    def attack(self, source: Character, element: Element, dmg_type: DamageType, *, main: tuple[tuple[StatKey, float], ...]=(), adjacent: tuple[tuple[StatKey, float], ...]=(), aoe: tuple[tuple[StatKey, float], ...]=(), others: tuple[tuple[StatKey, float], ...]=(), random: tuple[tuple[StatKey, float], ...]=(), random_hits: int=0, toughness: float | dict | None=None, flat_main: float=0.0, flat_adjacent: float=0.0, flat_aoe: float=0.0, flat_random: float=0.0, target: Enemy | None=None, label: str='', can_crit: bool | None=None, crit_rate_override: float | None=None, independent: float | Callable[[Enemy], float]=1.0, elation: tuple[float, float] | None=None, elation_shape: str='main', elation_rate: float | None=None, independent_random: float | Callable[[Enemy], float] | None=None, counts_as_attack: bool=True, rider: bool=False) -> float:
        alive = self.alive_enemies
        if not alive:
            return 0.0
        is_attack = counts_as_attack and dmg_type not in NON_ATTACK_TYPES
        current = self._action_stack[-1] if self._action_stack else None
        if is_attack and (not rider) and (not (current is not None and current.source is source and (current.dmg_type is dmg_type))):
            self.bus.emit(Event.ON_ATTACK_START, source_id=source.id, source=source, dmg_type=dmg_type)
        focus = target or alive[0]

        def tough(shape: str) -> float:
            if toughness is None:
                return 0.0
            if not isinstance(toughness, dict):
                return float(toughness)
            if shape == 'random':
                return float(toughness.get('main', toughness.get('all', 0.0)))
            return float(toughness.get(shape, 0.0))
        total = 0.0
        hit: set[str] = set()
        ind = independent if callable(independent) else lambda _e: independent
        ind_random = ind if independent_random is None else independent_random if callable(independent_random) else lambda _e: independent_random
        hits = 0
        if main or flat_main or (elation and elation_shape == 'main'):
            total += self.deal_damage(source, focus, element, dmg_type, main, flat=flat_main, can_crit=can_crit, crit_rate_override=crit_rate_override, independent=ind(focus), elation=elation, elation_rate=elation_rate)
            hit.add(focus.id)
            hits += 1
            self.reduce_toughness(source, focus, tough('main'), element)
        if adjacent or flat_adjacent or (elation and elation_shape == 'adjacent'):
            for e in self.adjacent_to(focus):
                total += self.deal_damage(source, e, element, dmg_type, adjacent, flat=flat_adjacent, can_crit=can_crit, crit_rate_override=crit_rate_override, independent=ind(e), elation=elation, elation_rate=elation_rate)
                hit.add(e.id)
                hits += 1
                self.reduce_toughness(source, e, tough('adjacent'), element)
        if others:
            for e in alive:
                if e is focus:
                    continue
                total += self.deal_damage(source, e, element, dmg_type, others, can_crit=can_crit, independent=ind(e), crit_rate_override=crit_rate_override, elation=elation, elation_rate=elation_rate)
                hit.add(e.id)
                hits += 1
                self.reduce_toughness(source, e, tough('all'), element)
        if aoe or flat_aoe or (elation and elation_shape == 'aoe'):
            for e in alive:
                total += self.deal_damage(source, e, element, dmg_type, aoe, flat=flat_aoe, can_crit=can_crit, crit_rate_override=crit_rate_override, independent=ind(e), elation=elation, elation_rate=elation_rate)
                hit.add(e.id)
                hits += 1
                self.reduce_toughness(source, e, tough('all'), element)
        struck = set(hit)
        if (random or flat_random or (elation and elation_shape == 'random')) and random_hits:
            share = random_hits / len(alive)
            hits += int(random_hits)
            for e in alive:
                total += self.deal_damage(source, e, element, dmg_type, random, flat=flat_random, can_crit=can_crit, crit_rate_override=crit_rate_override, weight=share, independent=ind_random(e), elation=elation, elation_rate=elation_rate)
                hit.add(e.id)
                self.reduce_toughness(source, e, tough('random') * share, element)
        hit_count = len(hit)
        self._log(source.name, label or dmg_type.value, total)
        self.bus.emit(Event.AFTER_DAMAGE, source_id=source.id, source=source, dmg_type=dmg_type, amount=total, targets_hit=hit_count, hits=hits, rider=rider, as_followup=self._as_followup(source, dmg_type), targets=[e for e in self.enemies if e.id in hit])
        if not is_attack:
            return total
        segment = _AttackScope(source=source, dmg_type=dmg_type, hits=hits, amount=total, target_ids=set(hit), struck_ids=struck, rider=rider)
        if not self._action_stack:
            self._emit_attack(segment)
            return total
        current = self._action_stack[-1]
        if current is not None and current.source is source and (current.dmg_type is dmg_type) and (current.rider == rider):
            current.hits += hits
            current.amount += total
            current.target_ids |= hit
            current.struck_ids |= struck
            return total
        self._action_stack[-1] = segment
        if current is not None:
            self._emit_attack(current)
        return total

    @contextmanager
    def sp_batch(self, actor):
        self._sp_batch_depth += 1
        try:
            yield
        finally:
            self._sp_batch_depth -= 1
            if self._sp_batch_depth == 0:
                self.bus.emit(Event.ON_SP_BATCH_END, source_id=getattr(actor, 'id', None), actor=actor)

    @property
    def in_sp_batch(self) -> bool:
        return self._sp_batch_depth > 0

    @contextmanager
    def attack_action(self, source=None):
        self._action_stack.append(None)
        try:
            yield
        finally:
            pending = self._action_stack.pop()
            if pending is not None:
                self._emit_attack(pending)

    def _emit_attack(self, scope: '_AttackScope') -> None:
        if not scope.hits:
            return
        self.bus.emit(Event.ON_ATTACK, source_id=getattr(scope.source, 'id', None), source=scope.source, dmg_type=scope.dmg_type, amount=scope.amount, hits=scope.hits, as_followup=self._as_followup(scope.source, scope.dmg_type), targets_hit=len(scope.target_ids), targets_struck=len(scope.struck_ids) or 1, targets=[e for e in self.enemies if e.id in scope.target_ids], rider=scope.rider)

    def apply_effect(self, target: Character | Enemy, effect: Effect) -> Effect | None:
        effect.pre_battle = self._pre_battle
        applied = target.effects.apply(effect)
        if applied is None:
            return None
        stacks = f'×{applied.stacks}' if applied.stacks > 1 else ''
        turns = f' {applied.duration.turns}T' if applied.duration else ''
        self._log(target.name, f'+ {applied.label or applied.key}{stacks}{turns}')
        self.bus.emit(Event.ON_EFFECT_APPLIED, source_id=effect.source_id, target=target, effect=applied)
        return applied

    def apply_to_team(self, effect_factory) -> None:
        for c in self.team:
            self.apply_effect(c, effect_factory(c))
        for m in self.memosprites:
            self.apply_effect(m, effect_factory(m))

    def apply_aura(self, holder, effect_factory, *, key: str | None=None) -> None:
        self.apply_to_team(effect_factory)

        def follow(memo=None, **kw) -> None:
            if memo is not None:
                self.apply_effect(memo, effect_factory(memo))
        listener = self.bus.subscribe(Event.ON_MEMO_SUMMON, follow, owner_id=getattr(holder, 'id', ''))
        if key is None:
            return
        mine = holder.effects.get(key)
        if mine is None:
            self.bus.unsubscribe(listener)
            return
        self._drop_listeners(mine)
        mine.listener_ids.append(listener)

    def remove_effect(self, target: Character | Enemy, key: str) -> None:
        removed = target.effects.remove(key)
        if removed is not None:
            self._drop_listeners(removed)

    def _drop_listeners(self, effect: Effect) -> None:
        for lid in effect.listener_ids:
            self.bus.unsubscribe(lid)
        effect.listener_ids.clear()

    def summon_memosprite(self, summoner: Character, spec: MemospriteSpec, *, entry_av: float | None=None, allow_multiple: bool=False) -> Memosprite:
        if not allow_multiple:
            existing = self.memosprite_of(summoner)
            if existing is not None:
                return existing
        snapshot = summoner.stats
        inherited = summoner.stats_with(summoner.effects.total(only_pre_battle=True))
        base = StatSheet(dict(inherited.values))
        hp_total = spec.initial_hp(inherited)
        hp_white = summoner.built.base[StatKey.HP] * spec.hp_ratio if spec.hp_from is StatKey.HP else 0.0
        base[StatKey.HP] = hp_total
        base[StatKey.SPD] = spec.initial_speed(snapshot)
        memo = Memosprite(summoner=summoner, name=spec.name, element=summoner.element, level=summoner.level, spd=base[StatKey.SPD], aggro=spec.aggro, base=base, hp_white=hp_white, hp_bonus=hp_total - hp_white)
        self.memosprites.append(memo)
        if memo.on_action_bar:
            av = entry_av
            if av is None and spec.acts_immediately:
                av = 0.0
            self.queue.add(memo, order=summoner.position, initial_av=av)
        self._log(summoner.name, '召喚: {} (HP {:,.0f} / 速度 {:.0f})'.format(memo.name, memo.max_hp, memo.spd))
        self.bus.emit(Event.ON_MEMO_SUMMON, source_id=summoner.id, memo=memo)
        return memo

    def memosprite_of(self, summoner: Character) -> Memosprite | None:
        for m in self.memosprites:
            if m.summoner is summoner and m.alive:
                return m
        return None

    def memosprites_of(self, summoner: Character) -> list[Memosprite]:
        return [m for m in self.memosprites if m.summoner is summoner and m.alive]

    def add_countdown(self, timer: Countdown, *, order: int=0, entry_av: float | None=None) -> Countdown:
        self.timers.append(timer)
        self.queue.add(timer, order=order, initial_av=entry_av)
        self._log(timer.name, f'カウントダウン開始 (速度 {timer.spd:.0f})')
        return timer

    def remove_countdown(self, timer: Countdown) -> None:
        if timer not in self.timers:
            return
        self.timers.remove(timer)
        self.queue.remove(timer)
        self._log(timer.name, 'カウントダウン終了')

    def dismiss_memosprite(self, memo: Memosprite) -> None:
        if memo not in self.memosprites:
            return
        self.memosprites.remove(memo)
        self.queue.remove(memo)
        for eff in list(memo.effects):
            self._drop_listeners(eff)
        self._log(memo.name, '退場')
        self.bus.emit(Event.ON_MEMO_DISMISS, source_id=memo.summoner.id, memo=memo)

    def heal(self, healer, target, amount: float, *, label: str='') -> float:
        from ..model.stats import StatKey as _SK
        healed = amount * (1.0 + healer.stats[_SK.HEAL_BOOST])
        taken = getattr(target, 'stats', None)
        if taken is not None:
            healed *= 1.0 + taken[_SK.HEAL_TAKEN]
        if hasattr(target, 'heal'):
            target.heal(healed)
        self.healing_done[healer.id] = self.healing_done.get(healer.id, 0.0) + healed
        self._log(healer.name, f'治癒 {healed:,.0f} -> {target.name}' + (f' ({label})' if label else ''))
        self.bus.emit(Event.ON_HEAL, source_id=healer.id, healer=healer, target=target, amount=healed)
        return healed

    def add_healing(self, who, amount: float) -> None:
        if amount <= 0:
            return
        self.healing_done[who.id] = self.healing_done.get(who.id, 0.0) + amount

    def healing_by(self, *entities) -> float:
        return sum((self.healing_done.get(e.id, 0.0) for e in entities if e is not None))

    def clear_healing(self, *entities, ratio: float=1.0) -> None:
        for e in entities:
            if e is None:
                continue
            self.healing_done[e.id] = self.healing_done.get(e.id, 0.0) * (1.0 - ratio)

    def tick_own_effects(self, holder) -> None:
        for expired in holder.effects.tick(holder.id, TurnKind.NORMAL, TickTiming.OWNER_TURN_START):
            self._drop_listeners(expired)
            self._log(holder.name, f'- {expired.label or expired.key} 終了')

    def spend_hp(self, who: Character, *, ratio: float=0.0, amount: float=0.0) -> float:
        spent = who.spend_hp(ratio=ratio, amount=amount)
        if spent:
            self._log(who.name, f'HP -{spent:,.0f} (残 {who.hp:,.0f})')
            self.bus.emit(Event.ON_HP_LOSS, source_id=who.id, target=who, amount=spent)
        return spent

    def target_ally(self, actor: Character, target) -> None:
        self.bus.emit(Event.ON_ALLY_TARGETED, source_id=actor.id, actor=actor, target=target)

    def target_team(self, actor) -> None:
        for ally in self.team:
            self.bus.emit(Event.ON_ALLY_TARGETED, source_id=getattr(actor, 'id', None), actor=actor, target=ally)

    def extra_turn(self, c: Character) -> None:
        self._log(c.name, '追加ターン')
        self._take_turn(c)

    def act_next(self, actor) -> None:
        if getattr(actor, 'on_action_bar', True):
            self.queue.act_next(actor)

    def act_now(self, memo: Memosprite) -> None:
        if not memo.alive:
            return
        impl = self._impls[memo.summoner.id]
        act = getattr(impl, 'memo_turn', None)
        if act is None:
            return
        self._log(memo.name, '即時行動')
        self.bus.emit(Event.ON_MEMO_SKILL_START, source_id=memo.summoner.id, memo=memo)
        with self.attack_action(memo):
            act(memo, self)
        self.bus.emit(Event.ON_MEMO_SKILL, source_id=memo.summoner.id, memo=memo)

    def gain_counter(self, who: Character, name: str, amount: float, *, maximum: float | None=None) -> float:
        counter = who.counter(name, maximum=maximum)
        gained = counter.gain(amount)
        if gained:
            self._log(who.name, f'{name} +{gained:.0f} (計 {counter.current:.0f})')
        return gained

    def spend_counter(self, who: Character, name: str, amount: float | None=None) -> float:
        counter = who.counter(name)
        spent = counter.spend(amount)
        if spent:
            self._log(who.name, f'{name} -{spent:.0f} (残 {counter.current:.0f})')
        return spent

    def counter_value(self, who: Character, name: str) -> float:
        return who.counter(name).current

    def shared_counter(self, name: str, *, maximum: float | None=None) -> Counter:
        counter = self.shared.get(name)
        if counter is None:
            counter = Counter(name=name, maximum=maximum)
            self.shared[name] = counter
        elif maximum is not None:
            counter.maximum = maximum
        return counter

    def gain_shared(self, name: str, amount: float, *, maximum: float | None=None) -> float:
        counter = self.shared_counter(name, maximum=maximum)
        gained = counter.gain(amount)
        if gained:
            self._log('PT', f'{name} +{gained:.0f} (計 {counter.current:.0f})')
            self.bus.emit(Event.ON_SHARED_GAIN, name=name, amount=gained, total=counter.current)
        return gained

    def spend_shared(self, name: str, amount: float | None=None) -> float:
        counter = self.shared_counter(name)
        spent = counter.spend(amount)
        if spent:
            self._log('PT', f'{name} -{spent:.0f} (残 {counter.current:.0f})')
            self.bus.emit(Event.ON_SHARED_SPEND, name=name, amount=spent, total=counter.current)
        return spent

    def shared_value(self, name: str) -> float:
        return self.shared_counter(name).current

    def gain_energy(self, who: Character, amount: float, *, apply_regen: bool=True) -> None:
        if hasattr(who.resource, 'regen'):
            who.resource.regen = who.stats[StatKey.ENERGY_REGEN]
        before = getattr(who.resource, 'current', None)
        regen = getattr(who.resource, 'regen', 0.0)
        who.resource.gain(amount, apply_regen=apply_regen)
        after = getattr(who.resource, 'current', None)
        if before is None or after is None:
            return
        requested = amount * (1.0 + regen) if apply_regen else amount
        gained = float(after) - float(before)
        self.bus.emit(Event.ON_ENERGY_GAIN, source_id=who.id, who=who, amount=gained, overflow=max(0.0, requested - gained))

    def spend_sp(self, n: int, *, actor=None) -> None:
        self.sp.spend(n)
        if n:
            self.notify_sp_spent(n, actor=actor if actor is not None else self.acting)

    def notify_sp_spent(self, n: float, *, actor=None) -> None:
        self.bus.emit(Event.ON_SP_CHANGE, spent=n, current=self.sp.current, actor=actor)

    def gain_sp(self, n: int) -> None:
        self.sp.gain(n)

    def advance_forward(self, who: Character, ratio: float) -> None:
        self.queue.advance_forward(who, ratio)

    def resolve_target_override(self, wearer: Character, priority: tuple[str, ...]) -> Character | None:
        others = [c for c in self.team if c is not wearer]
        if not others:
            return None
        picked = self.target_override.get(wearer.id)
        if picked:
            found = next((c for c in others if c.id == picked), None)
            if found is not None:
                return found
        for cid in priority:
            found = next((c for c in others if c.id == cid), None)
            if found is not None:
                return found
        return others[0]

    def delay_action(self, who, ratio: float) -> None:
        self.queue.delay(who, ratio)

    def _log(self, actor: str, text: str, damage: float=0.0) -> None:
        self.log.append(LogLine(self.queue.total_av, self.queue.cycle, actor, text, damage, self._turn_no))

    def _use_ultimates(self) -> None:
        guard = 0
        while True:
            guard += 1
            if guard > 20:
                raise RuntimeError('必殺技の連鎖が止まりません')
            ready = [c for c in self.team if c.resource.is_ready() and self._ult_allowed(c)]
            if not ready:
                return
            c = ready[0]
            c.resource.consume()
            self._log(c.name, '必殺技')
            self.bus.emit(Event.ON_ACTION_START, source_id=c.id, actor=c, action=Action.ULTIMATE)
            with self.attack_action(c):
                self._impls[c.id].ultimate(c, self)
            self.bus.emit(Event.ON_ULT_USED, source_id=c.id, actor=c)

    def _as_followup(self, source, dmg_type) -> bool:
        if dmg_type is DamageType.FOLLOWUP:
            return True
        return bool(self.ultimate_as_followup and dmg_type is DamageType.ULTIMATE and (getattr(source, 'attributed_to', source) in self.team))

    def reduce_toughness(self, source, target: Enemy, amount: float, element: Element) -> None:
        if not target.breakable or amount <= 0 or (not target.alive):
            return
        if target.is_broken:
            self._super_break(source, target, element, amount)
            return
        if element not in target.weaknesses and (not _ignores_weakness(source)):
            return
        stats = getattr(source, 'stats', None)
        efficiency = stats[StatKey.BREAK_EFFICIENCY] if stats is not None else 0.0
        target.toughness = max(0.0, target.toughness - amount * (1.0 + efficiency))
        if target.toughness > 0:
            return
        self._break(source, target, element)

    def _break(self, source, target: Enemy, element: Element) -> None:
        target.is_broken = True
        target.break_turns_left = 1
        self._log(target.name, f'弱点撃破（{element.value}）')
        level = getattr(source, 'level', 95)
        base = dmg.break_damage_base(element, level, target.max_toughness)
        dealt = self.deal_damage(source, target, element, DamageType.BREAK, (), break_base=base)
        self._log(source.name, '撃破ダメージ', dealt)
        break_effects.apply(self, source, target, element, base)
        self.delay_action(target, BREAK_DELAY)
        self.bus.emit(Event.ON_WEAKNESS_BREAK, source_id=getattr(source, 'id', None), source=source, target=target, element=element)

    def _tick_dots(self, target: Enemy) -> None:
        for eff in list(target.effects):
            if not eff.dot_base or eff.dot_element is None:
                continue
            source = next((c for c in self.team if c.id == eff.source_id), None)
            if source is None:
                continue
            dealt = self.deal_damage(source, target, eff.dot_element, DamageType.DOT, (), flat=eff.dot_base * eff.stacks)
            if dealt:
                self._log(source.name, eff.label or '持続ダメージ', dealt)

    def _super_break(self, source, target: Enemy, element: Element, amount: float) -> None:
        stats = getattr(source, 'stats', None)
        if stats is None:
            return
        rate = stats[StatKey.SUPER_BREAK_RATE]
        if rate <= 0:
            return
        reduced = amount * (1.0 + stats[StatKey.BREAK_EFFICIENCY])
        base = dmg.super_break_damage_base(getattr(source, 'level', 95), reduced, rate)
        dealt = self.deal_damage(source, target, element, DamageType.SUPER_BREAK, (), break_base=base)
        if dealt:
            self._log(source.name, '超撃破ダメージ', dealt)

    def _recover_toughness(self, target: Enemy) -> None:
        if not target.is_broken:
            return
        target.break_turns_left -= 1
        if target.break_turns_left > 0:
            return
        target.is_broken = False
        target.toughness = target.max_toughness
        self._log(target.name, '靭性が回復')

    def _ult_allowed(self, c: Character) -> bool:
        policy = self.ult_policy.get(c.id)
        if policy is None:
            return True
        return bool(policy(self, c))

    def impl_of(self, c: Character):
        return self._impls.get(c.id)

    def skill_cost(self, c: Character) -> int:
        impl = self._impls.get(c.id)
        override = getattr(impl, 'skill_sp_cost', None)
        return int(override) if override is not None else skill_sp_cost(c.id)

    def _decide(self, c: Character) -> Action:
        impl = self._impls.get(c.id)
        rotation = getattr(impl, 'rotation', None)
        policy = self.policy.get(c.id)
        if policy is not None:
            action = policy(self, c)
        elif rotation is not None:
            action = rotation(c, self)
        else:
            action = default_policy(self, c)
        if action is Action.SKILL:
            gate = getattr(impl, 'can_use_skill', None)
            if gate is not None and (not gate(c, self)):
                return Action.BASIC
            can_pay = getattr(impl, 'can_pay_skill', None)
            payable = can_pay(c, self) if can_pay is not None else self.sp.can_spend(self.skill_cost(c))
            if not payable:
                return Action.BASIC
        return action

    def _take_turn(self, c: Character) -> None:
        outer, self.acting = (self.acting, c)
        try:
            with self.attack_action(c):
                self._take_turn_inner(c)
        finally:
            self.acting = outer

    def _take_turn_inner(self, c: Character) -> None:
        impl = self._impls[c.id]
        idle = getattr(impl, 'skips_turn', None)
        if idle is not None and idle(c, self):
            self._log(c.name, '行動なし')
            return
        action = self._decide(c)
        if action is Action.BASIC:
            self._log(c.name, '通常攻撃')
            self.bus.emit(Event.ON_ACTION_START, source_id=c.id, actor=c, action=action)
            impl.basic(c, self)
            self.bus.emit(Event.ON_BASIC_USED, source_id=c.id, actor=c)
        elif action is Action.SKILL:
            self._log(c.name, '戦闘スキル')
            self.skill_uses[c.id] = self.skill_uses.get(c.id, 0) + 1
            self.bus.emit(Event.ON_ACTION_START, source_id=c.id, actor=c, action=action)
            impl.skill(c, self)
            if getattr(impl, 'skill_counts_as_skill', True):
                self.bus.emit(Event.ON_SKILL_USED, source_id=c.id, actor=c)
        else:
            raise ValueError(f'ターン中に選べない行動です: {action}')

    def _tick_effects(self, actor, kind: TurnKind, timing: TickTiming) -> None:
        for holder in [*self.team, *self.memosprites, *self.enemies, *self.timers]:
            for expired in holder.effects.tick(actor.id, kind, timing):
                self._drop_listeners(expired)
                self._log(holder.name, f'- {expired.label or expired.key} 終了')

    def _memo_turn(self, memo: Memosprite) -> None:
        if not memo.alive:
            self.dismiss_memosprite(memo)
            return
        impl = self._impls[memo.summoner.id]
        act = getattr(impl, 'memo_turn', None)
        if act is None:
            raise NotImplementedError(memo.summoner.name + ' の憶像 ' + memo.name + ' の行動が未実装です。 content 側に memo_turn を書いてください')
        self.bus.emit(Event.ON_MEMO_SKILL_START, source_id=memo.summoner.id, memo=memo)
        with self.attack_action(memo):
            act(memo, self)
        self.bus.emit(Event.ON_MEMO_SKILL, source_id=memo.summoner.id, memo=memo)

    def _aggro(self, unit) -> float:
        value = getattr(unit, 'aggro', None)
        if value is not None:
            return float(value)
        from ..data import loader
        stats = (loader.character(unit.id).get('stats') or {}).get('0') or {}
        return float(stats.get('base_aggro') or 100.0)

    def _enemy_attack(self, e: Enemy) -> None:
        units = [*self.team, *[m for m in self.memosprites if m.alive]]
        if not units:
            return
        target = max(units, key=lambda u: (self._aggro(u), -units.index(u)))
        self._log(e.name, f'単体攻撃 -> {target.name}')
        amount = min(target.max_hp * self.enemy_hit_ratio, max(0.0, target.hp - 1.0))
        if amount > 0:
            self.spend_hp(target, amount=amount)
        if self.enemy_hit_energy and isinstance(target, Character):
            self.gain_energy(target, ENERGY_ON_BEING_HIT)
        self.bus.emit(Event.ON_ENEMY_HIT, source_id=getattr(target, 'id', None), target=target, enemy=e)

    def _enemy_turn(self, e: Enemy) -> None:
        self._tick_dots(e)
        self._recover_toughness(e)
        if self.enemy_attacks:
            self._enemy_attack(e)
            return
        if e.behavior is EnemyBehavior.PASSIVE or e.has_attacked:
            self._log(e.name, '行動なし')
            return
        if self.queue.cycle < e.behavior_at_cycle:
            self._log(e.name, '行動なし')
            return
        e.has_attacked = True
        targets = self.team if e.behavior is EnemyBehavior.AOE else self.team[:1]
        kind = '全体攻撃' if e.behavior is EnemyBehavior.AOE else '単体攻撃'
        self._log(e.name, kind)
        for t in targets:
            self.gain_energy(t, ENERGY_ON_BEING_HIT)

    def run(self) -> BattleResult:
        budget = av_budget(self.max_cycles)
        while True:
            actor, delta = self.queue.peek()
            if self.queue.total_av + delta > budget:
                break
            if not self.alive_enemies:
                break
            self.queue.step()
            self._turn_no += 1
            self.turn_actors[self._turn_no] = (actor.name, self.queue.total_av)
            kind = TurnKind.NORMAL
            self.bus.reset_turn_counters()
            self.bus.emit(Event.TURN_START, source_id=actor.id, actor=actor, kind=kind)
            self._tick_effects(actor, kind, TickTiming.OWNER_TURN_START)
            if isinstance(actor, Character):
                hook = getattr(self._impls[actor.id], 'on_turn_start', None)
                if hook is not None:
                    hook(actor, self)
            self._use_ultimates()
            if isinstance(actor, Enemy):
                if actor.alive:
                    self._enemy_turn(actor)
            elif isinstance(actor, Memosprite):
                self._memo_turn(actor)
            elif isinstance(actor, Countdown):
                actor.on_turn()
            else:
                self._take_turn(actor)
            self._use_ultimates()
            self._tick_effects(actor, kind, TickTiming.OWNER_TURN_END)
            self.bus.emit(Event.TURN_END, source_id=actor.id, actor=actor, kind=kind)
        total_av = self.queue.total_av
        return BattleResult(total_damage=self.total_damage, total_av=total_av, cycles=cycles_elapsed(total_av), sp_balance=self.sp.balance, sp_final=self.sp.current, damage_by_character=dict(self.damage_by_character), damage_by_source=dict(self.damage_by_source), log=list(self.log), av_budget=budget)
Policy = Callable[['Battle', Character], Action]

def default_policy(battle: Battle, c: Character) -> Action:
    return Action.SKILL if battle.sp.can_spend(battle.skill_cost(c)) else Action.BASIC

def basic_only(battle: Battle, c: Character) -> Action:
    return Action.BASIC

def skill_when_sp_at_least(n: int):

    def policy(battle: Battle, c: Character) -> Action:
        return Action.SKILL if battle.sp.current >= n else Action.BASIC
    return policy
