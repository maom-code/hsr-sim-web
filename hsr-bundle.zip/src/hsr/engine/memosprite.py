from __future__ import annotations
from dataclasses import dataclass, field
from ..model.enums import Element
from ..model.stats import StatKey, StatSheet
from .effects import EffectContainer
OVERRIDDEN_STATS = (StatKey.HP, StatKey.SPD)

@dataclass(frozen=True)
class MemospriteSpec:
    name: str
    hp_base: float = 0.0
    hp_ratio: float = 0.0
    hp_from: StatKey = StatKey.HP
    spd_base: float = 0.0
    spd_ratio: float = 0.0
    spd_from: StatKey = StatKey.SPD
    aggro: float = 100.0
    acts_immediately: bool = False

    def initial_hp(self, summoner_stats: StatSheet) -> float:
        return self.hp_base + summoner_stats[self.hp_from] * self.hp_ratio

    def initial_speed(self, summoner_stats: StatSheet) -> float:
        return self.spd_base + summoner_stats[self.spd_from] * self.spd_ratio

@dataclass
class Memosprite:
    summoner: 'object'
    name: str
    element: Element
    level: int
    spd: float
    aggro: float = 100.0
    hp: float = 0.0
    effects: EffectContainer = field(default_factory=EffectContainer)
    base: StatSheet = field(default_factory=StatSheet)
    id: str = ''
    hp_white: float = 0.0
    hp_bonus: float = 0.0

    def __post_init__(self) -> None:
        if not self.id:
            self.id = f'memo.{getattr(self.summoner, 'id', '?')}'
        self.effects.holder_id = self.id
        if not self.base.values:
            self.base = StatSheet.of(spd=self.spd)
        if not self.hp_white and (not self.hp_bonus):
            self.hp_bonus = self.base[StatKey.HP]
        if self.hp == 0.0:
            self.hp = self.max_hp

    @property
    def max_hp(self) -> float:
        buffs = self.effects.total()
        return self.hp_white * (1.0 + buffs[StatKey.HP_PCT]) + self.hp_bonus + buffs[StatKey.HP]

    def speed(self) -> float:
        return self.stats[StatKey.SPD]

    @property
    def on_action_bar(self) -> bool:
        return self.spd > 0

    @property
    def stats(self) -> StatSheet:
        buffs = self.effects.total()
        out = self.base.merged(buffs) if buffs.values else StatSheet(dict(self.base.values))
        for flat, pct in ((StatKey.ATK, StatKey.ATK_PCT), (StatKey.DEF, StatKey.DEF_PCT), (StatKey.SPD, StatKey.SPD_PCT)):
            out[flat] = self.base[flat] * (1.0 + buffs[pct]) + buffs[flat]
            out.values.pop(pct, None)
        out[StatKey.HP] = self.max_hp
        out.values.pop(StatKey.HP_PCT, None)
        return out

    @property
    def attributed_to(self):
        return self.summoner

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def take_hp_cost(self, amount: float) -> float:
        dealt = min(amount, self.hp)
        self.hp -= dealt
        return dealt

    def spend_hp(self, *, ratio: float=0.0, amount: float=0.0) -> float:
        return self.take_hp_cost(self.hp * ratio + amount)

    def heal(self, amount: float) -> None:
        self.hp = min(self.hp + amount, self.max_hp)

def spec_from_curated(data: dict, ref_skill: dict | None, level: int) -> MemospriteSpec:
    from ..content.base import params_at
    params = params_at(ref_skill, level) if ref_skill else []

    def resolve(entry: dict, key: str) -> float:
        ref = entry.get(f'{key}_ref')
        if ref is not None:
            try:
                return params[ref - 1]
            except (IndexError, TypeError):
                return 0.0
        return float(entry.get(key) or 0.0)
    hp = data.get('hp') or {}
    spd = data.get('speed') or {}
    return MemospriteSpec(name=data.get('name') or '記憶の精霊', hp_base=resolve(hp, 'base'), hp_ratio=resolve(hp, 'ratio'), spd_base=resolve(spd, 'base'), spd_ratio=resolve(spd, 'ratio'), aggro=float(data.get('aggro') or 100.0))
