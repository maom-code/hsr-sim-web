from __future__ import annotations
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Protocol, runtime_checkable
FIRST_CYCLE_AV = 150.0
CYCLE_AV = 100.0

@runtime_checkable
class Actor(Protocol):
    id: str
    name: str

    def speed(self) -> float:
        ...

class TurnKind(StrEnum):
    NORMAL = 'normal'
    EXTRA = 'extra'

def base_action_value(speed: float) -> float:
    if speed <= 0:
        raise ValueError(f'速度が 0 以下です: {speed}')
    return 10000.0 / speed

def cycle_of(total_av: float) -> int:
    if total_av < FIRST_CYCLE_AV:
        return 1
    return 2 + int((total_av - FIRST_CYCLE_AV) // CYCLE_AV)

def cycles_elapsed(total_av: float) -> float:
    if total_av <= FIRST_CYCLE_AV:
        return total_av / FIRST_CYCLE_AV
    return 1.0 + (total_av - FIRST_CYCLE_AV) / CYCLE_AV

def av_budget(cycles: int) -> float:
    return FIRST_CYCLE_AV + CYCLE_AV * (cycles - 1)

@dataclass
class Slot:
    actor: Actor
    av: float
    order: int
    priority: int = 0

def _sort_key(av: float, priority: int, order: int) -> tuple[float, int, int]:
    return (av, -priority, order)

@dataclass
class ActionQueue:
    slots: list[Slot] = field(default_factory=list)
    total_av: float = 0.0
    _priority_seq: int = 0

    def add(self, actor: Actor, order: int, initial_av: float | None=None) -> None:
        av = base_action_value(actor.speed()) if initial_av is None else initial_av
        self.slots.append(Slot(actor, av, order))

    def remove(self, actor: Actor) -> None:
        self.slots = [s for s in self.slots if s.actor is not actor]

    def slot_of(self, actor: Actor) -> Slot:
        for s in self.slots:
            if s.actor is actor:
                return s
        raise KeyError(f'キューにいません: {actor.name}')

    def peek(self) -> tuple[Actor, float]:
        if not self.slots:
            raise RuntimeError('キューが空です')
        nxt = min(self.slots, key=lambda s: _sort_key(s.av, s.priority, s.order))
        return (nxt.actor, nxt.av)

    def step(self) -> Actor:
        nxt = min(self.slots, key=lambda s: _sort_key(s.av, s.priority, s.order))
        delta = nxt.av
        for s in self.slots:
            s.av -= delta
        self.total_av += delta
        nxt.av = base_action_value(nxt.actor.speed())
        nxt.priority = 0
        return nxt.actor

    def advance_forward(self, actor: Actor, ratio: float) -> None:
        slot = self.slot_of(actor)
        slot.av = max(0.0, slot.av - base_action_value(actor.speed()) * ratio)
        if slot.av == 0.0 and ratio > 0:
            self._priority_seq += 1
            slot.priority = self._priority_seq

    def act_next(self, actor: Actor) -> None:
        self.slot_of(actor).av = 0.0

    def delay(self, actor: Actor, ratio: float) -> None:
        slot = self.slot_of(actor)
        slot.av += base_action_value(actor.speed()) * ratio

    @property
    def cycle(self) -> int:
        return cycle_of(self.total_av)

    def order_preview(self, n: int=8) -> list[tuple[str, float]]:
        sim = [(s.av, s.priority, s.order, s.actor) for s in self.slots]
        out: list[tuple[str, float]] = []
        elapsed = 0.0
        for _ in range(n):
            av, _pri, _order, actor = min(sim, key=lambda x: _sort_key(x[0], x[1], x[2]))
            elapsed += av
            out.append((actor.name, self.total_av + elapsed))
            sim = [(a - av, pr, o, ac) for a, pr, o, ac in sim]
            sim = [(base_action_value(actor.speed()), 0, o, ac) if ac is actor else (a, pr, o, ac) for a, pr, o, ac in sim]
        return out
