from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol
ENERGY_ON_BEING_HIT = 10.0

class ResourcePool(Protocol):

    def gain(self, amount: float) -> None:
        ...

    def is_ready(self) -> bool:
        ...

    def consume(self) -> None:
        ...

    def describe(self) -> str:
        ...
INITIAL_ENERGY_RATIO = 0.5

@dataclass
class EnergyPool:
    maximum: float
    current: float | None = None
    regen: float = 0.0
    stock: int = 1

    def __post_init__(self) -> None:
        if self.current is None:
            self.current = self.maximum * INITIAL_ENERGY_RATIO

    def gain(self, amount: float, *, apply_regen: bool=True) -> None:
        if apply_regen:
            amount *= 1.0 + self.regen
        self.current = min(float(self.current) + amount, self.cap())

    def cap(self) -> float:
        return self.maximum * max(1, int(self.stock))

    def is_ready(self) -> bool:
        return float(self.current) >= self.maximum

    def consume(self) -> None:
        self.current = max(0.0, float(self.current) - self.maximum) if int(self.stock) > 1 else 0.0

    def set_stock(self, n: int) -> None:
        self.stock = max(1, int(n))
        self.current = min(float(self.current), self.cap())

    def describe(self) -> str:
        return f'{float(self.current):.0f}/{self.maximum:.0f}'

@dataclass
class NoUltimate:

    def gain(self, amount: float, *, apply_regen: bool=True) -> None:
        return

    def is_ready(self) -> bool:
        return False

    def consume(self) -> None:
        return

    def describe(self) -> str:
        return '-'

@dataclass
class SkillPoints:
    maximum: int = 5
    current: int = 3
    spent: int = 0
    gained: int = 0

    def can_spend(self, n: int) -> bool:
        return self.current >= n

    def spend(self, n: int) -> None:
        if not self.can_spend(n):
            raise ValueError(f'SP が足りません (残り {self.current}, 必要 {n})')
        self.current -= n
        self.spent += n

    def gain(self, n: int) -> None:
        room = self.maximum - self.current
        self.current += min(n, room)
        self.gained += min(n, room)

    @property
    def balance(self) -> int:
        return self.gained - self.spent

@dataclass
class Counter:
    name: str
    current: float = 0.0
    maximum: float | None = None
    bonus_per_gain: float = 0.0
    total_gained: float = 0.0

    def gain(self, amount: float) -> float:
        if amount <= 0:
            return 0.0
        amount += self.bonus_per_gain
        before = self.current
        self.current += amount
        if self.maximum is not None:
            self.current = min(self.current, self.maximum)
        gained = self.current - before
        self.total_gained += gained
        return gained

    def spend(self, amount: float | None=None) -> float:
        take = self.current if amount is None else min(amount, self.current)
        self.current -= take
        return take

    def has(self, amount: float) -> bool:
        return self.current >= amount

    def describe(self) -> str:
        cap = f'/{self.maximum:.0f}' if self.maximum is not None else ''
        return f'{self.name} {self.current:.0f}{cap}'

@dataclass
class CounterPool:
    counter: Counter
    threshold: float | None = None
    cost: float | None = None

    def gain(self, amount: float, *, apply_regen: bool=True) -> None:
        return

    def _need(self) -> float | None:
        return self.threshold if self.threshold is not None else self.counter.maximum

    def is_ready(self) -> bool:
        need = self._need()
        return need is not None and self.counter.current >= need

    def consume(self) -> None:
        self.counter.spend(self.cost if self.cost is not None else self._need())

    def describe(self) -> str:
        return self.counter.describe()
