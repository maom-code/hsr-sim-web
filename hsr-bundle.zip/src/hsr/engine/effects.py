from __future__ import annotations
from dataclasses import dataclass, field
from enum import StrEnum
from ..model.stats import StatKey, StatSheet
from .queue import TurnKind

class Stacking(StrEnum):
    STACK = 'stack'
    REFRESH = 'refresh'
    UNIQUE = 'unique'

class TickTiming(StrEnum):
    OWNER_TURN_START = 'owner_turn_start'
    OWNER_TURN_END = 'owner_turn_end'

@dataclass
class Duration:
    turns: int
    tick_on: TickTiming = TickTiming.OWNER_TURN_START
    counts_extra_turns: bool = False
    tick_owner_id: str | None = None

    def ticks_for(self, actor_id: str, holder_id: str, kind: TurnKind) -> bool:
        if kind is TurnKind.EXTRA and (not self.counts_extra_turns):
            return False
        return actor_id == (self.tick_owner_id or holder_id)

@dataclass
class Effect:
    key: str
    stats: StatSheet = field(default_factory=StatSheet)
    duration: Duration | None = None
    stacking: Stacking = Stacking.REFRESH
    max_stacks: int = 1
    stacks: int = 1
    multiplier: float = 1.0
    pre_battle: bool = False
    source_id: str = ''
    label: str = ''
    value: float = 0.0
    dot_base: float = 0.0
    dot_element: object | None = None
    listener_ids: list[int] = field(default_factory=list)

    def contribution(self) -> StatSheet:
        if self.stacks == 1:
            return self.stats
        out = StatSheet()
        for k, v in self.stats.values.items():
            out.add(k, v * self.stacks)
        return out

@dataclass
class EffectContainer:
    holder_id: str = ''
    effects: list[Effect] = field(default_factory=list)

    def __iter__(self):
        return iter(self.effects)

    def __len__(self) -> int:
        return len(self.effects)

    def get(self, key: str) -> Effect | None:
        for e in self.effects:
            if e.key == key:
                return e
        return None

    def has(self, key: str) -> bool:
        return self.get(key) is not None

    def apply(self, effect: Effect) -> Effect | None:
        existing = self.get(effect.key)
        if existing is None:
            self.effects.append(effect)
            return effect
        match effect.stacking:
            case Stacking.UNIQUE:
                return None
            case Stacking.STACK:
                existing.stacks = min(existing.stacks + effect.stacks, existing.max_stacks)
                existing.duration = effect.duration
                return existing
            case _:
                existing.stats = effect.stats
                existing.duration = effect.duration
                existing.stacks = effect.stacks
                existing.source_id = effect.source_id
                existing.pre_battle = effect.pre_battle
                return existing

    def remove(self, key: str) -> Effect | None:
        e = self.get(key)
        if e is not None:
            self.effects.remove(e)
        return e

    def total(self, *, only_pre_battle: bool=False) -> StatSheet:
        out = StatSheet()
        for e in self.effects:
            if only_pre_battle and (not e.pre_battle):
                continue
            for k, v in e.contribution().values.items():
                out.add(k, v)
        return out

    def damage_multiplier(self) -> float:
        total = 1.0
        for e in self.effects:
            if e.multiplier != 1.0:
                total *= e.multiplier ** e.stacks
        return total

    def tick(self, actor_id: str, kind: TurnKind, timing: TickTiming) -> list[Effect]:
        expired: list[Effect] = []
        for e in list(self.effects):
            d = e.duration
            if d is None or d.tick_on is not timing:
                continue
            if not d.ticks_for(actor_id, self.holder_id, kind):
                continue
            d.turns -= 1
            if d.turns <= 0:
                self.effects.remove(e)
                expired.append(e)
        return expired

    def describe(self) -> str:
        if not self.effects:
            return '-'
        parts = []
        for e in self.effects:
            turns = f'{e.duration.turns}T' if e.duration else '∞'
            stacks = f'×{e.stacks}' if e.stacks > 1 else ''
            parts.append(f'{e.label or e.key}{stacks}({turns})')
        return ' '.join(parts)

def buff(key: str, *, label: str='', turns: int | None=None, tick_owner_id: str | None=None, stacking: Stacking=Stacking.REFRESH, max_stacks: int=1, source_id: str='', **stats: float) -> Effect:
    return Effect(key=key, label=label, stats=StatSheet.of(**stats), duration=None if turns is None else Duration(turns=turns, tick_owner_id=tick_owner_id), stacking=stacking, max_stacks=max_stacks, source_id=source_id)
__all__ = ['Duration', 'Effect', 'EffectContainer', 'StatKey', 'Stacking', 'TickTiming', 'buff']
