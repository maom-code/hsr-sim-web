from __future__ import annotations
from collections.abc import Callable
ROTATION_LABELS: dict[str, str] = {'auto': '既定', 'basic': '通常攻撃のみ', 'skill': 'SP があればスキル', 'sp2': 'SP が 2 以上ならスキル', 'sp3': 'SP が 3 以上ならスキル', 'refresh': 'バフが切れるならスキル', 'first': '最初だけスキル'}
ULT_LABELS: dict[str, str] = {'asap': '溜まり次第すぐ', 'hold': 'バフが切れるときに撃つ'}

def available_ult_modes(impl) -> list[str]:
    modes = ['asap']
    if getattr(impl, 'ult_expiring', None) is not None:
        modes.append('hold')
    return modes

def ult_policy_for(mode: str, impl) -> Callable | None:
    if mode in (None, '', 'asap'):
        return None
    if mode == 'hold':
        if getattr(impl, 'ult_expiring', None) is None:
            raise ValueError('このキャラは必殺技の温存を選べません')
        return lambda battle, c: battle.impl_of(c).ult_expiring(c, battle)
    raise ValueError(f'知らない必殺技のモードです: {mode}')

def available_modes(impl) -> list[str]:
    modes = ['auto', 'basic', 'skill', 'sp2', 'sp3']
    if getattr(impl, 'buff_expiring', None) is not None:
        modes.append('refresh')
    modes.append('first')
    return modes

def auto_label(impl) -> str:
    return getattr(impl, 'rotation_label', None) or ROTATION_LABELS['skill']

def policy_for(mode: str, impl) -> Callable | None:
    from .battle import Action
    if mode in (None, '', 'auto'):
        return None
    if mode == 'basic':
        return lambda battle, c: Action.BASIC
    if mode == 'skill':
        return lambda battle, c: Action.SKILL
    if mode in ('sp2', 'sp3'):
        from .battle import skill_when_sp_at_least
        return skill_when_sp_at_least(int(mode[2:]))
    if mode == 'refresh':
        if getattr(impl, 'buff_expiring', None) is None:
            raise ValueError('このキャラは「バフが切れるならスキル」を選べません')
        return lambda battle, c: Action.SKILL if battle.impl_of(c).buff_expiring(c, battle) else Action.BASIC
    if mode == 'first':
        return lambda battle, c: Action.SKILL if battle.skill_uses.get(c.id, 0) == 0 else Action.BASIC
    raise ValueError(f'知らないローテです: {mode}')
