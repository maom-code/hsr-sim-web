from __future__ import annotations
from ..model.enums import Element
from ..model.stats import StatSheet
from .effects import Duration, Effect, Stacking
KEY = 'break.effect'
IGNORE_WEAKNESS_KEY = 'break.ignore_weakness'
DOT_RATIO: dict[Element, float] = {Element.FIRE: 1.0, Element.LIGHTNING: 2.0, Element.WIND: 1.0, Element.QUANTUM: 0.6, Element.ICE: 1.0}
LABELS: dict[Element, str] = {Element.PHYSICAL: '裂創', Element.FIRE: '燃焼', Element.LIGHTNING: '感電', Element.WIND: '風化', Element.QUANTUM: '纏縛', Element.ICE: '凍結', Element.IMAGINARY: '禁錮'}
MAX_STACKS: dict[Element, int] = {Element.WIND: 5, Element.QUANTUM: 5}
DELAY: dict[Element, float] = {Element.QUANTUM: 0.2, Element.ICE: 0.5, Element.IMAGINARY: 0.3}
IMPRISON_SPD_DOWN = 0.1
BLEED_HP_RATIO = 0.07
BLEED_CAP_RATIO = 2.0
TURNS = 2

def apply(battle, source, target, element: Element, break_base: float) -> None:
    label = LABELS.get(element)
    if label is None:
        return
    if element is Element.PHYSICAL:
        dot = min(target.max_hp * BLEED_HP_RATIO, break_base * BLEED_CAP_RATIO)
    else:
        dot = break_base * DOT_RATIO.get(element, 0.0)
    stats = StatSheet()
    if element is Element.IMAGINARY:
        stats = StatSheet.of(spd_pct=-IMPRISON_SPD_DOWN)
    battle.apply_effect(target, Effect(key=f'{KEY}.{element.value}', label=label, stats=stats, dot_base=dot, dot_element=element, duration=Duration(turns=TURNS, tick_owner_id=target.id), stacking=Stacking.STACK if element in MAX_STACKS else Stacking.REFRESH, max_stacks=MAX_STACKS.get(element, 1), source_id=getattr(source, 'id', '')))
    delay = DELAY.get(element)
    if delay:
        battle.delay_action(target, delay)
