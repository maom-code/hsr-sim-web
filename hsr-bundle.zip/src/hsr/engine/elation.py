from __future__ import annotations
from dataclasses import dataclass, field
from ..model.enums import Path
from .effects import Duration, Effect, Stacking
from .events import Event
from .timer import Countdown
NOTES = '爆笑ネタ'
REWARD_PREFIX = 'elation.reward.'
REWARD_TURNS = 2
INITIAL_REWARD = 20.0
INITIAL_NOTES_PER_MEMBER = 1.0
AHA_BASE_SPEED = 80.0
AHA_SPEED_WEIGHTS = (0.2, 0.1, 0.05, 0.025)

def elation_members(battle) -> list:
    return sorted((c for c in battle.team if c.built.path is Path.ELATION), key=lambda c: c.id)

def aha_speed(battle) -> float:
    speeds = sorted((c.speed() for c in elation_members(battle)), reverse=True)
    total = AHA_BASE_SPEED
    for weight, spd in zip(AHA_SPEED_WEIGHTS, speeds, strict=False):
        total += spd * weight
    return total

def reward_total(who) -> float:
    return sum((e.value for e in who.effects if e.key.startswith(REWARD_PREFIX)))

@dataclass
class Aha:
    battle: object
    timer: Countdown | None = None
    rounds: int = 0
    skill_multiplier: float = 1.0
    reward_turn_bonus: dict[str, int] = field(default_factory=dict)
    reward_permanent: set[str] = field(default_factory=set)
    reward_cap: dict[str, float] = field(default_factory=dict)
    in_aha_time: bool = False
    _speed_bonus: float = field(default=0.0, init=False)

    def start(self) -> None:
        battle = self.battle
        members = elation_members(battle)
        if not members:
            return
        battle.gain_shared(NOTES, INITIAL_NOTES_PER_MEMBER * len(members))
        for who in members:
            self.grant_reward(who, INITIAL_REWARD)
        self.timer = battle.add_countdown(Countdown(name='アッハ', spd=self.speed(), on_turn=lambda: self.aha_time()), order=len(battle.team))

    def speed(self) -> float:
        return aha_speed(self.battle) + self._speed_bonus

    def add_speed(self, amount: float) -> None:
        self._speed_bonus += amount
        if self.timer is not None:
            self.timer.spd = self.speed()

    def grant_reward(self, who, amount: float, *, key: str | None=None) -> float:
        cap = self.reward_cap.get(who.id)
        if cap is not None:
            amount = min(amount, cap - reward_total(who))
        if amount <= 0:
            return 0.0
        permanent = who.id in self.reward_permanent
        if key is None:
            key = f'{REWARD_PREFIX}{('held' if permanent else self.rounds)}'
        held = who.effects.get(key) if permanent else None
        if held is not None:
            held.value += amount
            held.label = f'爆笑の褒美 {held.value:.0f}'
            return amount
        duration = None if permanent else Duration(turns=REWARD_TURNS + self.reward_turn_bonus.get(who.id, 0), tick_owner_id=who.id)
        self.battle.apply_effect(who, Effect(key=key, label=f'爆笑の褒美 {amount:.0f}', value=amount, duration=duration, stacking=Stacking.UNIQUE, source_id='aha'))
        return amount

    def fire_elation_skill(self, who, notes: float) -> bool:
        battle = self.battle
        hook = getattr(battle.impl_of(who), 'elation_skill', None)
        if hook is None:
            return False
        with battle.attack_action(who):
            hook(who, battle, notes)
        battle.bus.emit(Event.ON_ELATION_SKILL, source_id=who.id, source=who, notes=notes)
        return True

    def has_elation_skill(self, who) -> bool:
        return getattr(self.battle.impl_of(who), 'elation_skill', None) is not None

    def aha_time(self, *, extra: bool=False, notes: float | None=None, multiplier: float=1.0) -> None:
        battle = self.battle
        members = elation_members(battle)
        if not members:
            return
        counted = battle.shared_value(NOTES) if notes is None else notes
        battle._log('アッハ', f'アッハタイム（爆笑ネタ {counted:.0f}）')
        self.skill_multiplier = multiplier
        self.in_aha_time = True
        try:
            for who in members:
                self.fire_elation_skill(who, counted)
        finally:
            self.skill_multiplier = 1.0
            self.in_aha_time = False
        self.rounds += 1
        for who in members:
            self.grant_reward(who, counted)
        if not extra:
            battle.spend_shared(NOTES)
            self._speed_bonus = 0.0
            if self.timer is not None:
                self.timer.spd = self.speed()
        battle.bus.emit(Event.ON_AHA_TIME_END, extra=extra, notes=counted)
