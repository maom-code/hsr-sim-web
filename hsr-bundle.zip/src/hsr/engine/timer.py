from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from .effects import EffectContainer

@dataclass
class Countdown:
    name: str
    spd: float
    on_turn: Callable[[], None]
    id: str = ''
    effects: EffectContainer = field(default_factory=EffectContainer)

    def __post_init__(self) -> None:
        if not self.id:
            self.id = f'timer.{self.name}'
        self.effects.holder_id = self.id

    def speed(self) -> float:
        return self.spd
